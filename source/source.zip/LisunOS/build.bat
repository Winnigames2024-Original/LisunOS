@echo off
setlocal enabledelayedexpansion
title LisunOS - sborka
cd /d "C:\Visual Studio Projects\LisunOS"

set "LOG=C:\Visual Studio Projects\LisunOS\build.log"
echo [LisunOS] start %DATE% %TIME%> "%LOG%"

rem ---------- poisk MSBuild ----------
set "MSBUILD="
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"

if exist "%VSWHERE%" (
  for /f "usebackq tokens=*" %%i in (`"%VSWHERE%" -latest -prerelease -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe 2^>nul`) do set "MSBUILD=%%i"
)

if not defined MSBUILD call :find "%ProgramFiles%\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%ProgramFiles%\Microsoft Visual Studio\18\Professional\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%ProgramFiles%\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\MSBuild\Current\Bin\MSBuild.exe"
if not defined MSBUILD call :find "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe"
if not defined MSBUILD call :find "%WINDIR%\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"

if not defined MSBUILD (
  echo [ERROR] MSBuild ne nayden>> "%LOG%"
  echo EXITCODE=9009>> "%LOG%"
  echo DONE>> "%LOG%"
  goto :end
)

echo [LisunOS] MSBuild: !MSBUILD!>> "%LOG%"

rem ---------- sborka Release ----------
"!MSBUILD!" "LisunOS\LisunOS.csproj" /t:Rebuild /p:Configuration=Release /p:Platform=AnyCPU /p:DebugType=none /p:DebugSymbols=false /v:minimal /nologo >> "%LOG%" 2>&1
set "CODE=!ERRORLEVEL!"

echo EXITCODE=!CODE!>> "%LOG%"

del /q "LisunOS\bin\Release\*.config" >nul 2>&1
del /q "LisunOS\bin\Release\*.pdb" >nul 2>&1
del /q "LisunOS\bin\Release\*.xml" >nul 2>&1

if exist "LisunOS\bin\Release\LisunOS.exe" (
  echo [LisunOS] exe sobran>> "%LOG%"
  dir /b /-c "LisunOS\bin\Release">> "%LOG%"
)

echo DONE>> "%LOG%"

:end
endlocal
exit

:find
if exist %1 set "MSBUILD=%~1"
goto :eof
