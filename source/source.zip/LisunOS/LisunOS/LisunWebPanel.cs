﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Веб-панель управления сайтом: файл panel.php в корне www
    /// и пароль входа в .panel.pass (наружу не отдаётся).
    /// Пароль хранится как sha256:&lt;соль&gt;:&lt;хеш&gt; — такой формат проверяет PHP.
    /// </summary>
    public static class LisunWebPanel
    {
        public const string PanelFileName = "panel.php";
        public const string PasswordFileName = ".panel.pass";

        public static string PanelPath(string rootDirectory)
        {
            return Path.Combine(rootDirectory, PanelFileName);
        }

        public static string PasswordPath(string rootDirectory)
        {
            return Path.Combine(rootDirectory, PasswordFileName);
        }

        public static bool PanelPresent(string rootDirectory)
        {
            return File.Exists(PanelPath(rootDirectory));
        }

        public static bool PasswordSet(string rootDirectory)
        {
            try
            {
                string path = PasswordPath(rootDirectory);
                if (!File.Exists(path)) return false;

                string[] parts = File.ReadAllText(path).Trim().Split(':');
                return parts.Length == 3 && parts[0] == "sha256" && parts[2].Length == 64;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Файлы панели
        // =====================================================================

        /// <summary>Создаёт panel.php, если его ещё нет. Правки пользователя не затираются.</summary>
        public static bool EnsureFiles(string rootDirectory)
        {
            try
            {
                if (!Directory.Exists(rootDirectory)) Directory.CreateDirectory(rootDirectory);

                // Панель работает через api.php — он должен существовать.
                LisunApiEndpoint.EnsureFiles(rootDirectory);

                string path = PanelPath(rootDirectory);
                if (File.Exists(path)) return false;

                File.WriteAllText(path, PanelContent(), new UTF8Encoding(false));
                LisunEngine.Log("[Panel] Создан " + PanelFileName + " в корне сайта.");
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Panel] [ОШИБКА] Создание панели: " + ex.Message);
                return false;
            }
        }

        // =====================================================================
        //  Пароль
        // =====================================================================

        /// <summary>Задаёт пароль панели. Возвращает false при ошибке записи.</summary>
        public static bool SetPassword(string rootDirectory, string password)
        {
            if (string.IsNullOrEmpty(password) || password.Length < 4) return false;

            try
            {
                byte[] saltBytes = new byte[16];
                using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider()) random.GetBytes(saltBytes);

                string salt = ToHex(saltBytes);
                string line = "sha256:" + salt + ":" + Hash(salt, password);

                if (!Directory.Exists(rootDirectory)) Directory.CreateDirectory(rootDirectory);
                File.WriteAllText(PasswordPath(rootDirectory), line, new UTF8Encoding(false));

                LisunEngine.Log("[Panel] Пароль веб-панели обновлён.");
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Panel] [ОШИБКА] Запись пароля: " + ex.Message);
                return false;
            }
        }

        /// <summary>Случайный пароль, который удобно прочитать и скопировать.</summary>
        public static string GeneratePassword()
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
            byte[] buffer = new byte[14];

            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider()) random.GetBytes(buffer);

            StringBuilder sb = new StringBuilder();
            foreach (byte value in buffer) sb.Append(alphabet[value % alphabet.Length]);
            return sb.ToString();
        }

        public static bool Verify(string rootDirectory, string password)
        {
            try
            {
                string path = PasswordPath(rootDirectory);
                if (!File.Exists(path)) return false;

                string[] parts = File.ReadAllText(path).Trim().Split(':');
                if (parts.Length != 3 || parts[0] != "sha256") return false;

                return string.Equals(parts[2], Hash(parts[1], password), StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public static bool ClearPassword(string rootDirectory)
        {
            try
            {
                string path = PasswordPath(rootDirectory);
                if (File.Exists(path)) File.Delete(path);
                return true;
            }
            catch { return false; }
        }

        /// <summary>sha256(соль + "|" + пароль) — ровно так же считает panel.php.</summary>
        private static string Hash(string salt, string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] data = Encoding.UTF8.GetBytes(salt + "|" + password);
                return ToHex(sha.ComputeHash(data));
            }
        }

        private static string ToHex(byte[] data)
        {
            StringBuilder sb = new StringBuilder(data.Length * 2);
            foreach (byte value in data) sb.Append(value.ToString("x2"));
            return sb.ToString();
        }

        // =====================================================================
        //  Содержимое panel.php
        // =====================================================================

        private static string PanelContent()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<?php");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  LisunOS Web Panel — управление сайтом и службой из браузера");
            sb.AppendLine("#");
            sb.AppendLine("#  Адрес:   http://localhost:<порт>/panel.php");
            sb.AppendLine("#  Пароль:  задаётся в панели «Сервер v2» → кнопка «Веб-панель»");
            sb.AppendLine("#           и хранится в файле .panel.pass (наружу не отдаётся).");
            sb.AppendLine("#");
            sb.AppendLine("#  Код ниже в защищённом блоке NOREMOVE: его строки нельзя удалить");
            sb.AppendLine("#  или изменить через редактор LisunOS, а сам файл — удалить.");
            sb.AppendLine("#  Свой код дописывайте ПОСЛЕ закрывающего маркера, в конце файла.");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("");
            sb.AppendLine("# ~~~NOREMOVE~");
            sb.AppendLine("@session_start();");
            sb.AppendLine("");
            sb.AppendLine("require_once __DIR__ . '/api.php';");
            sb.AppendLine("");
            sb.AppendLine("define('PANEL_VERSION', '1.0');");
            sb.AppendLine("define('PANEL_PASS_FILE', __DIR__ . DIRECTORY_SEPARATOR . '.panel.pass');");
            sb.AppendLine("define('PANEL_ROOT', __DIR__);");
            sb.AppendLine("");
            sb.AppendLine("# ---------- пароль ----------");
            sb.AppendLine("");
            sb.AppendLine("function panel_pass_hash($salt, $password)");
            sb.AppendLine("{");
            sb.AppendLine("    return hash('sha256', $salt . '|' . $password);");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_pass_stored()");
            sb.AppendLine("{");
            sb.AppendLine("    if (!is_file(PANEL_PASS_FILE)) return null;");
            sb.AppendLine("");
            sb.AppendLine("    $raw = trim((string)file_get_contents(PANEL_PASS_FILE));");
            sb.AppendLine("    $parts = explode(':', $raw);");
            sb.AppendLine("");
            sb.AppendLine("    if (count($parts) !== 3 || $parts[0] !== 'sha256') return null;");
            sb.AppendLine("    return array('salt' => $parts[1], 'hash' => $parts[2]);");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_pass_check($password)");
            sb.AppendLine("{");
            sb.AppendLine("    $stored = panel_pass_stored();");
            sb.AppendLine("    if ($stored === null) return false;");
            sb.AppendLine("");
            sb.AppendLine("    $computed = panel_pass_hash($stored['salt'], (string)$password);");
            sb.AppendLine("");
            sb.AppendLine("    return function_exists('hash_equals')");
            sb.AppendLine("        ? hash_equals($stored['hash'], $computed)");
            sb.AppendLine("        : ($stored['hash'] === $computed);");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_pass_save($password)");
            sb.AppendLine("{");
            sb.AppendLine("    $salt = bin2hex(panel_random(16));");
            sb.AppendLine("    $line = 'sha256:' . $salt . ':' . panel_pass_hash($salt, (string)$password);");
            sb.AppendLine("");
            sb.AppendLine("    return @file_put_contents(PANEL_PASS_FILE, $line) !== false;");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_random($bytes)");
            sb.AppendLine("{");
            sb.AppendLine("    if (function_exists('random_bytes')) return random_bytes($bytes);");
            sb.AppendLine("    if (function_exists('openssl_random_pseudo_bytes')) return openssl_random_pseudo_bytes($bytes);");
            sb.AppendLine("");
            sb.AppendLine("    $out = '';");
            sb.AppendLine("    for ($i = 0; $i < $bytes; $i++) $out .= chr(mt_rand(0, 255));");
            sb.AppendLine("    return $out;");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_logged_in()");
            sb.AppendLine("{");
            sb.AppendLine("    return isset($_SESSION['lisun_panel']) && $_SESSION['lisun_panel'] === true;");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_token()");
            sb.AppendLine("{");
            sb.AppendLine("    if (!isset($_SESSION['lisun_token'])) $_SESSION['lisun_token'] = bin2hex(panel_random(16));");
            sb.AppendLine("    return $_SESSION['lisun_token'];");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_token_ok()");
            sb.AppendLine("{");
            sb.AppendLine("    $given = isset($_POST['token']) ? (string)$_POST['token'] : '';");
            sb.AppendLine("    return $given !== '' && isset($_SESSION['lisun_token']) && $given === $_SESSION['lisun_token'];");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("# ---------- утилиты ----------");
            sb.AppendLine("");
            sb.AppendLine("function panel_escape($value)");
            sb.AppendLine("{");
            sb.AppendLine("    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_safe_path($relative)");
            sb.AppendLine("{");
            sb.AppendLine("    $relative = str_replace('\\\\', '/', (string)$relative);");
            sb.AppendLine("    if ($relative === '' || $relative === '/') return PANEL_ROOT;");
            sb.AppendLine("    if (strpos($relative, '..') !== false) return PANEL_ROOT;");
            sb.AppendLine("");
            sb.AppendLine("    $full = PANEL_ROOT . DIRECTORY_SEPARATOR . ltrim($relative, '/');");
            sb.AppendLine("    $real = realpath($full);");
            sb.AppendLine("    $root = realpath(PANEL_ROOT);");
            sb.AppendLine("");
            sb.AppendLine("    if ($real === false || strpos($real, $root) !== 0) return PANEL_ROOT;");
            sb.AppendLine("    return $real;");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_relative($path)");
            sb.AppendLine("{");
            sb.AppendLine("    $root = realpath(PANEL_ROOT);");
            sb.AppendLine("    $real = realpath($path);");
            sb.AppendLine("    if ($real === false) $real = $path;");
            sb.AppendLine("    return str_replace('\\\\', '/', ltrim(str_replace($root, '', $real), '\\\\/'));");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_size($bytes)");
            sb.AppendLine("{");
            sb.AppendLine("    if ($bytes === null) return '';");
            sb.AppendLine("    $units = array('Б', 'КБ', 'МБ', 'ГБ');");
            sb.AppendLine("    $i = 0;");
            sb.AppendLine("    while ($bytes >= 1024 && $i < 3) { $bytes /= 1024; $i++; }");
            sb.AppendLine("    return round($bytes, $i === 0 ? 0 : 1) . ' ' . $units[$i];");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("function panel_api($action, $name = '', $code = '', $target = '')");
            sb.AppendLine("{");
            sb.AppendLine("    return lisun_handle(array(");
            sb.AppendLine("        'key'    => ServerAPI_Key(),");
            sb.AppendLine("        'action' => $action,");
            sb.AppendLine("        'name'   => $name,");
            sb.AppendLine("        'code'   => $code,");
            sb.AppendLine("        'target' => $target");
            sb.AppendLine("    ), false);");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("# ---------- обработка запросов ----------");
            sb.AppendLine("");
            sb.AppendLine("$notice = null;");
            sb.AppendLine("$error  = null;");
            sb.AppendLine("");
            sb.AppendLine("if (isset($_GET['logout'])) {");
            sb.AppendLine("    $_SESSION = array();");
            sb.AppendLine("    @session_destroy();");
            sb.AppendLine("    header('Location: panel.php');");
            sb.AppendLine("    exit;");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("if (isset($_POST['do']) && $_POST['do'] === 'login') {");
            sb.AppendLine("    $attempt = isset($_POST['password']) ? (string)$_POST['password'] : '';");
            sb.AppendLine("");
            sb.AppendLine("    if (panel_pass_stored() === null) {");
            sb.AppendLine("        $error = 'Пароль панели не задан. Откройте «Сервер v2» → «Веб-панель» и задайте его.';");
            sb.AppendLine("    } elseif (panel_pass_check($attempt)) {");
            sb.AppendLine("        $_SESSION['lisun_panel'] = true;");
            sb.AppendLine("        panel_token();");
            sb.AppendLine("        header('Location: panel.php');");
            sb.AppendLine("        exit;");
            sb.AppendLine("    } else {");
            sb.AppendLine("        sleep(1);");
            sb.AppendLine("        $error = 'Неверный пароль.';");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("if (panel_logged_in() && isset($_POST['do']) && $_POST['do'] !== 'login') {");
            sb.AppendLine("    if (!panel_token_ok()) {");
            sb.AppendLine("        $error = 'Неверный токен запроса — обновите страницу.';");
            sb.AppendLine("    } else {");
            sb.AppendLine("        $do     = (string)$_POST['do'];");
            sb.AppendLine("        $name   = isset($_POST['name'])   ? (string)$_POST['name']   : '';");
            sb.AppendLine("        $code   = isset($_POST['code'])   ? (string)$_POST['code']   : '';");
            sb.AppendLine("        $target = isset($_POST['target']) ? (string)$_POST['target'] : '';");
            sb.AppendLine("");
            sb.AppendLine("        if ($do === 'change_password') {");
            sb.AppendLine("            if (strlen($code) < 4) $error = 'Пароль короче четырёх символов.';");
            sb.AppendLine("            elseif (!panel_pass_save($code)) $error = 'Не удалось записать файл пароля.';");
            sb.AppendLine("            else $notice = 'Пароль панели изменён.';");
            sb.AppendLine("        } else {");
            sb.AppendLine("            $map = array(");
            sb.AppendLine("                'create_file'   => 'create_file',");
            sb.AppendLine("                'create_folder' => 'create_folder',");
            sb.AppendLine("                'save_file'     => 'edit_file',");
            sb.AppendLine("                'delete_file'   => 'delete_file',");
            sb.AppendLine("                'delete_folder' => 'delete_folder',");
            sb.AppendLine("                'rename'        => 'move_file'");
            sb.AppendLine("            );");
            sb.AppendLine("");
            sb.AppendLine("            if (isset($map[$do])) {");
            sb.AppendLine("                $result = panel_api($map[$do], $name, $code, $target);");
            sb.AppendLine("");
            sb.AppendLine("                if (!empty($result['ok'])) $notice = 'Готово: ' . $do . ' → ' . panel_escape($name);");
            sb.AppendLine("                else $error = isset($result['error']) ? (string)$result['error'] : 'ошибка операции';");
            sb.AppendLine("            } else {");
            sb.AppendLine("                $error = 'Неизвестное действие панели.';");
            sb.AppendLine("            }");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("$currentRelative = isset($_GET['p']) ? (string)$_GET['p'] : '';");
            sb.AppendLine("$currentPath     = panel_safe_path($currentRelative);");
            sb.AppendLine("$currentRelative = panel_relative($currentPath);");
            sb.AppendLine("");
            sb.AppendLine("$editRelative = isset($_GET['edit']) ? (string)$_GET['edit'] : '';");
            sb.AppendLine("$editPath     = $editRelative === '' ? null : panel_safe_path($editRelative);");
            sb.AppendLine("$editText     = ($editPath !== null && is_file($editPath)) ? (string)file_get_contents($editPath) : null;");
            sb.AppendLine("");
            sb.AppendLine("header('Content-Type: text/html; charset=utf-8');");
            sb.AppendLine("?>");
            sb.AppendLine("<!doctype html>");
            sb.AppendLine("<html lang=\"ru\">");
            sb.AppendLine("<head>");
            sb.AppendLine("<meta charset=\"utf-8\">");
            sb.AppendLine("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            sb.AppendLine("<title>LisunOS — панель управления</title>");
            sb.AppendLine("<style>");
            sb.AppendLine(":root { --bg:#0d1117; --surface:#161b22; --alt:#1e242e; --line:#30363d;");
            sb.AppendLine("        --text:#ced6e0; --dim:#808995; --accent:#58a6ff; --ok:#56d364;");
            sb.AppendLine("        --warn:#e2b041; --bad:#f86159; --cyan:#57d0d6; }");
            sb.AppendLine("* { box-sizing:border-box; }");
            sb.AppendLine("body { margin:0; background:var(--bg); color:var(--text);");
            sb.AppendLine("       font:15px/1.6 \"Segoe UI\",system-ui,sans-serif; }");
            sb.AppendLine("a { color:var(--accent); text-decoration:none; }");
            sb.AppendLine("a:hover { text-decoration:underline; }");
            sb.AppendLine("header { background:var(--surface); border-bottom:1px solid var(--line);");
            sb.AppendLine("         padding:18px 28px; display:flex; align-items:center; gap:18px; flex-wrap:wrap; }");
            sb.AppendLine("header h1 { margin:0; font-size:19px; color:var(--accent); }");
            sb.AppendLine("header .sp { flex:1; }");
            sb.AppendLine(".badge { font:13px/1 ui-monospace,Consolas,monospace; color:var(--dim);");
            sb.AppendLine("         border:1px solid var(--line); border-radius:20px; padding:7px 14px; }");
            sb.AppendLine("main { max-width:1120px; margin:0 auto; padding:28px; }");
            sb.AppendLine(".card { background:var(--surface); border:1px solid var(--line);");
            sb.AppendLine("        border-radius:12px; padding:22px; margin-bottom:22px; }");
            sb.AppendLine(".card h2 { margin:0 0 16px; font-size:14px; letter-spacing:.08em;");
            sb.AppendLine("           text-transform:uppercase; color:var(--dim); font-weight:600; }");
            sb.AppendLine("table { width:100%; border-collapse:collapse; font-size:14px; }");
            sb.AppendLine("th { text-align:left; color:var(--dim); font-weight:600; font-size:12px;");
            sb.AppendLine("     letter-spacing:.06em; text-transform:uppercase; padding:0 10px 10px; }");
            sb.AppendLine("td { padding:9px 10px; border-top:1px solid var(--line); }");
            sb.AppendLine("td.r, th.r { text-align:right; }");
            sb.AppendLine("input, textarea, button, select {");
            sb.AppendLine("    font:14px/1.4 \"Segoe UI\",system-ui,sans-serif; border-radius:8px;");
            sb.AppendLine("    border:1px solid var(--line); background:var(--bg); color:var(--text); padding:9px 12px; }");
            sb.AppendLine("textarea { width:100%; min-height:420px; font:14px/1.55 ui-monospace,Consolas,monospace;");
            sb.AppendLine("           background:#0b0f14; resize:vertical; }");
            sb.AppendLine("button { background:var(--alt); cursor:pointer; }");
            sb.AppendLine("button:hover { background:#29313c; }");
            sb.AppendLine("button.primary { background:#1f3c5c; color:#fff; border-color:#2b5783; }");
            sb.AppendLine("button.danger { background:#52201e; color:#ffb3ae; border-color:#7a2f2b; }");
            sb.AppendLine("form.inline { display:inline; }");
            sb.AppendLine(".row { display:flex; gap:10px; flex-wrap:wrap; align-items:center; }");
            sb.AppendLine(".row.gap { margin-top:16px; }");
            sb.AppendLine(".msg { padding:13px 18px; border-radius:10px; margin-bottom:20px; font-size:14px; }");
            sb.AppendLine(".msg.ok { background:#13301d; color:var(--ok); border:1px solid #1f5c32; }");
            sb.AppendLine(".msg.err { background:#3a1c1a; color:var(--bad); border:1px solid #6d2a26; }");
            sb.AppendLine(".grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(210px,1fr)); gap:16px; }");
            sb.AppendLine(".tile { background:var(--alt); border:1px solid var(--line); border-radius:10px; padding:16px; }");
            sb.AppendLine(".tile span { display:block; color:var(--dim); font-size:12px;");
            sb.AppendLine("             text-transform:uppercase; letter-spacing:.06em; margin-bottom:6px; }");
            sb.AppendLine(".tile b { font:15px/1.4 ui-monospace,Consolas,monospace; font-weight:600; word-break:break-all; }");
            sb.AppendLine(".login { max-width:420px; margin:14vh auto; }");
            sb.AppendLine(".dim { color:var(--dim); }");
            sb.AppendLine(".mono { font-family:ui-monospace,Consolas,monospace; }");
            sb.AppendLine(".prot { color:var(--warn); font-size:12px; }");
            sb.AppendLine("</style>");
            sb.AppendLine("</head>");
            sb.AppendLine("<body>");
            sb.AppendLine("");
            sb.AppendLine("<?php if (!panel_logged_in()): ?>");
            sb.AppendLine("");
            sb.AppendLine("  <main class=\"login\">");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>LisunOS — вход в панель</h2>");
            sb.AppendLine("      <?php if ($error !== null): ?><div class=\"msg err\"><?php echo panel_escape($error); ?></div><?php endif; ?>");
            sb.AppendLine("      <form method=\"post\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"do\" value=\"login\">");
            sb.AppendLine("        <div class=\"row\">");
            sb.AppendLine("          <input type=\"password\" name=\"password\" placeholder=\"Пароль панели\" style=\"flex:1\" autofocus>");
            sb.AppendLine("          <button class=\"primary\" type=\"submit\">Войти</button>");
            sb.AppendLine("        </div>");
            sb.AppendLine("      </form>");
            sb.AppendLine("      <p class=\"dim\" style=\"margin:16px 0 0;font-size:13px\">");
            sb.AppendLine("        Пароль задаётся в приложении: «Сервер v2» → кнопка «Веб-панель».");
            sb.AppendLine("      </p>");
            sb.AppendLine("    </div>");
            sb.AppendLine("  </main>");
            sb.AppendLine("");
            sb.AppendLine("<?php else: ?>");
            sb.AppendLine("");
            sb.AppendLine("  <header>");
            sb.AppendLine("    <h1>LisunOS</h1>");
            sb.AppendLine("    <span class=\"badge\">панель <?php echo PANEL_VERSION; ?></span>");
            sb.AppendLine("    <span class=\"badge\">www:\\<?php echo panel_escape($currentRelative); ?></span>");
            sb.AppendLine("    <span class=\"sp\"></span>");
            sb.AppendLine("    <a class=\"badge\" href=\"panel.php\">Файлы</a>");
            sb.AppendLine("    <a class=\"badge\" href=\"panel.php?view=system\">Система</a>");
            sb.AppendLine("    <a class=\"badge\" href=\"panel.php?logout=1\">Выйти</a>");
            sb.AppendLine("  </header>");
            sb.AppendLine("");
            sb.AppendLine("  <main>");
            sb.AppendLine("  <?php if ($notice !== null): ?><div class=\"msg ok\"><?php echo panel_escape($notice); ?></div><?php endif; ?>");
            sb.AppendLine("  <?php if ($error !== null): ?><div class=\"msg err\"><?php echo panel_escape($error); ?></div><?php endif; ?>");
            sb.AppendLine("");
            sb.AppendLine("  <?php if (isset($_GET['view']) && $_GET['view'] === 'system'): ?>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Сведения о сервере</h2>");
            sb.AppendLine("      <div class=\"grid\">");
            sb.AppendLine("        <div class=\"tile\"><span>PHP</span><b><?php echo panel_escape(PHP_VERSION); ?></b></div>");
            sb.AppendLine("        <div class=\"tile\"><span>Сервер</span><b><?php echo panel_escape(isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'LisunOS'); ?></b></div>");
            sb.AppendLine("        <div class=\"tile\"><span>Корень сайта</span><b>www:\\</b></div>");
            sb.AppendLine("        <div class=\"tile\"><span>API</span><b><?php echo is_file(__DIR__ . '/api.php') ? 'api.php' : 'нет'; ?></b></div>");
            sb.AppendLine("        <div class=\"tile\"><span>Ключ API</span><b><?php echo ServerAPI_Key() === '' ? 'не задан' : substr(ServerAPI_Key(), 0, 12) . '…'; ?></b></div>");
            sb.AppendLine("        <div class=\"tile\"><span>Время</span><b><?php echo date('H:i:s'); ?></b></div>");
            sb.AppendLine("      </div>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Смена пароля панели</h2>");
            sb.AppendLine("      <form method=\"post\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"do\" value=\"change_password\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("        <div class=\"row\">");
            sb.AppendLine("          <input type=\"password\" name=\"code\" placeholder=\"Новый пароль (от 4 символов)\" style=\"flex:1\">");
            sb.AppendLine("          <button class=\"primary\" type=\"submit\">Сменить</button>");
            sb.AppendLine("        </div>");
            sb.AppendLine("      </form>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Проверка API</h2>");
            sb.AppendLine("      <p class=\"dim\" style=\"margin:0 0 12px\">Запрос выполняется от имени панели, ключ берётся из .api.key.</p>");
            sb.AppendLine("      <pre class=\"mono\" style=\"margin:0;color:var(--cyan);font-size:13px;white-space:pre-wrap\"><?php");
            sb.AppendLine("        $ping = panel_api('ping');");
            sb.AppendLine("        echo panel_escape(json_encode($ping, 256 | 64));");
            sb.AppendLine("      ?></pre>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("  <?php elseif ($editText !== null): ?>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Правка — <?php echo panel_escape(panel_relative($editPath)); ?></h2>");
            sb.AppendLine("      <?php if (count(lisun_protected_blocks($editText)) > 0): ?>");
            sb.AppendLine("        <p class=\"prot\">В файле есть защищённые блоки NOREMOVE — их строки изменять нельзя.</p>");
            sb.AppendLine("      <?php endif; ?>");
            sb.AppendLine("      <form method=\"post\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"do\" value=\"save_file\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"name\" value=\"<?php echo panel_escape(panel_relative($editPath)); ?>\">");
            sb.AppendLine("        <textarea name=\"code\" spellcheck=\"false\"><?php echo panel_escape($editText); ?></textarea>");
            sb.AppendLine("        <div class=\"row gap\">");
            sb.AppendLine("          <button class=\"primary\" type=\"submit\">Сохранить</button>");
            sb.AppendLine("          <a class=\"badge\" href=\"panel.php?p=<?php echo urlencode(panel_relative(dirname($editPath))); ?>\">Назад</a>");
            sb.AppendLine("        </div>");
            sb.AppendLine("      </form>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("  <?php else: ?>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Файлы сайта</h2>");
            sb.AppendLine("      <table>");
            sb.AppendLine("        <tr><th>Имя</th><th>Тип</th><th class=\"r\">Размер</th><th>Изменён</th><th class=\"r\">Действия</th></tr>");
            sb.AppendLine("");
            sb.AppendLine("        <?php if ($currentRelative !== ''): ?>");
            sb.AppendLine("          <tr><td colspan=\"5\"><a href=\"panel.php?p=<?php echo urlencode(panel_relative(dirname($currentPath))); ?>\">↑ каталог выше</a></td></tr>");
            sb.AppendLine("        <?php endif; ?>");
            sb.AppendLine("");
            sb.AppendLine("        <?php");
            sb.AppendLine("        $listing = panel_api('list', $currentRelative);");
            sb.AppendLine("        $items = (!empty($listing['ok']) && isset($listing['data']['items'])) ? $listing['data']['items'] : array();");
            sb.AppendLine("");
            sb.AppendLine("        foreach ($items as $item):");
            sb.AppendLine("            $child = ($currentRelative === '' ? '' : $currentRelative . '/') . $item['name'];");
            sb.AppendLine("            $isDir = $item['type'] === 'dir';");
            sb.AppendLine("            $full  = panel_safe_path($child);");
            sb.AppendLine("            $locked = (!$isDir && is_file($full)) ? count(lisun_protected_blocks((string)file_get_contents($full))) > 0 : false;");
            sb.AppendLine("        ?>");
            sb.AppendLine("        <tr>");
            sb.AppendLine("          <td>");
            sb.AppendLine("            <?php if ($isDir): ?>");
            sb.AppendLine("              <a href=\"panel.php?p=<?php echo urlencode($child); ?>\">📁 <?php echo panel_escape($item['name']); ?></a>");
            sb.AppendLine("            <?php else: ?>");
            sb.AppendLine("              <a href=\"panel.php?edit=<?php echo urlencode($child); ?>\"><?php echo panel_escape($item['name']); ?></a>");
            sb.AppendLine("              <?php if ($locked): ?><span class=\"prot\"> NOREMOVE</span><?php endif; ?>");
            sb.AppendLine("            <?php endif; ?>");
            sb.AppendLine("          </td>");
            sb.AppendLine("          <td class=\"dim\"><?php echo $isDir ? 'папка' : 'файл'; ?></td>");
            sb.AppendLine("          <td class=\"r dim\"><?php echo panel_size(isset($item['size']) ? $item['size'] : null); ?></td>");
            sb.AppendLine("          <td class=\"dim mono\" style=\"font-size:13px\"><?php echo panel_escape($item['mtime']); ?></td>");
            sb.AppendLine("          <td class=\"r\">");
            sb.AppendLine("            <form class=\"inline\" method=\"post\" onsubmit=\"return prompt_rename(this)\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"do\" value=\"rename\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"name\" value=\"<?php echo panel_escape($child); ?>\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"target\" value=\"\">");
            sb.AppendLine("              <button type=\"submit\">Имя</button>");
            sb.AppendLine("            </form>");
            sb.AppendLine("            <form class=\"inline\" method=\"post\" onsubmit=\"return confirm('Удалить <?php echo panel_escape($item['name']); ?>?')\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"do\" value=\"<?php echo $isDir ? 'delete_folder' : 'delete_file'; ?>\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("              <input type=\"hidden\" name=\"name\" value=\"<?php echo panel_escape($child); ?>\">");
            sb.AppendLine("              <button class=\"danger\" type=\"submit\"<?php echo $locked ? ' disabled title=\"файл защищён\"' : ''; ?>>Удалить</button>");
            sb.AppendLine("            </form>");
            sb.AppendLine("          </td>");
            sb.AppendLine("        </tr>");
            sb.AppendLine("        <?php endforeach; ?>");
            sb.AppendLine("      </table>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("    <div class=\"card\">");
            sb.AppendLine("      <h2>Создать</h2>");
            sb.AppendLine("      <form method=\"post\" style=\"margin-bottom:14px\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"do\" value=\"create_file\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("        <div class=\"row\">");
            sb.AppendLine("          <input name=\"name\" placeholder=\"<?php echo panel_escape(($currentRelative === '' ? '' : $currentRelative . '/') . 'page.html'); ?>\" style=\"flex:1\">");
            sb.AppendLine("          <button class=\"primary\" type=\"submit\">Файл</button>");
            sb.AppendLine("        </div>");
            sb.AppendLine("      </form>");
            sb.AppendLine("      <form method=\"post\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"do\" value=\"create_folder\">");
            sb.AppendLine("        <input type=\"hidden\" name=\"token\" value=\"<?php echo panel_token(); ?>\">");
            sb.AppendLine("        <div class=\"row\">");
            sb.AppendLine("          <input name=\"name\" placeholder=\"<?php echo panel_escape(($currentRelative === '' ? '' : $currentRelative . '/') . 'assets'); ?>\" style=\"flex:1\">");
            sb.AppendLine("          <button type=\"submit\">Папка</button>");
            sb.AppendLine("        </div>");
            sb.AppendLine("      </form>");
            sb.AppendLine("    </div>");
            sb.AppendLine("");
            sb.AppendLine("  <?php endif; ?>");
            sb.AppendLine("  </main>");
            sb.AppendLine("");
            sb.AppendLine("  <script>");
            sb.AppendLine("  function prompt_rename(form) {");
            sb.AppendLine("      var from = form.elements['name'].value;");
            sb.AppendLine("      var to = prompt('Новое имя или путь:', from);");
            sb.AppendLine("      if (!to) return false;");
            sb.AppendLine("      form.elements['target'].value = to;");
            sb.AppendLine("      return true;");
            sb.AppendLine("  }");
            sb.AppendLine("  </script>");
            sb.AppendLine("");
            sb.AppendLine("<?php endif; ?>");
            sb.AppendLine("");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");
            sb.AppendLine("<?php");
            sb.AppendLine("# ~NOREMOVE~~~");
            sb.AppendLine("");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  Ниже можно дописывать свой код — эта часть не защищена.");
            sb.AppendLine("# ============================================================");
            return sb.ToString();
        }
    }
}
