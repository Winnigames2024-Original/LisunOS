﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace LisunOS
{
    /// <summary>
    /// Конфигурация встроенного сервера LisunOS.
    /// Читается из файла .htaccess в корне сайта, синтаксис — как у nginx:
    /// директивы вида «ключ значение;» и блоки «location &lt;шаблон&gt; { ... }».
    /// </summary>
    public class LisunServerConfig
    {
        public const string FileName = ".htaccess";

        public enum LocationKind
        {
            Static,
            Deny,
            Php,
            Proxy
        }

        public sealed class Location
        {
            public string Pattern = string.Empty;
            public bool IsRegex;
            public LocationKind Kind = LocationKind.Static;

            public string Handler = string.Empty;        // php | node | static
            public string FastCgiPath = string.Empty;    // путь к php-cgi.exe или php.exe
            public string ProxyTarget = string.Empty;    // http://127.0.0.1:3000
            public string ProxyHost = string.Empty;
            public int ProxyPort;
            public int TimeoutSeconds = 15;
            public string Root = string.Empty;           // своя корневая папка для блока
            public bool? AutoIndex;

            /// <summary>return &lt;код&gt; [адрес или текст] — ответ без чтения файла.</summary>
            public int ReturnCode;
            public string ReturnValue = string.Empty;

            /// <summary>try_files a b =404 — что пробовать по очереди.</summary>
            public readonly List<string> TryFiles = new List<string>();

            /// <summary>rewrite &lt;шаблон&gt; &lt;замена&gt; — переписывание пути.</summary>
            public readonly List<string[]> Rewrites = new List<string[]>();

            /// <summary>allow / deny по адресу: пусто — разрешено всем.</summary>
            public readonly List<string> Allow = new List<string>();
            public readonly List<string> Deny = new List<string>();

            public readonly List<string> Index = new List<string>();
            public readonly Dictionary<string, string> Headers =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            private Regex compiled;

            /// <summary>Подходит ли путь запроса под шаблон блока.</summary>
            public bool Matches(string urlPath)
            {
                if (string.IsNullOrEmpty(Pattern)) return false;

                if (IsRegex)
                {
                    try
                    {
                        if (compiled == null)
                            compiled = new Regex(Pattern, RegexOptions.IgnoreCase | RegexOptions.Compiled);

                        return compiled.IsMatch(urlPath);
                    }
                    catch { return false; }
                }

                if (Pattern == "/") return true;
                return urlPath.StartsWith(Pattern, StringComparison.OrdinalIgnoreCase);
            }

            /// <summary>Длина префикса — чем длиннее, тем выше приоритет блока.</summary>
            public int Weight
            {
                get { return IsRegex ? 1000 + Pattern.Length : Pattern.Length; }
            }
        }

        // ---------- общие параметры ----------

        public readonly List<string> Index = new List<string>();
        public bool AutoIndex = true;
        public bool AccessLog = true;
        public string Charset = "utf-8";
        public string DefaultType = "application/octet-stream";
        public long ClientMaxBody = 8 * 1024 * 1024;
        public int KeepAliveTimeout = 10;
        public string ServerName = "LisunOS";

        /// <summary>Корень сайта, заданный директивой root вне блоков.</summary>
        public string Root = string.Empty;

        public readonly Dictionary<string, string> Headers =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public readonly Dictionary<int, string> ErrorPages = new Dictionary<int, string>();
        public readonly List<string> DeniedFiles = new List<string>();
        public readonly List<Location> Locations = new List<Location>();

        /// <summary>Виртуальный хост: имя и порт, на которых отвечает блок server.</summary>
        public sealed class VirtualHost
        {
            public string Name = string.Empty;
            public int Port;
            public string Root = string.Empty;

            public readonly List<Location> Locations = new List<Location>();
            public readonly List<string> Index = new List<string>();
        }

        public readonly List<VirtualHost> Hosts = new List<VirtualHost>();

        /// <summary>Файлы, подключённые директивой include.</summary>
        public readonly List<string> Included = new List<string>();

        /// <summary>Директивы уровня server, заданные вне блоков location.</summary>
        public int RootReturnCode;
        public string RootReturnValue = string.Empty;

        public readonly List<string> RootTryFiles = new List<string>();
        public readonly List<string[]> RootRewrites = new List<string[]>();
        public readonly List<string> RootAllow = new List<string>();
        public readonly List<string> RootDeny = new List<string>();

        public string SourcePath { get; private set; }
        public DateTime LoadedAt { get; private set; }
        public readonly List<string> Warnings = new List<string>();

        public LisunServerConfig()
        {
            Index.Add("index.html");
            Index.Add("index.htm");

            // Служебные файлы сервера наружу не отдаются.
            DeniedFiles.Add(FileName);
            DeniedFiles.Add(LisunApiEndpoint.KeyFileName);
            DeniedFiles.Add(LisunWebPanel.PasswordFileName);
            DeniedFiles.Add("*.lsi");
            DeniedFiles.Add("*.service");
        }

        // =====================================================================
        //  Загрузка
        // =====================================================================

        public static LisunServerConfig Load(string rootDirectory)
        {
            LisunServerConfig config = new LisunServerConfig();
            config.LoadedAt = DateTime.Now;

            try
            {
                string path = Path.Combine(rootDirectory, FileName);
                config.SourcePath = path;

                if (!File.Exists(path)) return config;

                config.rootDirectory = rootDirectory;
                config.Parse(LisunCrypto.ReadAllText(path));

                LisunEngine.Log("[Server] Конфигурация загружена: location — " + config.Locations.Count +
                                ", server — " + config.Hosts.Count +
                                (config.Included.Count > 0 ? ", include — " + config.Included.Count : "") + ".");
            }
            catch (Exception ex)
            {
                config.Warnings.Add(ex.Message);
                LisunEngine.Log("[Server] [ОШИБКА] Чтение .htaccess: " + ex.Message);
            }

            return config;
        }

        private string rootDirectory = string.Empty;

        /// <summary>Глубина include, чтобы файл не подключил сам себя по кругу.</summary>
        private int includeDepth;

        private void Parse(string text)
        {
            if (string.IsNullOrEmpty(text)) return;

            string[] lines = text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');

            Location current = null;
            VirtualHost currentHost = null;
            int depth = 0;

            foreach (string raw in lines)
            {
                string line = StripComment(raw).Trim();
                if (line.Length == 0) continue;

                // Открытие блока location
                Match location = Regex.Match(line,
                    @"^location\s+(?<mod>~\*?|=)?\s*(?<pattern>[^\s{]+)\s*\{?$", RegexOptions.IgnoreCase);
                if (location.Success)
                {
                    current = new Location();
                    current.IsRegex = location.Groups["mod"].Value.StartsWith("~");
                    current.Pattern = location.Groups["pattern"].Value.Trim();

                    Locations.Add(current);
                    if (currentHost != null) currentHost.Locations.Add(current);

                    depth++;
                    continue;
                }

                // Блок server — виртуальный хост со своим корнем и location.
                if (Regex.IsMatch(line, @"^server\s*\{?$", RegexOptions.IgnoreCase))
                {
                    currentHost = new VirtualHost();
                    Hosts.Add(currentHost);
                    depth++;
                    continue;
                }

                // Обёртки http { } / events { } ничего не задают — пропускаем.
                if (Regex.IsMatch(line, @"^(http|events)\s*\{?$", RegexOptions.IgnoreCase))
                {
                    depth++;
                    continue;
                }

                if (line == "{") { depth++; continue; }

                if (line.StartsWith("}"))
                {
                    depth--;

                    // Закрылся location — остаёмся внутри server; закрылся server — выходим.
                    if (current != null) current = null;
                    else currentHost = null;

                    continue;
                }

                ParseDirective(line.TrimEnd(';').Trim(), current, currentHost);
            }

            Locations.Sort((a, b) => b.Weight.CompareTo(a.Weight));
        }

        private static string StripComment(string line)
        {
            int hash = line.IndexOf('#');
            return hash < 0 ? line : line.Substring(0, hash);
        }

        private void ParseDirective(string line, Location location, VirtualHost host)
        {
            string[] parts = line.Split(new[] { ' ', '\t' }, 2, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) return;

            string key = parts[0].Trim().ToLowerInvariant();
            string value = parts.Length > 1 ? parts[1].Trim().Trim('"', '\'') : string.Empty;

            switch (key)
            {
                // ---------- подключение других файлов ----------
                case "include":
                    Include(value);
                    break;

                // ---------- виртуальный хост ----------
                case "listen":
                    {
                        int[] numbers = Numbers(value);
                        if (host != null && numbers.Length > 0) host.Port = numbers[0];
                        break;
                    }

                // ---------- ответ без чтения файла ----------
                case "return":
                    {
                        string[] pieces = value.Split(new[] { ' ' }, 2);

                        int code;
                        if (!int.TryParse(pieces[0], out code))
                        {
                            Warnings.Add("return: " + value);
                            break;
                        }

                        string payload = pieces.Length > 1 ? pieces[1].Trim().Trim('"') : string.Empty;

                        if (location != null) { location.ReturnCode = code; location.ReturnValue = payload; }
                        else { RootReturnCode = code; RootReturnValue = payload; }
                        break;
                    }

                // ---------- что пробовать по очереди ----------
                case "try_files":
                    {
                        List<string> targets = location != null ? location.TryFiles : RootTryFiles;
                        targets.Clear();

                        foreach (string piece in value.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries))
                            targets.Add(piece.Trim());
                        break;
                    }

                // ---------- переписывание пути ----------
                case "rewrite":
                    {
                        string[] pieces = value.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                        if (pieces.Length < 2)
                        {
                            Warnings.Add("rewrite: " + value);
                            break;
                        }

                        string[] rule = new string[] { pieces[0], pieces[1] };

                        if (location != null) location.Rewrites.Add(rule);
                        else RootRewrites.Add(rule);
                        break;
                    }

                // ---------- доступ по адресу ----------
                case "allow":
                    if (location != null) location.Allow.Add(value.Trim());
                    else RootAllow.Add(value.Trim());
                    break;

                case "index":
                    {
                        List<string> target = location != null ? location.Index : Index;
                        target.Clear();
                        foreach (string item in value.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries))
                            target.Add(item.Trim());
                        break;
                    }

                case "autoindex":
                    if (location != null) location.AutoIndex = IsOn(value);
                    else AutoIndex = IsOn(value);
                    break;

                case "access_log":
                    AccessLog = IsOn(value);
                    break;

                case "charset":
                    Charset = value.Length == 0 ? "utf-8" : value;
                    break;

                case "default_type":
                    DefaultType = value;
                    break;

                case "server_name":
                    if (host != null) { host.Name = value; break; }
                    goto case "server_label";

                case "server_label":
                    ServerName = value;
                    break;

                case "keepalive_timeout":
                    KeepAliveTimeout = ParseInt(value, KeepAliveTimeout);
                    break;

                case "client_max_body":
                case "client_max_body_size":
                    ClientMaxBody = ParseSize(value, ClientMaxBody);
                    break;

                case "root":
                    if (location != null) location.Root = value;
                    else if (host != null) host.Root = value;
                    else Root = value;
                    break;

                case "add_header":
                    {
                        string[] header = value.Split(new[] { ' ', '\t' }, 2, StringSplitOptions.RemoveEmptyEntries);
                        if (header.Length == 2)
                        {
                            if (location != null) location.Headers[header[0]] = header[1].Trim('"');
                            else Headers[header[0]] = header[1].Trim('"');
                        }
                        break;
                    }

                case "error_page":
                    {
                        string[] pageParts = value.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                        if (pageParts.Length >= 2)
                        {
                            int code;
                            if (int.TryParse(pageParts[0], out code))
                                ErrorPages[code] = pageParts[pageParts.Length - 1];
                        }
                        break;
                    }

                case "deny":
                    if (value.Equals("all", StringComparison.OrdinalIgnoreCase) || value.Length == 0)
                    {
                        // deny all внутри location закрывает весь блок.
                        if (location != null) location.Kind = LocationKind.Deny;
                        else RootDeny.Add("all");
                    }
                    else if (LooksLikeAddress(value))
                    {
                        // deny 10.0.0.5 — запрет по адресу клиента.
                        if (location != null) location.Deny.Add(value);
                        else RootDeny.Add(value);
                    }
                    else DeniedFiles.Add(value);   // deny *.bak — маска файлов
                    break;

                case "deny_files":
                    foreach (string mask in value.Split(new[] { ' ', '\t', ',' }, StringSplitOptions.RemoveEmptyEntries))
                        DeniedFiles.Add(mask.Trim());
                    break;

                case "handler":
                    if (location == null) break;
                    location.Handler = value.ToLowerInvariant();

                    if (location.Handler == "php") location.Kind = LocationKind.Php;
                    else if (location.Handler == "node" || location.Handler == "nodejs")
                        location.Kind = LocationKind.Proxy;
                    break;

                case "fastcgi_pass":
                case "php_path":
                    if (location == null) break;
                    location.FastCgiPath = value;
                    if (location.Kind == LocationKind.Static) location.Kind = LocationKind.Php;
                    break;

                case "proxy_pass":
                case "node_pass":
                    {
                        if (location == null) break;

                        location.ProxyTarget = value;
                        location.Kind = LocationKind.Proxy;

                        Match address = Regex.Match(value, @"^(?:http://)?(?<host>[^:/\s]+)(?::(?<port>\d+))?",
                            RegexOptions.IgnoreCase);
                        if (address.Success)
                        {
                            location.ProxyHost = address.Groups["host"].Value;
                            location.ProxyPort = address.Groups["port"].Success
                                ? ParseInt(address.Groups["port"].Value, 80)
                                : 80;
                        }
                        break;
                    }

                case "timeout":
                case "proxy_timeout":
                case "fastcgi_timeout":
                    if (location != null) location.TimeoutSeconds = ParseInt(value, location.TimeoutSeconds);
                    break;

                default:
                    Warnings.Add(key);
                    break;
            }
        }

        private static bool IsOn(string value)
        {
            if (string.IsNullOrEmpty(value)) return true;
            value = value.Trim().ToLowerInvariant();
            return value == "on" || value == "true" || value == "yes" || value == "1";
        }

        private static int ParseInt(string value, int fallback)
        {
            int parsed;
            return int.TryParse(new string(Array.FindAll(value.ToCharArray(), char.IsDigit)), out parsed) &&
                   parsed > 0 ? parsed : fallback;
        }

        private static long ParseSize(string value, long fallback)
        {
            if (string.IsNullOrEmpty(value)) return fallback;

            value = value.Trim().ToLowerInvariant();
            long multiplier = 1;

            if (value.EndsWith("k")) { multiplier = 1024; value = value.Substring(0, value.Length - 1); }
            else if (value.EndsWith("m")) { multiplier = 1024 * 1024; value = value.Substring(0, value.Length - 1); }
            else if (value.EndsWith("g")) { multiplier = 1024L * 1024 * 1024; value = value.Substring(0, value.Length - 1); }

            long number;
            return long.TryParse(value.Trim(), out number) ? number * multiplier : fallback;
        }

        // =====================================================================
        //  Применение
        // =====================================================================

        /// <summary>Подходящий блок location для пути запроса.</summary>
        public Location Match(string urlPath)
        {
            if (string.IsNullOrEmpty(urlPath)) urlPath = "/";

            foreach (Location location in Locations)
            {
                if (location.Matches(urlPath)) return location;
            }
            return null;
        }

        public List<string> IndexFilesFor(Location location)
        {
            if (location != null && location.Index.Count > 0) return location.Index;
            return Index;
        }

        public bool AutoIndexFor(Location location)
        {
            if (location != null && location.AutoIndex.HasValue) return location.AutoIndex.Value;
            return AutoIndex;
        }

        /// <summary>Запрещён ли файл к выдаче (служебные файлы и маски deny_files).</summary>
        public bool IsDenied(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return false;

            foreach (string mask in DeniedFiles)
            {
                if (mask.StartsWith("*."))
                {
                    if (fileName.EndsWith(mask.Substring(1), StringComparison.OrdinalIgnoreCase)) return true;
                }
                else if (fileName.Equals(mask, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        public string Summary()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("index: " + string.Join(" ", Index.ToArray()));
            sb.AppendLine("autoindex: " + (AutoIndex ? "on" : "off") + ", charset: " + Charset);
            sb.AppendLine("locations: " + Locations.Count);

            foreach (Location location in Locations)
            {
                sb.Append("   ").Append(location.IsRegex ? "~ " : "").Append(location.Pattern)
                  .Append("  →  ").Append(location.Kind.ToString().ToLowerInvariant());

                if (location.Kind == LocationKind.Proxy) sb.Append("  ").Append(location.ProxyTarget);
                if (location.Kind == LocationKind.Php) sb.Append("  ").Append(location.FastCgiPath);

                sb.AppendLine();
            }
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Файл по умолчанию
        // =====================================================================

        /// <summary>Создаёт .htaccess с примерами настроек PHP и Node.js, если файла нет.</summary>
        public static void EnsureDefaultFile(string rootDirectory)
        {
            try
            {
                string path = Path.Combine(rootDirectory, FileName);
                if (File.Exists(path)) return;

                CustomFormUtils.WriteFileText(path, DefaultContent());

                // Папка для своих файлов настроек: её подключает include.
                string extra = Path.Combine(rootDirectory, "conf.d");
                if (!Directory.Exists(extra)) Directory.CreateDirectory(extra);

                string sample = Path.Combine(extra, "example.conf.txt");
                if (!File.Exists(sample)) CustomFormUtils.WriteFileText(sample, SampleIncludeContent());
                LisunEngine.Log("[Server] Создан файл конфигурации " + FileName + ".");
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Server] [ОШИБКА] Создание " + FileName + ": " + ex.Message);
            }
        }

        public static string DefaultContent()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  Конфигурация сервера LisunOS  (.htaccess)");
            sb.AppendLine("#  Синтаксис как у nginx: директивы и блоки location { }");
            sb.AppendLine("#  После правки нажмите «Остановить» и «Запустить» в панели.");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("");
            sb.AppendLine("server {");
            sb.AppendLine("    server_name        LisunOS;");
            sb.AppendLine("    charset            utf-8;");
            sb.AppendLine("");
            sb.AppendLine("    # файлы, которые отдаются при запросе каталога");
            sb.AppendLine("    index              index.html index.htm index.php;");
            sb.AppendLine("");
            sb.AppendLine("    # показывать список файлов, если индексного файла нет");
            sb.AppendLine("    autoindex          on;");
            sb.AppendLine("");
            sb.AppendLine("    access_log         on;");
            sb.AppendLine("    client_max_body    8m;");
            sb.AppendLine("    keepalive_timeout  10;");
            sb.AppendLine("    default_type       application/octet-stream;");
            sb.AppendLine("");
            sb.AppendLine("    # свои заголовки в каждом ответе");
            sb.AppendLine("    add_header         X-Powered-By LisunOS;");
            sb.AppendLine("");
            sb.AppendLine("    # страницы ошибок (положите файлы рядом)");
            sb.AppendLine("    # error_page       404 /404.html;");
            sb.AppendLine("    # error_page       500 /500.html;");
            sb.AppendLine("");
            sb.AppendLine("    # дополнительные файлы настроек подключаются отсюда");
            sb.AppendLine("    include            conf.d/*.conf;");
            sb.AppendLine("");
            sb.AppendLine("    # доступ по адресу: пустые списки — пускать всех");
            sb.AppendLine("    # allow            127.0.0.1;");
            sb.AppendLine("    # deny             192.168.1.50;");
            sb.AppendLine("");
            sb.AppendLine("    # что пробовать по очереди, если файла нет");
            sb.AppendLine("    # try_files        $uri $uri/index.html =404;");
            sb.AppendLine("");
            sb.AppendLine("    # переписывание пути до поиска блока location");
            sb.AppendLine("    # rewrite          ^/старый/(.*)$ /новый/$1;");
            sb.AppendLine("");
            sb.AppendLine("    # файлы, которые нельзя скачать");
            sb.AppendLine("    deny_files         .htaccess .api.key .panel.pass *.lsi *.service *.env *.log;");
            sb.AppendLine("");
            sb.AppendLine("    # --------------------------------------------------------");
            sb.AppendLine("    #  PHP — через php-cgi.exe (блок включён)");
            sb.AppendLine("    #  Нужен установленный PHP для Windows; путь находится сам.");
            sb.AppendLine("    # --------------------------------------------------------");
            sb.AppendLine("    location ~ \\.php$ {");
            sb.AppendLine("        handler        php;");
            sb.AppendLine("        timeout        15;");
            sb.AppendLine("        add_header     X-Handler php-cgi;");
            sb.AppendLine("");
            sb.AppendLine("        # Путь ищется сам: PATH, C:\\php, C:\\xampp\\php, C:\\laragon, C:\\wamp64.");
            sb.AppendLine("        # Если PHP лежит в другом месте — укажите явно:");
            sb.AppendLine("        # fastcgi_pass C:\\php\\php-cgi.exe;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    # --------------------------------------------------------");
            sb.AppendLine("    #  Node.js — проксирование на запущенный процесс node");
            sb.AppendLine("    #  Сначала запустите приложение:  node server.js");
            sb.AppendLine("    # --------------------------------------------------------");
            sb.AppendLine("    # location /api {");
            sb.AppendLine("    #     handler        node;");
            sb.AppendLine("    #     proxy_pass     http://127.0.0.1:3000;");
            sb.AppendLine("    #     timeout        20;");
            sb.AppendLine("    # }");
            sb.AppendLine("");
            sb.AppendLine("    # всё приложение на Node.js вместо статики");
            sb.AppendLine("    # location / {");
            sb.AppendLine("    #     handler        node;");
            sb.AppendLine("    #     proxy_pass     http://127.0.0.1:3000;");
            sb.AppendLine("    # }");
            sb.AppendLine("");
            sb.AppendLine("    # закрытый каталог");
            sb.AppendLine("    # location /private {");
            sb.AppendLine("    #     deny all;");
            sb.AppendLine("    # }");
            sb.AppendLine("");
            sb.AppendLine("    # статика без списка файлов и с кэшем");
            sb.AppendLine("    # location /assets {");
            sb.AppendLine("    #     autoindex      off;");
            sb.AppendLine("    #     add_header     Cache-Control max-age=3600;");
            sb.AppendLine("    # }");
            sb.AppendLine("}");
            return sb.ToString();
        }

        // =====================================================================
        //  include, адреса, проверка конфигурации
        // =====================================================================

        /// <summary>
        /// include conf.d/*.conf — подключает другие файлы настроек.
        /// Глубина ограничена, чтобы файл не подключил сам себя по кругу.
        /// </summary>
        private void Include(string pattern)
        {
            if (pattern.Length == 0 || rootDirectory.Length == 0) return;

            if (includeDepth >= 4)
            {
                Warnings.Add("include: слишком глубокая вложенность — " + pattern);
                return;
            }

            try
            {
                pattern = pattern.Replace('/', Path.DirectorySeparatorChar).Trim();

                string folder = Path.GetDirectoryName(pattern);
                string mask = Path.GetFileName(pattern);

                string directory = Path.GetFullPath(Path.Combine(rootDirectory,
                    string.IsNullOrEmpty(folder) ? "." : folder));

                // Подключать можно только из корня сайта.
                if (!directory.StartsWith(Path.GetFullPath(rootDirectory), StringComparison.OrdinalIgnoreCase))
                {
                    Warnings.Add("include: путь за пределами корня — " + pattern);
                    return;
                }

                if (!Directory.Exists(directory)) return;
                if (mask.Length == 0) mask = "*.conf";

                string[] files = Directory.GetFiles(directory, mask);
                Array.Sort(files, StringComparer.OrdinalIgnoreCase);

                includeDepth++;
                try
                {
                    foreach (string file in files)
                    {
                        if (Included.Contains(file)) continue;

                        Included.Add(file);
                        Parse(LisunCrypto.ReadAllText(file));
                    }
                }
                finally { includeDepth--; }
            }
            catch (Exception ex)
            {
                Warnings.Add("include " + pattern + ": " + ex.Message);
            }
        }

        /// <summary>Адрес клиента отличается от маски файла наличием цифр и точек.</summary>
        private static bool LooksLikeAddress(string value)
        {
            if (value.IndexOf('*') >= 0 && value.IndexOf('.') >= 0 && !char.IsDigit(value[0])) return false;

            return Regex.IsMatch(value, @"^[0-9a-fA-F:.]+(/\d{1,3})?$");
        }

        private static int[] Numbers(string value)
        {
            MatchCollection matches = Regex.Matches(value ?? string.Empty, @"\d+");

            List<int> result = new List<int>();
            foreach (Match match in matches)
            {
                int parsed;
                if (int.TryParse(match.Value, out parsed)) result.Add(parsed);
            }

            return result.ToArray();
        }

        /// <summary>Пускать ли клиента: allow важнее deny, пустые списки — пускать всех.</summary>
        public bool AddressAllowed(Location location, string address)
        {
            if (address == null) address = string.Empty;

            List<string> allow = location != null && location.Allow.Count > 0 ? location.Allow : RootAllow;
            List<string> deny = location != null && location.Deny.Count > 0 ? location.Deny : RootDeny;

            foreach (string item in allow)
                if (item.Equals("all", StringComparison.OrdinalIgnoreCase) || address.StartsWith(item)) return true;

            foreach (string item in deny)
                if (item.Equals("all", StringComparison.OrdinalIgnoreCase) || address.StartsWith(item)) return false;

            return true;
        }

        /// <summary>Применяет rewrite к пути: первое совпавшее правило побеждает.</summary>
        public string ApplyRewrites(Location location, string urlPath)
        {
            List<string[]> rules = new List<string[]>(RootRewrites);
            if (location != null) rules.AddRange(location.Rewrites);

            foreach (string[] rule in rules)
            {
                try
                {
                    Regex pattern = new Regex(rule[0]);
                    if (!pattern.IsMatch(urlPath)) continue;

                    return pattern.Replace(urlPath, rule[1]);
                }
                catch { }
            }

            return urlPath;
        }

        /// <summary>
        /// Проверка конфигурации — ответ команды «server config test».
        /// Показывает, что именно разобрано, и все замечания.
        /// </summary>
        public string Describe()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("conf.title") + Environment.NewLine);

            sb.AppendLine("   " + LisunLocale.T("conf.fieldFile") + ": " +
                          (SourcePath.Length == 0 ? "—" : CustomFormUtils.ToVirtualPath(SourcePath)));

            if (Included.Count > 0)
            {
                sb.AppendLine("   " + LisunLocale.T("conf.fieldIncluded") + ":");
                foreach (string file in Included)
                    sb.AppendLine("       " + CustomFormUtils.ToVirtualPath(file));
            }

            sb.AppendLine("   " + LisunLocale.T("conf.fieldCharset") + ": " + Charset);
            sb.AppendLine("   " + LisunLocale.T("conf.fieldIndex") + ": " +
                          (Index.Count == 0 ? "—" : string.Join(" ", Index.ToArray())));
            sb.AppendLine("   " + LisunLocale.T("conf.fieldMaxBody") + ": " +
                          CustomFormUtils.FormatSize(ClientMaxBody));

            if (Hosts.Count > 0)
            {
                sb.AppendLine("   " + LisunLocale.T("conf.fieldHosts", Hosts.Count) + ":");
                foreach (VirtualHost host in Hosts)
                    sb.AppendLine("       " + (host.Name.Length == 0 ? "*" : host.Name) +
                                  (host.Port > 0 ? ":" + host.Port : "") +
                                  (host.Root.Length > 0 ? "  →  " + host.Root : "") +
                                  "   location: " + host.Locations.Count);
            }

            sb.AppendLine("   " + LisunLocale.T("conf.fieldLocations", Locations.Count) + ":");
            foreach (Location item in Locations)
            {
                sb.Append("       " + (item.IsRegex ? "~ " : "  ") + item.Pattern.PadRight(22) + item.Kind);

                if (item.ReturnCode > 0) sb.Append("  return " + item.ReturnCode);
                if (item.TryFiles.Count > 0) sb.Append("  try_files " + string.Join(" ", item.TryFiles.ToArray()));
                if (item.Rewrites.Count > 0) sb.Append("  rewrite ×" + item.Rewrites.Count);
                if (item.Deny.Count > 0) sb.Append("  deny ×" + item.Deny.Count);

                sb.AppendLine();
            }

            if (RootTryFiles.Count > 0)
                sb.AppendLine("   try_files: " + string.Join(" ", RootTryFiles.ToArray()));

            if (RootRewrites.Count > 0) sb.AppendLine("   rewrite: " + RootRewrites.Count);

            sb.AppendLine();
            sb.AppendLine(Warnings.Count == 0
                ? "   " + LisunLocale.T("conf.ok")
                : "   " + LisunLocale.T("conf.warnings", Warnings.Count));

            foreach (string warning in Warnings) sb.AppendLine("       " + warning);

            return sb.ToString().TrimEnd();
        }


        /// <summary>
        /// Пример файла для папки conf.d. Лежит с расширением .conf.txt,
        /// чтобы include его не подхватил: переименуйте в .conf, когда нужен.
        /// </summary>
        public static string SampleIncludeContent()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  Пример дополнительного файла настроек LisunOS");
            sb.AppendLine("#  Переименуйте в example.conf, чтобы include его подключил.");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("");
            sb.AppendLine("# Второй виртуальный хост со своим корнем:");
            sb.AppendLine("# server {");
            sb.AppendLine("#     listen         8081;");
            sb.AppendLine("#     server_name    blog;");
            sb.AppendLine("#     root           root/www/blog;");
            sb.AppendLine("#     index          index.html;");
            sb.AppendLine("# }");
            sb.AppendLine("");
            sb.AppendLine("# Короткая ссылка — ответ без чтения файла:");
            sb.AppendLine("# location /github {");
            sb.AppendLine("#     return     302 https://github.com/Winnigames2024-Original/LisunOS;");
            sb.AppendLine("# }");
            sb.AppendLine("");
            sb.AppendLine("# Закрытый раздел по адресу клиента:");
            sb.AppendLine("# location /admin {");
            sb.AppendLine("#     allow      127.0.0.1;");
            sb.AppendLine("#     deny       all;");
            sb.AppendLine("# }");
            sb.AppendLine("");
            sb.AppendLine("# Одностраничное приложение: всё, чего нет на диске, отдаётся index.html");
            sb.AppendLine("# location /app {");
            sb.AppendLine("#     try_files  $uri $uri/ /index.html =404;");
            sb.AppendLine("# }");
            return sb.ToString();
        }

    }
}
