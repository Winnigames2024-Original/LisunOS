﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика панели управления сервером LisunOS.
    /// Форма собирается из designer-файла пакета, а эта логика управляет
    /// настоящим HTTP-сервером (LisunWebServer), правилами ufw и журналом.
    /// </summary>
    public class ServerLogicBridge
    {
        private readonly DynamicFormContext context;
        private readonly Form form;
        private readonly string packageName;

        private readonly LisunWebServer server = new LisunWebServer();
        private readonly Timer refreshTimer = new Timer();

        private Panel pnlStatus;
        private Label lblServerState;
        private Label lblAddresses;
        private Label lblStats;
        private TextBox txtPort;
        private TextBox txtRoot;
        private CheckBox chkRemote;
        private CheckBox chkListing;
        private CheckBox chkUfw;
        private CheckBox chkAutostart;
        private Button btnStartServer;
        private Button btnStopServer;
        private Button btnOpenBrowser;
        private Button btnOpenFolder;
        private Button btnManageFiles;
        private Button btnApiKey;
        private Button btnPanel;
        private ListBox lstServerLog;

        public ServerLogicBridge(DynamicFormContext context)
        {
            this.context = context;
            form = context.Form;
            packageName = context.PackageName;

            pnlStatus = context.Get<Panel>("pnlStatus");
            lblServerState = context.Get<Label>("lblServerState");
            lblAddresses = context.Get<Label>("lblAddresses");
            lblStats = context.Get<Label>("lblStats");
            txtPort = context.Get<TextBox>("txtPort");
            txtRoot = context.Get<TextBox>("txtRoot");
            chkRemote = context.Get<CheckBox>("chkRemote");
            chkListing = context.Get<CheckBox>("chkListing");
            chkUfw = context.Get<CheckBox>("chkUfw");
            chkAutostart = context.Get<CheckBox>("chkAutostart");
            btnStartServer = context.Get<Button>("btnStartServer");
            btnStopServer = context.Get<Button>("btnStopServer");
            btnOpenBrowser = context.Get<Button>("btnOpenBrowser");
            btnOpenFolder = context.Get<Button>("btnOpenFolder");
            btnManageFiles = context.Get<Button>("btnManageFiles");
            btnApiKey = context.Get<Button>("btnApiKey");
            btnPanel = context.Get<Button>("btnPanel");
            lstServerLog = context.Get<ListBox>("lstServerLog");
        }

        // =====================================================================
        //  Инициализация
        // =====================================================================

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("srv.title");
                form.Disposed += (s, e) => Shutdown();
            }

            server.OnLog += AppendLog;

            RestoreSettings();
            StyleControls();

            refreshTimer.Interval = 1000;
            refreshTimer.Tick += (s, e) => RefreshState();
            refreshTimer.Start();

            AppendLog(LisunLocale.T("srv.ready"));
            RefreshState();

            // Автозапуск сайта: сервер поднимается сам, окно показывать не обязательно.
            if (AutostartEnabled) StartFromAutostart();
        }

        private void Shutdown()
        {
            try
            {
                refreshTimer.Stop();
                refreshTimer.Dispose();
                server.Stop();
            }
            catch { }
        }

        private void RestoreSettings()
        {
            string port;
            if (txtPort != null)
            {
                txtPort.Text = LisunEngine.RegistryData.TryGetValue("server_port", out port) && port.Length > 0
                    ? port
                    : "8080";
            }

            string root;
            if (txtRoot != null)
            {
                bool saved = LisunEngine.RegistryData.TryGetValue("server_root", out root) && root.Length > 0;
                txtRoot.Text = saved ? root : CustomFormUtils.ToVirtualPath(
                    Path.Combine(LisunEngine.RootPath, "root", "www"));
            }

            if (chkListing != null) chkListing.Checked = true;
            if (chkUfw != null) chkUfw.Checked = LisunFirewall.Enabled;

            if (chkAutostart != null) chkAutostart.Checked = AutostartEnabled;

            string remote;
            if (chkRemote != null && LisunEngine.RegistryData.TryGetValue("server_remote", out remote))
                chkRemote.Checked = remote.Equals("true", StringComparison.OrdinalIgnoreCase);
        }

        private void StyleControls()
        {
            if (lblServerState != null) lblServerState.Font = Theme.Ui(11f, FontStyle.Bold);
            if (lblAddresses != null) lblAddresses.Font = Theme.Mono(9.5f);
            if (lblStats != null) lblStats.Font = Theme.Mono(9.5f);

            if (txtPort != null) txtPort.Font = Theme.Mono(11f);
            if (txtRoot != null) txtRoot.Font = Theme.Mono(9.5f);

            if (lstServerLog != null)
            {
                lstServerLog.Font = Theme.Mono(9f);
                lstServerLog.BackColor = Theme.Background;
                lstServerLog.ForeColor = Theme.TextDim;
                lstServerLog.BorderStyle = BorderStyle.None;
                lstServerLog.ItemHeight = 17;
            }

            if (btnStartServer != null) Theme.StyleButton(btnStartServer, Color.FromArgb(27, 67, 50), Theme.Success);
            if (btnStopServer != null) Theme.StyleButton(btnStopServer, Color.FromArgb(82, 30, 30), Theme.Danger);
            if (btnOpenBrowser != null) Theme.StyleButton(btnOpenBrowser, Theme.AccentDeep, Theme.Text);
            if (btnOpenFolder != null) Theme.StyleButton(btnOpenFolder, Theme.SurfaceAlt, Theme.Text);
            if (btnManageFiles != null) Theme.StyleButton(btnManageFiles, Color.FromArgb(31, 60, 92), Theme.Cyan);
            if (btnApiKey != null) Theme.StyleButton(btnApiKey, Theme.SurfaceAlt, Theme.Magenta);
            if (btnPanel != null) Theme.StyleButton(btnPanel, Color.FromArgb(27, 67, 50), Theme.Success);

            // Индикатор состояния — цветная полоса слева от заголовка.
            if (pnlStatus != null) pnlStatus.Paint += PaintStatusStripe;
        }

        private void PaintStatusStripe(object sender, PaintEventArgs e)
        {
            Panel panel = sender as Panel;
            if (panel == null) return;

            Color color = server.IsRunning ? Theme.Success : Theme.Border;

            using (LinearGradientBrush brush = new LinearGradientBrush(
                new Rectangle(0, 0, 5, Math.Max(1, panel.Height)),
                color, Color.FromArgb(70, color), LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, 0, 0, 5, panel.Height);
            }
        }

        // =====================================================================
        //  Журнал и состояние
        // =====================================================================

        private void AppendLog(string message)
        {
            if (lstServerLog == null || lstServerLog.IsDisposed) return;

            if (lstServerLog.InvokeRequired)
            {
                try { lstServerLog.BeginInvoke(new Action<string>(AppendLog), message); }
                catch { }
                return;
            }

            lstServerLog.Items.Insert(0, DateTime.Now.ToString("HH:mm:ss") + "   " + message);
            while (lstServerLog.Items.Count > 300) lstServerLog.Items.RemoveAt(lstServerLog.Items.Count - 1);
        }

        /// <summary>Включён ли автозапуск сервера при загрузке системы.</summary>
        private static bool AutostartEnabled
        {
            get
            {
                string value;
                return LisunEngine.RegistryData.TryGetValue("server_autostart", out value) &&
                       value.Equals("true", StringComparison.OrdinalIgnoreCase);
            }
        }

        private void chkAutostart_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAutostart == null) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings))
            {
                chkAutostart.Checked = AutostartEnabled;
                return;
            }

            LisunEngine.RegistryData["server_autostart"] = chkAutostart.Checked ? "true" : "false";
            LisunEngine.SaveRegistry();

            AppendLog(chkAutostart.Checked
                ? LisunLocale.T("srv.autostartOn")
                : LisunLocale.T("srv.autostartOff"));
        }

        /// <summary>Запуск при загрузке: без диалогов и без запроса прав.</summary>
        private void StartFromAutostart()
        {
            if (server.IsRunning) return;

            // Право network при автозапуске не выпрашиваем — молча пропускаем, если его нет.
            if (!LisunPermissions.Check(packageName, LisunPermissions.Network))
            {
                AppendLog(LisunLocale.T("srv.autostartNoPerm"));
                return;
            }

            int port = ReadPortBox();
            string root = ResolveRoot();

            server.AllowRemoteClients = chkRemote != null && chkRemote.Checked;
            server.AllowDirectoryListing = chkListing == null || chkListing.Checked;

            string error;
            if (!server.Start(port, root, out error))
            {
                AppendLog(LisunLocale.T("srv.autostartFailed", error));
                RefreshState();
                return;
            }

            AppendLog(LisunLocale.T("srv.autostartDone", port));
            RefreshState();
        }

        private void RefreshState()
        {
            bool running = server.IsRunning;

            if (lblServerState != null)
            {
                lblServerState.Text = running
                    ? LisunLocale.T("srv.stateOn", server.Port)
                    : LisunLocale.T("srv.stateOff");
                lblServerState.ForeColor = running ? Theme.Success : Theme.TextDim;
            }

            if (lblAddresses != null)
            {
                lblAddresses.Text = running
                    ? string.Join("     ", server.Addresses().ToArray())
                    : LisunLocale.T("srv.noAddresses");
            }

            if (lblStats != null)
            {
                TimeSpan up = server.Uptime;
                lblStats.Text = LisunLocale.T("srv.stats",
                    server.RequestCount, server.ErrorCount,
                    (int)up.TotalHours + "h " + up.Minutes + "m " + up.Seconds + "s",
                    LisunFirewall.Enabled ? LisunLocale.T("ufw.on") : LisunLocale.T("ufw.off"));
            }

            if (btnStartServer != null) btnStartServer.Enabled = !running;
            if (btnStopServer != null) btnStopServer.Enabled = running;
            if (btnOpenBrowser != null) btnOpenBrowser.Enabled = running;
            if (txtPort != null) txtPort.Enabled = !running;
            if (txtRoot != null) txtRoot.Enabled = !running;
            if (chkRemote != null) chkRemote.Enabled = !running;
            if (chkAutostart != null) chkAutostart.Enabled = true;

            if (pnlStatus != null) pnlStatus.Invalidate();
        }

        // =====================================================================
        //  Обработчики кнопок
        // =====================================================================

        private void btnStartServer_Click(object sender, EventArgs e)
        {
            // Сетевая служба требует права network.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                AppendLog(LisunLocale.T("perm.denied", packageName, LisunPermissions.Network).Trim());
                return;
            }

            int port;
            if (txtPort == null || !int.TryParse(txtPort.Text.Trim(), out port))
            {
                AppendLog(LisunLocale.T("srv.badPort"));
                return;
            }

            string root = ResolveRoot();

            server.AllowRemoteClients = chkRemote != null && chkRemote.Checked;
            server.AllowDirectoryListing = chkListing == null || chkListing.Checked;

            // Флажок «открыть порт в ufw» добавляет правило до запуска.
            if (chkUfw != null && chkUfw.Checked && LisunFirewall.Enabled && !LisunFirewall.Allows(port))
            {
                if (LisunPermissions.Demand(packageName, LisunPermissions.EditSettings))
                {
                    LisunFirewall.SetPort(port, true);
                    AppendLog(LisunLocale.T("srv.ufwOpened", port));
                }
            }

            string error;
            if (!server.Start(port, root, out error))
            {
                AppendLog("[ERROR] " + error);
                RefreshState();
                return;
            }

            if (LisunPermissions.Check(packageName, LisunPermissions.EditSettings))
            {
                LisunEngine.RegistryData["server_port"] = port.ToString();
                LisunEngine.RegistryData["server_root"] = CustomFormUtils.ToVirtualPath(root);
                LisunEngine.SaveRegistry();
            }

            RefreshState();
        }

        private void btnStopServer_Click(object sender, EventArgs e)
        {
            server.Stop();
            RefreshState();
        }

        private void btnOpenBrowser_Click(object sender, EventArgs e)
        {
            if (!server.IsRunning) return;

            string address = "http://localhost:" + server.Port + "/";
            AppendLog(LisunLocale.T("srv.opening", address));

            // Сначала пробуем встроенный браузер LisunOS, затем системный.
            if (!LisunEngine.OpenInShellBrowser(address))
            {
                try { Process.Start(address); }
                catch (Exception ex) { AppendLog("[ERROR] " + ex.Message); }
            }
        }

        private void btnOpenFolder_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;

            string root = ResolveRoot();
            try
            {
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);
                Process.Start("explorer.exe", "\"" + root + "\"");
                AppendLog(LisunLocale.T("srv.folderOpened", CustomFormUtils.ToVirtualPath(root)));
            }
            catch (Exception ex)
            {
                AppendLog("[ERROR] " + ex.Message);
            }
        }

        /// <summary>Веб-панель: создание файла, пароль и открытие в браузере.</summary>
        private void btnPanel_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string root = ResolveRoot();

            try
            {
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);
            }
            catch (Exception ex)
            {
                AppendLog("[ERROR] " + ex.Message);
                return;
            }

            if (LisunWebPanel.EnsureFiles(root)) AppendLog(LisunLocale.T("srv.panelCreated"));
            if (!server.PhpEnabled) AppendLog(LisunLocale.T("srv.panelNoPhp"));

            ShowPanelDialog(root);
        }

        private void ShowPanelDialog(string root)
        {
            string address = "http://localhost:" + (server.IsRunning ? server.Port : ReadPortBox()) + "/panel.php";

            using (Form dialog = new Form())
            {
                dialog.Text = LisunLocale.T("srv.panelTitle");
                dialog.ClientSize = new Size(640, 320);
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.MinimizeBox = false;
                dialog.MaximizeBox = false;
                dialog.BackColor = Theme.Background;
                dialog.ForeColor = Theme.Text;
                dialog.Font = Theme.Ui(9.5f);

                Label hint = new Label();
                hint.Text = LisunLocale.T("srv.panelHint", address);
                hint.ForeColor = Theme.TextDim;
                hint.Font = Theme.Mono(9f);
                hint.AutoSize = false;
                hint.SetBounds(22, 20, 596, 60);

                Label state = new Label();
                state.ForeColor = LisunWebPanel.PasswordSet(root) ? Theme.Success : Theme.Warning;
                state.Text = LisunWebPanel.PasswordSet(root) ? "" : LisunLocale.T("srv.panelNoPass");
                state.AutoSize = false;
                state.SetBounds(22, 86, 596, 24);

                Label caption = new Label();
                caption.Text = LisunLocale.T("srv.panelPass");
                caption.ForeColor = Theme.TextDim;
                caption.SetBounds(22, 126, 596, 20);

                TextBox passBox = new TextBox();
                passBox.BackColor = Theme.Surface;
                passBox.ForeColor = Theme.Text;
                passBox.BorderStyle = BorderStyle.FixedSingle;
                passBox.Font = Theme.Mono(11f);
                passBox.SetBounds(22, 150, 470, 30);

                Button random = new Button();
                random.Text = LisunLocale.T("srv.panelRandom");
                random.SetBounds(502, 150, 116, 30);
                Theme.StyleButton(random, Theme.SurfaceAlt, Theme.Text);
                random.Click += (s, a) => passBox.Text = LisunWebPanel.GeneratePassword();

                Button save = new Button();
                save.Text = LisunLocale.T("srv.panelSet");
                save.SetBounds(22, 248, 170, 34);
                Theme.StyleButton(save, Theme.AccentDeep, Theme.Text);
                save.Click += (s, a) =>
                {
                    if (!LisunWebPanel.SetPassword(root, passBox.Text.Trim()))
                    {
                        AppendLog(LisunLocale.T("srv.panelShort"));
                        state.ForeColor = Theme.Danger;
                        state.Text = LisunLocale.T("srv.panelShort");
                        return;
                    }

                    AppendLog(LisunLocale.T("srv.panelSaved"));
                    state.ForeColor = Theme.Success;
                    state.Text = LisunLocale.T("srv.panelSaved");
                };

                Button open = new Button();
                open.Text = LisunLocale.T("srv.panelOpen");
                open.SetBounds(202, 248, 170, 34);
                Theme.StyleButton(open, Color.FromArgb(27, 67, 50), Theme.Success);
                open.Click += (s, a) =>
                {
                    if (!server.IsRunning)
                    {
                        AppendLog(LisunLocale.T("srv.panelNeedRun"));
                        return;
                    }

                    AppendLog(LisunLocale.T("srv.opening", address));
                    if (!LisunEngine.OpenInShellBrowser(address))
                    {
                        try { Process.Start(address); }
                        catch (Exception ex) { AppendLog("[ERROR] " + ex.Message); }
                    }
                };

                Button close = new Button();
                close.Text = LisunLocale.T("dialog.ok");
                close.DialogResult = DialogResult.OK;
                close.SetBounds(508, 248, 110, 34);
                Theme.StyleButton(close, Theme.SurfaceAlt, Theme.Text);

                dialog.Controls.Add(hint);
                dialog.Controls.Add(state);
                dialog.Controls.Add(caption);
                dialog.Controls.Add(passBox);
                dialog.Controls.Add(random);
                dialog.Controls.Add(save);
                dialog.Controls.Add(open);
                dialog.Controls.Add(close);
                dialog.AcceptButton = close;
                dialog.CancelButton = close;

                if (form != null) dialog.ShowDialog(form);
                else dialog.ShowDialog();
            }
        }

        private int ReadPortBox()
        {
            int port;
            if (txtPort != null && int.TryParse(txtPort.Text.Trim(), out port) && port > 0) return port;
            return 8080;
        }

        /// <summary>Показывает секретный ключ Server API с копированием и сменой.</summary>
        private void btnApiKey_Click(object sender, EventArgs e)
        {
            string root = ResolveRoot();

            try
            {
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);
            }
            catch (Exception ex)
            {
                AppendLog("[ERROR] " + ex.Message);
                return;
            }

            if (!server.PhpEnabled) AppendLog(LisunLocale.T("srv.apiNoPhp"));
            else if (LisunApiEndpoint.EnsureFiles(root)) AppendLog(LisunLocale.T("srv.apiCreated"));

            string key = LisunApiEndpoint.GetOrCreateKey(root);
            ShowApiKeyDialog(root, key);
        }

        private void ShowApiKeyDialog(string root, string key)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = LisunLocale.T("srv.apiTitle");
                dialog.ClientSize = new Size(620, 300);
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterParent;
                dialog.MinimizeBox = false;
                dialog.MaximizeBox = false;
                dialog.BackColor = Theme.Background;
                dialog.ForeColor = Theme.Text;
                dialog.Font = Theme.Ui(9.5f);

                TextBox keyBox = new TextBox();
                keyBox.Text = key;
                keyBox.ReadOnly = true;
                keyBox.BackColor = Theme.Surface;
                keyBox.ForeColor = Theme.Magenta;
                keyBox.BorderStyle = BorderStyle.FixedSingle;
                keyBox.Font = Theme.Mono(10.5f);
                keyBox.SetBounds(22, 24, 576, 30);

                Label hint = new Label();
                hint.Text = LisunLocale.T("srv.apiHint");
                hint.ForeColor = Theme.TextDim;
                hint.Font = Theme.Mono(9f);
                hint.AutoSize = false;
                hint.SetBounds(22, 68, 576, 130);

                Button copy = new Button();
                copy.Text = LisunLocale.T("srv.apiCopy");
                copy.SetBounds(22, 232, 150, 34);
                Theme.StyleButton(copy, Theme.AccentDeep, Theme.Text);
                copy.Click += (s, a) =>
                {
                    try
                    {
                        Clipboard.SetText(keyBox.Text);
                        AppendLog(LisunLocale.T("srv.apiCopied"));
                    }
                    catch (Exception ex) { AppendLog("[ERROR] " + ex.Message); }
                };

                Button regenerate = new Button();
                regenerate.Text = LisunLocale.T("srv.apiRegenerate");
                regenerate.SetBounds(182, 232, 150, 34);
                Theme.StyleButton(regenerate, Color.FromArgb(82, 30, 30), Theme.Danger);
                regenerate.Click += (s, a) =>
                {
                    if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) return;

                    keyBox.Text = LisunApiEndpoint.RegenerateKey(root);
                    AppendLog(LisunLocale.T("srv.apiRegenerated"));
                };

                Button close = new Button();
                close.Text = LisunLocale.T("dialog.ok");
                close.DialogResult = DialogResult.OK;
                close.SetBounds(488, 232, 110, 34);
                Theme.StyleButton(close, Theme.SurfaceAlt, Theme.Text);

                dialog.Controls.Add(keyBox);
                dialog.Controls.Add(hint);
                dialog.Controls.Add(copy);
                dialog.Controls.Add(regenerate);
                dialog.Controls.Add(close);
                dialog.AcceptButton = close;
                dialog.CancelButton = close;

                if (form != null) dialog.ShowDialog(form);
                else dialog.ShowDialog();
            }
        }

        /// <summary>Открывает управление файлами корневой папки сайта.</summary>
        private void btnManageFiles_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;

            string root = ResolveRoot();

            try
            {
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);
            }
            catch (Exception ex)
            {
                AppendLog("[ERROR] " + ex.Message);
                return;
            }

            AppendLog(LisunLocale.T("srv.filesOpened", CustomFormUtils.ToVirtualPath(root)));

            using (LisunFileManagerForm manager = new LisunFileManagerForm(root, packageName,
                LisunLocale.T("srv.filesTitle", CustomFormUtils.ToVirtualPath(root))))
            {
                if (form != null) manager.ShowDialog(form);
                else manager.ShowDialog();
            }
        }

        private void chkRemote_CheckedChanged(object sender, EventArgs e)
        {
            if (chkRemote == null) return;

            if (LisunPermissions.Check(packageName, LisunPermissions.EditSettings))
            {
                LisunEngine.RegistryData["server_remote"] = chkRemote.Checked ? "true" : "false";
                LisunEngine.SaveRegistry();
            }

            AppendLog(chkRemote.Checked
                ? LisunLocale.T("srv.remoteOn")
                : LisunLocale.T("srv.remoteOff"));
        }

        private void chkListing_CheckedChanged(object sender, EventArgs e)
        {
            if (chkListing == null) return;
            server.AllowDirectoryListing = chkListing.Checked;
        }

        private void chkUfw_CheckedChanged(object sender, EventArgs e)
        {
            if (chkUfw == null) return;
            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings))
            {
                chkUfw.Checked = LisunFirewall.Enabled;
                return;
            }

            if (chkUfw.Checked) LisunFirewall.Enable();
            else LisunFirewall.Disable();

            AppendLog(LisunLocale.T("srv.ufwState",
                LisunFirewall.Enabled ? LisunLocale.T("ufw.on") : LisunLocale.T("ufw.off")));
        }

        private string ResolveRoot()
        {
            string fallback = Path.Combine(LisunEngine.RootPath, "root", "www");
            if (txtRoot == null) return fallback;

            string value = txtRoot.Text.Trim();
            if (value.Length == 0) return fallback;

            // Путь может быть виртуальным (LisunOS:\root\www) или реальным.
            if (value.StartsWith("LisunOS:", StringComparison.OrdinalIgnoreCase))
            {
                string tail = value.Substring(8).TrimStart('\\', '/');
                return Path.Combine(LisunEngine.RootPath, tail);
            }

            string resolved;
            if (CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, value, out resolved)) return resolved;

            return fallback;
        }
    }
}
