﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>
    /// Фоновые службы LisunOS — те, что работают без окна.
    ///
    /// Описываются в .service рядом с обычным приложением:
    ///
    ///     daemon watcher
    ///         description = "Следит за папкой www"
    ///         run         = "ls root/www"
    ///         interval    = 60
    ///         autostart   = true
    ///         permission  = read_files
    ///     end
    ///
    /// Команда из run выполняется раз в interval секунд тем же исполнителем,
    /// что и терминал, поэтому доступно всё, что умеет система.
    /// </summary>
    public static class LisunDaemons
    {
        public sealed class Daemon
        {
            public string Name = string.Empty;
            public string PackageName = string.Empty;
            public string Description = string.Empty;
            public string Command = string.Empty;
            public string Permission = string.Empty;

            public int IntervalSeconds = 60;
            public bool Autostart;

            public bool Running;
            public DateTime StartedAt;
            public DateTime LastRunAt;
            public DateTime NextRunAt;
            public long Runs;
            public long Failures;
            public string LastOutput = string.Empty;

            /// <summary>Сколько осталось до следующего запуска.</summary>
            public TimeSpan Remaining
            {
                get
                {
                    if (!Running) return TimeSpan.Zero;

                    TimeSpan left = NextRunAt - DateTime.Now;
                    return left < TimeSpan.Zero ? TimeSpan.Zero : left;
                }
            }
        }

        private static readonly object gate = new object();

        private static readonly Dictionary<string, Daemon> daemons =
            new Dictionary<string, Daemon>(StringComparer.OrdinalIgnoreCase);

        private static Timer timer;
        private static bool ticking;

        /// <summary>Файл автозапуска фоновых служб.</summary>
        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "DAEMONS"); }
        }

        public static int Count
        {
            get { lock (gate) return daemons.Count; }
        }

        public static int RunningCount
        {
            get
            {
                lock (gate)
                {
                    int count = 0;
                    foreach (Daemon daemon in daemons.Values)
                        if (daemon.Running) count++;

                    return count;
                }
            }
        }

        public static List<Daemon> All()
        {
            List<Daemon> result;

            lock (gate) result = new List<Daemon>(daemons.Values);

            result.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));
            return result;
        }

        public static Daemon Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;

            lock (gate)
            {
                Daemon daemon;
                return daemons.TryGetValue(name.Trim(), out daemon) ? daemon : null;
            }
        }

        public static List<string> Names()
        {
            List<string> result = new List<string>();
            foreach (Daemon daemon in All()) result.Add(daemon.Name);

            return result;
        }

        // =====================================================================
        //  Регистрация из .service
        // =====================================================================

        /// <summary>
        /// Добавляет или обновляет описание фоновой службы.
        /// Вызывается разбором .service, когда встречается блок daemon.
        /// </summary>
        public static Daemon Register(Daemon daemon)
        {
            if (daemon == null || daemon.Name.Length == 0) return null;

            if (daemon.IntervalSeconds < 1) daemon.IntervalSeconds = 60;
            if (daemon.IntervalSeconds > 86400) daemon.IntervalSeconds = 86400;

            lock (gate)
            {
                Daemon existing;
                if (daemons.TryGetValue(daemon.Name, out existing))
                {
                    // Перезапуск службы не должен терять счётчики.
                    daemon.Running = existing.Running;
                    daemon.Runs = existing.Runs;
                    daemon.Failures = existing.Failures;
                    daemon.StartedAt = existing.StartedAt;
                    daemon.LastRunAt = existing.LastRunAt;
                    daemon.LastOutput = existing.LastOutput;
                }

                daemons[daemon.Name] = daemon;
            }

            LisunEngine.Log("[daemon] " + LisunLocale.T("daemon.registered", daemon.Name,
                daemon.IntervalSeconds).Trim());

            if (daemon.Autostart && Enabled(daemon.Name)) Start(daemon.Name);

            EnsureTimer();
            return daemon;
        }

        /// <summary>Убирает все фоновые службы пакета — при выгрузке или удалении.</summary>
        public static int RemovePackage(string packageName)
        {
            if (string.IsNullOrEmpty(packageName)) return 0;

            List<string> targets = new List<string>();

            lock (gate)
            {
                foreach (KeyValuePair<string, Daemon> item in daemons)
                    if (string.Equals(item.Value.PackageName, packageName, StringComparison.OrdinalIgnoreCase))
                        targets.Add(item.Key);

                foreach (string name in targets) daemons.Remove(name);
            }

            return targets.Count;
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        public static bool Start(string name)
        {
            Daemon daemon = Find(name);
            if (daemon == null) return false;

            lock (gate)
            {
                daemon.Running = true;
                daemon.StartedAt = DateTime.Now;
                daemon.NextRunAt = DateTime.Now;
            }

            LisunEngine.Log("[daemon] " + LisunLocale.T("daemon.started", daemon.Name).Trim());

            EnsureTimer();
            return true;
        }

        public static bool Stop(string name)
        {
            Daemon daemon = Find(name);
            if (daemon == null || !daemon.Running) return false;

            lock (gate) daemon.Running = false;

            LisunEngine.Log("[daemon] " + LisunLocale.T("daemon.stopped", daemon.Name).Trim());
            return true;
        }

        public static bool Restart(string name)
        {
            Daemon daemon = Find(name);
            if (daemon == null) return false;

            Stop(name);
            return Start(name);
        }

        /// <summary>Запускает команду службы немедленно, не дожидаясь таймера.</summary>
        public static string RunNow(string name)
        {
            Daemon daemon = Find(name);
            if (daemon == null) return LisunLocale.T("daemon.notFound", name);

            Execute(daemon);
            return LisunLocale.T("daemon.ranNow", daemon.Name, daemon.LastOutput);
        }

        // =====================================================================
        //  Автозапуск
        // =====================================================================

        private static readonly Dictionary<string, bool> autostartFlags =
            new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        private static bool flagsLoaded;

        public static bool Enabled(string name)
        {
            if (!flagsLoaded) LoadFlags();

            bool value;
            return !autostartFlags.TryGetValue(name, out value) || value;
        }

        public static bool SetEnabled(string name, bool value)
        {
            if (Find(name) == null) return false;

            if (!flagsLoaded) LoadFlags();

            autostartFlags[name] = value;
            SaveFlags();

            if (!value) Stop(name);
            return true;
        }

        private static void LoadFlags()
        {
            flagsLoaded = true;
            autostartFlags.Clear();

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    string[] parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length != 2) continue;

                    string value = parts[1].Trim().ToLowerInvariant();
                    autostartFlags[parts[0].Trim()] = value == "enabled" || value == "true" || value == "on";
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[daemon] [ОШИБКА] Чтение DAEMONS: " + ex.Message);
            }
        }

        private static void SaveFlags()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# Автозапуск фоновых служб LisunOS");

                foreach (KeyValuePair<string, bool> item in autostartFlags)
                    sb.AppendLine(item.Key + "=" + (item.Value ? "enabled" : "disabled"));

                CustomFormUtils.WriteFileText(StorePath, sb.ToString());
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[daemon] [ОШИБКА] Запись DAEMONS: " + ex.Message);
            }
        }

        // =====================================================================
        //  Таймер
        // =====================================================================

        private static void EnsureTimer()
        {
            lock (gate)
            {
                if (timer != null) return;

                // Тикаем раз в секунду: сами службы просыпаются по своему интервалу.
                timer = new Timer(Tick, null, 1000, 1000);
            }
        }

        /// <summary>Останавливает все службы — при выгрузке подсистем.</summary>
        public static void StopAll()
        {
            lock (gate)
            {
                foreach (Daemon daemon in daemons.Values) daemon.Running = false;
            }
        }

        private static void Tick(object ignored)
        {
            if (ticking) return;
            ticking = true;

            try
            {
                List<Daemon> due = new List<Daemon>();
                DateTime now = DateTime.Now;

                lock (gate)
                {
                    foreach (Daemon daemon in daemons.Values)
                        if (daemon.Running && now >= daemon.NextRunAt) due.Add(daemon);
                }

                foreach (Daemon daemon in due) Execute(daemon);
            }
            catch (Exception ex)
            {
                LisunEngine.RunOnUi(() => LisunEngine.Log("[daemon] [ОШИБКА] " + ex.Message));
            }
            finally { ticking = false; }
        }

        /// <summary>
        /// Выполняет команду службы. Исполнитель трогает формы и реестр,
        /// поэтому работа идёт в UI-потоке.
        /// </summary>
        private static void Execute(Daemon daemon)
        {
            lock (gate)
            {
                daemon.LastRunAt = DateTime.Now;
                daemon.NextRunAt = DateTime.Now.AddSeconds(daemon.IntervalSeconds);
                daemon.Runs++;
            }

            if (daemon.Command.Length == 0) return;

            // Служба без выданного права молча не работает: лучше остановить
            // и сказать об этом, чем крутить её вхолостую каждую минуту.
            if (daemon.Permission.Length > 0 &&
                !LisunPermissions.Check(daemon.PackageName, daemon.Permission))
            {
                lock (gate)
                {
                    daemon.Running = false;
                    daemon.Failures++;
                    daemon.LastOutput = LisunLocale.T("daemon.noRight", daemon.Permission);
                }

                LisunEngine.RunOnUi(() => LisunEngine.Log("[daemon] " +
                    LisunLocale.T("daemon.stoppedNoRight", daemon.Name, daemon.Permission).Trim()));
                return;
            }

            LisunEngine.RunOnUi(() =>
            {
                try
                {
                    string output = CommandExecutorEngine.Execute(daemon.Command);

                    lock (gate)
                    {
                        daemon.LastOutput = Compact(output);
                        if (daemon.LastOutput.IndexOf("[ERROR]", StringComparison.Ordinal) >= 0) daemon.Failures++;
                    }
                }
                catch (Exception ex)
                {
                    lock (gate)
                    {
                        daemon.Failures++;
                        daemon.LastOutput = "[ERROR] " + ex.Message;
                    }
                }
            });
        }

        private static string Compact(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;

            string single = text.Replace("\r", " ").Replace("\n", " ").Trim();
            while (single.IndexOf("  ", StringComparison.Ordinal) >= 0)
                single = single.Replace("  ", " ");

            return single.Length > 160 ? single.Substring(0, 160) + "…" : single;
        }

        // =====================================================================
        //  Вывод
        // =====================================================================

        public static string ListText()
        {
            List<Daemon> all = All();
            if (all.Count == 0) return LisunLocale.T("daemon.empty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("daemon.listTitle", all.Count, RunningCount));
            sb.AppendLine();

            foreach (Daemon daemon in all)
            {
                sb.AppendLine("   " + (daemon.Running ? "●" : "○") + " " +
                              daemon.Name.PadRight(18) +
                              (daemon.IntervalSeconds + "s").PadRight(8) +
                              LisunLocale.T(daemon.Running ? "daemon.stateRunning" : "daemon.stateStopped") +
                              (daemon.Running ? "  " + LisunLocale.T("daemon.in",
                                  (int)daemon.Remaining.TotalSeconds) : ""));

                if (daemon.Description.Length > 0) sb.AppendLine("       " + daemon.Description);
            }

            return sb.ToString().TrimEnd();
        }

        public static string StatusText(string name)
        {
            Daemon daemon = Find(name);
            if (daemon == null) return LisunLocale.T("daemon.notFound", name);

            StringBuilder sb = new StringBuilder(LisunLocale.T("daemon.statusTitle", daemon.Name));
            sb.AppendLine();

            sb.AppendLine("   " + LisunLocale.T("daemon.fieldState") + ": " +
                          LisunLocale.T(daemon.Running ? "daemon.stateRunning" : "daemon.stateStopped"));
            sb.AppendLine("   " + LisunLocale.T("daemon.fieldPackage") + ": " +
                          (daemon.PackageName.Length == 0 ? "—" : daemon.PackageName));
            sb.AppendLine("   " + LisunLocale.T("daemon.fieldCommand") + ": " + daemon.Command);
            sb.AppendLine("   " + LisunLocale.T("daemon.fieldInterval") + ": " + daemon.IntervalSeconds + " с");
            sb.AppendLine("   " + LisunLocale.T("daemon.fieldAutostart") + ": " +
                          LisunLocale.T(Enabled(daemon.Name) ? "php.on" : "php.off"));

            if (daemon.Permission.Length > 0)
                sb.AppendLine("   " + LisunLocale.T("daemon.fieldRight") + ": " + daemon.Permission);

            sb.AppendLine("   " + LisunLocale.T("daemon.fieldRuns") + ": " + daemon.Runs +
                          (daemon.Failures > 0 ? "  (" + LisunLocale.T("daemon.failures", daemon.Failures) + ")" : ""));

            if (daemon.Running)
                sb.AppendLine("   " + LisunLocale.T("daemon.fieldNext") + ": " +
                              (int)daemon.Remaining.TotalSeconds + " с");

            if (daemon.LastRunAt != DateTime.MinValue)
                sb.AppendLine("   " + LisunLocale.T("daemon.fieldLast") + ": " +
                              daemon.LastRunAt.ToString("HH:mm:ss", CultureInfo.InvariantCulture));

            if (daemon.LastOutput.Length > 0)
                sb.AppendLine("   " + LisunLocale.T("daemon.fieldOutput") + ": " + daemon.LastOutput);

            return sb.ToString().TrimEnd();
        }
    }
}
