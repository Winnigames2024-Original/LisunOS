﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика приложения «SystemOptimizer» (пакет apps/sysoptapp).
    ///
    /// Окно отвечает на вопрос «что сейчас работает вхолостую». В списке
    /// видно всё, чем система занята: приложения, службы, фоновые демоны,
    /// серверы. У каждой строки написано, работает она на кого-то или
    /// впустую, и — главное — какой командой её вернуть.
    ///
    /// Ничего не удаляется: оптимизатор только останавливает, и всё, что он
    /// остановил, включается обратно той же командой, что показана в списке.
    /// </summary>
    public partial class OptimizerLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label subtitle;

        private readonly ListView list;
        private readonly Label commands;

        private readonly Button refresh;
        private readonly Button stop;
        private readonly Button start;
        private readonly Button optimize;
        private readonly Button report;

        private readonly TextBox log;
        private readonly Label status;

        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        private readonly List<LisunOptimizer.Item> rows = new List<LisunOptimizer.Item>();

        private bool closing;

        public OptimizerLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblTitle");
            subtitle = context.Get<Label>("lblSubtitle");

            list = context.Get<ListView>("lstOptimizer");
            commands = context.Get<Label>("lblCommands");

            refresh = context.Get<Button>("btnRefresh");
            stop = context.Get<Button>("btnStopSelected");
            start = context.Get<Button>("btnStartSelected");
            optimize = context.Get<Button>("btnOptimize");
            report = context.Get<Button>("btnReport");

            log = context.Get<TextBox>("txtOptLog");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("optapp.windowTitle");
                form.Disposed += delegate
                {
                    closing = true;
                    try { timer.Stop(); timer.Dispose(); }
                    catch { }
                };
            }

            if (title != null)
            {
                title.Text = LisunLocale.T("optapp.windowTitle");
                title.Font = Theme.Ui(14f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
            }

            if (subtitle != null)
            {
                subtitle.Text = LisunLocale.T("optapp.subtitle");
                subtitle.Font = Theme.Ui(9f);
                subtitle.ForeColor = Theme.TextDim;
            }

            if (list != null)
            {
                list.Font = Theme.Mono(9.5f);
                list.Columns.Add(LisunLocale.T("optapp.columnName"), 180);
                list.Columns.Add(LisunLocale.T("optapp.columnKind"), 120);
                list.Columns.Add(LisunLocale.T("optapp.columnState"), 130);
                list.Columns.Add(LisunLocale.T("optapp.columnWhy"), 400);
            }

            if (commands != null)
            {
                commands.Font = Theme.Mono(9f);
                commands.ForeColor = Theme.Cyan;
            }

            if (refresh != null)
            {
                refresh.Text = LisunLocale.T("optapp.refresh");
                Theme.StyleButton(refresh, Theme.SurfaceAlt, Theme.Text);
            }

            if (stop != null)
            {
                stop.Text = LisunLocale.T("optapp.stop");
                Theme.StyleButton(stop, Theme.SurfaceAlt, Theme.Warning);
            }

            if (start != null)
            {
                start.Text = LisunLocale.T("optapp.start");
                Theme.StyleButton(start, Theme.AccentDeep, Theme.Text);
            }

            if (optimize != null)
            {
                optimize.Text = LisunLocale.T("optapp.optimize");
                Theme.StyleButton(optimize, Theme.AccentDeep, Theme.Text);
            }

            if (report != null)
            {
                report.Text = LisunLocale.T("optapp.report");
                Theme.StyleButton(report, Theme.SurfaceAlt, Theme.Text);
            }

            if (log != null) log.Font = Theme.Mono(9f);
            if (status != null) status.Font = Theme.Mono(8.75f);

            Fill();

            timer.Interval = 4000;
            timer.Tick += delegate { if (!closing) Fill(); };
            timer.Start();

            SetStatus(LisunLocale.T("optapp.ready"));
        }

        // =====================================================================
        //  Список
        // =====================================================================

        private void Fill()
        {
            if (list == null) return;

            string selected = SelectedName();

            List<LisunOptimizer.Item> items;
            try { items = LisunOptimizer.Scan(); }
            catch { items = new List<LisunOptimizer.Item>(); }

            list.BeginUpdate();
            list.Items.Clear();
            rows.Clear();

            int idle = 0;

            foreach (LisunOptimizer.Item item in items)
            {
                string state = item.Running
                    ? (item.Idle ? LisunLocale.T("opt.stateIdle") : LisunLocale.T("opt.stateWorking"))
                    : LisunLocale.T("opt.stateStopped");

                ListViewItem row = new ListViewItem(item.Name);
                row.SubItems.Add(item.Kind);
                row.SubItems.Add(state);
                row.SubItems.Add(item.Why);

                row.ForeColor = item.Idle ? Theme.Warning
                              : item.Running ? Theme.Success
                                             : Theme.TextDim;

                list.Items.Add(row);
                rows.Add(item);

                if (item.Idle) idle++;
            }

            list.EndUpdate();

            if (selected != null) Select(selected);
            if (list.SelectedIndices.Count == 0 && list.Items.Count > 0) list.Items[0].Selected = true;

            if (subtitle != null)
                subtitle.Text = LisunLocale.T("optapp.counters", items.Count, idle);

            if (optimize != null) optimize.Enabled = idle > 0;
        }

        private string SelectedName()
        {
            LisunOptimizer.Item item = Selected();
            return item == null ? null : item.Name;
        }

        private LisunOptimizer.Item Selected()
        {
            if (list == null || list.SelectedIndices.Count == 0) return null;

            int index = list.SelectedIndices[0];
            if (index < 0 || index >= rows.Count) return null;

            return rows[index];
        }

        private void Select(string name)
        {
            for (int index = 0; index < rows.Count; index++)
            {
                if (!string.Equals(rows[index].Name, name, StringComparison.OrdinalIgnoreCase)) continue;

                list.Items[index].Selected = true;
                list.Items[index].EnsureVisible();
                return;
            }
        }

        private void Append(string text)
        {
            if (log == null) return;

            log.AppendText((text ?? string.Empty).TrimEnd() + Environment.NewLine);
            log.SelectionStart = log.TextLength;
            log.ScrollToCaret();
        }

        private void SetStatus(string text)
        {
            if (status == null) return;

            status.Text = " " + (text ?? string.Empty).Trim();
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        public void lstOptimizer_SelectedIndexChanged(object sender, EventArgs e)
        {
            LisunOptimizer.Item item = Selected();

            if (item == null)
            {
                if (commands != null) commands.Text = string.Empty;
                return;
            }

            if (commands != null)
                commands.Text = LisunLocale.T("optapp.commands", item.StopCommand, item.StartCommand);

            if (stop != null) stop.Enabled = item.Running;
            if (start != null) start.Enabled = !item.Running;
        }

        public void btnRefresh_Click(object sender, EventArgs e)
        {
            Fill();
            SetStatus(LisunLocale.T("optapp.refreshed"));
        }

        public void btnStopSelected_Click(object sender, EventArgs e)
        {
            LisunOptimizer.Item item = Selected();

            if (item == null)
            {
                SetStatus(LisunLocale.T("optapp.pick"));
                return;
            }

            string message;
            LisunOptimizer.Stop(item.Name, out message);

            Append(item.Name + ": " + message.Trim());
            Append("   " + LisunLocale.T("opt.backWith", item.StartCommand));

            SetStatus(LisunLocale.T("optapp.stoppedOne", item.Name, item.StartCommand));
            Fill();
        }

        public void btnStartSelected_Click(object sender, EventArgs e)
        {
            LisunOptimizer.Item item = Selected();

            if (item == null)
            {
                SetStatus(LisunLocale.T("optapp.pick"));
                return;
            }

            string message;
            LisunOptimizer.Start(item.Name, out message);

            Append(item.Name + ": " + message.Trim());
            SetStatus(LisunLocale.T("optapp.startedOne", item.Name));

            Fill();
        }

        public void btnOptimize_Click(object sender, EventArgs e)
        {
            DialogResult answer = MessageBox.Show(
                LisunLocale.T("optapp.confirmBody"),
                LisunLocale.T("optapp.confirmTitle"),
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1);

            if (answer != DialogResult.Yes)
            {
                SetStatus(LisunLocale.T("optapp.cancelled"));
                return;
            }

            string report = LisunOptimizer.Optimize(true);

            foreach (string line in report.Split('\n'))
                if (line.Trim().Length > 0) Append(line);

            SetStatus(LisunLocale.T("optapp.optimized"));
            Fill();
        }

        public void btnReport_Click(object sender, EventArgs e)
        {
            // Тот же отчёт, что у команды perf: где именно система подвисала.
            foreach (string line in LisunPerf.ReportText().Split('\n'))
                if (line.Trim().Length > 0) Append(line);

            SetStatus(LisunLocale.T("optapp.reportDone"));
        }
    }
}
