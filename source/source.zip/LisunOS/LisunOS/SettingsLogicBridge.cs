﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика окна «Параметры системы» (пакет apps/settingsapp).
    /// Собирает в одном месте то, что иначе набирается командами:
    /// lang, layout, perm, webserverv2 и php-frm.
    /// </summary>
    public partial class SettingsLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly ComboBox language;
        private readonly ComboBox layout;
        private readonly ComboBox application;
        private readonly ListView permissions;
        private readonly Label serverState;
        private readonly Label status;
        private readonly Label title;
        private readonly Label subtitle;

        private bool filling;

        public SettingsLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            language = context.Get<ComboBox>("cmbLanguage");
            layout = context.Get<ComboBox>("cmbLayout");
            application = context.Get<ComboBox>("cmbApplication");
            permissions = context.Get<ListView>("lstPermissions");
            serverState = context.Get<Label>("lblServerState");
            status = context.Get<Label>("lblStatus");
            title = context.Get<Label>("lblTitle");
            subtitle = context.Get<Label>("lblSubtitle");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("settings.title");
            if (title != null)
            {
                title.Text = LisunLocale.T("settings.title");
                title.Font = Theme.Ui(14f, System.Drawing.FontStyle.Bold);
            }
            if (subtitle != null) subtitle.Text = LisunLocale.T("settings.subtitle");

            if (serverState != null) serverState.Font = Theme.Mono(9f);
            if (status != null) status.Font = Theme.Mono(8.75f);

            if (permissions != null)
            {
                permissions.Font = Theme.Mono(9.5f);
                permissions.Columns.Add(LisunLocale.T("settings.columnRight"), 170);
                permissions.Columns.Add(LisunLocale.T("settings.columnState"), 110);
                permissions.Columns.Add(LisunLocale.T("settings.columnWhat"), 260);
            }

            FillLanguages();
            FillLayouts();
            FillApplications();
            RefreshServer();

            SetStatus(LisunLocale.T("settings.ready"));
        }

        // =====================================================================
        //  Заполнение списков
        // =====================================================================

        private void FillLanguages()
        {
            if (language == null) return;

            filling = true;
            language.Items.Clear();

            foreach (LisunLocale.LanguagePack pack in LisunLocale.Available())
            {
                bool builtIn = pack.Code == "ru" || pack.Code == "en";

                language.Items.Add(pack.Name + "  (" + pack.Code +
                    (builtIn ? ")" : ", " + pack.Completeness + "%)"));

                if (pack.Code.Equals(LisunLocale.Code, StringComparison.OrdinalIgnoreCase))
                    language.SelectedIndex = language.Items.Count - 1;
            }

            filling = false;
        }

        private void FillLayouts()
        {
            if (layout == null) return;

            filling = true;
            layout.Items.Clear();

            try
            {
                foreach (InputLanguage installed in InputLanguage.InstalledInputLanguages)
                {
                    string code = installed.Culture.TwoLetterISOLanguageName.ToUpperInvariant();
                    layout.Items.Add(code + "  —  " + installed.Culture.NativeName);

                    if (code.Equals(LisunLocale.LayoutTag, StringComparison.OrdinalIgnoreCase))
                        layout.SelectedIndex = layout.Items.Count - 1;
                }
            }
            catch { }

            if (layout.Items.Count == 0) layout.Items.Add(LisunLocale.T("menu.noLayouts"));

            filling = false;
        }

        private void FillApplications()
        {
            if (application == null) return;

            filling = true;
            application.Items.Clear();

            List<string> names = new List<string>();

            foreach (string directory in LisunOSInstallerShell.InstalledPackageDirectories())
            {
                LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);
                if (manifest != null && manifest.Name.Length > 0 && !names.Contains(manifest.Name))
                    names.Add(manifest.Name);
            }

            foreach (string granted in LisunPermissions.ApplicationsWithGrants())
                if (!names.Contains(granted)) names.Add(granted);

            if (!names.Contains(LisunPhpModule.PackageName)) names.Add(LisunPhpModule.PackageName);
            if (!names.Contains(LisunWifi.PackageName)) names.Add(LisunWifi.PackageName);
            if (!names.Contains(LisunSystemServer.HallApplication)) names.Add(LisunSystemServer.HallApplication);

            names.Sort(StringComparer.OrdinalIgnoreCase);
            foreach (string name in names) application.Items.Add(name);

            if (application.Items.Count > 0) application.SelectedIndex = 0;

            filling = false;
            FillPermissions();
        }

        private void FillPermissions()
        {
            if (permissions == null) return;

            permissions.Items.Clear();

            string target = SelectedApplication;
            if (target.Length == 0) return;

            foreach (string right in LisunPermissions.Known)
            {
                bool granted = LisunPermissions.IsGranted(target, right);

                ListViewItem item = new ListViewItem(right);
                item.SubItems.Add(LisunLocale.T(granted ? "sys.granted" : "sys.denied"));
                item.SubItems.Add(LisunPermissions.Describe(right));
                item.ForeColor = granted ? Theme.Success : Theme.TextDim;
                item.Tag = right;

                permissions.Items.Add(item);
            }
        }

        private string SelectedApplication
        {
            get
            {
                if (application == null || application.SelectedItem == null) return string.Empty;
                return application.SelectedItem.ToString();
            }
        }

        private string SelectedRight
        {
            get
            {
                if (permissions == null || permissions.SelectedItems.Count == 0) return string.Empty;
                return permissions.SelectedItems[0].Tag as string ?? string.Empty;
            }
        }

        private void RefreshServer()
        {
            if (serverState == null) return;

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.AppendLine(LisunLocale.T("settings.phpLine",
                LisunLocale.T(LisunPhpModule.IsInstalled ? "php.on" : "php.off"),
                LisunPhpModule.FindPhp() ?? LisunLocale.T("php.engineName")));

            sb.AppendLine(LisunLocale.T("settings.portLine",
                LisunSystemServer.Port,
                LisunLocale.T(LisunSystemServer.Running ? "sys.open" : "sys.closed"),
                LisunLocale.T(LisunSystemServer.HallGranted ? "sys.granted" : "sys.denied")));

            sb.Append(LisunLocale.T("settings.netLine",
                LisunLocale.T(LisunWifi.Online ? "wifi.stateOnline" : "wifi.stateOffline"),
                LisunWifi.CurrentSsid().Length == 0 ? "—" : LisunWifi.CurrentSsid()));

            serverState.Text = sb.ToString();
        }

        private void SetStatus(string text)
        {
            if (status != null && !status.IsDisposed) status.Text = text;
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        private void cmbLanguage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filling || language == null || language.SelectedIndex < 0) return;

            List<LisunLocale.LanguagePack> packs = LisunLocale.Available();
            if (language.SelectedIndex >= packs.Count) return;

            string code = packs[language.SelectedIndex].Code;

            if (!LisunLocale.SetLanguage(code))
            {
                SetStatus(LisunLocale.T("lang.unknown", code));
                return;
            }

            SetStatus(LisunLocale.T("msg.langChanged", LisunLocale.DisplayName));

            // Надписи окна обновляются сразу, без перезапуска приложения.
            Initialize();
        }

        private void cmbLayout_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filling || layout == null || layout.SelectedItem == null) return;

            string text = layout.SelectedItem.ToString();
            int mark = text.IndexOf(' ');
            string code = mark > 0 ? text.Substring(0, mark) : text;

            SetStatus(LisunLocale.SetLayout(code)
                ? LisunLocale.T("msg.layoutChanged", code)
                : LisunLocale.T("msg.layoutMissing", code));
        }

        private void btnReloadPacks_Click(object sender, EventArgs e)
        {
            SetStatus(LisunLocale.T("lang.reloaded", LisunLocale.LoadPacks()));
            FillLanguages();
        }

        private void cmbApplication_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filling) return;
            FillPermissions();
        }

        private void lstPermissions_DoubleClick(object sender, EventArgs e)
        {
            string right = SelectedRight;
            string target = SelectedApplication;

            if (right.Length == 0 || target.Length == 0) return;

            if (LisunPermissions.IsGranted(target, right)) Revoke(target, right);
            else Grant(target, right);
        }

        private void btnGrant_Click(object sender, EventArgs e)
        {
            Grant(SelectedApplication, SelectedRight);
        }

        private void btnRevoke_Click(object sender, EventArgs e)
        {
            Revoke(SelectedApplication, SelectedRight);
        }

        private void Grant(string target, string right)
        {
            if (target.Length == 0 || right.Length == 0)
            {
                SetStatus(LisunLocale.T("settings.pickRight"));
                return;
            }

            // Изменение чужих прав — само по себе право edit_settings.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) return;

            LisunPermissions.Grant(target, right);
            FillPermissions();

            SetStatus(LisunLocale.T("perm.granted", target, right));
        }

        private void Revoke(string target, string right)
        {
            if (target.Length == 0 || right.Length == 0)
            {
                SetStatus(LisunLocale.T("settings.pickRight"));
                return;
            }

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) return;

            LisunPermissions.Revoke(target, right);
            FillPermissions();

            SetStatus(LisunLocale.T("perm.revoked", target, right));
        }

        private void btnResetRights_Click(object sender, EventArgs e)
        {
            string target = SelectedApplication;
            if (target.Length == 0) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) return;

            DialogResult answer = MessageBox.Show(
                LisunLocale.T("settings.resetAsk", target),
                LisunLocale.T("settings.title"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (answer != DialogResult.Yes) return;

            LisunPermissions.Reset(target);
            FillPermissions();

            SetStatus(LisunLocale.T("perm.resetDone", target));
        }

        private void btnOpenServer_Click(object sender, EventArgs e)
        {
            SetStatus(CommandExecutorEngine.Execute("webserverv2"));
        }

        private void btnOpenSetup_Click(object sender, EventArgs e)
        {
            SetStatus(CommandExecutorEngine.Execute("system open"));
            RefreshServer();
        }

        private void btnPhpStatus_Click(object sender, EventArgs e)
        {
            RefreshServer();
            FillApplications();

            SetStatus(LisunLocale.T("settings.refreshed"));
        }
    }
}
