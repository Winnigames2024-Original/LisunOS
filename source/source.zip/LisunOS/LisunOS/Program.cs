﻿using System;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Необработанные исключения больше не убивают процесс молча.
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => ReportCrash(e.Exception);
            AppDomain.CurrentDomain.UnhandledException += (s, e) => ReportCrash(e.ExceptionObject as Exception);

            // ВАЖНО: ядро больше НЕ стартует здесь.
            // Раньше Initialize() и StartServicesAndBlock() вызывались и тут, и в Form1 —
            // ядро грузилось дважды, а формы сервисов создавались до появления цикла сообщений.
            // Теперь вся загрузка идёт внутри Form1 в UI-потоке, с экраном загрузки.
            Application.Run(new Form1());
        }

        private static void ReportCrash(Exception ex)
        {
            if (ex == null) return;

            try { LisunEngine.Log("[FATAL] " + ex.GetType().Name + ": " + ex.Message); }
            catch { }

            StringBuilder report = new StringBuilder();
            report.AppendLine("Ядро LisunOS перехватило необработанное исключение.");
            report.AppendLine();
            report.AppendLine(ex.GetType().FullName);
            report.AppendLine(ex.Message);
            report.AppendLine();
            report.AppendLine(ex.StackTrace);

            MessageBox.Show(report.ToString(), "LisunOS — Kernel Panic",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
