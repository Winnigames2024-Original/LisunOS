﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика приложения «Wi-Fi» (пакет apps/wifiapp).
    ///
    /// Окно отвечает на один вопрос: какие сети видно вокруг и как к ним
    /// подключиться. Поэтому список занимает почти всё окно: имя сети, уровень
    /// сигнала полосками, защита и то, подключены мы к ней или она просто
    /// сохранена. Поиск сетей идёт в отдельном потоке — netsh отвечает
    /// две-три секунды, и всё это время окно должно оставаться живым.
    ///
    /// Справа — то, что делают с выбранной сетью: пароль, подключение,
    /// «забыть», страница входа. Ниже — загрузки: когда интернет появился,
    /// видно, что система догружает, и можно сразу докачать то, чего не хватает.
    /// </summary>
    public partial class WifiLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label state;

        private readonly Label networksCaption;
        private readonly ListView networks;
        private readonly Button scan;
        private readonly CheckBox autoScan;
        private readonly Label signalHint;

        private readonly Label connectCaption;
        private readonly Label passwordCaption;
        private readonly TextBox password;
        private readonly CheckBox showPassword;
        private readonly Button connect;
        private readonly Button disconnect;
        private readonly Button forget;
        private readonly Button portal;
        private readonly Label internet;

        private readonly Label downloadsCaption;
        private readonly ListBox downloads;
        private readonly ProgressBar progress;
        private readonly Button components;
        private readonly Button cancel;
        private readonly Label componentsState;

        private readonly Label status;

        private readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();

        private readonly List<WifiNetwork> rows = new List<WifiNetwork>();
        private List<string> saved = new List<string>();

        private bool busy;
        private bool closing;
        private DateTime lastScan = DateTime.MinValue;

        public WifiLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblTitle");
            state = context.Get<Label>("lblState");

            networksCaption = context.Get<Label>("lblNetworksCaption");
            networks = context.Get<ListView>("lstWifiNetworks");
            scan = context.Get<Button>("btnScan");
            autoScan = context.Get<CheckBox>("chkAutoScan");
            signalHint = context.Get<Label>("lblSignalHint");

            connectCaption = context.Get<Label>("lblConnectCaption");
            passwordCaption = context.Get<Label>("lblPasswordCaption");
            password = context.Get<TextBox>("txtWifiPassword");
            showPassword = context.Get<CheckBox>("chkShowPassword");
            connect = context.Get<Button>("btnConnect");
            disconnect = context.Get<Button>("btnDisconnect");
            forget = context.Get<Button>("btnForget");
            portal = context.Get<Button>("btnPortal");
            internet = context.Get<Label>("lblInternet");

            downloadsCaption = context.Get<Label>("lblDownloadsCaption");
            downloads = context.Get<ListBox>("lstDownloads");
            progress = context.Get<ProgressBar>("prgDownload");
            components = context.Get<Button>("btnComponents");
            cancel = context.Get<Button>("btnCancelDownload");
            componentsState = context.Get<Label>("lblComponentsState");

            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("wifiapp.windowTitle");
                form.Disposed += delegate
                {
                    closing = true;
                    try { timer.Stop(); timer.Dispose(); }
                    catch { }
                };
            }

            if (title != null)
            {
                title.Text = LisunLocale.T("wifiapp.windowTitle");
                title.Font = Theme.Ui(14f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
            }

            if (state != null)
            {
                state.Font = Theme.Mono(9.5f);
                state.ForeColor = Theme.TextDim;
            }

            if (networksCaption != null)
            {
                networksCaption.Text = LisunLocale.T("wifiapp.networksCaption");
                networksCaption.Font = Theme.Ui(11f, FontStyle.Bold);
            }

            if (networks != null)
            {
                networks.Font = Theme.Mono(9.5f);
                networks.Columns.Add(LisunLocale.T("wifiapp.columnSsid"), 210);
                networks.Columns.Add(LisunLocale.T("wifiapp.columnSignal"), 96);
                networks.Columns.Add(LisunLocale.T("wifiapp.columnSecurity"), 110);
                networks.Columns.Add(LisunLocale.T("wifiapp.columnState"), 88);
            }

            if (signalHint != null)
            {
                signalHint.Text = LisunLocale.T("wifiapp.signalHint");
                signalHint.Font = Theme.Ui(8.75f);
                signalHint.ForeColor = Theme.TextDim;
            }

            if (connectCaption != null)
            {
                connectCaption.Text = LisunLocale.T("wifiapp.connectCaption");
                connectCaption.Font = Theme.Ui(11f, FontStyle.Bold);
            }

            if (passwordCaption != null)
            {
                passwordCaption.Text = LisunLocale.T("wifiapp.password");
                passwordCaption.Font = Theme.Ui(9f);
            }

            if (password != null)
            {
                password.Font = Theme.Mono(10f);
                password.UseSystemPasswordChar = true;
            }

            if (showPassword != null)
            {
                showPassword.Text = LisunLocale.T("wifiapp.showPassword");
                showPassword.Font = Theme.Ui(8.75f);
                showPassword.ForeColor = Theme.TextDim;
            }

            if (scan != null)
            {
                scan.Text = LisunLocale.T("wifiapp.scan");
                Theme.StyleButton(scan, Theme.AccentDeep, Theme.Text);
            }

            if (autoScan != null)
            {
                autoScan.Text = LisunLocale.T("wifiapp.autoScan");
                autoScan.Font = Theme.Ui(8.75f);
                autoScan.ForeColor = Theme.TextDim;
                autoScan.Checked = true;
            }

            if (connect != null)
            {
                connect.Text = LisunLocale.T("wifiapp.connect");
                Theme.StyleButton(connect, Theme.AccentDeep, Theme.Text);
            }

            if (disconnect != null)
            {
                disconnect.Text = LisunLocale.T("wifiapp.disconnect");
                Theme.StyleButton(disconnect, Theme.SurfaceAlt, Theme.TextDim);
            }

            if (forget != null)
            {
                forget.Text = LisunLocale.T("wifiapp.forget");
                Theme.StyleButton(forget, Theme.SurfaceAlt, Theme.Danger);
            }

            if (portal != null)
            {
                portal.Text = LisunLocale.T("wifiapp.portal");
                Theme.StyleButton(portal, Theme.SurfaceAlt, Theme.Text);
            }

            if (internet != null)
            {
                internet.Font = Theme.Mono(9f);
                internet.ForeColor = Theme.TextDim;
            }

            if (downloadsCaption != null)
            {
                downloadsCaption.Text = LisunLocale.T("wifiapp.downloadsCaption");
                downloadsCaption.Font = Theme.Ui(11f, FontStyle.Bold);
            }

            if (downloads != null)
            {
                downloads.Font = Theme.Mono(8.75f);
                downloads.ItemHeight = 18;
            }

            if (progress != null)
            {
                progress.Minimum = 0;
                progress.Maximum = 100;
                progress.Value = 0;
            }

            if (components != null)
            {
                components.Text = LisunLocale.T("wifiapp.components");
                Theme.StyleButton(components, Theme.AccentDeep, Theme.Text);
            }

            if (cancel != null)
            {
                cancel.Text = LisunLocale.T("wifiapp.cancel");
                Theme.StyleButton(cancel, Theme.SurfaceAlt, Theme.TextDim);
            }

            if (componentsState != null)
            {
                componentsState.Font = Theme.Ui(8.75f);
                componentsState.ForeColor = Theme.TextDim;
            }

            if (status != null) status.Font = Theme.Mono(8.75f);

            ShowState();
            ShowDownloads();
            ShowComponents();

            timer.Interval = 1500;
            timer.Tick += delegate { Tick(); };
            timer.Start();

            if (!LisunWifi.AdapterPresent)
            {
                SetStatus(LisunLocale.T("wifiapp.noAdapter"));
                if (scan != null) scan.Enabled = false;
            }
            else
            {
                SetStatus(LisunLocale.T("wifiapp.scanning"));
                BeginScan();
            }
        }

        // =====================================================================
        //  Поиск сетей
        // =====================================================================

        /// <summary>Ищет сети в отдельном потоке: netsh думает несколько секунд.</summary>
        private void BeginScan()
        {
            if (busy) return;

            busy = true;
            lastScan = DateTime.Now;

            if (scan != null) scan.Enabled = false;

            Thread worker = new Thread(delegate ()
            {
                List<WifiNetwork> found;
                List<string> profiles;

                try { found = LisunWifi.Scan(); }
                catch { found = new List<WifiNetwork>(); }

                try { profiles = LisunWifi.SavedProfiles(); }
                catch { profiles = new List<string>(); }

                OnUi(delegate
                {
                    saved = profiles;
                    FillNetworks(found);

                    busy = false;
                    if (scan != null) scan.Enabled = LisunWifi.AdapterPresent;

                    SetStatus(found.Count == 0
                        ? LisunLocale.T("wifiapp.nothingFound")
                        : LisunLocale.T("wifiapp.found", found.Count));
                });
            });

            worker.IsBackground = true;
            worker.Name = "WifiScan";
            worker.Start();
        }

        private void FillNetworks(List<WifiNetwork> found)
        {
            if (networks == null) return;

            string selected = SelectedSsid();

            networks.BeginUpdate();
            networks.Items.Clear();
            rows.Clear();

            foreach (WifiNetwork network in found)
            {
                ListViewItem row = new ListViewItem(network.Ssid.Length > 0
                    ? network.Ssid
                    : LisunLocale.T("wifiapp.hidden"));

                row.SubItems.Add(Bars(network.Signal) + "  " + network.Signal + " %");
                row.SubItems.Add(Security(network));
                row.SubItems.Add(StateOf(network));

                if (network.Connected) row.ForeColor = Theme.Success;
                else if (Saved(network.Ssid)) row.ForeColor = Theme.Cyan;
                else row.ForeColor = Theme.Text;

                networks.Items.Add(row);
                rows.Add(network);
            }

            networks.EndUpdate();

            if (selected != null) SelectSsid(selected);
            if (networks.SelectedIndices.Count == 0 && networks.Items.Count > 0)
                networks.Items[0].Selected = true;
        }

        /// <summary>Уровень сигнала полосками — так он читается с одного взгляда.</summary>
        private static string Bars(int signal)
        {
            int level = signal >= 80 ? 4 : signal >= 60 ? 3 : signal >= 40 ? 2 : signal >= 20 ? 1 : 0;

            StringBuilder sb = new StringBuilder(4);
            for (int index = 0; index < 4; index++) sb.Append(index < level ? '█' : '░');

            return sb.ToString();
        }

        private static string Security(WifiNetwork network)
        {
            if (network.Enterprise) return LisunLocale.T("wifiapp.secEnterprise");
            if (network.Open) return LisunLocale.T("wifiapp.secOpen");

            string auth = (network.Authentication ?? string.Empty).Trim();
            return auth.Length > 0 ? auth : LisunLocale.T("wifiapp.secClosed");
        }

        private string StateOf(WifiNetwork network)
        {
            if (network.Connected) return LisunLocale.T("wifiapp.stateConnected");
            if (Saved(network.Ssid)) return LisunLocale.T("wifiapp.stateSaved");

            return "—";
        }

        private bool Saved(string ssid)
        {
            if (string.IsNullOrEmpty(ssid)) return false;

            foreach (string profile in saved)
                if (string.Equals(profile, ssid, StringComparison.OrdinalIgnoreCase)) return true;

            return false;
        }

        private string SelectedSsid()
        {
            WifiNetwork network = Selected();
            return network == null ? null : network.Ssid;
        }

        private WifiNetwork Selected()
        {
            if (networks == null || networks.SelectedIndices.Count == 0) return null;

            int index = networks.SelectedIndices[0];
            if (index < 0 || index >= rows.Count) return null;

            return rows[index];
        }

        private void SelectSsid(string ssid)
        {
            if (networks == null || ssid == null) return;

            for (int index = 0; index < rows.Count; index++)
            {
                if (!string.Equals(rows[index].Ssid, ssid, StringComparison.OrdinalIgnoreCase)) continue;

                networks.Items[index].Selected = true;
                networks.Items[index].EnsureVisible();
                return;
            }
        }

        // =====================================================================
        //  Состояние
        // =====================================================================

        private void ShowState()
        {
            string current;
            try { current = LisunWifi.CurrentSsid(); }
            catch { current = string.Empty; }

            if (state != null)
            {
                if (!LisunWifi.AdapterPresent)
                {
                    state.Text = LisunNetwork.WiredConnected
                        ? LisunLocale.T("wifiapp.wiredOnly", LisunNetwork.Short())
                        : LisunLocale.T("wifiapp.noAdapter");
                    state.ForeColor = LisunNetwork.WiredConnected ? Theme.Success : Theme.Warning;
                }
                else if (!string.IsNullOrEmpty(current))
                {
                    state.Text = LisunLocale.T("wifiapp.connectedTo", current) + "    " + LisunNetwork.Short();
                    state.ForeColor = Theme.Success;
                }
                else if (LisunNetwork.WiredConnected)
                {
                    // Кабель воткнут — это тоже подключение, и сеть уже есть.
                    state.Text = LisunNetwork.Short();
                    state.ForeColor = Theme.Success;
                }
                else
                {
                    state.Text = LisunLocale.T("wifiapp.notConnected");
                    state.ForeColor = Theme.TextDim;
                }
            }

            if (internet != null)
            {
                string portalUrl = LisunWifi.PortalUrl;

                if (LisunWifi.Online)
                {
                    internet.Text = LisunLocale.T("wifiapp.online");
                    internet.ForeColor = Theme.Success;
                }
                else if (!string.IsNullOrEmpty(portalUrl))
                {
                    internet.Text = LisunLocale.T("wifiapp.portalFound", portalUrl);
                    internet.ForeColor = Theme.Warning;
                }
                else
                {
                    internet.Text = LisunLocale.T("wifiapp.offline");
                    internet.ForeColor = Theme.TextDim;
                }
            }

            if (portal != null) portal.Enabled = !string.IsNullOrEmpty(LisunWifi.PortalUrl);
            if (disconnect != null) disconnect.Enabled = !string.IsNullOrEmpty(current);
        }

        private void ShowDownloads()
        {
            List<LisunDownload> items = LisunDownloads.Items();

            if (downloads != null)
            {
                int selected = downloads.SelectedIndex;

                downloads.BeginUpdate();
                downloads.Items.Clear();

                int shown = 0;

                for (int index = items.Count - 1; index >= 0 && shown < 12; index--)
                {
                    downloads.Items.Add(LisunDownloads.Line(items[index]));
                    shown++;
                }

                if (downloads.Items.Count == 0)
                    downloads.Items.Add(LisunLocale.T("wifiapp.noDownloads"));

                downloads.EndUpdate();

                if (selected >= 0 && selected < downloads.Items.Count)
                    downloads.SelectedIndex = selected;
            }

            List<LisunDownload> active = LisunDownloads.ActiveItems();

            if (progress != null)
            {
                int percent = active.Count > 0 ? active[0].Percent : 0;
                if (percent < 0) percent = 0;
                if (percent > 100) percent = 100;

                progress.Value = percent;
            }

            if (cancel != null) cancel.Enabled = active.Count > 0;
        }

        private void ShowComponents()
        {
            if (componentsState == null) return;

            int missing = 0;
            StringBuilder names = new StringBuilder();

            foreach (LisunComponent item in LisunLibraries.Items())
            {
                if (item.BuiltIn || LisunLibraries.Installed(item)) continue;

                missing++;
                if (names.Length > 0) names.Append(", ");
                names.Append(item.Name);
            }

            if (missing == 0)
            {
                componentsState.Text = LisunLocale.T("wifiapp.componentsOk");
                componentsState.ForeColor = Theme.TextDim;
            }
            else
            {
                componentsState.Text = LisunLocale.T("wifiapp.componentsMissing", missing, names.ToString());
                componentsState.ForeColor = Theme.Warning;
            }

            if (components != null)
                components.Enabled = missing > 0 && !LisunDownloads.Busy;
        }

        private void Tick()
        {
            if (closing) return;

            ShowState();
            ShowDownloads();

            // Сети пересматриваем не чаще, чем раз в 15 секунд: netsh не бесплатный.
            if (autoScan != null && autoScan.Checked && !busy &&
                (DateTime.Now - lastScan).TotalSeconds > 15)
                BeginScan();
        }

        private void SetStatus(string text)
        {
            if (status == null) return;

            status.Text = " " + (text ?? string.Empty).Trim();
        }

        /// <summary>Любая работа из фонового потока возвращается в поток окна.</summary>
        private void OnUi(Action action)
        {
            if (form == null || closing) return;

            try
            {
                if (form.IsDisposed) return;

                if (form.InvokeRequired) form.BeginInvoke(action);
                else action();
            }
            catch { }
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        public void btnScan_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifiapp.needNetwork"));
                return;
            }

            SetStatus(LisunLocale.T("wifiapp.scanning"));
            BeginScan();
        }

        public void chkAutoScan_CheckedChanged(object sender, EventArgs e)
        {
            if (autoScan == null) return;

            SetStatus(autoScan.Checked
                ? LisunLocale.T("wifiapp.autoOn")
                : LisunLocale.T("wifiapp.autoOff"));
        }

        public void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (password == null || showPassword == null) return;

            password.UseSystemPasswordChar = !showPassword.Checked;
        }

        public void lstWifiNetworks_SelectedIndexChanged(object sender, EventArgs e)
        {
            WifiNetwork network = Selected();
            if (network == null) return;

            bool needPassword = !network.Open && !Saved(network.Ssid);

            if (password != null) password.Enabled = needPassword;
            if (passwordCaption != null)
                passwordCaption.Text = needPassword
                    ? LisunLocale.T("wifiapp.password")
                    : LisunLocale.T("wifiapp.passwordNotNeeded");

            if (forget != null) forget.Enabled = Saved(network.Ssid);

            SetStatus(network.Enterprise
                ? LisunLocale.T("wifiapp.enterpriseHint", network.Ssid)
                : network.Open
                    ? LisunLocale.T("wifiapp.openHint", network.Ssid)
                    : LisunLocale.T("wifiapp.closedHint", network.Ssid));
        }

        public void lstWifiNetworks_DoubleClick(object sender, EventArgs e)
        {
            btnConnect_Click(sender, e);
        }

        public void btnConnect_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifiapp.needNetwork"));
                return;
            }

            WifiNetwork network = Selected();

            if (network == null)
            {
                SetStatus(LisunLocale.T("wifiapp.pickNetwork"));
                return;
            }

            if (busy)
            {
                SetStatus(LisunLocale.T("wifiapp.wait"));
                return;
            }

            string ssid = network.Ssid;
            string secret = password == null ? string.Empty : password.Text ?? string.Empty;

            if (!network.Open && !Saved(ssid) && secret.Length == 0)
            {
                SetStatus(LisunLocale.T("wifiapp.needPassword", ssid));
                if (password != null) password.Focus();
                return;
            }

            busy = true;
            if (connect != null) connect.Enabled = false;
            SetStatus(LisunLocale.T("wifiapp.connecting", ssid));

            Thread worker = new Thread(delegate ()
            {
                string message;
                bool ok;

                try { ok = LisunWifi.Connect(ssid, secret, out message); }
                catch (Exception ex) { ok = false; message = ex.Message; }

                OnUi(delegate
                {
                    busy = false;
                    if (connect != null) connect.Enabled = true;

                    if (ok && password != null) password.Text = string.Empty;

                    SetStatus(message.Trim());
                    ShowState();
                    lastScan = DateTime.MinValue;
                });
            });

            worker.IsBackground = true;
            worker.Name = "WifiConnect";
            worker.Start();
        }

        public void btnDisconnect_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifiapp.needNetwork"));
                return;
            }

            string message;
            LisunWifi.Disconnect(out message);

            SetStatus(message.Trim());
            ShowState();
            lastScan = DateTime.MinValue;
        }

        public void btnForget_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifiapp.needNetwork"));
                return;
            }

            WifiNetwork network = Selected();

            if (network == null || network.Ssid.Length == 0)
            {
                SetStatus(LisunLocale.T("wifiapp.pickNetwork"));
                return;
            }

            DialogResult answer = MessageBox.Show(
                LisunLocale.T("wifiapp.forgetBody", network.Ssid),
                LisunLocale.T("wifiapp.forgetTitle"),
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (answer != DialogResult.Yes)
            {
                SetStatus(LisunLocale.T("wifiapp.forgetCancelled"));
                return;
            }

            string message;
            LisunWifi.Forget(network.Ssid, out message);

            try { saved = LisunWifi.SavedProfiles(); }
            catch { }

            SetStatus(message.Trim());
            lastScan = DateTime.MinValue;
        }

        public void btnPortal_Click(object sender, EventArgs e)
        {
            string url = LisunWifi.PortalUrl;

            if (string.IsNullOrEmpty(url))
            {
                string found;
                LisunWifi.CheckConnectivity(out found);
                url = found;
            }

            if (string.IsNullOrEmpty(url))
            {
                SetStatus(LisunLocale.T("wifiapp.noPortal"));
                return;
            }

            LisunWifi.OpenPortal(url);
            SetStatus(LisunLocale.T("wifiapp.openingPortal", url));
        }

        /// <summary>Докачивает то, чего системе не хватает: интернет уже есть.</summary>
        public void btnComponents_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifiapp.needNetwork"));
                return;
            }

            if (LisunDownloads.Busy)
            {
                SetStatus(LisunLocale.T("wifiapp.alreadyDownloading"));
                return;
            }

            List<string> names = new List<string>();

            foreach (LisunComponent item in LisunLibraries.Items())
            {
                if (item.BuiltIn || LisunLibraries.Installed(item)) continue;

                names.Add(item.Name);
            }

            if (names.Count == 0)
            {
                SetStatus(LisunLocale.T("wifiapp.componentsOk"));
                return;
            }

            if (components != null) components.Enabled = false;
            SetStatus(LisunLocale.T("wifiapp.downloadingComponents", names.Count));

            Thread worker = new Thread(delegate ()
            {
                StringBuilder report = new StringBuilder();

                foreach (string name in names)
                {
                    string message;
                    bool ok = LisunLibraries.Install(name, out message);

                    if (report.Length > 0) report.Append("; ");
                    report.Append(name).Append(": ").Append(ok
                        ? LisunLocale.T("wifiapp.componentOk")
                        : message.Trim());
                }

                OnUi(delegate
                {
                    SetStatus(report.ToString());
                    ShowComponents();
                    ShowDownloads();
                });
            });

            worker.IsBackground = true;
            worker.Name = "WifiComponents";
            worker.Start();
        }

        public void btnCancelDownload_Click(object sender, EventArgs e)
        {
            int count = LisunDownloads.CancelAll();

            SetStatus(count == 0
                ? LisunLocale.T("wifiapp.noDownloads")
                : LisunLocale.T("wifiapp.cancelled", count));

            ShowDownloads();
        }
    }
}
