﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Учётные записи LisunOS. Нужны для входа снаружи — с компьютера
    /// или телефона — через SshHost. Пароль хранится не целиком:
    /// только соль и хэш PBKDF2, так что из файла его не прочитать.
    /// </summary>
    public static class LisunUsers
    {
        public sealed class Account
        {
            public string Name = string.Empty;
            public string Salt = string.Empty;
            public string Hash = string.Empty;
            public bool Superuser;
            public bool Enabled = true;
            public DateTime Created = DateTime.Now;
            public DateTime LastLogin = DateTime.MinValue;
            public long Logins;

            /// <summary>Закрытые области. У root всегда пусто.</summary>
            public readonly HashSet<string> Limits =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        }

        private const int Iterations = 20000;

        private static readonly Dictionary<string, Account> accounts =
            new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase);

        private static bool loaded;

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "USERS"); }
        }

        public static int Count
        {
            get { Ensure(); return accounts.Count; }
        }

        public static List<Account> All()
        {
            Ensure();

            List<Account> result = new List<Account>(accounts.Values);
            result.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));

            return result;
        }

        public static List<string> Names()
        {
            List<string> result = new List<string>();
            foreach (Account account in All()) result.Add(account.Name);

            return result;
        }

        public static Account Find(string name)
        {
            Ensure();

            if (string.IsNullOrEmpty(name)) return null;

            Account account;
            return accounts.TryGetValue(name.Trim(), out account) ? account : null;
        }

        // =====================================================================
        //  Хранилище
        // =====================================================================

        private static void Ensure()
        {
            if (!loaded) Load();
        }

        public static void Load()
        {
            loaded = true;
            accounts.Clear();

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    // имя:соль:хэш:флаги:создан:входов
                    string[] parts = line.Split(':');
                    if (parts.Length < 3) continue;

                    Account account = new Account();
                    account.Name = parts[0];
                    account.Salt = parts[1];
                    account.Hash = parts[2];

                    if (parts.Length > 3)
                    {
                        string flags = parts[3].ToLowerInvariant();
                        account.Superuser = flags.IndexOf('s') >= 0;
                        account.Enabled = flags.IndexOf('x') < 0;
                    }

                    if (parts.Length > 4)
                    {
                        DateTime created;
                        if (DateTime.TryParse(parts[4], CultureInfo.InvariantCulture,
                            DateTimeStyles.None, out created)) account.Created = created;
                    }

                    if (parts.Length > 5)
                    {
                        long logins;
                        if (long.TryParse(parts[5], out logins)) account.Logins = logins;
                    }

                    // Седьмое поле появилось позже: старые файлы читаются как есть.
                    if (parts.Length > 6 && parts[6] != "-")
                    {
                        foreach (string area in parts[6].Split(','))
                            if (area.Trim().Length > 0) account.Limits.Add(area.Trim());
                    }

                    if (account.Name.Length > 0) accounts[account.Name] = account;
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[users] [ОШИБКА] Чтение USERS: " + ex.Message);
            }
        }

        public static void Save()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# Учётные записи LisunOS");
                sb.AppendLine("# имя:соль:хэш:флаги:создан:входов:ограничения   (пароль не хранится)");

                foreach (Account account in All())
                {
                    string flags = (account.Superuser ? "s" : "") + (account.Enabled ? "" : "x");

                    sb.AppendLine(string.Join(":", new[]
                    {
                        account.Name,
                        account.Salt,
                        account.Hash,
                        flags.Length == 0 ? "-" : flags,
                        account.Created.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        account.Logins.ToString(CultureInfo.InvariantCulture),
                        account.Limits.Count == 0
                            ? "-"
                            : string.Join(",", new List<string>(account.Limits).ToArray())
                    }));
                }

                CustomFormUtils.WriteFileText(StorePath, sb.ToString());
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[users] [ОШИБКА] Запись USERS: " + ex.Message);
            }
        }

        // =====================================================================
        //  Пароли
        // =====================================================================

        private static string MakeSalt()
        {
            byte[] bytes = new byte[16];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
                rng.GetBytes(bytes);

            return Convert.ToBase64String(bytes);
        }

        private static string MakeHash(string password, string salt)
        {
            using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(
                password ?? string.Empty, Convert.FromBase64String(salt), Iterations))
            {
                return Convert.ToBase64String(derive.GetBytes(32));
            }
        }

        /// <summary>Сверяет пароль. Сравнение идёт побайтно до конца.</summary>
        public static bool Check(string name, string password)
        {
            Account account = Find(name);
            if (account == null || !account.Enabled) return false;

            // Учётная запись без пароля существует, но войти по нему нельзя:
            // пустая строка не должна подходить ко всему подряд.
            if (account.Hash.Length == 0) return false;

            try
            {
                string hash = MakeHash(password, account.Salt);
                if (hash.Length != account.Hash.Length) return false;

                int difference = 0;
                for (int index = 0; index < hash.Length; index++)
                    difference |= hash[index] ^ account.Hash[index];

                return difference == 0;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        public static bool Create(string name, string password, out string message)
        {
            Ensure();

            if (!ValidName(name))
            {
                message = LisunLocale.T("user.badName");
                return false;
            }

            if (accounts.ContainsKey(name.Trim()))
            {
                message = LisunLocale.T("user.exists", name);
                return false;
            }

            // Пароль необязателен: учётную запись заводят и без него,
            // тогда она работает локально, а войти по сети не выйдет.
            bool withPassword = !string.IsNullOrEmpty(password);

            if (withPassword && password.Length < 4)
            {
                message = LisunLocale.T("user.shortPassword");
                return false;
            }

            Account account = new Account();
            account.Name = name.Trim();
            account.Salt = MakeSalt();
            account.Hash = withPassword ? MakeHash(password, account.Salt) : string.Empty;

            accounts[account.Name] = account;
            Save();

            LisunEngine.Log("[users] " + LisunLocale.T("user.created", account.Name).Trim());

            message = withPassword
                ? LisunLocale.T("user.created", account.Name)
                : LisunLocale.T("user.createdNoPassword", account.Name);
            return true;
        }

        /// <summary>
        /// Задаёт пароль, создавая учётную запись, если её ещё нет.
        /// Так заводится root: он существует как имя с первого запуска,
        /// а записью в файле становится, когда ему назначают пароль.
        /// </summary>
        public static bool SetPassword(string name, string password, out string message)
        {
            Ensure();

            name = (name ?? string.Empty).Trim();
            if (name.Length == 0)
            {
                message = LisunLocale.T("user.badName");
                return false;
            }

            if (string.IsNullOrEmpty(password) || password.Length < 4)
            {
                message = LisunLocale.T("user.shortPassword");
                return false;
            }

            Account account = Find(name);
            if (account == null)
            {
                account = new Account();
                account.Name = name;
                account.Superuser = IsRoot(name);

                accounts[account.Name] = account;
            }

            account.Salt = MakeSalt();
            account.Hash = MakeHash(password, account.Salt);

            Save();

            message = LisunLocale.T("user.passwordSet", account.Name);
            return true;
        }

        /// <summary>
        /// Заводит служебные учётные записи, которых система ждёт всегда:
        /// www — под ней работает сайт.
        /// </summary>
        public static void EnsureBuiltIn()
        {
            Ensure();

            if (Find(WebName) != null) return;

            Account web = new Account();
            web.Name = WebName;
            web.Salt = MakeSalt();
            web.Hash = string.Empty;          // по сети под www не входят

            accounts[web.Name] = web;
            Save();

            LisunEngine.Log("[users] " + LisunLocale.T("user.webCreated", WebName).Trim());
        }

        public static bool Edit(string name, string password, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            if (password == null || password.Length < 4)
            {
                message = LisunLocale.T("user.shortPassword");
                return false;
            }

            account.Salt = MakeSalt();
            account.Hash = MakeHash(password, account.Salt);
            Save();

            message = LisunLocale.T("user.passwordChanged", account.Name);
            return true;
        }

        public static bool Remove(string name, out string message)
        {
            if (IsRoot(name))
            {
                message = LisunLocale.T("user.rootFree");
                return false;
            }

            if (!string.IsNullOrEmpty(name) && name.Trim().Equals(WebName, StringComparison.OrdinalIgnoreCase))
            {
                message = LisunLocale.T("user.webKept", WebName);
                return false;
            }

            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            accounts.Remove(account.Name);
            Save();

            message = LisunLocale.T("user.removed", account.Name);
            return true;
        }

        public static bool SetEnabled(string name, bool value, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            account.Enabled = value;
            Save();

            message = LisunLocale.T(value ? "user.enabled" : "user.disabled", account.Name);
            return true;
        }

        /// <summary>Отмечает удачный вход — показывается в списке.</summary>
        public static void NoteLogin(string name)
        {
            Account account = Find(name);
            if (account == null) return;

            account.LastLogin = DateTime.Now;
            account.Logins++;
            Save();
        }

        private static bool ValidName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;

            name = name.Trim();
            if (name.Length < 2 || name.Length > 32) return false;

            foreach (char symbol in name)
                if (!char.IsLetterOrDigit(symbol) && symbol != '_' && symbol != '-') return false;

            return true;
        }

        // =====================================================================
        //  Текущий пользователь и ограничения
        //
        //  root — это сама система: он есть всегда, его нельзя ограничить и
        //  нельзя удалить. Остальные учётные записи заводит root, и каждой
        //  можно закрыть отдельные области: работу с файлами, пакеты, сеть.
        //  Ограничение проверяется при разборе команды, до её выполнения.
        // =====================================================================

        public const string RootName = "root";

        /// <summary>Учётная запись, под которой система видит сайт.</summary>
        public const string WebName = "www";

        /// <summary>
        /// Токены ограничений.
        ///
        /// PERMISSION_* закрывает само действие: с таким ограничением
        /// пользователь не создаст файл, не поставит пакет, не выйдет в сеть.
        ///
        /// ALLOW_PERMISSION_*_REQUEST закрывает другое — право приложения
        /// ПОПРОСИТЬ эту возможность. Приложение не покажет окно запроса и
        /// не получит право даже с согласия пользователя.
        /// </summary>
        public static readonly string[] Tokens =
        {
            "PERMISSION_READ_FILES",
            "PERMISSION_CREATE_FILES",
            "PERMISSION_EDIT_FILES",
            "PERMISSION_DELETE_FILES",
            "PERMISSION_PACKAGES",
            "PERMISSION_NETWORK",
            "PERMISSION_USERS",
            "PERMISSION_APPS",
            "PERMISSION_SYSTEM",
            "PERMISSION_SUPERUSER",

            "ALLOW_PERMISSION_READ_FILES_REQUEST",
            "ALLOW_PERMISSION_CREATE_FILES_REQUEST",
            "ALLOW_PERMISSION_EDIT_FILES_REQUEST",
            "ALLOW_PERMISSION_DELETE_FILES_REQUEST",
            "ALLOW_PERMISSION_PACKAGES_REQUEST",
            "ALLOW_PERMISSION_NETWORK_REQUEST",
            "ALLOW_PERMISSION_USERS_REQUEST",
            "ALLOW_PERMISSION_APPS_REQUEST",
            "ALLOW_PERMISSION_SYSTEM_REQUEST",
            "ALLOW_PERMISSION_SUPERUSER_REQUEST"
        };

        private static readonly Dictionary<string, string[]> TokenDescriptions =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "PERMISSION_READ_FILES",    new[] { "чтение файлов",                    "reading files" } },
            { "PERMISSION_CREATE_FILES",  new[] { "создание файлов и папок",          "creating files and folders" } },
            { "PERMISSION_EDIT_FILES",    new[] { "правка и переименование файлов",   "editing and renaming files" } },
            { "PERMISSION_DELETE_FILES",  new[] { "удаление файлов и папок",          "deleting files and folders" } },
            { "PERMISSION_PACKAGES",      new[] { "установка и удаление пакетов",     "installing and removing packages" } },
            { "PERMISSION_NETWORK",       new[] { "сеть: curl, wifi, сервер, ssh",    "network: curl, wifi, the server, ssh" } },
            { "PERMISSION_USERS",         new[] { "управление учётными записями",     "managing accounts" } },
            { "PERMISSION_APPS",          new[] { "запуск приложений",                "launching applications" } },
            { "PERMISSION_SYSTEM",        new[] { "реестр, службы, перезапуск, язык", "registry, services, restart, language" } },
            { "PERMISSION_SUPERUSER",     new[] { "повышение прав",                   "elevating privileges" } }
        };

        /// <summary>Короткие имена из прежних версий — чтобы старые команды работали.</summary>
        private static readonly Dictionary<string, string> TokenAliases =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "files",     "PERMISSION_CREATE_FILES" },
            { "packages",  "PERMISSION_PACKAGES" },
            { "network",   "PERMISSION_NETWORK" },
            { "users",     "PERMISSION_USERS" },
            { "apps",      "PERMISSION_APPS" },
            { "system",    "PERMISSION_SYSTEM" },
            { "superuser", "PERMISSION_SUPERUSER" }
        };

        public static bool IsRoot(string name)
        {
            return !string.IsNullOrEmpty(name) &&
                   name.Trim().Equals(RootName, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>Приводит короткое имя к полному токену.</summary>
        public static string NormalizeToken(string token)
        {
            if (string.IsNullOrEmpty(token)) return string.Empty;

            string value = token.Trim();

            string full;
            if (TokenAliases.TryGetValue(value, out full)) return full;

            foreach (string known in Tokens)
                if (known.Equals(value, StringComparison.OrdinalIgnoreCase)) return known;

            return string.Empty;
        }

        public static bool IsKnownToken(string token)
        {
            return NormalizeToken(token).Length > 0;
        }

        public static string DescribeToken(string token)
        {
            string full = NormalizeToken(token);
            if (full.Length == 0) return token ?? string.Empty;

            bool request = full.StartsWith("ALLOW_", StringComparison.OrdinalIgnoreCase);
            string core = request
                ? "PERMISSION_" + full.Substring("ALLOW_PERMISSION_".Length,
                      full.Length - "ALLOW_PERMISSION_".Length - "_REQUEST".Length)
                : full;

            string[] pair;
            string what = TokenDescriptions.TryGetValue(core, out pair)
                ? (LisunLocale.Language == LisunLanguage.English ? pair[1] : pair[0])
                : core;

            return request ? LisunLocale.T("user.tokenRequest", what) : what;
        }

        public static string TokensText()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("user.areasTitle") + Environment.NewLine);

            foreach (string token in Tokens)
            {
                if (token.StartsWith("ALLOW_", StringComparison.Ordinal)) continue;
                sb.AppendLine("   " + token.PadRight(26) + DescribeToken(token));
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("user.requestTokens"));

            foreach (string token in Tokens)
            {
                if (!token.StartsWith("ALLOW_", StringComparison.Ordinal)) continue;
                sb.AppendLine("   " + token);
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>
        /// Имя того, от кого идут команды в терминале. Хранится в реестре,
        /// поэтому переживает перезапуск. По умолчанию — root.
        /// </summary>
        public static string Current
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData.TryGetValue("current_user", out value) &&
                    !string.IsNullOrEmpty(value))
                {
                    // Учётную запись могли удалить, пока она была текущей.
                    if (IsRoot(value) || Find(value) != null) return value;
                }

                return RootName;
            }
        }

        /// <summary>Сменить текущего пользователя терминала.</summary>
        public static bool SetCurrent(string name, out string message)
        {
            name = (name ?? string.Empty).Trim();

            if (name.Length == 0)
            {
                message = LisunLocale.T("user.currentUsage");
                return false;
            }

            if (!IsRoot(name))
            {
                Account account = Find(name);
                if (account == null)
                {
                    message = LisunLocale.T("user.notFound", name);
                    return false;
                }

                if (!account.Enabled)
                {
                    message = LisunLocale.T("user.disabledUser", account.Name);
                    return false;
                }

                name = account.Name;
            }
            else name = RootName;

            LisunEngine.RegistryData["current_user"] = name;
            LisunEngine.SaveRegistry();

            // Разрешение, выданное прошлому пользователю, новому не достаётся.
            LisunElevation.Forget();

            LisunEngine.Log("[users] " + LisunLocale.T("user.currentSet", name).Trim());

            message = LisunLocale.T("user.currentSet", name);
            return true;
        }

        /// <summary>
        /// Разрешена ли область этому пользователю. root — всегда да,
        /// незнакомое имя — тоже: ограничение ставится явно, а не по умолчанию.
        /// </summary>
        public static bool IsAllowed(string user, string area)
        {
            if (IsRoot(user) || string.IsNullOrEmpty(area)) return true;

            Account account = Find(user);
            if (account == null) return true;

            return !account.Limits.Contains(NormalizeToken(area));
        }

        public static bool AddLimit(string name, string area, out string message)
        {
            Account account = Find(name);

            if (IsRoot(name))
            {
                message = LisunLocale.T("user.rootFree");
                return false;
            }

            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            string token = NormalizeToken(area);
            if (token.Length == 0)
            {
                message = LisunLocale.T("user.badArea", area ?? "—");
                return false;
            }

            area = token;

            if (!account.Limits.Add(area))
            {
                message = LisunLocale.T("user.limitAlready", account.Name, area);
                return false;
            }

            Save();

            message = LisunLocale.T("user.limitAdded", account.Name, area, DescribeToken(area));
            return true;
        }

        public static bool RemoveLimit(string name, string area, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            bool all = string.IsNullOrEmpty(area) ||
                       area.Trim().Equals("all", StringComparison.OrdinalIgnoreCase) ||
                       area.Trim().Equals("clear", StringComparison.OrdinalIgnoreCase);

            if (all)
            {
                if (account.Limits.Count == 0)
                {
                    message = LisunLocale.T("user.limitNone", account.Name);
                    return false;
                }

                account.Limits.Clear();
                Save();

                message = LisunLocale.T("user.limitCleared", account.Name);
                return true;
            }

            if (!account.Limits.Remove(NormalizeToken(area)))
            {
                message = LisunLocale.T("user.limitMissing", account.Name, area);
                return false;
            }

            Save();

            message = LisunLocale.T("user.limitRemoved", account.Name, area);
            return true;
        }

        public static string LimitsText(string name)
        {
            if (IsRoot(name)) return LisunLocale.T("user.rootFree");

            Account account = Find(name);
            if (account == null) return LisunLocale.T("user.notFound", name);

            if (account.Limits.Count == 0) return LisunLocale.T("user.limitNone", account.Name);

            StringBuilder sb = new StringBuilder(
                LisunLocale.T("user.limitTitle", account.Name, account.Limits.Count) + Environment.NewLine);

            List<string> rows = new List<string>(account.Limits);
            rows.Sort(StringComparer.OrdinalIgnoreCase);

            foreach (string area in rows)
                sb.AppendLine("   " + area.PadRight(26) + DescribeToken(area));

            return sb.ToString().TrimEnd();
        }

        public static string ListText()
        {
            List<Account> all = All();
            if (all.Count == 0) return LisunLocale.T("user.empty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("user.listTitle", all.Count) + Environment.NewLine);

            foreach (Account account in all)
            {
                sb.AppendLine("   " + (account.Enabled ? "●" : "○") + " " +
                              account.Name.PadRight(20) +
                              (account.Superuser ? LisunLocale.T("user.markSuper") : "").PadRight(14) +
                              LisunLocale.T("user.logins", account.Logins) +
                              (account.LastLogin == DateTime.MinValue ? "" :
                                  "   " + account.LastLogin.ToString("dd.MM HH:mm", CultureInfo.InvariantCulture)));
            }

            return sb.ToString().TrimEnd();
        }
    }
}
