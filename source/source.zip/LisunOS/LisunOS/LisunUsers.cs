﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Учётные записи LisunOS. Нужны для входа снаружи — с компьютера
    /// или телефона — через SshHost. Пароль хранится не целиком:
    /// только соль и хэш PBKDF2, так что из файла его не прочитать.
    /// </summary>
    public static class LisunUsers
    {
        public sealed class Account
        {
            public string Name = string.Empty;
            public string Salt = string.Empty;
            public string Hash = string.Empty;
            public bool Superuser;
            public bool Enabled = true;
            public DateTime Created = DateTime.Now;
            public DateTime LastLogin = DateTime.MinValue;
            public long Logins;
        }

        private const int Iterations = 20000;

        private static readonly Dictionary<string, Account> accounts =
            new Dictionary<string, Account>(StringComparer.OrdinalIgnoreCase);

        private static bool loaded;

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "USERS"); }
        }

        public static int Count
        {
            get { Ensure(); return accounts.Count; }
        }

        public static List<Account> All()
        {
            Ensure();

            List<Account> result = new List<Account>(accounts.Values);
            result.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));

            return result;
        }

        public static List<string> Names()
        {
            List<string> result = new List<string>();
            foreach (Account account in All()) result.Add(account.Name);

            return result;
        }

        public static Account Find(string name)
        {
            Ensure();

            if (string.IsNullOrEmpty(name)) return null;

            Account account;
            return accounts.TryGetValue(name.Trim(), out account) ? account : null;
        }

        // =====================================================================
        //  Хранилище
        // =====================================================================

        private static void Ensure()
        {
            if (!loaded) Load();
        }

        public static void Load()
        {
            loaded = true;
            accounts.Clear();

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    // имя:соль:хэш:флаги:создан:входов
                    string[] parts = line.Split(':');
                    if (parts.Length < 3) continue;

                    Account account = new Account();
                    account.Name = parts[0];
                    account.Salt = parts[1];
                    account.Hash = parts[2];

                    if (parts.Length > 3)
                    {
                        string flags = parts[3].ToLowerInvariant();
                        account.Superuser = flags.IndexOf('s') >= 0;
                        account.Enabled = flags.IndexOf('x') < 0;
                    }

                    if (parts.Length > 4)
                    {
                        DateTime created;
                        if (DateTime.TryParse(parts[4], CultureInfo.InvariantCulture,
                            DateTimeStyles.None, out created)) account.Created = created;
                    }

                    if (parts.Length > 5)
                    {
                        long logins;
                        if (long.TryParse(parts[5], out logins)) account.Logins = logins;
                    }

                    if (account.Name.Length > 0) accounts[account.Name] = account;
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[users] [ОШИБКА] Чтение USERS: " + ex.Message);
            }
        }

        public static void Save()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("# Учётные записи LisunOS");
                sb.AppendLine("# имя:соль:хэш:флаги:создан:входов   (пароль не хранится)");

                foreach (Account account in All())
                {
                    string flags = (account.Superuser ? "s" : "") + (account.Enabled ? "" : "x");

                    sb.AppendLine(string.Join(":", new[]
                    {
                        account.Name,
                        account.Salt,
                        account.Hash,
                        flags.Length == 0 ? "-" : flags,
                        account.Created.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                        account.Logins.ToString(CultureInfo.InvariantCulture)
                    }));
                }

                CustomFormUtils.WriteFileText(StorePath, sb.ToString());
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[users] [ОШИБКА] Запись USERS: " + ex.Message);
            }
        }

        // =====================================================================
        //  Пароли
        // =====================================================================

        private static string MakeSalt()
        {
            byte[] bytes = new byte[16];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
                rng.GetBytes(bytes);

            return Convert.ToBase64String(bytes);
        }

        private static string MakeHash(string password, string salt)
        {
            using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(
                password ?? string.Empty, Convert.FromBase64String(salt), Iterations))
            {
                return Convert.ToBase64String(derive.GetBytes(32));
            }
        }

        /// <summary>Сверяет пароль. Сравнение идёт побайтно до конца.</summary>
        public static bool Check(string name, string password)
        {
            Account account = Find(name);
            if (account == null || !account.Enabled) return false;

            try
            {
                string hash = MakeHash(password, account.Salt);
                if (hash.Length != account.Hash.Length) return false;

                int difference = 0;
                for (int index = 0; index < hash.Length; index++)
                    difference |= hash[index] ^ account.Hash[index];

                return difference == 0;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        public static bool Create(string name, string password, out string message)
        {
            Ensure();

            if (!ValidName(name))
            {
                message = LisunLocale.T("user.badName");
                return false;
            }

            if (accounts.ContainsKey(name.Trim()))
            {
                message = LisunLocale.T("user.exists", name);
                return false;
            }

            if (password == null || password.Length < 4)
            {
                message = LisunLocale.T("user.shortPassword");
                return false;
            }

            Account account = new Account();
            account.Name = name.Trim();
            account.Salt = MakeSalt();
            account.Hash = MakeHash(password, account.Salt);

            accounts[account.Name] = account;
            Save();

            LisunEngine.Log("[users] " + LisunLocale.T("user.created", account.Name).Trim());

            message = LisunLocale.T("user.created", account.Name);
            return true;
        }

        public static bool Edit(string name, string password, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            if (password == null || password.Length < 4)
            {
                message = LisunLocale.T("user.shortPassword");
                return false;
            }

            account.Salt = MakeSalt();
            account.Hash = MakeHash(password, account.Salt);
            Save();

            message = LisunLocale.T("user.passwordChanged", account.Name);
            return true;
        }

        public static bool Remove(string name, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            accounts.Remove(account.Name);
            Save();

            message = LisunLocale.T("user.removed", account.Name);
            return true;
        }

        public static bool SetEnabled(string name, bool value, out string message)
        {
            Account account = Find(name);
            if (account == null)
            {
                message = LisunLocale.T("user.notFound", name);
                return false;
            }

            account.Enabled = value;
            Save();

            message = LisunLocale.T(value ? "user.enabled" : "user.disabled", account.Name);
            return true;
        }

        /// <summary>Отмечает удачный вход — показывается в списке.</summary>
        public static void NoteLogin(string name)
        {
            Account account = Find(name);
            if (account == null) return;

            account.LastLogin = DateTime.Now;
            account.Logins++;
            Save();
        }

        private static bool ValidName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;

            name = name.Trim();
            if (name.Length < 2 || name.Length > 32) return false;

            foreach (char symbol in name)
                if (!char.IsLetterOrDigit(symbol) && symbol != '_' && symbol != '-') return false;

            return true;
        }

        public static string ListText()
        {
            List<Account> all = All();
            if (all.Count == 0) return LisunLocale.T("user.empty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("user.listTitle", all.Count) + Environment.NewLine);

            foreach (Account account in all)
            {
                sb.AppendLine("   " + (account.Enabled ? "●" : "○") + " " +
                              account.Name.PadRight(20) +
                              (account.Superuser ? LisunLocale.T("user.markSuper") : "").PadRight(14) +
                              LisunLocale.T("user.logins", account.Logins) +
                              (account.LastLogin == DateTime.MinValue ? "" :
                                  "   " + account.LastLogin.ToString("dd.MM HH:mm", CultureInfo.InvariantCulture)));
            }

            return sb.ToString().TrimEnd();
        }
    }
}
