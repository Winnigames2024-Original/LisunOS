﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Что в системе сейчас работает и что из этого можно выключить.
    ///
    /// Правило здесь одно и простое: **выключать можно только то, что
    /// включается обратно**. Поэтому у каждой записи есть не только команда
    /// остановки, но и команда запуска — та самая, которой служба заводится
    /// обычно. Оптимизатор ничего не удаляет и ничего не ломает: он
    /// останавливает, показывает чем вернуть, и возвращает по просьбе.
    ///
    /// «Ненужным» считается то, что работает вхолостую: окно закрыто, демон
    /// отключён, сервер поднят, но к нему никто не подключён. Решение всегда
    /// остаётся за человеком — список показывается до того, как что-то
    /// произойдёт.
    /// </summary>
    public static class LisunOptimizer
    {
        public const string PackageName = "sysopt";

        /// <summary>Одна строка списка: что это, в каком состоянии и чем управлять.</summary>
        public sealed class Item
        {
            public string Name = string.Empty;
            public string Kind = string.Empty;
            public string Title = string.Empty;

            /// <summary>Работает прямо сейчас.</summary>
            public bool Running;

            /// <summary>Работает вхолостую — можно выключить.</summary>
            public bool Idle;

            /// <summary>Почему так решено.</summary>
            public string Why = string.Empty;

            /// <summary>Команда остановки и команда, которой это же включается обратно.</summary>
            public string StopCommand = string.Empty;
            public string StartCommand = string.Empty;

            public override string ToString()
            {
                return Name + " (" + Kind + ")";
            }
        }

        // =====================================================================
        //  Осмотр системы
        // =====================================================================

        /// <summary>Всё, чем оптимизатор умеет управлять.</summary>
        public static List<Item> Scan()
        {
            List<Item> result = new List<Item>();

            AddApplications(result);
            AddDaemons(result);
            AddServices(result);
            AddServers(result);

            return result;
        }

        private static void AddApplications(List<Item> result)
        {
            try
            {
                foreach (KeyValuePair<string, DynamicApp> pair in FormEngine.ActiveApps)
                {
                    DynamicApp app = pair.Value;

                    Item item = new Item();
                    item.Name = pair.Key;
                    item.Kind = LisunLocale.T("opt.kindApp");
                    item.Title = app.CustomTitle ?? app.Description ?? string.Empty;

                    bool hasWindow = app.Form != null && !app.Form.IsDisposed;
                    bool visible = hasWindow && app.Form.Visible;

                    item.Running = hasWindow;
                    item.Idle = hasWindow && !visible;
                    item.Why = !hasWindow ? LisunLocale.T("opt.whyNoWindow")
                             : visible ? LisunLocale.T("opt.whyOpen")
                                       : LisunLocale.T("opt.whyHidden");

                    item.StopCommand = "kill " + pair.Key;
                    item.StartCommand = CommandOf(app, pair.Key);

                    result.Add(item);
                }
            }
            catch { }
        }

        /// <summary>Команда, которой приложение открывается обратно.</summary>
        private static string CommandOf(DynamicApp app, string key)
        {
            try
            {
                foreach (KeyValuePair<string, List<string>> registered in LisunEngine.RegisteredCommands)
                {
                    if (registered.Value == null) continue;

                    foreach (string name in registered.Value)
                        if (string.Equals(name, key, StringComparison.OrdinalIgnoreCase))
                            return registered.Key;
                }
            }
            catch { }

            return key;
        }

        private static void AddDaemons(List<Item> result)
        {
            try
            {
                foreach (LisunDaemons.Daemon daemon in LisunDaemons.All())
                {
                    Item item = new Item();
                    item.Name = daemon.Name;
                    item.Kind = LisunLocale.T("opt.kindDaemon");
                    item.Title = daemon.Description ?? string.Empty;

                    item.Running = daemon.Running;
                    item.Idle = daemon.Running && !LisunDaemons.Enabled(daemon.Name);
                    item.Why = daemon.Running
                        ? (LisunDaemons.Enabled(daemon.Name) ? LisunLocale.T("opt.whyWorking")
                                                             : LisunLocale.T("opt.whyDisabled"))
                        : LisunLocale.T("opt.whyStopped");

                    item.StopCommand = "daemon stop " + daemon.Name;
                    item.StartCommand = "daemon start " + daemon.Name;

                    result.Add(item);
                }
            }
            catch { }
        }

        private static void AddServices(List<Item> result)
        {
            try
            {
                foreach (LisunServiceManager.ServiceInfo service in LisunServiceManager.All())
                {
                    Item item = new Item();
                    item.Name = service.Name;
                    item.Kind = LisunLocale.T("opt.kindService");
                    item.Title = service.Title ?? string.Empty;

                    item.Running = service.Running;

                    // Служба, которая загружена, но её окно нигде не открыто и
                    // автозапуск у неё выключен, работает вхолостую.
                    item.Idle = service.Running && !service.Enabled;
                    item.Why = service.Running
                        ? (service.Enabled ? LisunLocale.T("opt.whyWorking") : LisunLocale.T("opt.whyDisabled"))
                        : LisunLocale.T("opt.whyStopped");

                    item.StopCommand = "systemctl stop " + service.Name;
                    item.StartCommand = "systemctl start " + service.Name;

                    result.Add(item);
                }
            }
            catch { }
        }

        private static void AddServers(List<Item> result)
        {
            // Удалённый вход: поднят, но никто не подключён.
            try
            {
                Item ssh = new Item();
                ssh.Name = "ssh";
                ssh.Kind = LisunLocale.T("opt.kindServer");
                ssh.Title = LisunLocale.T("opt.titleSsh");
                ssh.Running = SshHost.Running;
                ssh.Idle = SshHost.Running && SshHost.Live.Count == 0;
                ssh.Why = !SshHost.Running ? LisunLocale.T("opt.whyStopped")
                        : SshHost.Live.Count > 0 ? LisunLocale.T("opt.whySessions", SshHost.Live.Count)
                                                : LisunLocale.T("opt.whyNoSessions");
                ssh.StopCommand = "ssh stop";
                ssh.StartCommand = "ssh start";

                result.Add(ssh);
            }
            catch { }

            // Системный порт 8989: нужен только во время установки PHP.
            try
            {
                Item system = new Item();
                system.Name = "system";
                system.Kind = LisunLocale.T("opt.kindServer");
                system.Title = LisunLocale.T("opt.titleSystem");
                system.Running = LisunSystemServer.Running;
                system.Idle = LisunSystemServer.Running && !LisunPhpModule.Downloading;
                system.Why = LisunSystemServer.Running
                    ? (LisunPhpModule.Downloading ? LisunLocale.T("opt.whyWorking")
                                                  : LisunLocale.T("opt.whyIdlePort"))
                    : LisunLocale.T("opt.whyStopped");
                system.StopCommand = "system stop";
                system.StartCommand = "system start";

                result.Add(system);
            }
            catch { }
        }

        // =====================================================================
        //  Что было остановлено
        //
        //  Оптимизатор помнит, что выключил он сам. Это и есть обещание
        //  «выключенное включается обратно»: «optimize start» без имени
        //  поднимает ровно то, что останавливал он, — каждое своей командой.
        // =====================================================================

        private static readonly object gate = new object();
        private static readonly List<string> stopped = new List<string>();

        /// <summary>Что оптимизатор остановил и ещё не вернул.</summary>
        public static List<string> Stopped()
        {
            lock (gate) return new List<string>(stopped);
        }

        private static void Remember(string name)
        {
            lock (gate)
            {
                if (!stopped.Contains(name)) stopped.Add(name);
            }
        }

        private static void Forget(string name)
        {
            lock (gate) stopped.Remove(name);
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        /// <summary>Останавливает запись её же командой остановки.</summary>
        public static bool Stop(string name, out string message)
        {
            Item item = Find(name);

            if (item == null)
            {
                message = LisunLocale.T("opt.unknown", name);
                return false;
            }

            if (!item.Running)
            {
                message = LisunLocale.T("opt.alreadyStopped", item.Name, item.StartCommand);
                return false;
            }

            message = Run(item.StopCommand);
            Remember(item.Name);

            LisunEngine.Log("[opt] " + LisunLocale.T("opt.stopped", item.Name, item.StartCommand).Trim());
            return true;
        }

        /// <summary>
        /// Запускает запись обратно — той самой командой, которая показана
        /// в списке. Это и есть обещание: выключенное включается обратно.
        /// </summary>
        public static bool Start(string name, out string message)
        {
            Item item = Find(name);

            if (item == null)
            {
                message = LisunLocale.T("opt.unknown", name);
                return false;
            }

            message = Run(item.StartCommand);
            Forget(item.Name);

            return true;
        }

        /// <summary>
        /// Возвращает обратно всё, что останавливал оптимизатор. Если он
        /// ничего не останавливал — поднимает то, что стоит остановленным и
        /// умеет запускаться своей командой.
        /// </summary>
        public static string StartAll()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("opt.startHeader"));
            sb.AppendLine();

            List<string> names = Stopped();

            if (names.Count == 0)
            {
                foreach (Item item in Scan())
                    if (!item.Running && item.StartCommand.Length > 0) names.Add(item.Name);
            }

            int started = 0;

            foreach (string name in names)
            {
                Item item = Find(name);
                if (item == null || item.Running) continue;

                string message;
                Start(name, out message);
                started++;

                sb.AppendLine("   " + Pad(name, 20) + message.Trim());
            }

            sb.AppendLine();
            sb.AppendLine("   " + (started == 0
                ? LisunLocale.T("opt.startNothing")
                : LisunLocale.T("opt.startCount", started)));

            return sb.ToString();
        }

        /// <summary>Подробно: что это, почему так решено и чем управлять.</summary>
        public static string InfoText()
        {
            List<Item> list = Scan();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("opt.infoHeader"));
            sb.AppendLine();

            foreach (Item item in list)
            {
                sb.AppendLine("   " + item.Name + "   (" + item.Kind + ")");

                if (item.Title.Length > 0) sb.AppendLine("      " + item.Title);

                sb.AppendLine("      " + LisunLocale.T("opt.fieldState") + (item.Running
                    ? (item.Idle ? LisunLocale.T("opt.stateIdle") : LisunLocale.T("opt.stateWorking"))
                    : LisunLocale.T("opt.stateStopped")) + "   —   " + item.Why);

                sb.AppendLine("      " + LisunLocale.T("opt.stopWith", item.StopCommand));
                sb.AppendLine("      " + LisunLocale.T("opt.backWith", item.StartCommand));
                sb.AppendLine();
            }

            List<string> remembered = Stopped();

            if (remembered.Count > 0)
                sb.AppendLine("   " + LisunLocale.T("opt.remembered",
                    string.Join(", ", remembered.ToArray())));

            sb.AppendLine("   " + LisunLocale.T("opt.hint"));

            return sb.ToString();
        }

        public static Item Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;

            foreach (Item item in Scan())
            {
                if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase)) return item;
                if (LisunStore.SameName(item.Name, name)) return item;
            }

            return null;
        }

        private static string Run(string command)
        {
            if (string.IsNullOrEmpty(command)) return LisunLocale.T("opt.noCommand");

            try { return CommandExecutorEngine.Execute(command); }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        /// <summary>
        /// Выключает всё, что работает вхолостую. Возвращает отчёт, в котором
        /// у каждой строки написано, чем её вернуть.
        /// </summary>
        public static string Optimize(bool apply)
        {
            List<Item> list = Scan();
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(apply ? LisunLocale.T("opt.runHeader") : LisunLocale.T("opt.planHeader"));
            sb.AppendLine();

            int touched = 0;

            foreach (Item item in list)
            {
                if (!item.Idle) continue;

                touched++;

                if (!apply)
                {
                    sb.AppendLine("   " + Pad(item.Name, 20) + Pad(item.Kind, 14) + item.Why);
                    sb.AppendLine("      " + LisunLocale.T("opt.wouldStop", item.StopCommand));
                    sb.AppendLine("      " + LisunLocale.T("opt.backWith", item.StartCommand));
                    continue;
                }

                string message;
                Stop(item.Name, out message);

                sb.AppendLine("   " + Pad(item.Name, 20) + Pad(item.Kind, 14) + message.Trim());
                sb.AppendLine("      " + LisunLocale.T("opt.backWith", item.StartCommand));
            }

            sb.AppendLine();

            if (touched == 0) sb.AppendLine("   " + LisunLocale.T("opt.nothing"));
            else sb.AppendLine("   " + LisunLocale.T(apply ? "opt.doneCount" : "opt.planCount", touched));

            if (!apply && touched > 0) sb.AppendLine("   " + LisunLocale.T("opt.applyHint"));

            return sb.ToString();
        }

        /// <summary>Полный список: что работает, что вхолостую, чем вернуть.</summary>
        public static string StatusText()
        {
            List<Item> list = Scan();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("opt.header"));
            sb.AppendLine();

            int running = 0;
            int idle = 0;

            foreach (Item item in list)
            {
                if (item.Running) running++;
                if (item.Idle) idle++;

                string state = item.Running
                    ? (item.Idle ? LisunLocale.T("opt.stateIdle") : LisunLocale.T("opt.stateWorking"))
                    : LisunLocale.T("opt.stateStopped");

                sb.AppendLine("   " + Pad(item.Name, 20) + Pad(item.Kind, 14) + Pad(state, 16) + item.Why);
                sb.AppendLine("      " + (item.Running
                    ? LisunLocale.T("opt.stopWith", item.StopCommand)
                    : LisunLocale.T("opt.backWith", item.StartCommand)));
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("opt.summary", list.Count, running, idle));
            sb.AppendLine("   " + LisunLocale.T("opt.hint"));

            return sb.ToString();
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value.Substring(0, width - 1) + " " : value.PadRight(width);
        }
    }
}
