﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>Логика блокнота LisunOS: чтение и запись файлов виртуальной системы.</summary>
    public class NotepadLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly TextBox editor;
        private readonly Label filePath;
        private readonly Label status;
        private readonly Button newFile;
        private readonly Button openFile;
        private readonly Button saveFile;

        private string currentFile;
        private bool dirty;

        public NotepadLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            editor = context.Get<TextBox>("txtEditor");
            filePath = context.Get<Label>("lblFilePath");
            status = context.Get<Label>("lblEditorStatus");
            newFile = context.Get<Button>("btnNewFile");
            openFile = context.Get<Button>("btnOpenFile");
            saveFile = context.Get<Button>("btnSaveFile");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("pad.title");

            if (editor != null) editor.Font = Theme.Mono(11f);
            if (filePath != null) filePath.Font = Theme.Mono(9f);
            if (status != null) status.Font = Theme.Mono(9f);

            if (newFile != null) Theme.StyleButton(newFile, Theme.SurfaceAlt, Theme.Text);
            if (openFile != null) Theme.StyleButton(openFile, Theme.SurfaceAlt, Theme.Text);
            if (saveFile != null) Theme.StyleButton(saveFile, Theme.AccentDeep, Theme.Text);

            UpdateStatus();
        }

        private void UpdateStatus()
        {
            if (filePath != null)
            {
                filePath.Text = (currentFile == null
                    ? LisunLocale.T("pad.newFile")
                    : CustomFormUtils.ToVirtualPath(currentFile)) + (dirty ? " •" : "");
                filePath.ForeColor = dirty ? Theme.Warning : Theme.TextDim;
            }

            if (status != null && editor != null)
            {
                string text = editor.Text ?? string.Empty;
                status.Text = LisunLocale.T("pad.status", editor.Lines.Length, text.Length);
            }
        }

        private void txtEditor_TextChanged(object sender, EventArgs e)
        {
            dirty = true;
            UpdateStatus();
        }

        private void btnNewFile_Click(object sender, EventArgs e)
        {
            if (!ConfirmDiscard()) return;

            currentFile = null;
            dirty = false;
            if (editor != null) editor.Text = string.Empty;

            dirty = false;
            UpdateStatus();
        }

        private void btnOpenFile_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;
            if (!ConfirmDiscard()) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("pad.openTitle"),
                LisunLocale.T("pad.openPrompt"), "root\\documents\\notes.txt", form);
            if (string.IsNullOrEmpty(name)) return;

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, name, out resolved))
            {
                Warn(LisunLocale.T("pad.outsideRoot"));
                return;
            }

            if (!File.Exists(resolved))
            {
                Warn(LisunLocale.T("pad.notFound", name));
                return;
            }

            if (editor != null) editor.Text = LisunCrypto.ReadAllText(resolved);

            currentFile = resolved;
            dirty = false;
            UpdateStatus();
        }

        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            string permission = currentFile == null ? LisunPermissions.WriteFiles : LisunPermissions.EditFiles;
            if (!LisunPermissions.Demand(packageName, permission)) return;

            if (currentFile == null)
            {
                string name = CustomFormUtils.Prompt(LisunLocale.T("pad.saveTitle"),
                    LisunLocale.T("pad.savePrompt"), "root\\documents\\notes.txt", form);
                if (string.IsNullOrEmpty(name)) return;

                string resolved;
                if (!CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, name, out resolved))
                {
                    Warn(LisunLocale.T("pad.outsideRoot"));
                    return;
                }
                currentFile = resolved;
            }

            if (!CustomFormUtils.WriteFileText(currentFile, editor == null ? string.Empty : editor.Text))
            {
                Warn(LisunLocale.T("pad.saveFailed"));
                return;
            }

            dirty = false;
            UpdateStatus();
            LisunEngine.Log("[Notepad] Сохранён " + CustomFormUtils.ToVirtualPath(currentFile));
        }

        private bool ConfirmDiscard()
        {
            if (!dirty) return true;

            DialogResult answer = MessageBox.Show(LisunLocale.T("pad.discard"),
                LisunLocale.T("pad.title"), MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            return answer == DialogResult.Yes;
        }

        private void Warn(string message)
        {
            MessageBox.Show(message, LisunLocale.T("pad.title"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
