﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Подтверждение действия паролем — как окно контроля учётных записей
    /// в Windows.
    ///
    /// Ограничение пользователя не означает «нельзя никогда»: оно означает
    /// «нельзя без разрешения». Поэтому вместо глухого отказа система
    /// показывает окно и спрашивает пароль администратора. Пароль задаётся
    /// один раз при первом запуске; если его не задали, окно просто
    /// спрашивает подтверждение — скрывать нечего.
    /// </summary>
    public static class LisunElevation
    {
        /// <summary>Пока true, окно не показывается: загрузка или сеанс по сети.</summary>
        public static bool SilentMode { get; set; }

        /// <summary>Сколько подтверждение действует, чтобы окно не всплывало на каждую команду.</summary>
        private static readonly TimeSpan Remember = TimeSpan.FromMinutes(5);

        private static DateTime confirmedUntil = DateTime.MinValue;
        private static string confirmedFor = string.Empty;

        // =====================================================================
        //  Пароль администратора
        // =====================================================================

        /// <summary>Задан ли пароль root. Пустой пароль — это «пароля нет».</summary>
        public static bool HasPassword
        {
            get
            {
                LisunUsers.Account root = LisunUsers.Find(LisunUsers.RootName);
                return root != null && root.Hash.Length > 0;
            }
        }

        /// <summary>
        /// Первый запуск: предложить задать пароль администратора.
        /// Отказ — не ошибка: систему можно держать и без пароля.
        /// </summary>
        public static void AskOnFirstRun()
        {
            string asked;
            if (LisunEngine.RegistryData.TryGetValue("root_password_asked", out asked) &&
                asked.Equals("true", StringComparison.OrdinalIgnoreCase)) return;

            LisunEngine.RegistryData["root_password_asked"] = "true";
            LisunEngine.SaveRegistry();

            if (HasPassword) return;

            string password = AskPassword(
                LisunLocale.T("elev.setupTitle"),
                LisunLocale.T("elev.setupBody"),
                true);

            if (string.IsNullOrEmpty(password))
            {
                LisunEngine.Log("[elev] " + LisunLocale.T("elev.setupSkipped").Trim());
                return;
            }

            string message;
            LisunUsers.SetPassword(LisunUsers.RootName, password, out message);
            LisunEngine.Log("[elev] " + message.Trim());
        }

        // =====================================================================
        //  Подтверждение
        // =====================================================================

        /// <summary>
        /// Спрашивает подтверждение на закрытое действие.
        /// Возвращает true, если пользователь его разрешил.
        /// </summary>
        public static bool Confirm(string user, string token, string what)
        {
            if (SilentMode) return false;

            // Одно подтверждение держится несколько минут: иначе окно
            // всплывало бы на каждую команду подряд.
            if (confirmedFor == token && DateTime.Now < confirmedUntil) return true;

            bool allowed = false;

            LisunEngine.RunOnUi(() =>
            {
                allowed = Ask(user, token, what);
            });

            if (allowed)
            {
                confirmedFor = token;
                confirmedUntil = DateTime.Now.Add(Remember);

                LisunEngine.Log("[elev] " + LisunLocale.T("elev.allowed", user, token).Trim());
            }
            else LisunEngine.Log("[elev] " + LisunLocale.T("elev.refused", user, token).Trim());

            return allowed;
        }

        /// <summary>Забыть подтверждение — например при смене пользователя.</summary>
        public static void Forget()
        {
            confirmedFor = string.Empty;
            confirmedUntil = DateTime.MinValue;
        }

        private static bool Ask(string user, string token, string what)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = LisunLocale.T("elev.title");
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = FormStartPosition.CenterScreen;
                dialog.MinimizeBox = false;
                dialog.MaximizeBox = false;
                dialog.ShowInTaskbar = false;
                dialog.TopMost = true;
                dialog.BackColor = Theme.Background;
                dialog.ForeColor = Theme.Text;
                dialog.Font = Theme.Ui(9.5f);
                dialog.ClientSize = new Size(520, HasPassword ? 268 : 224);

                // Полоса сверху: сразу видно, что окно системное.
                Panel stripe = new Panel();
                stripe.BackColor = Theme.Warning;
                stripe.SetBounds(0, 0, 520, 4);
                dialog.Controls.Add(stripe);

                Label title = new Label();
                title.Text = LisunLocale.T("elev.header");
                title.Font = Theme.Ui(13f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
                title.AutoSize = false;
                title.SetBounds(24, 22, 472, 28);
                dialog.Controls.Add(title);

                Label body = new Label();
                body.Text = LisunLocale.T("elev.body", user);
                body.ForeColor = Theme.TextDim;
                body.AutoSize = false;
                body.SetBounds(24, 54, 472, 38);
                dialog.Controls.Add(body);

                Panel card = new Panel();
                card.BackColor = Theme.Surface;
                card.SetBounds(24, 96, 472, 62);
                dialog.Controls.Add(card);

                Label action = new Label();
                action.Text = LisunUsers.DescribeToken(token);
                action.Font = Theme.Ui(10.5f, FontStyle.Bold);
                action.ForeColor = Theme.Text;
                action.AutoSize = false;
                action.SetBounds(16, 10, 440, 22);
                card.Controls.Add(action);

                Label detail = new Label();
                detail.Text = LisunLocale.T("elev.detail", what, token);
                detail.Font = Theme.Mono(8.5f);
                detail.ForeColor = Theme.TextDim;
                detail.AutoSize = false;
                detail.SetBounds(16, 34, 440, 20);
                card.Controls.Add(detail);

                TextBox password = null;

                if (HasPassword)
                {
                    Label caption = new Label();
                    caption.Text = LisunLocale.T("elev.passwordCaption");
                    caption.ForeColor = Theme.TextDim;
                    caption.AutoSize = false;
                    caption.SetBounds(24, 170, 472, 20);
                    dialog.Controls.Add(caption);

                    password = new TextBox();
                    password.UseSystemPasswordChar = true;
                    password.Font = Theme.Mono(11f);
                    password.BackColor = Theme.SurfaceAlt;
                    password.ForeColor = Theme.Text;
                    password.BorderStyle = BorderStyle.FixedSingle;
                    password.SetBounds(24, 192, 472, 26);
                    dialog.Controls.Add(password);
                }

                Label hint = new Label();
                hint.Text = LisunLocale.T("elev.hint");
                hint.Font = Theme.Ui(8.5f);
                hint.ForeColor = Theme.TextDim;
                hint.AutoSize = false;
                hint.SetBounds(24, HasPassword ? 226 : 170, 300, 34);
                dialog.Controls.Add(hint);

                Button no = new Button();
                no.Text = LisunLocale.T("elev.no");
                no.DialogResult = DialogResult.Cancel;
                no.SetBounds(290, HasPassword ? 228 : 184, 100, 30);
                Theme.StyleButton(no, Theme.SurfaceAlt, Theme.TextDim);
                dialog.Controls.Add(no);

                Button yes = new Button();
                yes.Text = LisunLocale.T("elev.yes");
                yes.DialogResult = DialogResult.OK;
                yes.SetBounds(396, HasPassword ? 228 : 184, 100, 30);
                Theme.StyleButton(yes, Theme.AccentDeep, Theme.Text);
                dialog.Controls.Add(yes);

                dialog.AcceptButton = yes;
                dialog.CancelButton = no;

                // Три попытки: обычная опечатка не должна закрывать окно.
                for (int attempt = 0; attempt < 3; attempt++)
                {
                    if (dialog.ShowDialog() != DialogResult.OK) return false;
                    if (password == null) return true;

                    if (LisunUsers.Check(LisunUsers.RootName, password.Text)) return true;

                    password.Text = string.Empty;
                    password.Focus();

                    hint.ForeColor = Theme.Danger;
                    hint.Text = LisunLocale.T("elev.wrong", 2 - attempt);
                }

                return false;
            }
        }

        /// <summary>Окно ввода пароля — и для первой настройки, и для смены.</summary>
        public static string AskPassword(string title, string body, bool allowSkip)
        {
            string result = null;

            LisunEngine.RunOnUi(() =>
            {
                using (Form dialog = new Form())
                {
                    dialog.Text = title;
                    dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                    dialog.StartPosition = FormStartPosition.CenterScreen;
                    dialog.MinimizeBox = false;
                    dialog.MaximizeBox = false;
                    dialog.ShowInTaskbar = false;
                    dialog.TopMost = true;
                    dialog.BackColor = Theme.Background;
                    dialog.ForeColor = Theme.Text;
                    dialog.Font = Theme.Ui(9.5f);
                    dialog.ClientSize = new Size(520, 246);

                    Panel stripe = new Panel();
                    stripe.BackColor = Theme.Accent;
                    stripe.SetBounds(0, 0, 520, 4);
                    dialog.Controls.Add(stripe);

                    Label caption = new Label();
                    caption.Text = title;
                    caption.Font = Theme.Ui(13f, FontStyle.Bold);
                    caption.AutoSize = false;
                    caption.SetBounds(24, 22, 472, 28);
                    dialog.Controls.Add(caption);

                    Label text = new Label();
                    text.Text = body;
                    text.ForeColor = Theme.TextDim;
                    text.AutoSize = false;
                    text.SetBounds(24, 54, 472, 56);
                    dialog.Controls.Add(text);

                    TextBox first = new TextBox();
                    first.UseSystemPasswordChar = true;
                    first.Font = Theme.Mono(11f);
                    first.BackColor = Theme.SurfaceAlt;
                    first.ForeColor = Theme.Text;
                    first.BorderStyle = BorderStyle.FixedSingle;
                    first.SetBounds(24, 116, 472, 26);
                    dialog.Controls.Add(first);

                    TextBox again = new TextBox();
                    again.UseSystemPasswordChar = true;
                    again.Font = Theme.Mono(11f);
                    again.BackColor = Theme.SurfaceAlt;
                    again.ForeColor = Theme.Text;
                    again.BorderStyle = BorderStyle.FixedSingle;
                    again.SetBounds(24, 150, 472, 26);
                    dialog.Controls.Add(again);

                    Label note = new Label();
                    note.Text = LisunLocale.T("elev.repeat");
                    note.Font = Theme.Ui(8.5f);
                    note.ForeColor = Theme.TextDim;
                    note.AutoSize = false;
                    note.SetBounds(24, 182, 300, 34);
                    dialog.Controls.Add(note);

                    Button skip = new Button();
                    skip.Text = LisunLocale.T("elev.skip");
                    skip.DialogResult = DialogResult.Cancel;
                    skip.Visible = allowSkip;
                    skip.SetBounds(290, 196, 100, 30);
                    Theme.StyleButton(skip, Theme.SurfaceAlt, Theme.TextDim);
                    dialog.Controls.Add(skip);

                    Button ok = new Button();
                    ok.Text = LisunLocale.T("elev.save");
                    ok.DialogResult = DialogResult.OK;
                    ok.SetBounds(396, 196, 100, 30);
                    Theme.StyleButton(ok, Theme.AccentDeep, Theme.Text);
                    dialog.Controls.Add(ok);

                    dialog.AcceptButton = ok;
                    dialog.CancelButton = skip;

                    while (true)
                    {
                        if (dialog.ShowDialog() != DialogResult.OK) { result = null; return; }

                        if (first.Text.Length < 4)
                        {
                            note.ForeColor = Theme.Danger;
                            note.Text = LisunLocale.T("elev.tooShort");
                            continue;
                        }

                        if (first.Text != again.Text)
                        {
                            note.ForeColor = Theme.Danger;
                            note.Text = LisunLocale.T("elev.mismatch");

                            again.Text = string.Empty;
                            continue;
                        }

                        result = first.Text;
                        return;
                    }
                }
            });

            return result;
        }
    }
}
