﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Один компонент системы: то, что LisunOS умеет докачать с сайта.
    /// Kind решает, что делать после загрузки.
    /// </summary>
    public sealed class LisunComponent
    {
        /// <summary>runtime — интерпретатор, zip — архив в папку, catalog — список
        /// пакетов, builtin — уже внутри ядра, system — сам LisunOS.exe.</summary>
        public string Kind = "zip";

        public string Name = string.Empty;
        public string Title = string.Empty;
        public string Description = string.Empty;
        public string Version = string.Empty;
        public string Note = string.Empty;

        /// <summary>Кому компонент нужен: «webserverv2», «mdreader» и т. п.</summary>
        public string NeededBy = string.Empty;

        /// <summary>Зеркала: перебираются до первого рабочего.</summary>
        public List<string> Urls = new List<string>();

        /// <summary>Ожидаемый отпечаток архива, если он указан в каталоге.</summary>
        public string Sha256 = string.Empty;

        /// <summary>Примерный размер для списка — чтобы было видно, что качать.</summary>
        public long Size;

        public bool BuiltIn
        {
            get { return string.Equals(Kind, "builtin", StringComparison.OrdinalIgnoreCase); }
        }

        public bool Removable
        {
            get
            {
                return !BuiltIn &&
                       !string.Equals(Kind, "system", StringComparison.OrdinalIgnoreCase) &&
                       !string.Equals(Kind, "catalog", StringComparison.OrdinalIgnoreCase);
            }
        }

        public override string ToString()
        {
            return Name + " " + Version;
        }
    }

    /// <summary>
    /// Компоненты LisunOS: что система может докачать сама и что у неё уже есть.
    ///
    /// Список лежит на сайте (libs/index.json), а в коде есть такой же
    /// встроенный — без интернета «lib list» всё равно отвечает. Про встроенное
    /// здесь написано честно: SSH-2, Wi-Fi и движок PHP живут в ядре, и качать
    /// для них нечего. Докачиваются только настоящие внешние вещи: сборка PHP
    /// для Windows, документация, каталог пакетов и сам LisunOS.exe.
    /// </summary>
    public static class LisunLibraries
    {
        public const string PackageName = "lib";

        public const string DefaultCatalogUrl =
            "https://winnigames2024-original.github.io/LisunOS/libs/index.json";

        private static readonly object gate = new object();
        private static readonly List<LisunComponent> remote = new List<LisunComponent>();

        private static DateTime fetchedAt = DateTime.MinValue;
        private static string lastError = string.Empty;

        /// <summary>Папка докачанных компонентов: /os/root/lib/&lt;имя&gt;.</summary>
        public static readonly string LibPath = Path.Combine(LisunEngine.RootPath, "root", "lib");

        /// <summary>Папка документации: /os/root/docs.</summary>
        public static readonly string DocsPath = Path.Combine(LisunEngine.RootPath, "root", "docs");

        public static DateTime FetchedAt { get { return fetchedAt; } }
        public static string LastError { get { return lastError; } }

        /// <summary>Адрес каталога компонентов: CONFIG libs_url, иначе сайт проекта.</summary>
        public static string CatalogUrl
        {
            get
            {
                string value;
                if (LisunEngine.RegistryConfig != null &&
                    LisunEngine.RegistryConfig.TryGetValue("libs_url", out value) &&
                    !string.IsNullOrEmpty(value))
                    return value.Trim();

                return DefaultCatalogUrl;
            }
            set
            {
                if (LisunEngine.RegistryConfig == null) return;

                LisunEngine.RegistryConfig["libs_url"] = (value ?? string.Empty).Trim();
                LisunEngine.SaveRegistry();
            }
        }

        /// <summary>Докачивать ли компонент молча, когда он понадобился.</summary>
        public static bool AutoEnabled
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData != null &&
                    LisunEngine.RegistryData.TryGetValue("libs_auto", out value))
                    return !string.Equals(value, "0", StringComparison.Ordinal) &&
                           !string.Equals(value, "off", StringComparison.OrdinalIgnoreCase);

                return true;
            }
            set
            {
                if (LisunEngine.RegistryData == null) return;

                LisunEngine.RegistryData["libs_auto"] = value ? "1" : "0";
                LisunEngine.SaveRegistry();
            }
        }

        // =====================================================================
        //  Встроенный список
        // =====================================================================

        /// <summary>
        /// Тот же список, что на сайте, но вшитый в exe. Сетевой каталог может
        /// только уточнить версии и ссылки — выдумать новый компонент он не может:
        /// распаковывать неизвестное из интернета система не станет.
        /// </summary>
        private static List<LisunComponent> BuiltInList()
        {
            List<LisunComponent> list = new List<LisunComponent>();

            LisunComponent php = new LisunComponent();
            php.Name = "php";
            php.Kind = "runtime";
            php.Version = "8.x";
            php.Title = LisunLocale.T("lib.phpTitle");
            php.Description = LisunLocale.T("lib.phpDescription");
            php.NeededBy = "webserverv2";
            php.Size = 30 * 1024 * 1024;
            php.Urls.AddRange(LisunPhpModule.Mirrors);
            list.Add(php);

            LisunComponent docs = new LisunComponent();
            docs.Name = "docs";
            docs.Kind = "zip";
            docs.Version = LisunEngine.Version;
            docs.Title = LisunLocale.T("lib.docsTitle");
            docs.Description = LisunLocale.T("lib.docsDescription");
            docs.Size = 380 * 1024;
            docs.Urls.Add("https://github.com/Winnigames2024-Original/LisunOS/releases/download/v" +
                          LisunEngine.Version + "/LisunOS-" + LisunEngine.Version + ".zip");
            list.Add(docs);

            LisunComponent apps = new LisunComponent();
            apps.Name = "apps";
            apps.Kind = "catalog";
            apps.Version = LisunEngine.Version;
            apps.Title = LisunLocale.T("lib.appsTitle");
            apps.Description = LisunLocale.T("lib.appsDescription");
            apps.Urls.Add(LisunStore.CatalogUrl);
            list.Add(apps);

            LisunComponent system = new LisunComponent();
            system.Name = "system";
            system.Kind = "system";
            system.Version = LisunEngine.Version;
            system.Title = LisunLocale.T("lib.systemTitle");
            system.Description = LisunLocale.T("lib.systemDescription");
            system.Urls.Add(LisunUpdates.ReleasesUrl);
            list.Add(system);

            LisunComponent ssh = new LisunComponent();
            ssh.Name = "ssh";
            ssh.Kind = "builtin";
            ssh.Version = "SSH-2";
            ssh.Title = LisunLocale.T("lib.sshTitle");
            ssh.Description = LisunLocale.T("lib.sshDescription");
            ssh.Note = LisunLocale.T("lib.sshNote");
            list.Add(ssh);

            LisunComponent wifi = new LisunComponent();
            wifi.Name = "wifi";
            wifi.Kind = "builtin";
            wifi.Version = "netsh wlan";
            wifi.Title = LisunLocale.T("lib.wifiTitle");
            wifi.Description = LisunLocale.T("lib.wifiDescription");
            wifi.Note = LisunLocale.T("lib.wifiNote");
            list.Add(wifi);

            LisunComponent engine = new LisunComponent();
            engine.Name = "php-engine";
            engine.Kind = "builtin";
            engine.Version = LisunEngine.Version;
            engine.Title = LisunLocale.T("lib.engineTitle");
            engine.Description = LisunLocale.T("lib.engineDescription");
            engine.Note = LisunLocale.T("lib.engineNote");
            list.Add(engine);

            return list;
        }

        /// <summary>Список компонентов: встроенный, уточнённый сетевым каталогом.</summary>
        public static List<LisunComponent> Items()
        {
            List<LisunComponent> list = BuiltInList();

            lock (gate)
            {
                foreach (LisunComponent fresh in remote)
                {
                    LisunComponent known = null;

                    foreach (LisunComponent item in list)
                    {
                        if (!string.Equals(item.Name, fresh.Name, StringComparison.OrdinalIgnoreCase))
                            continue;

                        known = item;
                        break;
                    }

                    if (known == null) continue;   // чужое имя — молча мимо

                    if (fresh.Version.Length > 0) known.Version = fresh.Version;
                    if (fresh.Title.Length > 0) known.Title = fresh.Title;
                    if (fresh.Description.Length > 0) known.Description = fresh.Description;
                    if (fresh.Note.Length > 0) known.Note = fresh.Note;
                    if (fresh.NeededBy.Length > 0) known.NeededBy = fresh.NeededBy;
                    if (fresh.Sha256.Length > 0) known.Sha256 = fresh.Sha256;
                    if (fresh.Size > 0) known.Size = fresh.Size;

                    if (fresh.Urls.Count > 0 && !known.BuiltIn)
                    {
                        known.Urls.Clear();
                        known.Urls.AddRange(fresh.Urls);
                    }
                }
            }

            return list;
        }

        public static LisunComponent Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;

            foreach (LisunComponent item in Items())
                if (string.Equals(item.Name, name, StringComparison.OrdinalIgnoreCase))
                    return item;

            return null;
        }

        // =====================================================================
        //  Каталог с сайта
        // =====================================================================

        /// <summary>Перечитывает libs/index.json с сайта.</summary>
        public static bool Refresh(string requester, out string message)
        {
            if (!LisunPermissions.Demand(requester ?? PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("lib.needNetwork");
                return false;
            }

            string error;
            string body = LisunDownloads.FetchText(CatalogUrl, 15000, out error);

            if (body == null)
            {
                lastError = error;
                message = LisunLocale.T("lib.catalogFailed", error);
                return false;
            }

            int count = Parse(body);

            fetchedAt = DateTime.Now;
            lastError = string.Empty;

            message = LisunLocale.T("lib.catalogOk", count);
            LisunEngine.Log("[lib] " + message.Trim());
            return true;
        }

        private static int Parse(string body)
        {
            lock (gate) remote.Clear();

            LisunJson.Node root = LisunJson.Parse(body);
            if (root == null) return 0;

            LisunJson.Node list = root.IsArray ? root : root.Child("components");
            if (list == null || !list.IsArray) return 0;

            bool english = LisunLocale.Language == LisunLanguage.English;

            foreach (LisunJson.Node node in list.Array)
            {
                if (!node.IsObject) continue;

                LisunComponent item = new LisunComponent();
                item.Name = Text(node, "name");
                if (item.Name.Length == 0) continue;

                item.Kind = Text(node, "kind");
                item.Version = Text(node, "version");
                item.Sha256 = Text(node, "sha256");
                item.NeededBy = Text(node, "needed_by");

                item.Title = Text(node, english ? "title_en" : "title_ru");
                if (item.Title.Length == 0) item.Title = Text(node, "title");

                item.Description = Text(node, english ? "description_en" : "description_ru");
                if (item.Description.Length == 0) item.Description = Text(node, "description");

                item.Note = Text(node, english ? "note_en" : "note_ru");
                if (item.Note.Length == 0) item.Note = Text(node, "note");

                LisunJson.Node size = node.Child("size");
                if (size != null) item.Size = (long)size.Number;

                LisunJson.Node urls = node.Child("urls");
                if (urls != null && urls.IsArray) item.Urls.AddRange(urls.AsTextList());

                string single = Text(node, "url");
                if (item.Urls.Count == 0 && single.Length > 0) item.Urls.Add(single);

                lock (gate) remote.Add(item);
            }

            lock (gate) return remote.Count;
        }

        private static string Text(LisunJson.Node node, string key)
        {
            LisunJson.Node child = node.Child(key);
            return child == null ? string.Empty : child.AsText().Trim();
        }

        // =====================================================================
        //  Установлен или нет
        // =====================================================================

        /// <summary>Где лежит компонент. Пусто — он не ставится в папку.</summary>
        public static string PathOf(LisunComponent item)
        {
            if (item == null) return string.Empty;

            switch (item.Kind.ToLowerInvariant())
            {
                case "runtime":
                    return LisunPhpModule.OwnDirectory;

                case "zip":
                    return string.Equals(item.Name, "docs", StringComparison.OrdinalIgnoreCase)
                        ? DocsPath
                        : Path.Combine(LibPath, item.Name);

                default:
                    return string.Empty;
            }
        }

        public static bool Installed(LisunComponent item)
        {
            if (item == null) return false;

            switch (item.Kind.ToLowerInvariant())
            {
                case "builtin":
                    return true;

                case "system":
                    return true;

                case "runtime":
                    return LisunPhpModule.OwnPhpInstalled || LisunPhpModule.IsInstalled;

                case "catalog":
                    return LisunStore.Remote().Count > 0;

                default:
                    string path = PathOf(item);

                    try
                    {
                        // Достаточно знать, что папка не пуста: обход всего
                        // дерева файлов ради одного «да» стоил заметного времени,
                        // а спрашивают это часто — вплоть до каждой подсказки.
                        if (path.Length == 0 || !Directory.Exists(path)) return false;

                        foreach (string entry in Directory.EnumerateFileSystemEntries(path)) return true;

                        return false;
                    }
                    catch { return false; }
            }
        }

        /// <summary>Сколько места занял компонент на диске.</summary>
        public static long SizeOnDisk(LisunComponent item)
        {
            string path = PathOf(item);
            if (path.Length == 0 || !Directory.Exists(path)) return 0;

            long total = 0;

            try
            {
                string[] files = Directory.GetFiles(path, "*", SearchOption.AllDirectories);

                for (int index = 0; index < files.Length; index++)
                {
                    try { total += new FileInfo(files[index]).Length; }
                    catch { }
                }
            }
            catch { }

            return total;
        }

        // =====================================================================
        //  Установка
        // =====================================================================

        /// <summary>Ставит компонент: качает, проверяет и раскладывает по месту.</summary>
        public static bool Install(string name, out string message)
        {
            LisunComponent item = Find(name);

            if (item == null)
            {
                message = LisunLocale.T("lib.unknown", name);
                return false;
            }

            if (item.BuiltIn)
            {
                message = LisunLocale.T("lib.builtinNothing", item.Name,
                    item.Note.Length > 0 ? item.Note : item.Description);
                return true;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("lib.needNetwork");
                return false;
            }

            switch (item.Kind.ToLowerInvariant())
            {
                case "catalog":
                    return Refresh(PackageName, out message);

                case "system":
                    return LisunUpdates.Check(out message);

                case "runtime":
                    return InstallRuntime(item, out message);

                default:
                    return InstallZip(item, out message);
            }
        }

        /// <summary>Сборка PHP для Windows: архив с php.net в папку php-frm.</summary>
        private static bool InstallRuntime(LisunComponent item, out string message)
        {
            string archive = Path.Combine(LisunEngine.TempPath, "php-frm.zip");

            try { if (File.Exists(archive)) File.Delete(archive); }
            catch { }

            string note;
            LisunDownload download = LisunDownloads.Fetch("php", item.Urls.ToArray(),
                archive, item.Sha256, out note);

            if (download.State != LisunDownloadState.Done)
            {
                message = note;
                return false;
            }

            if (!LisunDownloads.LooksLikeZip(archive))
            {
                message = LisunLocale.T("lib.notArchive", item.Name);
                return false;
            }

            StringBuilder report = new StringBuilder();
            string executable = LisunPhpModule.ImportFromZip(archive, report);

            try { File.Delete(archive); }
            catch { }

            if (executable == null)
            {
                message = LisunLocale.T("lib.runtimeNoBinary");
                return false;
            }

            LisunPhpModule.Attach(executable);

            message = LisunLocale.T("lib.installed", item.Name,
                CustomFormUtils.ToVirtualPath(Path.GetDirectoryName(executable)),
                CustomFormUtils.FormatSize(download.Received));
            return true;
        }

        /// <summary>Обычный архив: качаем и распаковываем в папку компонента.</summary>
        private static bool InstallZip(LisunComponent item, out string message)
        {
            string target = PathOf(item);

            if (target.Length == 0)
            {
                message = LisunLocale.T("lib.noTarget", item.Name);
                return false;
            }

            string archive = Path.Combine(LisunEngine.TempPath, item.Name + ".zip");

            try { if (File.Exists(archive)) File.Delete(archive); }
            catch { }

            string note;
            LisunDownload download = LisunDownloads.Fetch(item.Name, item.Urls.ToArray(),
                archive, item.Sha256, out note);

            if (download.State != LisunDownloadState.Done)
            {
                message = note;
                return false;
            }

            if (!LisunDownloads.LooksLikeZip(archive))
            {
                message = LisunLocale.T("lib.notArchive", item.Name);
                return false;
            }

            int files = 0;

            try
            {
                if (!Directory.Exists(target)) Directory.CreateDirectory(target);

                using (ZipArchive zip = ZipFile.OpenRead(archive))
                {
                    foreach (ZipArchiveEntry entry in zip.Entries)
                    {
                        if (entry.FullName.EndsWith("/", StringComparison.Ordinal)) continue;

                        string relative = entry.FullName.Replace('/', Path.DirectorySeparatorChar);
                        string destination = Path.GetFullPath(Path.Combine(target, relative));

                        // Архив из сети не должен писать выше своей папки.
                        if (!destination.StartsWith(Path.GetFullPath(target), StringComparison.OrdinalIgnoreCase))
                            continue;

                        string directory = Path.GetDirectoryName(destination);
                        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                            Directory.CreateDirectory(directory);

                        entry.ExtractToFile(destination, true);
                        files++;
                    }
                }
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("lib.unpackFailed", item.Name, ex.Message);
                return false;
            }
            finally
            {
                try { File.Delete(archive); }
                catch { }
            }

            LisunEngine.Log("[lib] " + LisunLocale.T("lib.unpacked", item.Name, files).Trim());

            message = LisunLocale.T("lib.installed", item.Name,
                CustomFormUtils.ToVirtualPath(target),
                CustomFormUtils.FormatSize(download.Received));
            return true;
        }

        /// <summary>Убирает докачанный компонент с диска.</summary>
        public static bool Remove(string name, out string message)
        {
            LisunComponent item = Find(name);

            if (item == null)
            {
                message = LisunLocale.T("lib.unknown", name);
                return false;
            }

            if (!item.Removable)
            {
                message = LisunLocale.T("lib.notRemovable", item.Name);
                return false;
            }

            if (string.Equals(item.Kind, "runtime", StringComparison.OrdinalIgnoreCase))
                return LisunPhpModule.RemoveOwnPhp(out message);

            string path = PathOf(item);

            if (path.Length == 0 || !Directory.Exists(path))
            {
                message = LisunLocale.T("lib.notInstalled", item.Name);
                return false;
            }

            try
            {
                Directory.Delete(path, true);

                message = LisunLocale.T("lib.removed", item.Name);
                LisunEngine.Log("[lib] " + message.Trim());
                return true;
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("lib.removeFailed", item.Name, ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Компонент нужен прямо сейчас: если его нет и автодокачка включена —
        /// качаем молча. Это и есть «библиотеки скачиваются сами».
        /// </summary>
        public static bool Ensure(string name, out string message)
        {
            LisunComponent item = Find(name);

            if (item == null)
            {
                message = LisunLocale.T("lib.unknown", name);
                return false;
            }

            if (Installed(item))
            {
                message = LisunLocale.T("lib.already", item.Name);
                return true;
            }

            if (!AutoEnabled)
            {
                message = LisunLocale.T("lib.autoOffHint", item.Name);
                return false;
            }

            LisunEngine.Log("[lib] " + LisunLocale.T("lib.autoFetch", item.Name).Trim());
            return Install(item.Name, out message);
        }

        // =====================================================================
        //  Текст
        // =====================================================================

        public static string ListText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("lib.listHeader"));
            sb.AppendLine();

            foreach (LisunComponent item in Items())
            {
                string state = item.BuiltIn
                    ? LisunLocale.T("lib.stateBuiltIn")
                    : Installed(item)
                        ? LisunLocale.T("lib.stateInstalled")
                        : LisunLocale.T("lib.stateMissing");

                long disk = SizeOnDisk(item);
                string size = disk > 0
                    ? CustomFormUtils.FormatSize(disk)
                    : item.Size > 0 ? "~" + CustomFormUtils.FormatSize(item.Size) : "—";

                sb.AppendLine("   " + Pad(item.Name, 12) + Pad(item.Version, 10) +
                              Pad(state, 16) + size);
                sb.AppendLine("      " + item.Title);

                if (item.Note.Length > 0)
                    sb.AppendLine("      " + item.Note);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("lib.autoState",
                AutoEnabled ? LisunLocale.T("word.on") : LisunLocale.T("word.off")));
            sb.AppendLine("   " + LisunLocale.T("lib.catalogState", CatalogUrl,
                fetchedAt == DateTime.MinValue ? "—" : fetchedAt.ToString("HH:mm:ss")));
            sb.AppendLine("   " + LisunLocale.T("lib.hint"));

            return sb.ToString();
        }

        public static string InfoText(string name)
        {
            LisunComponent item = Find(name);
            if (item == null) return LisunLocale.T("lib.unknown", name);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("lib.infoHeader", item.Name));
            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("lib.fieldTitle") + item.Title);
            sb.AppendLine("   " + LisunLocale.T("lib.fieldKind") + item.Kind);
            sb.AppendLine("   " + LisunLocale.T("lib.fieldVersion") + item.Version);
            sb.AppendLine("   " + LisunLocale.T("lib.fieldState") +
                (item.BuiltIn ? LisunLocale.T("lib.stateBuiltIn")
                              : Installed(item) ? LisunLocale.T("lib.stateInstalled")
                                                : LisunLocale.T("lib.stateMissing")));

            if (item.NeededBy.Length > 0)
                sb.AppendLine("   " + LisunLocale.T("lib.fieldNeeded") + item.NeededBy);

            string path = PathOf(item);
            if (path.Length > 0)
                sb.AppendLine("   " + LisunLocale.T("lib.fieldPath") +
                    (Directory.Exists(path) ? CustomFormUtils.ToVirtualPath(path)
                                            : LisunLocale.T("lib.pathNone")));

            if (item.Size > 0)
                sb.AppendLine("   " + LisunLocale.T("lib.fieldSize") +
                    CustomFormUtils.FormatSize(item.Size));

            if (item.Sha256.Length > 0)
                sb.AppendLine("   " + LisunLocale.T("lib.fieldHash") + item.Sha256);

            if (item.Description.Length > 0)
            {
                sb.AppendLine();
                sb.AppendLine("   " + item.Description);
            }

            if (item.Note.Length > 0)
                sb.AppendLine("   " + item.Note);

            if (!item.BuiltIn && item.Urls.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("   " + LisunLocale.T("lib.fieldUrls"));

                foreach (string url in item.Urls)
                    sb.AppendLine("      " + url);
            }

            return sb.ToString();
        }

        /// <summary>Что есть, чего нет и что стоит докачать.</summary>
        public static string CheckText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("lib.checkHeader"));
            sb.AppendLine();

            int missing = 0;

            foreach (LisunComponent item in Items())
            {
                if (item.BuiltIn)
                {
                    sb.AppendLine("   [ OK ] " + Pad(item.Name, 12) + LisunLocale.T("lib.stateBuiltIn"));
                    continue;
                }

                if (Installed(item))
                {
                    sb.AppendLine("   [ OK ] " + Pad(item.Name, 12) +
                        LisunLocale.T("lib.stateInstalled") +
                        (SizeOnDisk(item) > 0 ? "  " + CustomFormUtils.FormatSize(SizeOnDisk(item)) : string.Empty));
                    continue;
                }

                missing++;
                sb.AppendLine("   [ -- ] " + Pad(item.Name, 12) + LisunLocale.T("lib.stateMissing") +
                    "  →  lib install " + item.Name);
            }

            sb.AppendLine();
            sb.AppendLine("   " + (missing == 0
                ? LisunLocale.T("lib.checkAllOk")
                : LisunLocale.T("lib.checkMissing", missing)));

            return sb.ToString();
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value + " " : value.PadRight(width);
        }
    }
}
