﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Единая палитра и типографика LisunOS.
    /// Все формы — системные и динамические — приводятся к одному виду через Harmonize().
    /// </summary>
    public static class Theme
    {
        public static readonly Color Background = Color.FromArgb(13, 17, 23);
        public static readonly Color Surface = Color.FromArgb(22, 27, 34);
        public static readonly Color SurfaceAlt = Color.FromArgb(30, 36, 46);
        public static readonly Color SurfaceHot = Color.FromArgb(41, 49, 60);
        public static readonly Color Border = Color.FromArgb(48, 54, 61);
        public static readonly Color Text = Color.FromArgb(206, 214, 224);
        public static readonly Color TextDim = Color.FromArgb(128, 137, 149);
        public static readonly Color Accent = Color.FromArgb(88, 166, 255);
        public static readonly Color AccentDeep = Color.FromArgb(31, 60, 92);
        public static readonly Color Success = Color.FromArgb(86, 211, 100);
        public static readonly Color Warning = Color.FromArgb(226, 176, 65);
        public static readonly Color Danger = Color.FromArgb(248, 97, 89);
        public static readonly Color Magenta = Color.FromArgb(188, 140, 255);
        public static readonly Color Cyan = Color.FromArgb(87, 208, 214);

        private static readonly Dictionary<string, Font> FontCache = new Dictionary<string, Font>();

        private static readonly string[] MonoFamilies = { "Cascadia Mono", "Consolas", "JetBrains Mono", "Lucida Console" };
        private static readonly string[] UiFamilies = { "Segoe UI", "Tahoma", "Verdana" };

        public static Font Mono(float size) { return Mono(size, FontStyle.Regular); }

        public static Font Mono(float size, FontStyle style)
        {
            return Resolve("m", MonoFamilies, FontFamily.GenericMonospace, size, style);
        }

        public static Font Ui(float size) { return Ui(size, FontStyle.Regular); }

        public static Font Ui(float size, FontStyle style)
        {
            return Resolve("u", UiFamilies, FontFamily.GenericSansSerif, size, style);
        }

        private static Font Resolve(string prefix, string[] candidates, FontFamily fallback, float size, FontStyle style)
        {
            string key = prefix + "|" + size.ToString("0.##") + "|" + ((int)style);
            Font cached;
            if (FontCache.TryGetValue(key, out cached)) return cached;

            Font result = null;
            foreach (string name in candidates)
            {
                try
                {
                    FontFamily family = new FontFamily(name);
                    if (family.IsStyleAvailable(style))
                    {
                        result = new Font(family, size, style);
                        break;
                    }
                }
                catch { }
            }
            if (result == null) result = new Font(fallback, size, style);

            FontCache[key] = result;
            return result;
        }

        /// <summary>Путь со скруглёнными углами — для панелей ввода и карточек.</summary>
        public static GraphicsPath RoundedRect(Rectangle bounds, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0 || bounds.Width <= 0 || bounds.Height <= 0)
            {
                path.AddRectangle(bounds);
                return path;
            }

            int d = Math.Min(radius * 2, Math.Min(bounds.Width, bounds.Height));
            path.StartFigure();
            path.AddArc(bounds.Left, bounds.Top, d, d, 180, 90);
            path.AddArc(bounds.Right - d, bounds.Top, d, d, 270, 90);
            path.AddArc(bounds.Right - d, bounds.Bottom - d, d, d, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - d, d, d, 90, 90);
            path.CloseFigure();
            return path;
        }

        /// <summary>
        /// Назначает контролу скруглённый регион. Старый регион корректно освобождается,
        /// поэтому утечки GDI-объектов (как в прежнем Rounding_Paint) не происходит.
        /// </summary>
        public static void ApplyRoundedRegion(Control control, int radius)
        {
            if (control == null || control.Width <= 0 || control.Height <= 0) return;

            using (GraphicsPath path = RoundedRect(new Rectangle(0, 0, control.Width, control.Height), radius))
            {
                Region old = control.Region;
                control.Region = new Region(path);
                if (old != null) old.Dispose();
            }
        }

        /// <summary>Плоская тёмная кнопка в стиле оболочки.</summary>
        public static void StyleButton(Button button, Color back, Color fore)
        {
            if (button == null) return;
            button.FlatStyle = FlatStyle.Flat;
            button.BackColor = back;
            button.ForeColor = fore;
            button.UseVisualStyleBackColor = false;
            button.FlatAppearance.BorderSize = 1;
            button.FlatAppearance.BorderColor = Border;
            button.FlatAppearance.MouseOverBackColor = SurfaceHot;
            button.FlatAppearance.MouseDownBackColor = AccentDeep;
            if (button.Font == null || button.Font.Size < 1f) button.Font = Ui(9f);
            button.Cursor = Cursors.Hand;
        }

        /// <summary>
        /// Аккуратно приводит дерево контролов к тёмной теме.
        /// Явно заданные в дизайнере цвета не трогаются — заменяются только системные значения по умолчанию.
        /// </summary>
        public static void Harmonize(Control root)
        {
            if (root == null) return;

            Form form = root as Form;
            if (form != null)
            {
                if (IsSystemDefault(form.BackColor)) form.BackColor = Background;
                if (IsSystemDefault(form.ForeColor)) form.ForeColor = Text;
                form.Font = Ui(9f);
            }

            foreach (Control child in root.Controls) HarmonizeControl(child);
        }

        private static void HarmonizeControl(Control control)
        {
            if (control == null) return;

            Button button = control as Button;
            if (button != null)
            {
                Color back = IsSystemDefault(button.BackColor) ? SurfaceAlt : button.BackColor;
                Color fore = IsSystemDefault(button.ForeColor) ? Text : button.ForeColor;
                StyleButton(button, back, fore);
            }
            else if (control is TextBox || control is RichTextBox || control is ListBox || control is ComboBox)
            {
                if (IsSystemDefault(control.BackColor)) control.BackColor = Surface;
                if (IsSystemDefault(control.ForeColor)) control.ForeColor = Text;
                TextBox textBox = control as TextBox;
                if (textBox != null && textBox.BorderStyle == BorderStyle.Fixed3D) textBox.BorderStyle = BorderStyle.FixedSingle;
            }
            else if (control is ListView)
            {
                ListView listView = (ListView)control;
                if (IsSystemDefault(listView.BackColor)) listView.BackColor = Surface;
                if (IsSystemDefault(listView.ForeColor)) listView.ForeColor = Text;
                if (listView.BorderStyle == BorderStyle.Fixed3D) listView.BorderStyle = BorderStyle.None;
                listView.FullRowSelect = true;
                listView.HideSelection = false;
            }
            else if (control is TreeView)
            {
                TreeView treeView = (TreeView)control;
                if (IsSystemDefault(treeView.BackColor)) treeView.BackColor = Surface;
                if (IsSystemDefault(treeView.ForeColor)) treeView.ForeColor = Text;
                if (treeView.BorderStyle == BorderStyle.Fixed3D) treeView.BorderStyle = BorderStyle.None;
                treeView.LineColor = Border;
                treeView.HideSelection = false;
            }
            else if (control is SplitContainer)
            {
                SplitContainer split = (SplitContainer)control;
                split.BackColor = Border;
                split.Panel1.BackColor = Surface;
                split.Panel2.BackColor = Background;
            }
            else if (control is ToolStrip)
            {
                ToolStrip strip = (ToolStrip)control;
                strip.RenderMode = ToolStripRenderMode.System;
                if (IsSystemDefault(strip.BackColor)) strip.BackColor = SurfaceAlt;
                if (IsSystemDefault(strip.ForeColor)) strip.ForeColor = Text;
                foreach (ToolStripItem item in strip.Items) HarmonizeStripItem(item);
            }
            else
            {
                if (IsSystemDefault(control.BackColor)) control.BackColor = Background;
                if (IsSystemDefault(control.ForeColor)) control.ForeColor = Text;
            }

            if (control.ContextMenuStrip != null) HarmonizeStrip(control.ContextMenuStrip);

            foreach (Control child in control.Controls) HarmonizeControl(child);
        }

        public static void HarmonizeStrip(ToolStrip strip)
        {
            if (strip == null) return;
            strip.BackColor = SurfaceAlt;
            strip.ForeColor = Text;
            strip.RenderMode = ToolStripRenderMode.System;
            strip.Font = Ui(9f);
            foreach (ToolStripItem item in strip.Items) HarmonizeStripItem(item);
        }

        private static void HarmonizeStripItem(ToolStripItem item)
        {
            if (item == null) return;
            item.BackColor = SurfaceAlt;
            item.ForeColor = Text;
            ToolStripMenuItem menuItem = item as ToolStripMenuItem;
            if (menuItem != null)
            {
                foreach (ToolStripItem sub in menuItem.DropDownItems) HarmonizeStripItem(sub);
            }
        }

        private static bool IsSystemDefault(Color color)
        {
            if (color.IsEmpty) return true;
            if (!color.IsKnownColor) return false;
            KnownColor known = color.ToKnownColor();
            return known == KnownColor.Control
                || known == KnownColor.Window
                || known == KnownColor.ControlText
                || known == KnownColor.WindowText
                || known == KnownColor.ButtonFace
                || known == KnownColor.ButtonShadow
                || known == KnownColor.Transparent;
        }
    }
}
