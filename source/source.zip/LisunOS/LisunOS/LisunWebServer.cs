﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>
    /// Встроенный HTTP-сервер LisunOS.
    /// Реализован на TcpListener, поэтому не требует прав администратора
    /// (в отличие от HttpListener, которому нужна регистрация URL).
    /// Отдаёт файлы из виртуальной файловой системы и уважает правила ufw.
    /// </summary>
    public class LisunWebServer
    {
        private TcpListener listener;
        private Thread worker;
        private volatile bool running;

        private readonly object sync = new object();

        public int Port { get; private set; }
        public string RootDirectory { get; private set; }
        public bool AllowDirectoryListing { get; set; }
        public bool AllowRemoteClients { get; set; }

        /// <summary>Конфигурация из .htaccess корня сайта.</summary>
        public LisunServerConfig Config { get; private set; }

        /// <summary>Данные текущего запроса — у каждого соединения свой поток.</summary>
        [ThreadStatic] private static string currentMethod;
        [ThreadStatic] private static string currentPostBody;
        [ThreadStatic] private static string currentCookies;
        [ThreadStatic] private static string currentUri;

        private static string CurrentMethod { get { return currentMethod ?? "GET"; } }
        private static string CurrentPostBody { get { return currentPostBody ?? ""; } }
        private static string CurrentCookies { get { return currentCookies ?? ""; } }
        private static string CurrentUri { get { return currentUri ?? "/"; } }

        public int RequestCount { get; private set; }
        public int ErrorCount { get; private set; }
        public DateTime StartedAt { get; private set; }

        public bool IsRunning { get { return running; } }

        public event Action<string> OnLog;

        public LisunWebServer()
        {
            Port = 8080;
            AllowDirectoryListing = true;
            Config = new LisunServerConfig();
            RootDirectory = Path.Combine(LisunEngine.RootPath, "root", "www");
        }

        private void Log(string message)
        {
            Action<string> handler = OnLog;
            if (handler != null) handler(message);
        }

        /// <summary>
        /// Есть ли в конфигурации обработчик PHP. Интерпретатор встроен в ядро
        /// (LisunOS PHP Engine), поэтому внешний php-cgi.exe не требуется.
        /// </summary>
        public bool PhpEnabled
        {
            get
            {
                foreach (LisunServerConfig.Location location in Config.Locations)
                {
                    if (location.Kind == LisunServerConfig.LocationKind.Php) return true;
                }
                return false;
            }
        }

        public TimeSpan Uptime
        {
            get { return running ? DateTime.Now - StartedAt : TimeSpan.Zero; }
        }

        // =====================================================================
        //  Запуск и остановка
        // =====================================================================

        public bool Start(int port, string rootDirectory, out string error)
        {
            error = null;

            lock (sync)
            {
                if (running)
                {
                    error = LisunLocale.T("srv.alreadyRunning");
                    return false;
                }

                if (port < 1 || port > 65535)
                {
                    error = LisunLocale.T("srv.badPort");
                    return false;
                }

                if (!LisunFirewall.Allows(port))
                {
                    error = LisunLocale.T("srv.blockedByUfw", port);
                    return false;
                }

                try
                {
                    if (string.IsNullOrEmpty(rootDirectory)) rootDirectory = RootDirectory;
                    if (!Directory.Exists(rootDirectory)) Directory.CreateDirectory(rootDirectory);

                    EnsureIndexPage(rootDirectory);

                    // Конфигурация читается при каждом запуске, поэтому правка .htaccess
                    // применяется простым «Остановить → Запустить».
                    LisunServerConfig.EnsureDefaultFile(rootDirectory);
                    Config = LisunServerConfig.Load(rootDirectory);

                    // api.php появляется только когда PHP действительно работает.
                    if (PhpEnabled)
                    {
                        LisunApiEndpoint.EnsureFiles(rootDirectory);
                        LisunWebPanel.EnsureFiles(rootDirectory);
                    }

                    IPAddress address = AllowRemoteClients ? IPAddress.Any : IPAddress.Loopback;
                    listener = new TcpListener(address, port);
                    listener.Start();

                    Port = port;
                    RootDirectory = rootDirectory;
                    RequestCount = 0;
                    ErrorCount = 0;
                    StartedAt = DateTime.Now;
                    running = true;

                    worker = new Thread(AcceptLoop);
                    worker.IsBackground = true;
                    worker.Name = "LisunWebServer";
                    worker.Start();

                    Log(LisunLocale.T("srv.started", port, AllowRemoteClients ? "0.0.0.0" : "127.0.0.1"));
                    LisunEngine.Log("[WebServer] Запущен на порту " + port + ".");
                    return true;
                }
                catch (SocketException ex)
                {
                    running = false;
                    error = LisunLocale.T("srv.portBusy", port) + "  (" + ex.SocketErrorCode + ")";
                    return false;
                }
                catch (Exception ex)
                {
                    running = false;
                    error = ex.Message;
                    return false;
                }
            }
        }

        public void Stop()
        {
            lock (sync)
            {
                if (!running) return;
                running = false;

                try { if (listener != null) listener.Stop(); }
                catch { }

                listener = null;
                Log(LisunLocale.T("srv.stopped"));
                LisunEngine.Log("[WebServer] Остановлен.");
            }
        }

        private void EnsureIndexPage(string directory)
        {
            string index = Path.Combine(directory, "index.html");
            if (File.Exists(index)) return;

            string page =
                "<!doctype html>" + Environment.NewLine +
                "<html lang=\"ru\"><head><meta charset=\"utf-8\">" + Environment.NewLine +
                "<title>LisunOS Server</title>" + Environment.NewLine +
                "<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;" +
                "background:#0d1117;color:#ced6e0;font:16px/1.6 Segoe UI,system-ui,sans-serif}" +
                ".card{padding:40px 48px;border:1px solid #30363d;border-radius:14px;background:#161b22;text-align:center}" +
                "h1{margin:0 0 8px;font-size:26px;color:#58a6ff}p{margin:4px 0;color:#808995}" +
                "code{color:#57d0d6}</style></head><body>" + Environment.NewLine +
                "<div class=\"card\"><h1>LisunOS Server</h1>" + Environment.NewLine +
                "<p>Сервер работает.</p>" + Environment.NewLine +
                "<p>Файлы раздаются из <code>LisunOS:\\root\\www</code></p></div>" + Environment.NewLine +
                "</body></html>";

            CustomFormUtils.WriteFileText(index, page);
        }

        // =====================================================================
        //  Приём соединений
        // =====================================================================

        private void AcceptLoop()
        {
            while (running)
            {
                TcpClient client = null;
                try
                {
                    if (listener == null) break;
                    client = listener.AcceptTcpClient();
                }
                catch
                {
                    // Listener остановлен — выходим без шума.
                    break;
                }

                TcpClient captured = client;
                ThreadPool.QueueUserWorkItem(state => HandleClient(captured));
            }
        }

        private void HandleClient(TcpClient client)
        {
            try
            {
                using (client)
                {
                    client.ReceiveTimeout = 6000;
                    client.SendTimeout = 6000;

                    using (NetworkStream stream = client.GetStream())
                    {
                        string requestLine = ReadLine(stream);
                        if (string.IsNullOrEmpty(requestLine)) return;

                        // Заголовки сохраняем — они нужны для проксирования и CGI.
                        List<string> headers = new List<string>();
                        while (true)
                        {
                            string header = ReadLine(stream);
                            if (header == null || header.Length == 0) break;
                            if (headers.Count < 64) headers.Add(header);
                        }

                        RequestCount++;

                        string[] parts = requestLine.Split(' ');
                        string method = parts.Length > 0 ? parts[0].ToUpperInvariant() : "GET";
                        string rawUrl = parts.Length > 1 ? parts[1] : "/";

                        // Тело запроса нужно формам PHP ($_POST).
                        int contentLength = 0;
                        string cookieHeader = "";

                        foreach (string header in headers)
                        {
                            if (header.StartsWith("Content-Length:", StringComparison.OrdinalIgnoreCase))
                                int.TryParse(header.Substring(15).Trim(), out contentLength);
                            else if (header.StartsWith("Cookie:", StringComparison.OrdinalIgnoreCase))
                                cookieHeader = header.Substring(7).Trim();
                        }

                        string postBody = "";
                        if (contentLength > 0 && contentLength <= Config.ClientMaxBody)
                        {
                            byte[] buffer = new byte[contentLength];
                            int read = 0;

                            while (read < contentLength)
                            {
                                int chunk = stream.Read(buffer, read, contentLength - read);
                                if (chunk <= 0) break;
                                read += chunk;
                            }

                            postBody = Encoding.UTF8.GetString(buffer, 0, read);
                        }

                        currentMethod = method;
                        currentPostBody = postBody;
                        currentCookies = cookieHeader;
                        currentUri = rawUrl;

                        if (Config.AccessLog) Log(method + "  " + rawUrl);

                        ServeRequest(stream, requestLine, headers, method, rawUrl, method == "HEAD");
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorCount++;
                Log("[ERROR] " + ex.Message);
            }
        }

        private void ServeRequest(NetworkStream stream, string requestLine, List<string> headers,
            string method, string rawUrl, bool headOnly)
        {
            string path = rawUrl;
            string query = string.Empty;

            int questionMark = path.IndexOf('?');
            if (questionMark >= 0)
            {
                query = path.Substring(questionMark + 1);
                path = path.Substring(0, questionMark);
            }

            LisunServerConfig.Location location = Config.Match(path);

            if (location != null)
            {
                if (location.Kind == LisunServerConfig.LocationKind.Deny)
                {
                    ErrorCount++;
                    Log("[DENY] " + rawUrl);
                    SendError(stream, 403, "Forbidden", "403 — доступ закрыт настройками .htaccess");
                    return;
                }

                if (location.Kind == LisunServerConfig.LocationKind.Proxy)
                {
                    ProxyRequest(stream, requestLine, headers, location, rawUrl);
                    return;
                }
            }

            if (method != "GET" && method != "HEAD" &&
                (location == null || location.Kind != LisunServerConfig.LocationKind.Php))
            {
                ErrorCount++;
                SendError(stream, 405, "Method Not Allowed", "405 — метод не поддерживается");
                return;
            }

            ServeFromDisk(stream, location, path, query, rawUrl, method, headOnly);
        }

        private void ServeFromDisk(NetworkStream stream, LisunServerConfig.Location location,
            string pathPart, string query, string rawUrl, string method, bool headOnly)
        {
            string path = pathPart;

            try { path = Uri.UnescapeDataString(path); }
            catch { }

            path = path.Replace('/', Path.DirectorySeparatorChar).TrimStart(Path.DirectorySeparatorChar);

            string baseDirectory = RootDirectory;
            if (location != null && location.Root.Length > 0)
            {
                string custom;
                if (CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, location.Root, out custom))
                    baseDirectory = custom;
            }

            string target;
            try { target = Path.GetFullPath(Path.Combine(baseDirectory, path)); }
            catch
            {
                ErrorCount++;
                SendText(stream, 400, "Bad Request", "400 — некорректный путь");
                return;
            }

            // Защита от выхода за пределы корня сервера (path traversal).
            string root = Path.GetFullPath(baseDirectory).TrimEnd(Path.DirectorySeparatorChar);
            if (!target.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            {
                ErrorCount++;
                Log("[DENY] " + rawUrl);
                SendText(stream, 403, "Forbidden", "403 — доступ запрещён");
                return;
            }

            if (Directory.Exists(target))
            {
                // Индексные файлы берём из директивы index.
                foreach (string indexName in Config.IndexFilesFor(location))
                {
                    string candidate = Path.Combine(target, indexName);
                    if (!File.Exists(candidate)) continue;

                    LisunServerConfig.Location indexLocation = Config.Match(
                        (rawUrl.EndsWith("/") ? rawUrl : rawUrl + "/") + indexName);

                    if (indexLocation != null && indexLocation.Kind == LisunServerConfig.LocationKind.Php)
                    {
                        ExecutePhp(stream, indexLocation, candidate, query, headOnly);
                        return;
                    }

                    if (IsPhpFile(candidate))
                    {
                        SendPhpAsHtml(stream, candidate, headOnly, location);
                        return;
                    }

                    SendFile(stream, candidate, headOnly, location);
                    return;
                }

                if (!AllowDirectoryListing || !Config.AutoIndexFor(location))
                {
                    ErrorCount++;
                    SendError(stream, 403, "Forbidden", "403 — просмотр каталога запрещён");
                    return;
                }

                SendDirectoryListing(stream, target, rawUrl, headOnly);
                return;
            }

            if (!File.Exists(target))
            {
                ErrorCount++;
                SendError(stream, 404, "Not Found", "404 — " + rawUrl + " не найден");
                return;
            }

            if (Config.IsDenied(Path.GetFileName(target)))
            {
                ErrorCount++;
                Log("[DENY] " + rawUrl);
                SendError(stream, 403, "Forbidden", "403 — файл закрыт настройками .htaccess");
                return;
            }

            if (location != null && location.Kind == LisunServerConfig.LocationKind.Php)
            {
                ExecutePhp(stream, location, target, query, headOnly);
                return;
            }

            // PHP не подключён: страница всё равно открывается — HTML работает,
            // код внутри <?php ... ?> вырезается и не исполняется.
            if (IsPhpFile(target))
            {
                SendPhpAsHtml(stream, target, headOnly, location);
                return;
            }

            SendFile(stream, target, headOnly, location);
        }

        private static bool IsPhpFile(string path)
        {
            string extension = Path.GetExtension(path);
            return extension.Equals(".php", StringComparison.OrdinalIgnoreCase) ||
                   extension.Equals(".phtml", StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>Отдаёт .php как HTML с вырезанным кодом — когда PHP не подключён.</summary>
        private void SendPhpAsHtml(NetworkStream stream, string path, bool headOnly,
            LisunServerConfig.Location location)
        {
            try
            {
                string html = LisunPhpModule.StripPhp(LisunCrypto.ReadAllText(path));

                Log("[HTML] " + Path.GetFileName(path) + "  (PHP выключен, код вырезан)");
                SendResponse(stream, 200, "OK", "text/html; charset=" + Config.Charset,
                    Encoding.UTF8.GetBytes(html), headOnly, location);
            }
            catch (Exception ex)
            {
                ErrorCount++;
                SendError(stream, 500, "Internal Server Error", "500 — " + WebEscape(ex.Message));
            }
        }

        // =====================================================================
        //  PHP через CGI
        // =====================================================================

        private void ExecutePhp(NetworkStream stream, LisunServerConfig.Location location,
            string scriptPath, string query, bool headOnly)
        {
            // Внешний интерпретатор используется только если он явно прописан
            // в fastcgi_pass и действительно существует. По умолчанию работает
            // встроенный движок LisunOS PHP Engine.
            string external = null;
            if (!string.IsNullOrEmpty(location.FastCgiPath))
                external = ResolvePhpExecutable(location.FastCgiPath);

            if (external != null)
            {
                ExecutePhpExternal(stream, location, external, scriptPath, query, headOnly);
                return;
            }

            ExecutePhpBuiltIn(stream, location, scriptPath, query, headOnly);
        }

        /// <summary>Исполнение страницы встроенным интерпретатором.</summary>
        private void ExecutePhpBuiltIn(NetworkStream stream, LisunServerConfig.Location location,
            string scriptPath, string query, bool headOnly)
        {
            try
            {
                Php.PhpResult result = Php.PhpExecuter.Execute(scriptPath, RootDirectory,
                    CurrentMethod, query, CurrentPostBody, CurrentCookies, CurrentUri);

                if (!result.Ok)
                {
                    ErrorCount++;
                    Log("[PHP] [ОШИБКА] " + Path.GetFileName(scriptPath) + ": " + result.Error);

                    string page = "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">" +
                                  "<title>Ошибка PHP</title><style>body{margin:0;padding:48px;background:#0d1117;" +
                                  "color:#f86159;font:15px/1.6 Consolas,monospace}h1{font-size:19px;color:#f86159}" +
                                  "pre{color:#ced6e0;background:#161b22;padding:18px;border-radius:10px;" +
                                  "border:1px solid #30363d;white-space:pre-wrap}</style></head><body>" +
                                  "<h1>Ошибка PHP — " + WebEscape(Path.GetFileName(scriptPath)) + "</h1><pre>" +
                                  WebEscape(result.Error) + "</pre>" +
                                  (result.Body.Length > 0 ? "<pre>" + WebEscape(result.Body) + "</pre>" : "") +
                                  "</body></html>";

                    SendResponse(stream, 500, "Internal Server Error", "text/html; charset=utf-8",
                        Encoding.UTF8.GetBytes(page), headOnly, location);
                    return;
                }

                byte[] body = Encoding.UTF8.GetBytes(result.Body);
                Log("[PHP] " + Path.GetFileName(scriptPath) + "  " + CustomFormUtils.FormatSize(body.Length) +
                    "  (встроенный движок)");

                SendResponse(stream, result.StatusCode, result.StatusCode == 200 ? "OK" : "Status",
                    result.ContentType, body, headOnly, location, result.Headers);
            }
            catch (Exception ex)
            {
                ErrorCount++;
                SendError(stream, 500, "Internal Server Error",
                    "500 — движок PHP: " + WebEscape(ex.Message));
            }
        }

        /// <summary>Исполнение через внешний php-cgi.exe, если он задан в fastcgi_pass.</summary>
        private void ExecutePhpExternal(NetworkStream stream, LisunServerConfig.Location location,
            string executable, string scriptPath, string query, bool headOnly)
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo();
                info.FileName = executable;
                info.UseShellExecute = false;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                info.CreateNoWindow = true;
                info.WorkingDirectory = Path.GetDirectoryName(scriptPath);

                bool isCgi = Path.GetFileName(executable).IndexOf("cgi", StringComparison.OrdinalIgnoreCase) >= 0;

                if (isCgi)
                {
                    info.EnvironmentVariables["REDIRECT_STATUS"] = "1";
                    info.EnvironmentVariables["GATEWAY_INTERFACE"] = "CGI/1.1";
                    info.EnvironmentVariables["SCRIPT_FILENAME"] = scriptPath;
                    info.EnvironmentVariables["SCRIPT_NAME"] = Path.GetFileName(scriptPath);
                    info.EnvironmentVariables["QUERY_STRING"] = query ?? string.Empty;
                    info.EnvironmentVariables["REQUEST_METHOD"] = CurrentMethod ?? "GET";
                    info.EnvironmentVariables["SERVER_SOFTWARE"] = "LisunOS/" + LisunEngine.Version;
                    info.EnvironmentVariables["SERVER_PROTOCOL"] = "HTTP/1.1";
                    info.EnvironmentVariables["DOCUMENT_ROOT"] = RootDirectory;
                }
                else info.Arguments = "-f \"" + scriptPath + "\"";

                string output;
                using (Process process = Process.Start(info))
                {
                    output = process.StandardOutput.ReadToEnd();
                    string errors = process.StandardError.ReadToEnd();

                    if (!process.WaitForExit(Math.Max(1, location.TimeoutSeconds) * 1000))
                    {
                        try { process.Kill(); } catch { }

                        ErrorCount++;
                        SendError(stream, 504, "Gateway Timeout", "504 — PHP не ответил вовремя");
                        return;
                    }

                    if (output.Length == 0 && errors.Length > 0)
                    {
                        ErrorCount++;
                        SendError(stream, 500, "Internal Server Error",
                            "500 — ошибка PHP:<br><pre>" + WebEscape(errors) + "</pre>");
                        return;
                    }
                }

                string contentType = "text/html; charset=" + Config.Charset;
                string body = output;

                int split = output.IndexOf("\r\n\r\n", StringComparison.Ordinal);
                int skip = 4;
                if (split < 0) { split = output.IndexOf("\n\n", StringComparison.Ordinal); skip = 2; }

                if (split > 0)
                {
                    string head = output.Substring(0, split);
                    body = output.Substring(split + skip);

                    foreach (string headerLine in head.Replace("\r\n", "\n").Split('\n'))
                    {
                        int colon = headerLine.IndexOf(':');
                        if (colon <= 0) continue;

                        if (headerLine.Substring(0, colon).Trim()
                            .Equals("Content-Type", StringComparison.OrdinalIgnoreCase))
                            contentType = headerLine.Substring(colon + 1).Trim();
                    }
                }

                Log("[PHP] " + Path.GetFileName(scriptPath) + "  " + body.Length + " Б  (php-cgi)");
                SendResponse(stream, 200, "OK", contentType, Encoding.UTF8.GetBytes(body), headOnly, location);
            }
            catch (Exception ex)
            {
                ErrorCount++;
                SendError(stream, 500, "Internal Server Error",
                    "500 — не удалось запустить php-cgi: " + WebEscape(ex.Message));
            }
        }

        /// <summary>Путь к интерпретатору: из fastcgi_pass либо через модуль php-frm.</summary>
        private string ResolvePhpExecutable(string configured)
        {
            if (!string.IsNullOrEmpty(configured))
            {
                if (File.Exists(configured)) return configured;

                bool hasDirectory = configured.IndexOf(Path.DirectorySeparatorChar) >= 0 ||
                                    configured.IndexOf(Path.AltDirectorySeparatorChar) >= 0;

                // Явно указанный путь не подменяем молча.
                if (hasDirectory) return null;

                string inPath = LisunPhpModule.SearchInPath(configured);
                if (inPath != null) return inPath;
            }

            return LisunPhpModule.FindPhp();
        }

        // =====================================================================
        //  Проксирование (Node.js и любой другой локальный сервер)
        // =====================================================================

        private void ProxyRequest(NetworkStream stream, string requestLine, List<string> headers,
            LisunServerConfig.Location location, string rawUrl)
        {
            if (string.IsNullOrEmpty(location.ProxyHost) || location.ProxyPort <= 0)
            {
                ErrorCount++;
                SendError(stream, 502, "Bad Gateway", "502 — в proxy_pass не указан адрес");
                return;
            }

            try
            {
                using (TcpClient upstream = new TcpClient())
                {
                    IAsyncResult connect = upstream.BeginConnect(location.ProxyHost, location.ProxyPort, null, null);
                    if (!connect.AsyncWaitHandle.WaitOne(Math.Max(1, location.TimeoutSeconds) * 1000))
                    {
                        ErrorCount++;
                        SendError(stream, 504, "Gateway Timeout",
                            "504 — " + location.ProxyTarget + " не ответил");
                        return;
                    }
                    upstream.EndConnect(connect);

                    using (NetworkStream upstreamStream = upstream.GetStream())
                    {
                        StringBuilder request = new StringBuilder();
                        request.Append(requestLine).Append("\r\n");

                        bool hasHost = false;
                        foreach (string header in headers)
                        {
                            if (header.StartsWith("Connection:", StringComparison.OrdinalIgnoreCase)) continue;
                            if (header.StartsWith("Host:", StringComparison.OrdinalIgnoreCase))
                            {
                                hasHost = true;
                                request.Append("Host: ").Append(location.ProxyHost)
                                       .Append(':').Append(location.ProxyPort).Append("\r\n");
                                continue;
                            }
                            request.Append(header).Append("\r\n");
                        }

                        if (!hasHost)
                            request.Append("Host: ").Append(location.ProxyHost)
                                   .Append(':').Append(location.ProxyPort).Append("\r\n");

                        request.Append("X-Forwarded-By: LisunOS\r\n");
                        request.Append("Connection: close\r\n\r\n");

                        byte[] requestBytes = Encoding.UTF8.GetBytes(request.ToString());
                        upstreamStream.Write(requestBytes, 0, requestBytes.Length);
                        upstreamStream.Flush();

                        upstream.ReceiveTimeout = Math.Max(1, location.TimeoutSeconds) * 1000;

                        byte[] buffer = new byte[8192];
                        int read;
                        long total = 0;

                        while ((read = upstreamStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            stream.Write(buffer, 0, read);
                            total += read;
                        }

                        stream.Flush();
                        Log("[PROXY] " + rawUrl + "  →  " + location.ProxyTarget + "  " +
                            CustomFormUtils.FormatSize(total));
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorCount++;
                Log("[PROXY ERROR] " + ex.Message);
                SendError(stream, 502, "Bad Gateway",
                    "502 — " + WebEscape(location.ProxyTarget) + " недоступен:<br>" + WebEscape(ex.Message));
            }
        }

        /// <summary>Ответ с ошибкой: своя страница из error_page или стандартная.</summary>
        private void SendError(NetworkStream stream, int code, string reason, string message)
        {
            string page;
            if (Config.ErrorPages.TryGetValue(code, out page) && !string.IsNullOrEmpty(page))
            {
                try
                {
                    string file = Path.Combine(RootDirectory, page.TrimStart('/', '\\')
                        .Replace('/', Path.DirectorySeparatorChar));

                    if (File.Exists(file))
                    {
                        SendResponse(stream, code, reason, "text/html; charset=" + Config.Charset,
                            File.ReadAllBytes(file), false, null);
                        return;
                    }
                }
                catch { }
            }

            SendText(stream, code, reason, message);
        }

        // =====================================================================
        //  Ответы
        // =====================================================================

        private static string ReadLine(NetworkStream stream)
        {
            StringBuilder builder = new StringBuilder();

            while (true)
            {
                int value = stream.ReadByte();
                if (value < 0) return builder.Length == 0 ? null : builder.ToString();
                if (value == '\n') break;
                if (value != '\r') builder.Append((char)value);

                if (builder.Length > 8192) break;
            }

            return builder.ToString();
        }

        private void SendFile(NetworkStream stream, string path, bool headOnly)
        {
            SendFile(stream, path, headOnly, null);
        }

        private void SendFile(NetworkStream stream, string path, bool headOnly,
            LisunServerConfig.Location location)
        {
            byte[] body;
            try { body = File.ReadAllBytes(path); }
            catch (Exception ex)
            {
                ErrorCount++;
                SendText(stream, 500, "Internal Server Error", "500 — " + ex.Message);
                return;
            }

            // Зашифрованные файлы пакетов отдаются в расшифрованном виде.
            if (LisunCrypto.IsEncrypted(body))
                body = Encoding.UTF8.GetBytes(LisunCrypto.ReadAllText(path));

            SendResponse(stream, 200, "OK", MimeFor(path), body, headOnly, location);
        }

        private void SendDirectoryListing(NetworkStream stream, string directory, string rawUrl, bool headOnly)
        {
            StringBuilder html = new StringBuilder();
            html.AppendLine("<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">");
            html.AppendLine("<title>" + WebEscape(rawUrl) + "</title><style>");
            html.AppendLine("body{margin:0;padding:40px;background:#0d1117;color:#ced6e0;" +
                            "font:15px/1.7 Segoe UI,system-ui,sans-serif}");
            html.AppendLine("h1{font-size:20px;color:#58a6ff;margin:0 0 20px}");
            html.AppendLine("a{color:#ced6e0;text-decoration:none}a:hover{color:#58a6ff}");
            html.AppendLine("ul{list-style:none;padding:0;max-width:720px}");
            html.AppendLine("li{padding:9px 14px;border-bottom:1px solid #21262d;display:flex;" +
                            "justify-content:space-between}");
            html.AppendLine("span{color:#6e7681;font-size:13px}");
            html.AppendLine("</style></head><body>");
            html.AppendLine("<h1>" + WebEscape(rawUrl) + "</h1><ul>");

            string prefix = rawUrl.EndsWith("/") ? rawUrl : rawUrl + "/";
            if (prefix != "/") html.AppendLine("<li><a href=\"../\">../</a><span>каталог выше</span></li>");

            try
            {
                foreach (string dir in Directory.GetDirectories(directory))
                {
                    string name = Path.GetFileName(dir);
                    html.AppendLine("<li><a href=\"" + WebEscape(prefix + name) + "/\">" +
                                    WebEscape(name) + "/</a><span>каталог</span></li>");
                }

                foreach (string file in Directory.GetFiles(directory))
                {
                    string name = Path.GetFileName(file);
                    long size = 0;
                    try { size = new FileInfo(file).Length; }
                    catch { }

                    html.AppendLine("<li><a href=\"" + WebEscape(prefix + name) + "\">" +
                                    WebEscape(name) + "</a><span>" +
                                    CustomFormUtils.FormatSize(size) + "</span></li>");
                }
            }
            catch (Exception ex)
            {
                html.AppendLine("<li>" + WebEscape(ex.Message) + "</li>");
            }

            html.AppendLine("</ul></body></html>");

            SendResponse(stream, 200, "OK", "text/html; charset=" + Config.Charset,
                Encoding.UTF8.GetBytes(html.ToString()), headOnly, null);
        }

        private void SendText(NetworkStream stream, int code, string reason, string message)
        {
            string html = "<!doctype html><html lang=\"ru\"><head><meta charset=\"utf-8\">" +
                          "<title>" + code + "</title><style>body{margin:0;min-height:100vh;display:flex;" +
                          "align-items:center;justify-content:center;background:#0d1117;color:#f86159;" +
                          "font:17px Segoe UI,system-ui,sans-serif}</style></head><body>" +
                          WebEscape(message) + "</body></html>";

            SendResponse(stream, code, reason, "text/html; charset=" + Config.Charset,
                Encoding.UTF8.GetBytes(html), false, null);
        }

        private void SendResponse(NetworkStream stream, int code, string reason,
            string contentType, byte[] body, bool headOnly)
        {
            SendResponse(stream, code, reason, contentType, body, headOnly, null);
        }

        private void SendResponse(NetworkStream stream, int code, string reason,
            string contentType, byte[] body, bool headOnly, LisunServerConfig.Location location)
        {
            SendResponse(stream, code, reason, contentType, body, headOnly, location, null);
        }

        private void SendResponse(NetworkStream stream, int code, string reason,
            string contentType, byte[] body, bool headOnly, LisunServerConfig.Location location,
            List<string> extraHeaders)
        {
            try
            {
                StringBuilder head = new StringBuilder();
                head.Append("HTTP/1.1 ").Append(code).Append(' ').Append(reason).Append("\r\n");
                head.Append("Server: ").Append(Config.ServerName).Append('/')
                    .Append(LisunEngine.Version).Append("\r\n");
                head.Append("Content-Type: ").Append(contentType).Append("\r\n");
                head.Append("Content-Length: ").Append(body.Length).Append("\r\n");

                // Заголовки из директив add_header: сначала общие, затем из блока location.
                Dictionary<string, string> extra = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (KeyValuePair<string, string> item in Config.Headers) extra[item.Key] = item.Value;
                if (location != null)
                {
                    foreach (KeyValuePair<string, string> item in location.Headers) extra[item.Key] = item.Value;
                }

                bool hasCacheControl = false;
                foreach (KeyValuePair<string, string> item in extra)
                {
                    if (item.Key.Equals("Cache-Control", StringComparison.OrdinalIgnoreCase)) hasCacheControl = true;
                    head.Append(item.Key).Append(": ").Append(item.Value).Append("\r\n");
                }

                if (!hasCacheControl) head.Append("Cache-Control: no-cache\r\n");

                // Заголовки, выставленные самим PHP: Set-Cookie, Location и прочие.
                if (extraHeaders != null)
                {
                    foreach (string header in extraHeaders)
                    {
                        if (header.StartsWith("Content-Type:", StringComparison.OrdinalIgnoreCase)) continue;
                        if (header.StartsWith("HTTP/", StringComparison.OrdinalIgnoreCase)) continue;

                        head.Append(header).Append("\r\n");
                    }
                }

                head.Append("Connection: close\r\n\r\n");

                byte[] headBytes = Encoding.UTF8.GetBytes(head.ToString());
                stream.Write(headBytes, 0, headBytes.Length);

                if (!headOnly && body.Length > 0) stream.Write(body, 0, body.Length);
                stream.Flush();
            }
            catch { }
        }

        private static string WebEscape(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return value.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        private static readonly Dictionary<string, string> MimeTypes =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { ".html", "text/html; charset=utf-8" },  { ".htm", "text/html; charset=utf-8" },
            { ".css", "text/css; charset=utf-8" },    { ".js", "application/javascript; charset=utf-8" },
            { ".json", "application/json; charset=utf-8" }, { ".xml", "application/xml; charset=utf-8" },
            { ".txt", "text/plain; charset=utf-8" },  { ".md", "text/plain; charset=utf-8" },
            { ".png", "image/png" },                  { ".jpg", "image/jpeg" },
            { ".jpeg", "image/jpeg" },                { ".gif", "image/gif" },
            { ".svg", "image/svg+xml" },              { ".ico", "image/x-icon" },
            { ".webp", "image/webp" },                { ".mp3", "audio/mpeg" },
            { ".mp4", "video/mp4" },                  { ".woff", "font/woff" },
            { ".woff2", "font/woff2" },               { ".pdf", "application/pdf" },
            { ".zip", "application/zip" }
        };

        private string MimeFor(string path)
        {
            string type;
            if (MimeTypes.TryGetValue(Path.GetExtension(path), out type)) return type;
            return Config.DefaultType;
        }

        // =====================================================================
        //  Адреса
        // =====================================================================

        public List<string> Addresses()
        {
            List<string> result = new List<string>();
            result.Add("http://localhost:" + Port + "/");
            result.Add("http://127.0.0.1:" + Port + "/");

            if (!AllowRemoteClients) return result;

            try
            {
                foreach (IPAddress address in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                {
                    if (address.AddressFamily == AddressFamily.InterNetwork)
                        result.Add("http://" + address + ":" + Port + "/");
                }
            }
            catch { }

            return result;
        }
    }
}
