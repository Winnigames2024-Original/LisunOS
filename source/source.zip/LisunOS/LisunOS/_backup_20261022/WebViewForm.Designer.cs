﻿namespace LisunOS
{
    partial class WebViewForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ToolStrip toolStripBrowser;
        private System.Windows.Forms.ToolStripTextBox txtBrowserUrl;
        private System.Windows.Forms.ToolStripButton btnSearchGoogle;
        private System.Windows.Forms.ToolStripButton btnSearchYandex;
        private System.Windows.Forms.ToolStripButton btnSearchBing;
        private System.Windows.Forms.WebBrowser miniWebBrowser;
        private System.Windows.Forms.Button btnCloseBrowser;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.toolStripBrowser = new System.Windows.Forms.ToolStrip();
            this.txtBrowserUrl = new System.Windows.Forms.ToolStripTextBox();
            this.btnSearchGoogle = new System.Windows.Forms.ToolStripButton();
            this.btnSearchYandex = new System.Windows.Forms.ToolStripButton();
            this.btnSearchBing = new System.Windows.Forms.ToolStripButton();
            this.miniWebBrowser = new System.Windows.Forms.WebBrowser();
            this.btnCloseBrowser = new System.Windows.Forms.Button();
            this.toolStripBrowser.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripBrowser
            // 
            this.toolStripBrowser.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.toolStripBrowser.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStripBrowser.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txtBrowserUrl, this.btnSearchGoogle, this.btnSearchYandex, this.btnSearchBing});
            this.toolStripBrowser.Location = new System.Drawing.Point(0, 0);
            this.toolStripBrowser.Size = new System.Drawing.Size(852, 35);
            // 
            // txtBrowserUrl
            // 
            this.txtBrowserUrl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            this.txtBrowserUrl.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtBrowserUrl.ForeColor = System.Drawing.Color.White;
            this.txtBrowserUrl.Size = new System.Drawing.Size(400, 29);
            this.txtBrowserUrl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBrowserUrl_KeyDown);
            // 
            // Кнопки поисковиков
            // 
            this.btnSearchGoogle.Text = "Google"; this.btnSearchGoogle.ForeColor = System.Drawing.Color.White; this.btnSearchGoogle.Click += new System.EventHandler(this.btnSearchGoogle_Click);
            this.btnSearchYandex.Text = "Яндекс"; this.btnSearchYandex.ForeColor = System.Drawing.Color.White; this.btnSearchYandex.Click += new System.EventHandler(this.btnSearchYandex_Click);
            this.btnSearchBing.Text = "Bing"; this.btnSearchBing.ForeColor = System.Drawing.Color.White; this.btnSearchBing.Click += new System.EventHandler(this.btnSearchBing_Click);
            // 
            // miniWebBrowser
            // 
            this.miniWebBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.miniWebBrowser.Location = new System.Drawing.Point(0, 35);
            this.miniWebBrowser.ScriptErrorsSuppressed = true;
            this.miniWebBrowser.Size = new System.Drawing.Size(852, 537);
            // 
            // btnCloseBrowser
            // 
            this.btnCloseBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCloseBrowser.BackColor = System.Drawing.Color.Crimson;
            this.btnCloseBrowser.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCloseBrowser.ForeColor = System.Drawing.Color.White;
            this.btnCloseBrowser.Location = new System.Drawing.Point(710, 3);
            this.btnCloseBrowser.Size = new System.Drawing.Size(135, 29);
            this.btnCloseBrowser.Text = "✕ Скрыть Панель";
            this.btnCloseBrowser.Click += new System.EventHandler(this.btnCloseBrowser_Click);
            // 
            // WebViewForm
            // 
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(852, 572);
            this.Controls.Add(this.btnCloseBrowser);
            this.Controls.Add(this.miniWebBrowser);
            this.Controls.Add(this.toolStripBrowser);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.toolStripBrowser.ResumeLayout(false);
            this.toolStripBrowser.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
