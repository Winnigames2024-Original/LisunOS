﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace LisunOS
{
    public partial class MainForm : Form
    {
        // Постоянный экземпляр встроенной формы браузера
        private WebViewForm embeddedBrowser;

        public MainForm()
        {
            InitializeComponent();

            txtConsoleLog.AppendText("— LisunOS [Версия 1.0.0.MultiForm] —" + Environment.NewLine);
            txtConsoleLog.AppendText("Инициализировано чистое встраивание внешних форм." + Environment.NewLine + Environment.NewLine);

            // Инициализируем и настраиваем WebViewForm один раз при старте
            embeddedBrowser = new WebViewForm();
            embeddedBrowser.TopLevel = false; // КРИТИЧЕСКИ: Указываем, что это дочерний элемент
            embeddedBrowser.FormBorderStyle = FormBorderStyle.None;
            embeddedBrowser.Dock = DockStyle.Fill;

            // Подписываемся на событие закрытия внутри WebViewForm
            embeddedBrowser.OnBrowserCloseRequested += HideEmbeddedBrowser;
        }

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                string input = txtInput.Text.Trim();
                if (string.IsNullOrWhiteSpace(input)) return;

                txtConsoleLog.AppendText($"LisunOS:\\> {input}" + Environment.NewLine);

                if (input.ToLower().StartsWith("webview"))
                {
                    string[] parts = input.Split(new[] { ' ' }, 2);
                    string target = parts.Length > 1 ? parts[1].Trim() : "https://google.com";

                    txtInput.Clear();
                    ShowEmbeddedBrowser(target);
                    return;
                }

                if (input.ToLower() == "clear")
                {
                    txtConsoleLog.Clear();
                    txtInput.Clear();
                    return;
                }

                string outputResult = CommandExecutorEngine.Execute(input);
                if (!string.IsNullOrEmpty(outputResult))
                {
                    txtConsoleLog.AppendText(outputResult + Environment.NewLine + Environment.NewLine);
                }

                txtInput.Clear();
                txtConsoleLog.SelectionStart = txtConsoleLog.Text.Length;
                txtConsoleLog.ScrollToCaret();
            }
        }

        // --- ЛОГИКА ОПЕРАЦИОННОЙ СИСТЕМЫ: МОНТИРОВАНИЕ ВНЕШНЕЙ ФОРМЫ ---
        private void ShowEmbeddedBrowser(string url)
        {
            if (!this.Controls.Contains(embeddedBrowser))
            {
                // Добавляем форму в коллекцию элементов MainForm
                this.Controls.Add(embeddedBrowser);
            }

            // Выносим её поверх черной консоли и активируем
            embeddedBrowser.Visible = true;
            embeddedBrowser.BringToFront();
            embeddedBrowser.NavigateTo(url);
        }

        private void HideEmbeddedBrowser()
        {
            // Просто убираем видимость формы. Состояние страницы НЕ стирается
            embeddedBrowser.Visible = false;

            txtConsoleLog.AppendText(" [SYS] WebViewForm успешно отмонтирована. Сессия сохранена во встроенной памяти." + Environment.NewLine + Environment.NewLine);
            txtInput.Focus();
        }

        private void Rounding_Paint(object sender, PaintEventArgs e)
        {
            if (sender is Control ctrl)
            {
                GraphicsPath path = new GraphicsPath();
                int radius = 12;
                path.StartFigure();
                path.AddArc(0, 0, radius, radius, 180, 90);
                path.AddArc(ctrl.Width - radius, 0, radius, radius, 270, 90);
                path.AddArc(ctrl.Width - radius, ctrl.Height - radius, radius, radius, 0, 90);
                path.AddArc(0, ctrl.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();
                ctrl.Region = new Region(path);
            }
        }
    }
}
