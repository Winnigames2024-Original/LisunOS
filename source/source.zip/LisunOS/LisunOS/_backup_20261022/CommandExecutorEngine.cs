﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace LisunOS
{
    public static class CommandExecutorEngine
    {
        private static string currentVirtualDir = "";
        public static bool IsSuperUser { get; private set; } = false;

        static CommandExecutorEngine()
        {
            currentVirtualDir = LisunEngine.RootPath;
        }

        public static string Execute(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;

            bool usedSudo = false;
            if (input.Trim().StartsWith("sudo "))
            {
                usedSudo = true;
                input = input.Trim().Substring(5).Trim();
            }

            string[] tokens = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length == 0) return string.Empty;

            string commandName = tokens[0].ToLower().Trim();

            bool oldSuperUserStatus = IsSuperUser;
            if (usedSudo) IsSuperUser = true;

            if (LisunEngine.RegisteredCommands.ContainsKey(commandName))
            {
                List<string> appList = LisunEngine.RegisteredCommands[commandName];
                if (appList != null && appList.Count > 0)
                {
                    string appVarName = appList[0]; // Исправлено: берем элемент по индексу
                    if (FormEngine.ActiveApps.ContainsKey(appVarName))
                    {
                        FormEngine.ActiveApps[appVarName].Show();
                        IsSuperUser = oldSuperUserStatus;
                        return $" [SYS] Запущен процесс из сервиса: '{commandName}'";
                    }
                }
            }

            List<string> rawParams = new List<string>();
            Dictionary<string, string> namedArgs = new Dictionary<string, string>();
            for (int i = 1; i < tokens.Length; i++)
            {
                if (tokens[i].StartsWith("-") && tokens[i].Contains(":"))
                {
                    string[] argParts = tokens[i].TrimStart('-').Split(new[] { ':' }, 2);
                    if (argParts.Length == 2) namedArgs[argParts[0].ToLower().Trim()] = argParts[1].Trim();
                }
                else rawParams.Add(tokens[i]);
            }
            string combinedText = string.Join(" ", rawParams);
            string outputResult = "";

            switch (commandName)
            {
                case "su":
                    if (IsSuperUser && !usedSudo)
                    {
                        IsSuperUser = false;
                        outputResult = " [SYS] Режим суперпользователя отключен.";
                    }
                    else
                    {
                        string password = namedArgs.ContainsKey("pass") ? namedArgs["pass"] : (rawParams.Count > 0 ? rawParams[0] : "");
                        if (password == "root" || password == "admin")
                        {
                            IsSuperUser = true;
                            outputResult = " [⚡ ACCESS GRANTED ⚡] Доступ суперпользователя активирован.";
                        }
                        else outputResult = " [ERROR] Отказ в доступе.";
                    }
                    break;

                case "pwd":
                    string displayPath = currentVirtualDir.Replace(LisunEngine.RootPath, "LisunOS://");
                    outputResult = string.IsNullOrEmpty(displayPath) || displayPath == "LisunOS://" ? "LisunOS://" : displayPath;
                    break;

                case "whoami":
                    outputResult = IsSuperUser ? "root" : (LisunEngine.RegistryData.ContainsKey("user_name") ? LisunEngine.RegistryData["user_name"] : "user");
                    break;

                case "cd":
                    if (string.IsNullOrEmpty(combinedText) || combinedText == "~") currentVirtualDir = LisunEngine.RootPath;
                    else
                    {
                        string targetPath = Path.GetFullPath(Path.Combine(currentVirtualDir, combinedText));
                        if (targetPath.ToLower().StartsWith(LisunEngine.RootPath.ToLower()) && Directory.Exists(targetPath)) currentVirtualDir = targetPath;
                        else outputResult = $" [cd] Ошибка: Путь не найден.";
                    }
                    break;

                case "ls":
                    List<string> subDirs;
                    List<string> subFiles = CustomFormUtils.GetDirectoryContent(currentVirtualDir, out subDirs);
                    var lsSb = new StringBuilder();
                    foreach (var d in subDirs) lsSb.AppendLine($"  [DIR]  {d}");
                    foreach (var f in subFiles) lsSb.AppendLine($"  [FILE] {f}");
                    outputResult = lsSb.Length == 0 ? " Пусто." : lsSb.ToString();
                    break;

                case "cat":
                    if (string.IsNullOrEmpty(combinedText)) return "Укажите файл.";
                    outputResult = CustomFormUtils.ReadFileText(Path.Combine(currentVirtualDir, combinedText));
                    break;

                case "touch":
                    if (string.IsNullOrEmpty(combinedText)) return "Укажите имя.";
                    CustomFormUtils.WriteFileText(Path.Combine(currentVirtualDir, combinedText), "");
                    outputResult = "Файл создан.";
                    break;

                case "mkdir":
                    if (string.IsNullOrEmpty(combinedText)) return "Укажите имя.";
                    CustomFormUtils.CreateFolder(Path.Combine(currentVirtualDir, combinedText));
                    outputResult = "Папка создана.";
                    break;

                case "rm":
                    if (string.IsNullOrEmpty(combinedText)) return "Укажите файл.";
                    CustomFormUtils.DeleteFile(Path.Combine(currentVirtualDir, combinedText));
                    outputResult = "Объект удален.";
                    break;

                case "rmdir":
                    if (string.IsNullOrEmpty(combinedText)) return "Укажите папку.";
                    CustomFormUtils.DeleteFolder(Path.Combine(currentVirtualDir, combinedText));
                    outputResult = "Папка удалена.";
                    break;

                case "clear":
                    outputResult = "clear";
                    break;

                case "restart":
                    System.Threading.Tasks.Task.Run(() => LisunEngine.RequestSoftRestart());
                    outputResult = " Перезапуск...";
                    break;

                case "regedit":
                    if (namedArgs.ContainsKey("config"))
                    {
                        var outStr = new StringBuilder(" [REGEDIT // CONFIG]:\n");
                        foreach (var kvp in LisunEngine.RegistryConfig) outStr.AppendLine($"  {kvp.Key} = {kvp.Value}");
                        outputResult = outStr.ToString();
                    }
                    else if (namedArgs.ContainsKey("data"))
                    {
                        var outStr = new StringBuilder(" [REGEDIT // DATA]:\n");
                        foreach (var kvp in LisunEngine.RegistryData) outStr.AppendLine($"  {kvp.Key} = {kvp.Value}");
                        outputResult = outStr.ToString();
                    }
                    else if (namedArgs.ContainsKey("commands"))
                    {
                        if (!File.Exists(LisunEngine.RegCommandsFilePath)) return " Файл COMMANDS пуст.";
                        var outStr = new StringBuilder(" [REGEDIT // COMMANDS]:\n");
                        foreach (var line in File.ReadAllLines(LisunEngine.RegCommandsFilePath)) outStr.AppendLine($"  • {line}");
                        outputResult = outStr.ToString();
                    }
                    else if (namedArgs.ContainsKey("set") && namedArgs.ContainsKey("val"))
                    {
                        string key = namedArgs["set"].ToLower().Trim();
                        string val = namedArgs["val"].Trim();

                        if (key == "hallapp" || key == "hall" || key == "lisunhallkey")
                        {
                            if (!IsSuperUser) return " [🔒 SECURITY ALERT] Доступ заблокирован.";
                        }

                        if (key == "hallapp" || key == "lisunhallkey")
                        {
                            LisunEngine.RegistryConfig[key] = val;
                            LisunEngine.SaveRegistry();
                        }
                        else
                        {
                            LisunEngine.RegistryData[key] = val;
                            LisunEngine.SaveRegistry();
                        }
                        outputResult = "Запись успешна.";
                    }
                    break;

                default:
                    outputResult = $" [bash] {commandName}: command not found.";
                    break;
            }

            IsSuperUser = oldSuperUserStatus;
            return outputResult;
        }
    }
}
