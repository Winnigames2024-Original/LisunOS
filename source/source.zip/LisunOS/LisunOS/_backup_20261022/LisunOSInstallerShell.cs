﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Windows.Forms;

namespace LisunOS
{
    public static class LisunOSInstallerShell
    {
        private static readonly string HiddenHallTokenPath = Path.Combine(LisunEngine.RegeditPath, ".hall_token");
        private const string MasterHallKey = "LisunOSHallKey0100101001";

        public static void InitializeSecurityTokens()
        {
            if (!File.Exists(HiddenHallTokenPath))
            {
                string dynamicKey = "Hall_" + Guid.NewGuid().ToString("N").Substring(0, 16).ToUpper();
                File.WriteAllText(HiddenHallTokenPath, dynamicKey);
                LisunEngine.RegistryConfig["lisunhallkey"] = dynamicKey;
                LisunEngine.SaveRegistry();
            }
            else
            {
                LisunEngine.RegistryConfig["lisunhallkey"] = File.ReadAllText(HiddenHallTokenPath).Trim();
            }
        }

        public static bool InstallPackage(string packagePath)
        {
            string appName = Path.GetFileNameWithoutExtension(packagePath);
            string extractionTempDir = Path.Combine(LisunEngine.TempPath, "extract_" + appName);

            try
            {
                if (Directory.Exists(extractionTempDir)) Directory.Delete(extractionTempDir, true);
                Directory.CreateDirectory(extractionTempDir);

                LisunEngine.Log($"[Installer] Распаковка структуры {appName}.lnsh...");
                ZipFile.ExtractToDirectory(packagePath, extractionTempDir);

                string metaPath = Path.Combine(extractionTempDir, "meta.json");
                if (!File.Exists(metaPath))
                {
                    LisunEngine.Log("[Installer] [ОШИБКА] Отсутствует манифест meta.json");
                    return false;
                }

                Dictionary<string, string> meta = ParseSimpleJson(File.ReadAllText(metaPath));
                string appType = meta.ContainsKey("type") ? meta["type"].ToLower() : "service";

                if (appType == "hall")
                {
                    string providedKey = meta.ContainsKey("hall_key") ? meta["hall_key"] : "";
                    string currentSystemKey = File.Exists(HiddenHallTokenPath) ? File.ReadAllText(HiddenHallTokenPath).Trim() : "";

                    if (providedKey != MasterHallKey && providedKey != currentSystemKey)
                    {
                        LisunEngine.Log("[Installer] [ОТКАЗ] Ключ hall_key не валиден.");
                        return false;
                    }
                }

                string targetDir = Path.Combine(LisunEngine.ServicesPath, appName);
                if (Directory.Exists(targetDir)) Directory.Delete(targetDir, true);
                Directory.CreateDirectory(targetDir);

                foreach (string dirPath in Directory.GetDirectories(extractionTempDir, "*", SearchOption.AllDirectories))
                    Directory.CreateDirectory(dirPath.Replace(extractionTempDir, targetDir));
                foreach (string newPath in Directory.GetFiles(extractionTempDir, "*.*", SearchOption.AllDirectories))
                    File.Copy(newPath, newPath.Replace(extractionTempDir, targetDir), true);

                string lsiPath = Path.Combine(targetDir, "main.lsi");
                if (File.Exists(lsiPath))
                {
                    LisunEngine.Log($"[Installer] Обнаружен сценарий main.lsi. Запуск развёртывания...");
                    ExecuteLsiScript(File.ReadAllLines(lsiPath), targetDir);
                }
                else
                {
                    LisunEngine.Log("[Installer] Предупреждение: Файл main.lsi не найден.");
                }

                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[Installer] Ошибка рантайма: {ex.Message}");
                return false;
            }
            finally
            {
                if (Directory.Exists(extractionTempDir)) Directory.Delete(extractionTempDir, true);
            }
        }

        private static void ExecuteLsiScript(string[] lines, string targetDir)
        {
            bool needsRestart = false;

            foreach (var line in lines)
            {
                string clean = line.Trim();
                if (string.IsNullOrEmpty(clean) || clean.StartsWith("#")) continue;

                string[] parts = clean.Split(new[] { ' ' }, 2);
                string cmd = parts[0].ToLower().Trim();
                string arg = parts.Length > 1 ? parts[1].Trim('\'', '"') : "";

                switch (cmd)
                {
                    case "register_service":
                        string sPath = Path.Combine(targetDir, arg);
                        if (File.Exists(sPath))
                        {
                            FormEngine.ExecuteScript(File.ReadAllLines(sPath), targetDir);
                            LisunEngine.Log($"[LSI] Зарегистрирована служба из файла: {arg}");
                        }
                        break;

                    case "download_file":
                        string[] dlParts = arg.Split(new[] { "->" }, StringSplitOptions.None);
                        if (dlParts.Length == 2)
                        {
                            try
                            {
                                using (var client = new WebClient())
                                {
                                    string dest = Path.Combine(targetDir, "assets", dlParts[1].Trim());
                                    Directory.CreateDirectory(Path.GetDirectoryName(dest));
                                    client.DownloadFile(dlParts[0].Trim(), dest);
                                    LisunEngine.Log($"[LSI] Загружен внешний ресурс: {dlParts[1]}");
                                }
                            }
                            catch (Exception ex) { LisunEngine.Log($"[LSI] Ошибка загрузки: {ex.Message}"); }
                        }
                        break;

                    case "request_restart":
                        needsRestart = true;
                        break;
                }
            }

            if (needsRestart)
            {
                DialogResult dialogResult = MessageBox.Show(
                    "Для завершения конфигурации пакета требуется перезагрузка оболочки LisunOS. Выполнить перезапуск прямо сейчас?",
                    "LisunOS Installer Core",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );

                if (dialogResult == DialogResult.Yes)
                {
                    LisunEngine.Log("[SYS] Инициализирован мягкий перезапуск после установки...");

                    // ИСПРАВЛЕНО: Запускаем перезагрузку ядра LisunOS на лету без закрытия .exe процесса
                    System.Threading.Tasks.Task.Run(() => LisunEngine.RequestSoftRestart());
                }
            }
        }

        private static Dictionary<string, string> ParseSimpleJson(string json)
        {
            var result = new Dictionary<string, string>();
            string clean = json.Replace("{", "").Replace("}", "").Trim();
            string[] tokens = clean.Split(',');
            foreach (var token in tokens)
            {
                string[] kvp = token.Split(new[] { ':' }, 2);
                if (kvp.Length == 2) result[kvp[0].Trim(' ', '"', '\n', '\r')] = kvp[1].Trim(' ', '"', '\n', '\r');
            }
            return result;
        }
    }
}
