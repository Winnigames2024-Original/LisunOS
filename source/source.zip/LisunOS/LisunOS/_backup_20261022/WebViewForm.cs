﻿using System;
using System.Web;
using System.Windows.Forms;

namespace LisunOS
{
    public partial class WebViewForm : Form
    {
        // Событие, уведомляющее MainForm о том, что браузер скрывается
        public event Action OnBrowserCloseRequested;

        public WebViewForm()
        {
            InitializeComponent();
        }

        public void NavigateTo(string target)
        {
            txtBrowserUrl.Text = target;

            if (target.StartsWith("http://") || target.StartsWith("https://"))
            {
                miniWebBrowser.Navigate(target);
            }
            else
            {
                miniWebBrowser.Navigate("https://google.com" + HttpUtility.UrlEncode(target));
            }
        }

        private void btnCloseBrowser_Click(object sender, EventArgs e)
        {
            // Вызываем событие закрытия, перехватываемое MainForm
            OnBrowserCloseRequested?.Invoke();
        }

        private void txtBrowserUrl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                NavigateTo(txtBrowserUrl.Text.Trim());
            }
        }

        private void btnSearchGoogle_Click(object sender, EventArgs e) => miniWebBrowser.Navigate("https://google.com" + HttpUtility.UrlEncode(txtBrowserUrl.Text));
        private void btnSearchYandex_Click(object sender, EventArgs e) => miniWebBrowser.Navigate("https://yandex.ru" + HttpUtility.UrlEncode(txtBrowserUrl.Text));
        private void btnSearchBing_Click(object sender, EventArgs e) => miniWebBrowser.Navigate("https://bing.com" + HttpUtility.UrlEncode(txtBrowserUrl.Text));
    }
}
