﻿namespace LisunOS
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtConsoleLog;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Panel pnlInputBackground;
        private System.Windows.Forms.Label lblPrompt;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtConsoleLog = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.pnlInputBackground = new System.Windows.Forms.Panel();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.pnlInputBackground.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtConsoleLog
            // 
            this.txtConsoleLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConsoleLog.BackColor = System.Drawing.Color.Black;
            this.txtConsoleLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConsoleLog.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtConsoleLog.ForeColor = System.Drawing.Color.LightGray;
            this.txtConsoleLog.Location = new System.Drawing.Point(12, 10);
            this.txtConsoleLog.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtConsoleLog.Multiline = true;
            this.txtConsoleLog.Name = "txtConsoleLog";
            this.txtConsoleLog.ReadOnly = true;
            this.txtConsoleLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtConsoleLog.Size = new System.Drawing.Size(615, 312);
            this.txtConsoleLog.TabIndex = 99;
            // 
            // txtInput
            // 
            this.txtInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.txtInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtInput.ForeColor = System.Drawing.Color.White;
            this.txtInput.Location = new System.Drawing.Point(94, 7);
            this.txtInput.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(510, 18);
            this.txtInput.TabIndex = 0;
            this.txtInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInput_KeyDown);
            // 
            // pnlInputBackground
            // 
            this.pnlInputBackground.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInputBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pnlInputBackground.Controls.Add(this.lblPrompt);
            this.pnlInputBackground.Controls.Add(this.txtInput);
            this.pnlInputBackground.Location = new System.Drawing.Point(12, 333);
            this.pnlInputBackground.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pnlInputBackground.Name = "pnlInputBackground";
            this.pnlInputBackground.Size = new System.Drawing.Size(615, 27);
            this.pnlInputBackground.TabIndex = 1;
            this.pnlInputBackground.Paint += new System.Windows.Forms.PaintEventHandler(this.Rounding_Paint);
            // 
            // lblPrompt
            // 
            this.lblPrompt.AutoSize = true;
            this.lblPrompt.Font = new System.Drawing.Font("Consolas", 11F);
            this.lblPrompt.ForeColor = System.Drawing.Color.DarkGray;
            this.lblPrompt.Location = new System.Drawing.Point(2, 7);
            this.lblPrompt.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(88, 18);
            this.lblPrompt.TabIndex = 0;
            this.lblPrompt.Text = "LisunOS:\\>";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(639, 372);
            this.Controls.Add(this.pnlInputBackground);
            this.Controls.Add(this.txtConsoleLog);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Администратор: LisunOS Core Terminal";
            this.pnlInputBackground.ResumeLayout(false);
            this.pnlInputBackground.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}
