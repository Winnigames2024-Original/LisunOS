﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LisunOS
{
    public partial class Form1 : Form
    {
        // Постоянная ссылка на форму браузера, которая будет встраиваться
        private WebViewForm embeddedBrowser;

        public Form1()
        {
            // ОСТАВЛЕН ТОЛЬКО ОДИН ВЫЗОВ (Критически важно для работы дизайнера!)
            InitializeComponent();

            // Инициализируем форму браузера один раз при старте приложения
            embeddedBrowser = new WebViewForm();
            embeddedBrowser.TopLevel = false; // Указываем, что форма дочерняя и её можно встроить
            embeddedBrowser.FormBorderStyle = FormBorderStyle.None; // Убираем у неё рамки
            embeddedBrowser.Dock = DockStyle.Fill; // Разворачиваем на всё доступное пространство

            // Подписываемся на событие закрытия, которое генерирует кнопка внутри WebViewForm
            embeddedBrowser.OnBrowserCloseRequested += HideBrowserForm;

            // Подписываем вывод текстового окна на события глобального лога ядра
            LisunEngine.OnLogAdded += AppendToTerminal;

            // Запускаем асинхронный экран загрузки операционной системы
            StartLoadingOS();
        }

        private async void StartLoadingOS()
        {
            // Блокируем ввод на время загрузки системы
            txtInput.ReadOnly = true;
            pnlInputBackground.Visible = false;

            txtConsoleLog.AppendText("Starting LisunOS Kernel Engine..." + Environment.NewLine);
            await Task.Delay(400);

            // 1. Инициализируем папки и реестр CONFIG/DATA
            LisunEngine.Initialize();
            await Task.Delay(500);

            // 2. Сканируем сервисы и выполняем запуск
            txtConsoleLog.AppendText("[BOOT] Подключение подсистем и сканирование /sys/services/..." + Environment.NewLine);
            await Task.Run(() => LisunEngine.StartServicesAndBlock());
            await Task.Delay(400);

            // Перенесено сюда: Лог приветствия LisunOS появляется ПРАВИЛЬНО после загрузки ядра
            txtConsoleLog.AppendText(Environment.NewLine + "Microsoft Windows [Version 10.0.22631.LisunOS]" + Environment.NewLine);
            txtConsoleLog.AppendText("(c) Корпорация Lisun Core Engine. Все права защищены." + Environment.NewLine + Environment.NewLine);

            txtConsoleLog.AppendText("— LisunOS [Версия 1.0.0] —" + Environment.NewLine);
            txtConsoleLog.AppendText("Консоль готова. Команда 'webview <ссылка>' встроит форму браузера." + Environment.NewLine + Environment.NewLine);

            // Загрузка завершена: возвращаем строку ввода на экран
            txtInput.ReadOnly = false;
            pnlInputBackground.Visible = true;
            txtInput.Focus();
        }

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                string input = txtInput.Text.Trim();
                if (string.IsNullOrWhiteSpace(input)) return;

                txtConsoleLog.AppendText($"LisunOS:\\> {input}" + Environment.NewLine);

                // Перехватываем команду вызова браузера
                if (input.ToLower().StartsWith("webview"))
                {
                    string[] parts = input.Split(new[] { ' ' }, 2);
                    // Берем элемент [1] (сам адрес) и чистим его от пробелов. 
                    // Если аргумента нет, по умолчанию открываем google.
                    string target = parts.Length > 1 ? parts[1].Trim() : "https://google.com";

                    txtInput.Clear();
                    ShowBrowserForm(target);
                    return;
                }

                if (input.ToLower() == "clear")
                {
                    txtConsoleLog.Clear();
                    txtInput.Clear();
                    return;
                }

                // Выполнение через CommandExecutorEngine
                string outputResult = CommandExecutorEngine.Execute(input);
                if (!string.IsNullOrEmpty(outputResult))
                {
                    txtConsoleLog.AppendText(outputResult + Environment.NewLine + Environment.NewLine);
                }

                txtInput.Clear();
                txtConsoleLog.SelectionStart = txtConsoleLog.Text.Length;
                txtConsoleLog.ScrollToCaret();
            }
        }

        private void AppendToTerminal(string message)
        {
            // Проверяем, нужен ли вызов из другого потока
            if (txtConsoleLog.InvokeRequired)
            {
                txtConsoleLog.Invoke(new Action<string>(AppendToTerminal), message);
            }
            else
            {
                txtConsoleLog.AppendText(message + Environment.NewLine);
                txtConsoleLog.SelectionStart = txtConsoleLog.Text.Length;
                txtConsoleLog.ScrollToCaret();
            }
        }

        // --- МЕТОД ВСТРАИВАНИЯ ФОРМЫ БРАУЗЕРА ---
        private void ShowBrowserForm(string url)
        {
            // Если форма браузера еще не добавлена в элементы управления Form1, добавляем её
            if (!this.Controls.Contains(embeddedBrowser))
            {
                this.Controls.Add(embeddedBrowser);
            }

            embeddedBrowser.Visible = true;
            embeddedBrowser.BringToFront(); // Выносим её на самый верхний слой
            embeddedBrowser.NavigateTo(url); // Даем команду загрузить сайт
        }

        // --- МЕТОД ИЗВЛЕЧЕНИЯ (СКРЫТИЯ) ФОРМЫ БРАУЗЕРА ---
        private void HideBrowserForm()
        {
            embeddedBrowser.Visible = false; // Просто скрываем форму, кэш и вкладка остаются живы

            txtConsoleLog.AppendText(" [SYS] WebViewForm скрыта. Управление возвращено в Form1." + Environment.NewLine + Environment.NewLine);
            txtInput.Focus(); // Возвращаем фокус на строку ввода
        }

        private void Rounding_Paint(object sender, PaintEventArgs e)
        {
            if (sender is Control ctrl)
            {
                GraphicsPath path = new GraphicsPath();
                int radius = 12;
                path.StartFigure();
                path.AddArc(0, 0, radius, radius, 180, 90);
                path.AddArc(ctrl.Width - radius, 0, radius, radius, 270, 90);
                path.AddArc(ctrl.Width - radius, ctrl.Height - radius, radius, radius, 0, 90);
                path.AddArc(0, ctrl.Height - radius, radius, radius, 90, 90);
                path.CloseFigure();
                ctrl.Region = new Region(path);
            }
        }
    }
}
