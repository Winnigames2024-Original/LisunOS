﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace LisunOS
{
    public static class LisunEngine
    {
        public static readonly string RootPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "files", "os");
        public static readonly string ServicesPath = Path.Combine(RootPath, "sys", "services");

        public static readonly string RegeditPath = Path.Combine(RootPath, "root", "regedit");
        public static readonly string TempPath = Path.Combine(RootPath, "temp");
        public static readonly string RegConfigFilePath = Path.Combine(RegeditPath, "CONFIG");
        public static readonly string RegDataFilePath = Path.Combine(RegeditPath, "DATA");
        public static readonly string RegCommandsFilePath = Path.Combine(RegeditPath, "COMMANDS");

        public static Dictionary<string, object> Assets { get; private set; } = new Dictionary<string, object>();
        public static Dictionary<string, List<string>> RegisteredCommands { get; private set; } = new Dictionary<string, List<string>>();

        public static Dictionary<string, string> RegistryConfig { get; private set; } = new Dictionary<string, string>();
        public static Dictionary<string, string> RegistryData { get; private set; } = new Dictionary<string, string>();

        public static List<string> SystemLog { get; private set; } = new List<string>();
        public static event Action<string> OnLogAdded;
        public static event Action OnSoftRestartRequested;

        public static void Log(string message)
        {
            string formatted = $"[{DateTime.Now:HH:mm:ss}] {message}";
            SystemLog.Add(formatted);
            OnLogAdded?.Invoke(formatted);
        }

        public static void Initialize()
        {
            Log("Запуск ядра LisunOS...");

            if (!Directory.Exists(ServicesPath)) Directory.CreateDirectory(ServicesPath);
            if (!Directory.Exists(RegeditPath)) Directory.CreateDirectory(RegeditPath);
            if (!Directory.Exists(TempPath)) Directory.CreateDirectory(TempPath);

            ClearTempDirectory();
            LoadRegistry();

            LisunOSInstallerShell.InitializeSecurityTokens();
        }

        private static void ClearTempDirectory()
        {
            try
            {
                string[] files = Directory.GetFiles(TempPath);
                foreach (var file in files) File.Delete(file);
                Log("[Kernel] Директория /os/temp/ успешно очищена.");
            }
            catch (Exception ex) { Log($"[Kernel] Ошибка очистки Temp: {ex.Message}"); }
        }

        private static void LoadRegistry()
        {
            if (!File.Exists(RegConfigFilePath))
                File.WriteAllText(RegConfigFilePath, "OS_VERSION=1.0.0\nKERNEL_TYPE=Core\nHallApp=LisunOS.lshall\nMAX_THREADS=4");
            if (!File.Exists(RegDataFilePath))
                File.WriteAllText(RegDataFilePath, "USER_NAME=Administrator\nTHEME=Dark");

            RegistryConfig.Clear();
            foreach (var line in File.ReadAllLines(RegConfigFilePath))
            {
                string[] parts = line.Split('=');
                if (parts.Length == 2) RegistryConfig[parts[0].ToLower().Trim()] = parts[1].Trim();
            }

            if (!RegistryConfig.ContainsKey("hallapp")) RegistryConfig["hallapp"] = "LisunOS.lshall";

            RegistryData.Clear();
            foreach (var line in File.ReadAllLines(RegDataFilePath))
            {
                string[] parts = line.Split('=');
                if (parts.Length == 2) RegistryData[parts[0].ToLower().Trim()] = parts[1].Trim();
            }
            Log("[Kernel] База данных Regedit успешно смонтирована.");
        }

        public static void SaveRegistry()
        {
            List<string> cfgLines = new List<string>();
            foreach (var kvp in RegistryConfig) cfgLines.Add($"{kvp.Key}={kvp.Value}");
            File.WriteAllLines(RegConfigFilePath, cfgLines);

            List<string> datLines = new List<string>();
            foreach (var kvp in RegistryData) datLines.Add($"{kvp.Key}={kvp.Value}");
            File.WriteAllLines(RegDataFilePath, datLines);
        }

        public static void SaveRegisteredCommands()
        {
            try
            {
                List<string> cmdLines = new List<string>();
                foreach (var kvp in RegisteredCommands)
                {
                    string apps = string.Join(",", kvp.Value);
                    cmdLines.Add($"{kvp.Key}={apps}");
                }
                File.WriteAllLines(RegCommandsFilePath, cmdLines);
            }
            catch { }
        }

        public static void StartServicesAndBlock()
        {
            if (File.Exists(RegCommandsFilePath)) File.Delete(RegCommandsFilePath);

            if (!Directory.Exists(ServicesPath)) return;
            string[] serviceDirs = Directory.GetDirectories(ServicesPath);
            List<Task> tasks = new List<Task>();

            foreach (var dir in serviceDirs)
            {
                string[] serviceFiles = Directory.GetFiles(dir, "*.service");
                foreach (var file in serviceFiles)
                {
                    string[] lines = File.ReadAllLines(file);
                    Task t = Task.Run(() => FormEngine.ExecuteScript(lines, dir));
                    tasks.Add(t);
                }
            }
            Task.WaitAll(tasks.ToArray());
            SaveRegisteredCommands();
        }

        public static void RequestSoftRestart()
        {
            Log("[Kernel] Инициализация мягкого перезапуска...");
            RegisteredCommands.Clear();
            Assets.Clear();
            FormEngine.ClearAllActiveApps();
            OnSoftRestartRequested?.Invoke();
        }
    }
}