﻿using System;
using System.Windows.Forms;

namespace LisunOS
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 1. Инициализация и запуск сервисов из /files/os/sys/services/
            LisunEngine.Initialize();
            LisunEngine.StartServicesAndBlock();

            // 2. Открытие интерфейса ОС
            Application.Run(new Form1());
        }
    }
}
