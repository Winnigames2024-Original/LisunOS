﻿namespace LisunOS
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TextBox txtConsoleLog;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Panel pnlInputBackground;
        private System.Windows.Forms.Label lblPrompt;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.txtConsoleLog = new System.Windows.Forms.TextBox();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.pnlInputBackground = new System.Windows.Forms.Panel();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.pnlInputBackground.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtConsoleLog
            // 
            this.txtConsoleLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.txtConsoleLog.BackColor = System.Drawing.Color.Black;
            this.txtConsoleLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConsoleLog.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtConsoleLog.ForeColor = System.Drawing.Color.LightGray;
            this.txtConsoleLog.Location = new System.Drawing.Point(16, 16);
            this.txtConsoleLog.Multiline = true;
            this.txtConsoleLog.Size = new System.Drawing.Size(820, 480);
            // 
            // pnlInputBackground
            // 
            this.pnlInputBackground.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlInputBackground.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pnlInputBackground.Controls.Add(this.lblPrompt);
            this.pnlInputBackground.Controls.Add(this.txtInput);
            this.pnlInputBackground.Location = new System.Drawing.Point(16, 512);
            this.pnlInputBackground.Size = new System.Drawing.Size(820, 42);
            this.pnlInputBackground.Paint += new System.Windows.Forms.PaintEventHandler(this.Rounding_Paint);
            // 
            // lblPrompt
            // 
            this.lblPrompt.ForeColor = System.Drawing.Color.DarkGray;
            this.lblPrompt.Location = new System.Drawing.Point(10, 10);
            this.lblPrompt.Size = new System.Drawing.Size(110, 22);
            this.lblPrompt.Text = "LisunOS:\\>";
            // 
            // txtInput
            // 
            this.txtInput.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.txtInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInput.Font = new System.Drawing.Font("Consolas", 11F);
            this.txtInput.ForeColor = System.Drawing.Color.White;
            this.txtInput.Location = new System.Drawing.Point(125, 11);
            this.txtInput.Size = new System.Drawing.Size(680, 22);
            this.txtInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInput_KeyDown);
            // 
            // MainForm
            // 
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(852, 572);
            this.Controls.Add(this.pnlInputBackground);
            this.Controls.Add(this.txtConsoleLog);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LisunOS — MainForm Core Container";
            this.pnlInputBackground.ResumeLayout(false);
            this.pnlInputBackground.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
