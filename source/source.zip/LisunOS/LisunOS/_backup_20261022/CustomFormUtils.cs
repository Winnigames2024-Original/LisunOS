﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;

namespace LisunOS
{
    /// <summary>
    /// Утилиты для безопасной работы с файлами и директориями в среде LisunOS.
    /// </summary>
    public static class CustomFormUtils
    {
        /// <summary>
        /// Безопасное чтение текстового контента из файла.
        /// </summary>
        public static string ReadFileText(string path)
        {
            try
            {
                if (!File.Exists(path)) return $"[ERR] Файл не найден: {Path.GetFileName(path)}";
                return File.ReadAllText(path, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                return $"[ERR] Ошибка чтения: {ex.Message}";
            }
        }

        /// <summary>
        /// Безопасная запись текста в файл (перезапись контента).
        /// </summary>
        public static bool WriteFileText(string path, string content)
        {
            try
            {
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }
                File.WriteAllText(path, content, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[IO Error] Не удалось записать файл {Path.GetFileName(path)}: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Удаление файла с диска виртуальной ОС.
        /// </summary>
        public static bool DeleteFile(string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[IO Error] Не удалось удалить файл: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Создание новой папки.
        /// </summary>
        public static bool CreateFolder(string path)
        {
            try
            {
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[IO Error] Не удалось создать каталог: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Удаление папки и всего её содержимого (рекурсивно).
        /// </summary>
        public static bool DeleteFolder(string path)
        {
            try
            {
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[IO Error] Не удалось удалить каталог: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Получение списка всех файлов и папок в директории (аналог ls / dir).
        /// </summary>
        public static List<string> GetDirectoryContent(string path, out List<string> directoriesOnly)
        {
            List<string> filesOnly = new List<string>();
            directoriesOnly = new List<string>();

            try
            {
                if (Directory.Exists(path))
                {
                    foreach (var d in Directory.GetDirectories(path))
                    {
                        directoriesOnly.Add(Path.GetFileName(d));
                    }
                    foreach (var f in Directory.GetFiles(path))
                    {
                        filesOnly.Add(Path.GetFileName(f));
                    }
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[IO Error] Ошибка сканирования {path}: {ex.Message}");
            }

            return filesOnly;
        }
    }
}
