﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Documents;
using System.Windows.Forms;

namespace LisunOS
{
    public static class FormEngine
    {
        public static Dictionary<string, DynamicApp> ActiveApps { get; private set; } = new Dictionary<string, DynamicApp>();
        private static bool isWinformsImported = false;

        public static void ExecuteScript(string[] lines, string serviceFolderPath = "")
        {
            DynamicApp currentAppContext = null;

            foreach (var line in lines)
            {
                string trimmed = line.Trim();
                if (string.IsNullOrEmpty(trimmed) || trimmed.StartsWith("#")) continue;

                if (trimmed == "import winforms")
                {
                    isWinformsImported = true;
                    LisunEngine.Log("[FormEngine] Модуль 'winforms' успешно импортирован.");
                    continue;
                }

                if (trimmed.Contains("winforms.") && !isWinformsImported)
                {
                    LisunEngine.Log("[FormEngine] [Ошибка] Сбой: модуль 'winforms' не импортирован.");
                    return;
                }

                if (trimmed.StartsWith("winforms.Application") && trimmed.Contains("="))
                {
                    string cleanLine = trimmed.Replace("winforms.Application", "");
                    string[] parts = cleanLine.Split('=');
                    if (parts.Length > 0)
                    {
                        string appName = parts[0].Trim();
                        if (!string.IsNullOrEmpty(appName))
                        {
                            if (ActiveApps.ContainsKey(appName))
                            {
                                Form oldForm = ActiveApps[appName].Form;
                                if (oldForm != null)
                                {
                                    if (oldForm.InvokeRequired) oldForm.Invoke(new Action(() => oldForm.Close()));
                                    else oldForm.Close();
                                }
                            }
                            currentAppContext = new DynamicApp(appName);
                            ActiveApps[appName] = currentAppContext;
                            LisunEngine.Log($"[FormEngine] Создан дескриптор приложения: {appName}");
                        }
                    }
                    continue;
                }

                if (currentAppContext == null)
                {
                    foreach (var app in ActiveApps.Keys)
                    {
                        if (trimmed.StartsWith(app)) { currentAppContext = ActiveApps[app]; break; }
                    }
                }

                if (trimmed.StartsWith("winforms.Form") && trimmed.Contains("=") && trimmed.Contains("new winforms.Form"))
                {
                    ParseFormInitialization(trimmed, serviceFolderPath, currentAppContext);
                    continue;
                }

                if (currentAppContext != null)
                {
                    if (trimmed.StartsWith($"{currentAppContext.Name}.program.addForm(")) continue;

                    if (trimmed.StartsWith($"{currentAppContext.Name}.program.setDefaultForm("))
                    {
                        string defaultAppTarget = !string.IsNullOrEmpty(currentAppContext.Namespace) ? currentAppContext.Namespace : currentAppContext.Name;
                        LisunEngine.RegistryConfig["hallapp"] = defaultAppTarget;
                        LisunEngine.SaveRegistry();
                        LisunEngine.Log($"[FormEngine] [⚡ CORE] Установлена дефолтная оболочка: '{defaultAppTarget}'.");
                        continue;
                    }

                    if (trimmed.StartsWith($"{currentAppContext.Name}.namespace") && trimmed.Contains("="))
                    {
                        string[] nsParts = trimmed.Split('=');
                        if (nsParts.Length > 1)
                        {
                            string nsValue = nsParts[1].Trim().Trim('\'', '"');
                            currentAppContext.Namespace = nsValue;

                            string commandTrigger = nsValue.ToLower();
                            if (!LisunEngine.RegisteredCommands.ContainsKey(commandTrigger))
                            {
                                LisunEngine.RegisteredCommands[commandTrigger] = new List<string> { currentAppContext.Name };
                                LisunEngine.Log($"[FormEngine] Создана привязка вызова: введите '{commandTrigger}' в консоли.");
                                LisunEngine.SaveRegisteredCommands();
                            }
                        }
                        continue;
                    }

                    if (trimmed == $"{currentAppContext.Name}.show()")
                    {
                        currentAppContext.Show();
                        continue;
                    }
                }
            }
        }

        private static void ParseFormInitialization(string line, string serviceFolderPath, DynamicApp currentApp)
        {
            try
            {
                string[] parts = line.Split('=');
                if (parts.Length < 2) return;
                string rightSide = parts[1].Trim();

                int firstQuote = rightSide.IndexOf('"');
                int secondQuote = rightSide.IndexOf('"', firstQuote + 1);
                int thirdQuote = rightSide.IndexOf('"', secondQuote + 1);
                int fourthQuote = rightSide.IndexOf('"', thirdQuote + 1);

                string csPath = rightSide.Substring(firstQuote + 1, secondQuote - firstQuote - 1);
                string designerPath = rightSide.Substring(thirdQuote + 1, fourthQuote - thirdQuote - 1);

                string assetsPath = Path.Combine(serviceFolderPath, "assets");
                csPath = csPath.Replace("%appfiles%", assetsPath);
                designerPath = designerPath.Replace("%appfiles%", assetsPath);

                Form compiledForm = BuildDynamicForm(designerPath, csPath);
                if (currentApp != null)
                {
                    currentApp.SetForm(compiledForm);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log($"[FormEngine] Ошибка чтения метаданных формы: {ex.Message}");
            }
        }

        private static Form BuildDynamicForm(string designerPath, string csPath)
        {
            Form customForm = new Form();
            customForm.Size = new Size(800, 500);
            customForm.BackColor = Color.FromArgb(30, 30, 30);
            customForm.ForeColor = Color.White;
            customForm.StartPosition = FormStartPosition.CenterScreen;

            if (!File.Exists(designerPath)) return customForm;

            Dictionary<string, Control> formControls = new Dictionary<string, Control>();
            Dictionary<string, ToolStripMenuItem> menuItems = new Dictionary<string, ToolStripMenuItem>();
            ContextMenuStrip contextMenu = null;

            string[] lines = File.ReadAllLines(designerPath);

            foreach (var line in lines)
            {
                string clean = line.Trim();
                if (clean.StartsWith("private System.Windows.Forms."))
                {
                    string declaration = clean.Replace("private System.Windows.Forms.", "").Replace(";", "");
                    string[] parts = declaration.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 2)
                    {
                        string typeName = parts[0].Trim();
                        string controlName = parts[1].Trim();

                        if (typeName == "ContextMenuStrip")
                        {
                            contextMenu = new ContextMenuStrip();
                        }
                        else if (typeName == "ToolStripMenuItem")
                        {
                            var menu = new ToolStripMenuItem();
                            menu.Name = controlName;
                            menuItems[controlName.ToLower()] = menu;
                        }
                        else
                        {
                            Control ctrl = CreateControlInstance(typeName);
                            if (ctrl != null)
                            {
                                ctrl.Name = controlName;
                                formControls[controlName.ToLower()] = ctrl;
                            }
                        }
                    }
                }
            }

            foreach (var line in lines)
            {
                string clean = line.Trim();
                if (string.IsNullOrEmpty(clean) || !clean.Contains(".")) continue;

                if (clean.StartsWith("this."))
                {
                    if (clean.Contains("ClientSize") && clean.Contains("Size("))
                    {
                        try
                        {
                            int start = clean.IndexOf("Size(") + 5;
                            int end = clean.IndexOf(")", start);
                            string[] dims = clean.Substring(start, end - start).Split(',');
                            customForm.ClientSize = new Size(int.Parse(dims[0].Trim()), int.Parse(dims[1].Trim()));
                        }
                        catch { }
                    }
                    if (clean.StartsWith("this.Text") && clean.Contains("="))
                    {
                        string[] textParts = clean.Split('=');
                        if (textParts.Length > 1)
                            customForm.Text = textParts[1].Trim().Trim(';', '"', ' ');
                    }
                    if (clean.Contains("Controls.Add(this."))
                    {
                        string childName = clean.Split(new[] { "Controls.Add(this." }, StringSplitOptions.None)[1].Replace(");", "").Trim().ToLower();
                        if (formControls.ContainsKey(childName)) customForm.Controls.Add(formControls[childName]);
                    }
                    continue;
                }
                if (clean.StartsWith("this.") && clean.Contains(" = "))
                {
                    try
                    {
                        string body = clean.Replace("this.", "");
                        string[] targetAndValue = body.Split(new[] { " = " }, 2, StringSplitOptions.None);
                        string[] componentAndProp = targetAndValue[0].Split('.');
                        string ctrlName = componentAndProp[0].ToLower();
                        string property = componentAndProp[1].Trim();
                        string valStr = targetAndValue[1].Replace(";", "").Trim();
                        if (formControls.ContainsKey(ctrlName))
                        {
                            ApplyProperty(formControls[ctrlName], property, valStr);
                        }
                        else if (menuItems.ContainsKey(ctrlName) && property == "Text")
                        {
                            menuItems[ctrlName].Text = valStr.Trim('"');
                        }
                    }
                    catch { }
                }
                if (clean.StartsWith("this.") && clean.Contains(".Controls.Add(this."))
                {
                    try
                    {
                        string parentName = clean.Split('.')[1].Trim().ToLower();
                        string childName = clean.Split(new[] { "Controls.Add(this." }, StringSplitOptions.None)[1].Replace(");", "").Trim().ToLower();
                        if (formControls.ContainsKey(parentName) && formControls.ContainsKey(childName))
                        {
                            formControls[parentName].Controls.Add(formControls[childName]);
                        }
                    }
                    catch { }
                }
                if (clean.Contains("ContextMenuStrip = this."))
                {
                    // ИСПРАВЛЕНО: Безопасное извлечение lstfilesview из словаря вместо прямого обращения
                    if (formControls.ContainsKey("lstfilesview") && contextMenu != null)
                    {
                        formControls["lstfilesview"].ContextMenuStrip = contextMenu;
                    }
                }
                if (clean.Contains("Items.Add(this."))
                {
                    string childMenu = clean.Split(new[] { "Items.Add(this." }, StringSplitOptions.None)[1].Replace(");", "").Trim().ToLower();
                    if (contextMenu != null && menuItems.ContainsKey(childMenu))
                    {
                        contextMenu.Items.Add(menuItems[childMenu]);
                    }
                }
            }
            InjectFormLogic(customForm, formControls, menuItems, csPath);
            return customForm;
        }
        private static Control CreateControlInstance(string typeName)
        {
            switch (typeName)
            {
                case "Button": return new Button();
                case "TextBox": return new TextBox();
                case "ListBox": return new ListBox();
                case "ListView": return new ListView();
                case "TreeView": return new TreeView();
                case "Panel": return new Panel();
                case "SplitContainer": return new SplitContainer();
                default: return null;
            }
        }
        private static void ApplyProperty(Control ctrl, string property, string value)
        {
            try
            {
                if (property == "Text") ctrl.Text = value.Trim('"');
                else if (property == "Location" && value.Contains("Point("))
                {
                    int start = value.IndexOf("Point(") + 6;
                    int end = value.IndexOf(")", start);
                    string[] pts = value.Substring(start, end - start).Split(',');
                    ctrl.Location = new Point(int.Parse(pts[0].Trim()), int.Parse(pts[1].Trim()));
                }
                else if (property == "Size" && value.Contains("Size("))
                {
                    int start = value.IndexOf("Size(") + 5;
                    int end = value.IndexOf(")", start);
                    string[] dims = value.Substring(start, end - start).Split(',');
                    ctrl.Size = new Size(int.Parse(dims[0].Trim()), int.Parse(dims[1].Trim()));
                }
                else if (property == "Dock")
                {
                    string dockType = value.Replace("System.Windows.Forms.DockStyle.", "");
                    ctrl.Dock = (DockStyle)Enum.Parse(typeof(DockStyle), dockType);
                }
            }
            catch { }
        }
        private static void InjectFormLogic(Form form, Dictionary<string, Control> controls, Dictionary<string, ToolStripMenuItem> menus, string csPath)
        {
            if (!File.Exists(csPath)) return;
            if (csPath.ToLower().Contains("explorer"))
            {
                var explorerBackend = new ExplorerLogicBridge(form, controls, menus);
            }
        }
        public static void ClearAllActiveApps()
        {
            foreach (var app in ActiveApps.Values)
            {
                if (app.Form != null)
                {
                    try
                    {
                        if (app.Form.InvokeRequired) app.Form.Invoke(new Action(() => app.Form.Close()));
                        else app.Form.Close();
                    }
                    catch { }
                }
            }
            ActiveApps.Clear();
            isWinformsImported = false;
        }
    }
    public class DynamicApp
    {
        public string Name { get; set; }
        public string Namespace { get; set; }
        public Form Form { get; private set; }
        public DynamicApp(string name) { Name = name; }
        public void SetForm(Form form) { Form = form; }
        public void Show()
        {
            if (Form == null) return;
            if (Form.InvokeRequired) Form.Invoke(new Action(() => Form.Show()));
            else Form.Show();
            LisunEngine.Log($"[OS] Процесс {Namespace} ({Name}) развернут.");
        }
    }
    /// 
    /// ИСПРАВЛЕНО: Класс ExplorerLogicBridge перенесен внутрь файла FormEngine.cs для полной видимости
    /// 
    public class ExplorerLogicBridge
    {
        private Form _form;
        private string rootPath;
        private string currentPath;
        private Stack historyStack = new Stack();
        private Button btnBack;
        private Button btnUp;
        private TextBox txtAddressBar;
        private TreeView treeDirNodes;
        private ListView lstFilesView;
        public ExplorerLogicBridge(Form form, Dictionary<string, Control> controls, Dictionary<string, ToolStripMenuItem> menus)
        {
            _form = form;
            rootPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "files", "os");
            if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
            currentPath = rootPath;
            if (controls.ContainsKey("btnback")) btnBack = (Button)controls["btnback"];
            if (controls.ContainsKey("btnup")) btnUp = (Button)controls["btnup"];
            if (controls.ContainsKey("txtaddressbar")) txtAddressBar = (TextBox)controls["txtaddressbar"];
            if (controls.ContainsKey("treedirnodes")) treeDirNodes = (TreeView)controls["treedirnodes"];
            if (controls.ContainsKey("lstfilesview")) lstFilesView = (ListView)controls["lstfilesview"];
            if (btnBack != null) btnBack.Click += (s, e) => { if (historyStack.Count > 0) LoadDirectory(historyStack.Pop()); };
            if (btnUp != null) btnUp.Click += btnUp_Click;
            if (treeDirNodes != null)
            {
                treeDirNodes.BeforeExpand += (s, e) => UpdateTreeNodes(e.Node);
                treeDirNodes.AfterSelect += (s, e) => { if (e.Node.Tag != null) { historyStack.Push(currentPath); LoadDirectory(e.Node.Tag.ToString()); } };
            }
            if (lstFilesView != null)
            {
                lstFilesView.View = View.LargeIcon;
                lstFilesView.MouseDoubleClick += lstFilesView_MouseDoubleClick;
                InitializeSystemIcons();
            }
            InitTreeView();
            LoadDirectory(currentPath);
        }
        private void InitializeSystemIcons()
        {
            ImageList imgList = new ImageList { ImageSize = new Size(32, 32), ColorDepth = ColorDepth.Depth32Bit };
            Bitmap folderBmp = new Bitmap(32, 32); using (Graphics g = Graphics.FromImage(folderBmp)) g.Clear(Color.Gold);
            imgList.Images.Add("folder", folderBmp);
            Bitmap fileBmp = new Bitmap(32, 32); using (Graphics g = Graphics.FromImage(fileBmp)) g.Clear(Color.LightGray);
            imgList.Images.Add("file", fileBmp);
            lstFilesView.LargeImageList = imgList;
        }
        private void InitTreeView()
        {
            if (treeDirNodes == null) return;
            treeDirNodes.Nodes.Clear();
            TreeNode rootNode = new TreeNode("LisunOS (C:)") { Tag = rootPath };
            treeDirNodes.Nodes.Add(rootNode);
            UpdateTreeNodes(rootNode);
            rootNode.Expand();
        }
        private void UpdateTreeNodes(TreeNode parentNode)
        {
            try
            {
                parentNode.Nodes.Clear();
                string path = parentNode.Tag.ToString();
                foreach (var dir in Directory.GetDirectories(path))
                {
                    TreeNode node = new TreeNode(Path.GetFileName(dir)) { Tag = dir };
                    node.Nodes.Add(new TreeNode("..."));
                    parentNode.Nodes.Add(node);
                }
            }
            catch { }
        }
        private void LoadDirectory(string path)
        {
            if (!Directory.Exists(path) || lstFilesView == null) return;
            currentPath = path;
            if (txtAddressBar != null) txtAddressBar.Text = path.Replace(LisunEngine.RootPath, "LisunOS://");
            lstFilesView.Items.Clear();
            if (btnBack != null) btnBack.Enabled = historyStack.Count > 0;
            List folders;
            List files = CustomFormUtils.GetDirectoryContent(path, out folders);
            foreach (var folder in folders)
                lstFilesView.Items.Add(new ListViewItem(folder, "folder") { Tag = Path.Combine(path, folder) });
            foreach (var file in files)
                lstFilesView.Items.Add(new ListViewItem(file, "file") { Tag = Path.Combine(path, file) });
        }
        private void lstFilesView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lstFilesView.SelectedItems.Count == 0) return;
            string targetPath = lstFilesView.SelectedItems[0].Tag.ToString();
            if (Directory.Exists(targetPath))
            {
                historyStack.Push(currentPath);
                LoadDirectory(targetPath);
            }
            else if (File.Exists(targetPath))
            {
                string content = CustomFormUtils.ReadFileText(targetPath);
                MessageBox.Show(content, "View file: " + Path.GetFileName(targetPath));
            }
        }
        private void btnUp_Click(object sender, EventArgs e)
        {
            string parentPath = Path.GetDirectoryName(currentPath.TrimEnd('\', ' / '));
        if (!string.IsNullOrEmpty(parentPath)) { historyStack.Push(currentPath); LoadDirectory(parentPath); }
        }
    }
}