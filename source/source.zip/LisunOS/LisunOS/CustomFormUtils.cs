﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Утилиты для безопасной работы с файлами и директориями в среде LisunOS,
    /// плюс небольшие UI-помощники в стиле оболочки.
    /// </summary>
    public static class CustomFormUtils
    {
        public static string ReadFileText(string path)
        {
            try
            {
                if (!File.Exists(path)) return "[ERROR] Файл не найден: " + Path.GetFileName(path);
                return File.ReadAllText(path, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                return "[ERROR] Ошибка чтения: " + ex.Message;
            }
        }

        public static bool WriteFileText(string path, string content)
        {
            try
            {
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(path, content ?? string.Empty, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Запись " + Path.GetFileName(path) + ": " + ex.Message);
                return false;
            }
        }

        public static bool AppendFileText(string path, string content)
        {
            try
            {
                string dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.AppendAllText(path, content ?? string.Empty, Encoding.UTF8);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Дозапись " + Path.GetFileName(path) + ": " + ex.Message);
                return false;
            }
        }

        public static bool DeleteFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;
                File.Delete(path);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Удаление файла: " + ex.Message);
                return false;
            }
        }

        public static bool CreateFolder(string path)
        {
            try
            {
                if (Directory.Exists(path)) return false;
                Directory.CreateDirectory(path);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Создание каталога: " + ex.Message);
                return false;
            }
        }

        public static bool DeleteFolder(string path)
        {
            try
            {
                if (!Directory.Exists(path)) return false;
                Directory.Delete(path, true);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Удаление каталога: " + ex.Message);
                return false;
            }
        }

        public static List<string> GetDirectoryContent(string path, out List<string> directoriesOnly)
        {
            List<string> filesOnly = new List<string>();
            directoriesOnly = new List<string>();

            try
            {
                if (!Directory.Exists(path)) return filesOnly;

                foreach (string d in Directory.GetDirectories(path)) directoriesOnly.Add(Path.GetFileName(d));
                foreach (string f in Directory.GetFiles(path)) filesOnly.Add(Path.GetFileName(f));

                directoriesOnly.Sort(StringComparer.OrdinalIgnoreCase);
                filesOnly.Sort(StringComparer.OrdinalIgnoreCase);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[IO] [ОШИБКА] Сканирование " + path + ": " + ex.Message);
            }

            return filesOnly;
        }

        /// <summary>Человекочитаемый размер файла.</summary>
        public static string FormatSize(long bytes)
        {
            if (bytes < 0) return "—";
            if (bytes < 1024) return bytes + " Б";

            string[] units = { "КБ", "МБ", "ГБ", "ТБ" };
            double value = bytes / 1024.0;
            int unit = 0;
            while (value >= 1024 && unit < units.Length - 1)
            {
                value /= 1024;
                unit++;
            }
            return value.ToString("0.#") + " " + units[unit];
        }

        /// <summary>Превращает реальный путь в путь виртуальной ОС (LisunOS:\...).</summary>
        public static string ToVirtualPath(string realPath)
        {
            if (string.IsNullOrEmpty(realPath)) return "LisunOS:\\";

            string root = LisunEngine.RootPath.TrimEnd(Path.DirectorySeparatorChar);
            if (realPath.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            {
                string tail = realPath.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar);
                return tail.Length == 0 ? "LisunOS:\\" : "LisunOS:\\" + tail;
            }
            return realPath;
        }

        /// <summary>
        /// Разрешает путь относительно текущего каталога и не выпускает его за пределы
        /// корня виртуальной ОС (защита от «cd ..\..\Windows»).
        /// </summary>
        public static bool TryResolveInsideRoot(string currentDir, string relative, out string resolved)
        {
            resolved = null;
            try
            {
                string combined = string.IsNullOrEmpty(relative)
                    ? currentDir
                    : Path.GetFullPath(Path.Combine(currentDir, relative));

                string root = Path.GetFullPath(LisunEngine.RootPath).TrimEnd(Path.DirectorySeparatorChar);
                if (!combined.StartsWith(root, StringComparison.OrdinalIgnoreCase)) return false;

                resolved = combined;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Модальное окно ввода строки в стиле LisunOS (замена отсутствующему InputBox).</summary>
        public static string Prompt(string title, string label, string defaultValue, IWin32Window owner)
        {
            using (Form dialog = new Form())
            {
                dialog.Text = title;
                dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                dialog.StartPosition = owner == null ? FormStartPosition.CenterScreen : FormStartPosition.CenterParent;
                dialog.MinimizeBox = false;
                dialog.MaximizeBox = false;
                dialog.ShowInTaskbar = false;
                dialog.ClientSize = new Size(420, 148);
                dialog.BackColor = Theme.Surface;
                dialog.ForeColor = Theme.Text;
                dialog.Font = Theme.Ui(9.5f);

                Label caption = new Label();
                caption.Text = label;
                caption.ForeColor = Theme.TextDim;
                caption.AutoSize = false;
                caption.SetBounds(18, 18, 384, 20);

                TextBox input = new TextBox();
                input.Text = defaultValue ?? string.Empty;
                input.BackColor = Theme.Background;
                input.ForeColor = Theme.Text;
                input.BorderStyle = BorderStyle.FixedSingle;
                input.Font = Theme.Mono(10f);
                input.SetBounds(18, 46, 384, 26);

                Button ok = new Button();
                ok.Text = LisunLocale.T("dialog.ok");
                ok.DialogResult = DialogResult.OK;
                ok.SetBounds(222, 96, 86, 30);
                Theme.StyleButton(ok, Theme.AccentDeep, Theme.Text);

                Button cancel = new Button();
                cancel.Text = LisunLocale.T("dialog.cancel");
                cancel.DialogResult = DialogResult.Cancel;
                cancel.SetBounds(316, 96, 86, 30);
                Theme.StyleButton(cancel, Theme.SurfaceAlt, Theme.Text);

                dialog.Controls.Add(caption);
                dialog.Controls.Add(input);
                dialog.Controls.Add(ok);
                dialog.Controls.Add(cancel);
                dialog.AcceptButton = ok;
                dialog.CancelButton = cancel;

                input.SelectAll();

                DialogResult result = owner == null ? dialog.ShowDialog() : dialog.ShowDialog(owner);
                if (result != DialogResult.OK) return null;
                return input.Text;
            }
        }
    }
}
