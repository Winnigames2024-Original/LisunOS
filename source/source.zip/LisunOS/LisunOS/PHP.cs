﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace LisunOS.Php
{
    // =========================================================================
    //  Значения
    // =========================================================================

    /// <summary>Массив PHP: упорядоченная карта с ключами int и string.</summary>
    public class PhpArray
    {
        private readonly List<object> keys = new List<object>();
        private readonly Dictionary<object, object> values = new Dictionary<object, object>();
        private long nextIndex;

        public int Count { get { return keys.Count; } }
        public IList<object> Keys { get { return keys; } }

        public static object NormalizeKey(object key)
        {
            if (key == null) return "";
            if (key is bool) return (bool)key ? 1L : 0L;

            if (key is double)
            {
                double d = (double)key;
                return (long)d;
            }
            if (key is long) return key;

            string text = key.ToString();
            long parsed;
            if (long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) &&
                parsed.ToString(CultureInfo.InvariantCulture) == text) return parsed;

            return text;
        }

        public bool Has(object key)
        {
            return values.ContainsKey(NormalizeKey(key));
        }

        public object Get(object key)
        {
            object normalized = NormalizeKey(key);
            object value;
            return values.TryGetValue(normalized, out value) ? value : null;
        }

        public void Set(object key, object value)
        {
            object normalized = NormalizeKey(key);

            if (!values.ContainsKey(normalized)) keys.Add(normalized);
            values[normalized] = value;

            if (normalized is long)
            {
                long index = (long)normalized;
                if (index >= nextIndex) nextIndex = index + 1;
            }
        }

        public void Append(object value)
        {
            Set(nextIndex, value);
        }

        public void Remove(object key)
        {
            object normalized = NormalizeKey(key);
            if (!values.Remove(normalized)) return;

            keys.Remove(normalized);
        }

        public PhpArray Clone()
        {
            PhpArray copy = new PhpArray();
            foreach (object key in keys)
            {
                object value = values[key];
                PhpArray nested = value as PhpArray;
                copy.Set(key, nested != null ? nested.Clone() : value);
            }
            return copy;
        }

        public void Reindex()
        {
            List<object> oldKeys = new List<object>(keys);
            List<object> oldValues = new List<object>();
            foreach (object key in oldKeys) oldValues.Add(values[key]);

            keys.Clear();
            values.Clear();
            nextIndex = 0;

            foreach (object value in oldValues) Append(value);
        }

        public void SortKeys(Comparison<object> comparison)
        {
            keys.Sort(comparison);
        }

        public List<object> ValuesList()
        {
            List<object> list = new List<object>();
            foreach (object key in keys) list.Add(values[key]);
            return list;
        }
    }

    /// <summary>Преобразования между типами PHP.</summary>
    public static class PhpOps
    {
        public static string ToStr(object value)
        {
            if (value == null) return "";
            if (value is string) return (string)value;
            if (value is bool) return (bool)value ? "1" : "";
            if (value is long) return ((long)value).ToString(CultureInfo.InvariantCulture);

            if (value is double)
            {
                double d = (double)value;
                if (double.IsNaN(d)) return "NAN";
                if (double.IsInfinity(d)) return d > 0 ? "INF" : "-INF";
                if (d == Math.Floor(d) && Math.Abs(d) < 1e15)
                    return ((long)d).ToString(CultureInfo.InvariantCulture);

                return d.ToString("R", CultureInfo.InvariantCulture);
            }

            if (value is PhpArray) return "Array";
            return value.ToString();
        }

        public static double ToNum(object value)
        {
            if (value == null) return 0;
            if (value is double) return (double)value;
            if (value is long) return (long)value;
            if (value is bool) return (bool)value ? 1 : 0;

            if (value is string)
            {
                string text = ((string)value).Trim();
                int length = 0;

                while (length < text.Length)
                {
                    char c = text[length];
                    bool valid = char.IsDigit(c) || c == '.' ||
                                 ((c == '-' || c == '+') && length == 0) ||
                                 ((c == 'e' || c == 'E') && length > 0);
                    if (!valid) break;
                    length++;
                }

                double parsed;
                if (length > 0 && double.TryParse(text.Substring(0, length),
                    NumberStyles.Float, CultureInfo.InvariantCulture, out parsed)) return parsed;

                return 0;
            }

            if (value is PhpArray) return ((PhpArray)value).Count > 0 ? 1 : 0;
            return 0;
        }

        public static long ToInt(object value)
        {
            double number = ToNum(value);
            if (double.IsNaN(number) || double.IsInfinity(number)) return 0;
            return (long)number;
        }

        public static bool ToBool(object value)
        {
            if (value == null) return false;
            if (value is bool) return (bool)value;
            if (value is long) return (long)value != 0;
            if (value is double) return (double)value != 0;

            if (value is string)
            {
                string text = (string)value;
                return text.Length > 0 && text != "0";
            }

            if (value is PhpArray) return ((PhpArray)value).Count > 0;
            return true;
        }

        /// <summary>Число, если значение выглядит как число; иначе null.</summary>
        public static object ToNumberValue(object value)
        {
            double number = ToNum(value);
            if (number == Math.Floor(number) && Math.Abs(number) < 9.2e18) return (long)number;
            return number;
        }

        public static bool IsNumericString(string text)
        {
            if (string.IsNullOrEmpty(text)) return false;
            double unused;
            return double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out unused);
        }

        public static bool LooseEquals(object left, object right)
        {
            if (left == null && right == null) return true;
            if (left is bool || right is bool) return ToBool(left) == ToBool(right);

            if (left == null) return !ToBool(right) && !(right is string && ((string)right).Length > 0);
            if (right == null) return !ToBool(left) && !(left is string && ((string)left).Length > 0);

            if (left is string && right is string)
            {
                string a = (string)left, b = (string)right;
                if (IsNumericString(a) && IsNumericString(b)) return ToNum(a) == ToNum(b);
                return a == b;
            }

            if (left is PhpArray || right is PhpArray)
            {
                PhpArray la = left as PhpArray, ra = right as PhpArray;
                if (la == null || ra == null) return false;
                if (la.Count != ra.Count) return false;

                foreach (object key in la.Keys)
                {
                    if (!ra.Has(key)) return false;
                    if (!LooseEquals(la.Get(key), ra.Get(key))) return false;
                }
                return true;
            }

            return ToNum(left) == ToNum(right);
        }

        public static bool StrictEquals(object left, object right)
        {
            if (left == null || right == null) return left == null && right == null;
            if (left.GetType() != right.GetType())
            {
                bool leftNumber = left is long || left is double;
                bool rightNumber = right is long || right is double;
                if (!(leftNumber && rightNumber)) return false;
                if (left is long != right is long) return false;
            }

            if (left is string) return (string)left == (string)right;
            if (left is bool) return (bool)left == (bool)right;
            if (left is long) return (long)left == (long)right;
            if (left is double) return (double)left == (double)right;

            if (left is PhpArray)
            {
                PhpArray la = (PhpArray)left, ra = (PhpArray)right;
                if (la.Count != ra.Count) return false;

                for (int i = 0; i < la.Keys.Count; i++)
                {
                    object key = la.Keys[i];
                    if (!key.Equals(ra.Keys[i])) return false;
                    if (!StrictEquals(la.Get(key), ra.Get(key))) return false;
                }
                return true;
            }

            return left.Equals(right);
        }

        public static int Compare(object left, object right)
        {
            if (left is string && right is string)
            {
                string a = (string)left, b = (string)right;
                if (IsNumericString(a) && IsNumericString(b)) return ToNum(a).CompareTo(ToNum(b));
                return string.Compare(a, b, StringComparison.Ordinal);
            }

            return ToNum(left).CompareTo(ToNum(right));
        }

        public static object Add(object left, object right)
        {
            PhpArray la = left as PhpArray, ra = right as PhpArray;
            if (la != null && ra != null)
            {
                PhpArray result = la.Clone();
                foreach (object key in ra.Keys)
                {
                    if (!result.Has(key)) result.Set(key, ra.Get(key));
                }
                return result;
            }

            return Arith(ToNum(left) + ToNum(right), left, right);
        }

        public static object Arith(double value, object left, object right)
        {
            bool bothIntegers = IsIntegerLike(left) && IsIntegerLike(right);
            if (bothIntegers && value == Math.Floor(value) && Math.Abs(value) < 9.2e18) return (long)value;
            return value;
        }

        private static bool IsIntegerLike(object value)
        {
            if (value is long || value is bool || value == null) return true;
            if (value is double) return (double)value == Math.Floor((double)value);
            if (value is string) return !((string)value).Contains(".");
            return false;
        }
    }

    // =========================================================================
    //  Исключения управления
    // =========================================================================

    public class PhpExitException : Exception
    {
        public PhpExitException(string message) : base(message) { }
    }

    public class PhpErrorException : Exception
    {
        public int Line { get; private set; }

        public PhpErrorException(string message, int line) : base(message)
        {
            Line = line;
        }
    }

    internal class BreakSignal : Exception
    {
        public int Levels;
        public BreakSignal(int levels) { Levels = levels; }
    }

    internal class ContinueSignal : Exception
    {
        public int Levels;
        public ContinueSignal(int levels) { Levels = levels; }
    }

    internal class ReturnSignal : Exception
    {
        public object Value;
        public ReturnSignal(object value) { Value = value; }
    }
}

namespace LisunOS.Php
{
    // =========================================================================
    //  Лексер
    // =========================================================================

    public enum TokType
    {
        InlineHtml, OpenTag, OpenEcho, CloseTag,
        Variable, Ident, Number, String, InterpString,
        Op, End
    }

    public class Token
    {
        public TokType Type;
        public string Text;
        public object Value;
        public List<object> Parts;     // для строк с подстановкой
        public int Line;

        public override string ToString()
        {
            return Type + ":" + Text;
        }
    }

    public class Lexer
    {
        private readonly string src;
        private int pos;
        private int line = 1;
        private bool inPhp;

        private static readonly string[] Operators =
        {
            "<=>", "===", "!==", "**=", "...", "<<=", ">>=", "??=",
            "==", "!=", "<>", "<=", ">=", "&&", "||", "++", "--", "+=", "-=", "*=", "/=",
            ".=", "%=", "=>", "->", "::", "??", "<<", ">>", "**",
            "+", "-", "*", "/", "%", "=", "<", ">", "!", ".", ",", ";", "(", ")",
            "[", "]", "{", "}", "?", ":", "&", "|", "^", "~", "@", "$"
        };

        public Lexer(string source)
        {
            src = source ?? "";
        }

        public List<Token> Tokenize()
        {
            List<Token> tokens = new List<Token>();

            while (pos < src.Length)
            {
                if (!inPhp)
                {
                    ReadInlineHtml(tokens);
                    continue;
                }

                SkipWhitespaceAndComments();
                if (pos >= src.Length) break;

                if (Match("?>"))
                {
                    tokens.Add(Make(TokType.CloseTag, "?>"));
                    inPhp = false;

                    // Перевод строки сразу после ?> в PHP не выводится.
                    if (pos < src.Length && src[pos] == '\n') { pos++; line++; }
                    else if (pos + 1 < src.Length && src[pos] == '\r' && src[pos + 1] == '\n') { pos += 2; line++; }
                    continue;
                }

                char c = src[pos];

                if (c == '$' && pos + 1 < src.Length && (char.IsLetter(src[pos + 1]) || src[pos + 1] == '_'))
                {
                    tokens.Add(ReadVariable());
                    continue;
                }

                if (char.IsLetter(c) || c == '_' || c == '\\')
                {
                    tokens.Add(ReadIdentifier());
                    continue;
                }

                if (char.IsDigit(c) || (c == '.' && pos + 1 < src.Length && char.IsDigit(src[pos + 1])))
                {
                    tokens.Add(ReadNumber());
                    continue;
                }

                if (c == '\'') { tokens.Add(ReadSingleQuoted()); continue; }
                if (c == '"') { tokens.Add(ReadDoubleQuoted()); continue; }

                if (c == '<' && Peek("<<<")) { tokens.Add(ReadHeredoc()); continue; }

                Token op = ReadOperator();
                if (op == null) throw new PhpErrorException("неизвестный символ '" + c + "'", line);
                tokens.Add(op);
            }

            tokens.Add(Make(TokType.End, ""));
            return tokens;
        }

        private Token Make(TokType type, string text)
        {
            Token token = new Token();
            token.Type = type;
            token.Text = text;
            token.Line = line;
            return token;
        }

        private bool Peek(string text)
        {
            return string.CompareOrdinal(src, pos, text, 0, text.Length) == 0;
        }

        private bool Match(string text)
        {
            if (!Peek(text)) return false;
            pos += text.Length;
            return true;
        }

        private void ReadInlineHtml(List<Token> tokens)
        {
            int start = pos;

            while (pos < src.Length)
            {
                if (src[pos] == '<' && pos + 1 < src.Length && src[pos + 1] == '?') break;
                if (src[pos] == '\n') line++;
                pos++;
            }

            if (pos > start)
            {
                Token html = Make(TokType.InlineHtml, src.Substring(start, pos - start));
                html.Value = html.Text;
                tokens.Add(html);
            }

            if (pos >= src.Length) return;

            if (Match("<?php")) tokens.Add(Make(TokType.OpenTag, "<?php"));
            else if (Match("<?=")) tokens.Add(Make(TokType.OpenEcho, "<?="));
            else if (Match("<?")) tokens.Add(Make(TokType.OpenTag, "<?"));

            inPhp = true;
        }

        private void SkipWhitespaceAndComments()
        {
            while (pos < src.Length)
            {
                char c = src[pos];

                if (c == '\n') { line++; pos++; continue; }
                if (char.IsWhiteSpace(c)) { pos++; continue; }

                if (c == '/' && pos + 1 < src.Length && src[pos + 1] == '/')
                {
                    while (pos < src.Length && src[pos] != '\n' && !Peek("?>")) pos++;
                    continue;
                }

                if (c == '#')
                {
                    while (pos < src.Length && src[pos] != '\n' && !Peek("?>")) pos++;
                    continue;
                }

                if (c == '/' && pos + 1 < src.Length && src[pos + 1] == '*')
                {
                    pos += 2;
                    while (pos + 1 < src.Length && !(src[pos] == '*' && src[pos + 1] == '/'))
                    {
                        if (src[pos] == '\n') line++;
                        pos++;
                    }
                    pos += 2;
                    continue;
                }

                break;
            }
        }

        private Token ReadVariable()
        {
            pos++;   // $
            int start = pos;
            while (pos < src.Length && (char.IsLetterOrDigit(src[pos]) || src[pos] == '_')) pos++;

            return Make(TokType.Variable, src.Substring(start, pos - start));
        }

        private Token ReadIdentifier()
        {
            int start = pos;
            while (pos < src.Length && (char.IsLetterOrDigit(src[pos]) || src[pos] == '_' || src[pos] == '\\')) pos++;

            return Make(TokType.Ident, src.Substring(start, pos - start));
        }

        private Token ReadNumber()
        {
            int start = pos;
            bool isFloat = false;

            if (Peek("0x") || Peek("0X"))
            {
                pos += 2;
                while (pos < src.Length && Uri.IsHexDigit(src[pos])) pos++;

                Token hex = Make(TokType.Number, src.Substring(start, pos - start));
                hex.Value = Convert.ToInt64(hex.Text.Substring(2), 16);
                return hex;
            }

            while (pos < src.Length)
            {
                char c = src[pos];
                if (char.IsDigit(c) || c == '_') { pos++; continue; }
                if (c == '.' && !isFloat) { isFloat = true; pos++; continue; }
                if ((c == 'e' || c == 'E') && pos + 1 < src.Length &&
                    (char.IsDigit(src[pos + 1]) || src[pos + 1] == '-' || src[pos + 1] == '+'))
                {
                    isFloat = true; pos += 2; continue;
                }
                break;
            }

            string text = src.Substring(start, pos - start).Replace("_", "");
            Token token = Make(TokType.Number, text);

            if (isFloat) token.Value = double.Parse(text, CultureInfo.InvariantCulture);
            else
            {
                long parsed;
                if (long.TryParse(text, out parsed)) token.Value = parsed;
                else token.Value = double.Parse(text, CultureInfo.InvariantCulture);
            }
            return token;
        }

        private Token ReadSingleQuoted()
        {
            pos++;
            StringBuilder sb = new StringBuilder();

            while (pos < src.Length && src[pos] != '\'')
            {
                if (src[pos] == '\\' && pos + 1 < src.Length)
                {
                    char next = src[pos + 1];
                    if (next == '\'' || next == '\\') { sb.Append(next); pos += 2; continue; }
                }

                if (src[pos] == '\n') line++;
                sb.Append(src[pos]);
                pos++;
            }
            pos++;

            Token token = Make(TokType.String, sb.ToString());
            token.Value = token.Text;
            return token;
        }

        /// <summary>Двойные кавычки: собираем части — текст и выражения подстановки.</summary>
        private Token ReadDoubleQuoted()
        {
            pos++;
            List<object> parts = ParseInterpolated('"');
            pos++;

            return BuildStringToken(parts);
        }

        private Token ReadHeredoc()
        {
            pos += 3;
            bool nowdoc = false;

            while (pos < src.Length && (src[pos] == ' ' || src[pos] == '\t')) pos++;

            char quote = '\0';
            if (pos < src.Length && (src[pos] == '"' || src[pos] == '\'')) { quote = src[pos]; nowdoc = quote == '\''; pos++; }

            int startId = pos;
            while (pos < src.Length && (char.IsLetterOrDigit(src[pos]) || src[pos] == '_')) pos++;
            string label = src.Substring(startId, pos - startId);

            if (quote != '\0') pos++;
            while (pos < src.Length && src[pos] != '\n') pos++;
            pos++;
            line++;

            StringBuilder body = new StringBuilder();
            while (pos < src.Length)
            {
                int lineStart = pos;
                while (pos < src.Length && src[pos] != '\n') pos++;

                string current = src.Substring(lineStart, pos - lineStart);
                string trimmed = current.TrimStart(' ', '\t');

                if (trimmed == label || trimmed.StartsWith(label + ";"))
                {
                    pos = lineStart + current.IndexOf(label) + label.Length;
                    break;
                }

                body.Append(current).Append('\n');
                pos++;
                line++;
            }

            string text = body.ToString();
            if (text.EndsWith("\n")) text = text.Substring(0, text.Length - 1);

            if (nowdoc)
            {
                Token plain = Make(TokType.String, text);
                plain.Value = text;
                return plain;
            }

            Lexer inner = new Lexer("");
            List<object> parts = inner.ParseInterpolatedFrom(text);
            return BuildStringToken(parts);
        }

        private Token BuildStringToken(List<object> parts)
        {
            if (parts.Count == 0)
            {
                Token empty = Make(TokType.String, "");
                empty.Value = "";
                return empty;
            }

            if (parts.Count == 1 && parts[0] is string)
            {
                Token plain = Make(TokType.String, (string)parts[0]);
                plain.Value = plain.Text;
                return plain;
            }

            Token token = Make(TokType.InterpString, "");
            token.Parts = parts;
            return token;
        }

        private List<object> ParseInterpolatedFrom(string text)
        {
            Lexer lexer = new Lexer(text + "\0");
            lexer.inPhp = true;
            return lexer.ParseInterpolated('\0');
        }

        /// <summary>Разбор содержимого строки в кавычках: строки и вставки переменных.</summary>
        private List<object> ParseInterpolated(char terminator)
        {
            List<object> parts = new List<object>();
            StringBuilder text = new StringBuilder();

            while (pos < src.Length && src[pos] != terminator)
            {
                char c = src[pos];

                if (c == '\\' && pos + 1 < src.Length)
                {
                    char next = src[pos + 1];
                    pos += 2;

                    switch (next)
                    {
                        case 'n': text.Append('\n'); break;
                        case 'r': text.Append('\r'); break;
                        case 't': text.Append('\t'); break;
                        case 'v': text.Append('\v'); break;
                        case 'f': text.Append('\f'); break;
                        case 'e': text.Append('\u001b'); break;
                        case '0': text.Append('\0'); break;
                        case '\\': text.Append('\\'); break;
                        case '$': text.Append('$'); break;
                        case '"': text.Append('"'); break;
                        case 'u':
                            if (pos < src.Length && src[pos] == '{')
                            {
                                int close = src.IndexOf('}', pos);
                                if (close > 0)
                                {
                                    string hex = src.Substring(pos + 1, close - pos - 1);
                                    int code;
                                    if (int.TryParse(hex, NumberStyles.HexNumber,
                                        CultureInfo.InvariantCulture, out code))
                                        text.Append(char.ConvertFromUtf32(code));
                                    pos = close + 1;
                                }
                            }
                            else text.Append("\\u");
                            break;
                        default: text.Append('\\').Append(next); break;
                    }
                    continue;
                }

                // {$выражение}
                if (c == '{' && pos + 1 < src.Length && src[pos + 1] == '$')
                {
                    if (text.Length > 0) { parts.Add(text.ToString()); text.Length = 0; }

                    int depth = 1;
                    int start = ++pos;

                    while (pos < src.Length && depth > 0)
                    {
                        if (src[pos] == '{') depth++;
                        else if (src[pos] == '}') { depth--; if (depth == 0) break; }
                        pos++;
                    }

                    parts.Add(new InterpCode(src.Substring(start, pos - start)));
                    pos++;
                    continue;
                }

                // $имя, $имя[ключ]
                if (c == '$' && pos + 1 < src.Length && (char.IsLetter(src[pos + 1]) || src[pos + 1] == '_'))
                {
                    if (text.Length > 0) { parts.Add(text.ToString()); text.Length = 0; }

                    int start = pos;
                    pos++;
                    while (pos < src.Length && (char.IsLetterOrDigit(src[pos]) || src[pos] == '_')) pos++;

                    if (pos < src.Length && src[pos] == '[')
                    {
                        int depth = 1;
                        pos++;
                        while (pos < src.Length && depth > 0)
                        {
                            if (src[pos] == '[') depth++;
                            else if (src[pos] == ']') depth--;
                            pos++;
                        }

                        string expression = src.Substring(start, pos - start);

                        // Внутри строк ключ без кавычек считается строкой.
                        int bracket = expression.IndexOf('[');
                        string name = expression.Substring(0, bracket);
                        string key = expression.Substring(bracket + 1, expression.Length - bracket - 2).Trim();

                        if (key.Length > 0 && key[0] != '$' && key[0] != '\'' && key[0] != '"' &&
                            !char.IsDigit(key[0])) key = "'" + key + "'";

                        parts.Add(new InterpCode(name + "[" + key + "]"));
                        continue;
                    }

                    parts.Add(new InterpCode(src.Substring(start, pos - start)));
                    continue;
                }

                if (c == '\n') line++;
                text.Append(c);
                pos++;
            }

            if (text.Length > 0) parts.Add(text.ToString());
            return parts;
        }

        private Token ReadOperator()
        {
            foreach (string op in Operators)
            {
                if (!Peek(op)) continue;

                pos += op.Length;
                return Make(TokType.Op, op);
            }
            return null;
        }
    }

    /// <summary>Фрагмент кода внутри строки с подстановкой.</summary>
    public class InterpCode
    {
        public string Code;
        public object Compiled;

        public InterpCode(string code)
        {
            Code = code;
        }
    }
}

namespace LisunOS.Php
{
    // =========================================================================
    //  Узлы дерева
    // =========================================================================

    public abstract class Node
    {
        public int Line;
    }

    public abstract class Expr : Node
    {
        public abstract object Eval(Interp interp, Scope scope);

        /// <summary>Присваивание: по умолчанию выражение не является адресуемым.</summary>
        public virtual void Assign(Interp interp, Scope scope, object value)
        {
            throw new PhpErrorException("нельзя присвоить значение этому выражению", Line);
        }
    }

    public abstract class Stmt : Node
    {
        public abstract void Exec(Interp interp, Scope scope);
    }

    // ---------- выражения ----------

    public class LiteralExpr : Expr
    {
        public object Value;
        public override object Eval(Interp interp, Scope scope) { return Value; }
    }

    public class InterpExpr : Expr
    {
        public List<object> Parts;

        public override object Eval(Interp interp, Scope scope)
        {
            StringBuilder sb = new StringBuilder();

            foreach (object part in Parts)
            {
                if (part is string) { sb.Append((string)part); continue; }

                InterpCode code = (InterpCode)part;
                if (code.Compiled == null) code.Compiled = Parser.ParseExpression(code.Code);

                sb.Append(PhpOps.ToStr(((Expr)code.Compiled).Eval(interp, scope)));
            }

            return sb.ToString();
        }
    }

    public class VarExpr : Expr
    {
        public string Name;

        public override object Eval(Interp interp, Scope scope)
        {
            return scope.Get(Name);
        }

        public override void Assign(Interp interp, Scope scope, object value)
        {
            scope.Set(Name, value);
        }
    }

    public class ConstExpr : Expr
    {
        public string Name;

        public override object Eval(Interp interp, Scope scope)
        {
            return interp.GetConstant(Name, Line);
        }
    }

    public class ArrayExpr : Expr
    {
        public List<Expr> Keys = new List<Expr>();
        public List<Expr> Values = new List<Expr>();

        public override object Eval(Interp interp, Scope scope)
        {
            PhpArray array = new PhpArray();

            for (int i = 0; i < Values.Count; i++)
            {
                object value = Values[i].Eval(interp, scope);
                PhpArray nested = value as PhpArray;
                if (nested != null) value = nested.Clone();

                if (Keys[i] == null) array.Append(value);
                else array.Set(Keys[i].Eval(interp, scope), value);
            }

            return array;
        }
    }

    public class IndexExpr : Expr
    {
        public Expr Target;
        public Expr Key;          // null — добавление в конец

        public override object Eval(Interp interp, Scope scope)
        {
            object target = Target.Eval(interp, scope);

            if (target is PhpArray)
            {
                if (Key == null) return null;
                return ((PhpArray)target).Get(Key.Eval(interp, scope));
            }

            if (target is string)
            {
                string text = (string)target;
                long index = PhpOps.ToInt(Key.Eval(interp, scope));
                if (index < 0) index += text.Length;

                return index >= 0 && index < text.Length ? text[(int)index].ToString() : "";
            }

            return null;
        }

        public override void Assign(Interp interp, Scope scope, object value)
        {
            PhpArray array = ResolveContainer(interp, scope);

            if (Key == null) array.Append(value);
            else array.Set(Key.Eval(interp, scope), value);
        }

        /// <summary>Создаёт вложенные массивы по пути, как это делает PHP.</summary>
        public PhpArray ResolveContainer(Interp interp, Scope scope)
        {
            object current = Target.Eval(interp, scope);

            if (!(current is PhpArray))
            {
                current = new PhpArray();
                Target.Assign(interp, scope, current);
            }

            return (PhpArray)current;
        }
    }

    public class AssignExpr : Expr
    {
        public Expr Target;
        public Expr Value;
        public string Op;          // "", "+=", ".=", ...

        public override object Eval(Interp interp, Scope scope)
        {
            object value = Value.Eval(interp, scope);

            if (Op.Length > 0)
            {
                object current = Target.Eval(interp, scope);
                value = BinaryExpr.Apply(Op.Substring(0, Op.Length - 1), current, value, Line);
            }

            PhpArray array = value as PhpArray;
            if (array != null) value = array.Clone();

            Target.Assign(interp, scope, value);
            return value;
        }
    }

    public class IncDecExpr : Expr
    {
        public Expr Target;
        public bool Increment;
        public bool Prefix;

        public override object Eval(Interp interp, Scope scope)
        {
            object current = Target.Eval(interp, scope);
            object updated = PhpOps.Arith(PhpOps.ToNum(current) + (Increment ? 1 : -1), current, 1L);

            Target.Assign(interp, scope, updated);
            return Prefix ? updated : (current ?? (Increment ? (object)0L : null));
        }
    }

    public class UnaryExpr : Expr
    {
        public string Op;
        public Expr Operand;

        public override object Eval(Interp interp, Scope scope)
        {
            if (Op == "@")
            {
                try { return Operand.Eval(interp, scope); }
                catch (PhpExitException) { throw; }
                catch (BreakSignal) { throw; }
                catch (ContinueSignal) { throw; }
                catch (ReturnSignal) { throw; }
                catch { return null; }
            }

            object value = Operand.Eval(interp, scope);

            switch (Op)
            {
                case "-": return PhpOps.Arith(-PhpOps.ToNum(value), value, 1L);
                case "+": return PhpOps.ToNumberValue(value);
                case "!": return !PhpOps.ToBool(value);
                case "~": return ~PhpOps.ToInt(value);
                default: throw new PhpErrorException("неизвестная операция " + Op, Line);
            }
        }
    }

    public class CastExpr : Expr
    {
        public string Type;
        public Expr Operand;

        public override object Eval(Interp interp, Scope scope)
        {
            object value = Operand.Eval(interp, scope);

            switch (Type)
            {
                case "int":
                case "integer": return PhpOps.ToInt(value);
                case "float":
                case "double": return PhpOps.ToNum(value);
                case "string": return PhpOps.ToStr(value);
                case "bool":
                case "boolean": return PhpOps.ToBool(value);
                case "array":
                    {
                        if (value is PhpArray) return value;

                        PhpArray array = new PhpArray();
                        if (value != null) array.Append(value);
                        return array;
                    }
                default: return value;
            }
        }
    }

    public class BinaryExpr : Expr
    {
        public string Op;
        public Expr Left;
        public Expr Right;

        public override object Eval(Interp interp, Scope scope)
        {
            // Короткое замыкание
            if (Op == "&&" || Op == "and")
                return PhpOps.ToBool(Left.Eval(interp, scope)) && PhpOps.ToBool(Right.Eval(interp, scope));

            if (Op == "||" || Op == "or")
                return PhpOps.ToBool(Left.Eval(interp, scope)) || PhpOps.ToBool(Right.Eval(interp, scope));

            if (Op == "??")
            {
                object left = EvalQuiet(Left, interp, scope);
                return left != null ? left : Right.Eval(interp, scope);
            }

            return Apply(Op, Left.Eval(interp, scope), Right.Eval(interp, scope), Line);
        }

        private static object EvalQuiet(Expr expr, Interp interp, Scope scope)
        {
            try { return expr.Eval(interp, scope); }
            catch (PhpExitException) { throw; }
            catch { return null; }
        }

        public static object Apply(string op, object left, object right, int line)
        {
            switch (op)
            {
                case "+": return PhpOps.Add(left, right);
                case "-": return PhpOps.Arith(PhpOps.ToNum(left) - PhpOps.ToNum(right), left, right);
                case "*": return PhpOps.Arith(PhpOps.ToNum(left) * PhpOps.ToNum(right), left, right);
                case "/":
                    {
                        double divisor = PhpOps.ToNum(right);
                        if (divisor == 0) throw new PhpErrorException("деление на ноль", line);

                        double result = PhpOps.ToNum(left) / divisor;
                        return result == Math.Floor(result) ? PhpOps.Arith(result, left, right) : result;
                    }
                case "%":
                    {
                        long divisor = PhpOps.ToInt(right);
                        if (divisor == 0) throw new PhpErrorException("деление по модулю на ноль", line);
                        return PhpOps.ToInt(left) % divisor;
                    }
                case "**": return PhpOps.Arith(Math.Pow(PhpOps.ToNum(left), PhpOps.ToNum(right)), left, right);
                case ".": return PhpOps.ToStr(left) + PhpOps.ToStr(right);

                case "==": return PhpOps.LooseEquals(left, right);
                case "!=":
                case "<>": return !PhpOps.LooseEquals(left, right);
                case "===": return PhpOps.StrictEquals(left, right);
                case "!==": return !PhpOps.StrictEquals(left, right);

                case "<": return PhpOps.Compare(left, right) < 0;
                case ">": return PhpOps.Compare(left, right) > 0;
                case "<=": return PhpOps.Compare(left, right) <= 0;
                case ">=": return PhpOps.Compare(left, right) >= 0;
                case "<=>": return (long)PhpOps.Compare(left, right);

                case "&": return PhpOps.ToInt(left) & PhpOps.ToInt(right);
                case "|": return PhpOps.ToInt(left) | PhpOps.ToInt(right);
                case "^": return PhpOps.ToInt(left) ^ PhpOps.ToInt(right);
                case "<<": return PhpOps.ToInt(left) << (int)PhpOps.ToInt(right);
                case ">>": return PhpOps.ToInt(left) >> (int)PhpOps.ToInt(right);

                default: throw new PhpErrorException("неизвестная операция " + op, line);
            }
        }
    }

    public class TernaryExpr : Expr
    {
        public Expr Condition;
        public Expr IfTrue;        // null — короткая форма ?:
        public Expr IfFalse;

        public override object Eval(Interp interp, Scope scope)
        {
            object condition = Condition.Eval(interp, scope);

            if (PhpOps.ToBool(condition)) return IfTrue == null ? condition : IfTrue.Eval(interp, scope);
            return IfFalse.Eval(interp, scope);
        }
    }

    public class CallExpr : Expr
    {
        public string Name;
        public List<Expr> Args = new List<Expr>();

        public override object Eval(Interp interp, Scope scope)
        {
            return interp.CallFunction(Name, Args, scope, Line);
        }
    }

    public class IssetExpr : Expr
    {
        public List<Expr> Targets = new List<Expr>();

        public override object Eval(Interp interp, Scope scope)
        {
            foreach (Expr target in Targets)
            {
                object value;
                try { value = target.Eval(interp, scope); }
                catch { value = null; }

                if (value == null) return false;
            }
            return true;
        }
    }

    public class EmptyExpr : Expr
    {
        public Expr Target;

        public override object Eval(Interp interp, Scope scope)
        {
            object value;
            try { value = Target.Eval(interp, scope); }
            catch { value = null; }

            return !PhpOps.ToBool(value);
        }
    }

    public class ExitExpr : Expr
    {
        public Expr Message;

        public override object Eval(Interp interp, Scope scope)
        {
            string text = Message == null ? "" : PhpOps.ToStr(Message.Eval(interp, scope));
            if (text.Length > 0) interp.Output(text);

            throw new PhpExitException(text);
        }
    }
}

namespace LisunOS.Php
{
    // ---------- инструкции ----------

    public class BlockStmt : Stmt
    {
        public List<Stmt> Body = new List<Stmt>();

        public override void Exec(Interp interp, Scope scope)
        {
            foreach (Stmt statement in Body) statement.Exec(interp, scope);
        }
    }

    public class InlineHtmlStmt : Stmt
    {
        public string Text;

        public override void Exec(Interp interp, Scope scope)
        {
            interp.Output(Text);
        }
    }

    public class EchoStmt : Stmt
    {
        public List<Expr> Values = new List<Expr>();

        public override void Exec(Interp interp, Scope scope)
        {
            foreach (Expr value in Values) interp.Output(PhpOps.ToStr(value.Eval(interp, scope)));
        }
    }

    public class ExprStmt : Stmt
    {
        public Expr Value;

        public override void Exec(Interp interp, Scope scope)
        {
            Value.Eval(interp, scope);
        }
    }

    public class IfStmt : Stmt
    {
        public Expr Condition;
        public Stmt Then;
        public Stmt Else;

        public override void Exec(Interp interp, Scope scope)
        {
            if (PhpOps.ToBool(Condition.Eval(interp, scope))) Then.Exec(interp, scope);
            else if (Else != null) Else.Exec(interp, scope);
        }
    }

    public class WhileStmt : Stmt
    {
        public Expr Condition;
        public Stmt Body;

        public override void Exec(Interp interp, Scope scope)
        {
            int guard = 0;

            while (PhpOps.ToBool(Condition.Eval(interp, scope)))
            {
                if (++guard > Interp.LoopLimit) throw new PhpErrorException("слишком долгий цикл while", Line);

                try { Body.Exec(interp, scope); }
                catch (BreakSignal signal) { if (--signal.Levels > 0) throw; break; }
                catch (ContinueSignal signal) { if (--signal.Levels > 0) throw; }
            }
        }
    }

    public class DoWhileStmt : Stmt
    {
        public Expr Condition;
        public Stmt Body;

        public override void Exec(Interp interp, Scope scope)
        {
            int guard = 0;

            do
            {
                if (++guard > Interp.LoopLimit) throw new PhpErrorException("слишком долгий цикл do-while", Line);

                try { Body.Exec(interp, scope); }
                catch (BreakSignal signal) { if (--signal.Levels > 0) throw; break; }
                catch (ContinueSignal signal) { if (--signal.Levels > 0) throw; }
            }
            while (PhpOps.ToBool(Condition.Eval(interp, scope)));
        }
    }

    public class ForStmt : Stmt
    {
        public List<Expr> Init = new List<Expr>();
        public List<Expr> Condition = new List<Expr>();
        public List<Expr> Step = new List<Expr>();
        public Stmt Body;

        public override void Exec(Interp interp, Scope scope)
        {
            foreach (Expr expr in Init) expr.Eval(interp, scope);

            int guard = 0;
            while (true)
            {
                bool proceed = true;
                foreach (Expr expr in Condition) proceed = PhpOps.ToBool(expr.Eval(interp, scope));
                if (!proceed) break;

                if (++guard > Interp.LoopLimit) throw new PhpErrorException("слишком долгий цикл for", Line);

                try { Body.Exec(interp, scope); }
                catch (BreakSignal signal) { if (--signal.Levels > 0) throw; break; }
                catch (ContinueSignal signal) { if (--signal.Levels > 0) throw; }

                foreach (Expr expr in Step) expr.Eval(interp, scope);
            }
        }
    }

    public class ForeachStmt : Stmt
    {
        public Expr Source;
        public Expr KeyTarget;
        public Expr ValueTarget;
        public Stmt Body;

        public override void Exec(Interp interp, Scope scope)
        {
            object source = Source.Eval(interp, scope);

            PhpArray array = source as PhpArray;
            if (array == null) return;

            // Копия ключей: изменение массива внутри цикла не ломает обход.
            List<object> keys = new List<object>(array.Keys);

            foreach (object key in keys)
            {
                if (!array.Has(key)) continue;

                if (KeyTarget != null) KeyTarget.Assign(interp, scope, key);
                ValueTarget.Assign(interp, scope, array.Get(key));

                try { Body.Exec(interp, scope); }
                catch (BreakSignal signal) { if (--signal.Levels > 0) throw; break; }
                catch (ContinueSignal signal) { if (--signal.Levels > 0) throw; }
            }
        }
    }

    public class SwitchStmt : Stmt
    {
        public Expr Subject;
        public List<Expr> Cases = new List<Expr>();        // null — default
        public List<List<Stmt>> Bodies = new List<List<Stmt>>();

        public override void Exec(Interp interp, Scope scope)
        {
            object subject = Subject.Eval(interp, scope);
            int start = -1;

            for (int i = 0; i < Cases.Count; i++)
            {
                if (Cases[i] == null) continue;
                if (!PhpOps.LooseEquals(subject, Cases[i].Eval(interp, scope))) continue;

                start = i;
                break;
            }

            if (start < 0) start = Cases.IndexOf(null);
            if (start < 0) return;

            try
            {
                for (int i = start; i < Bodies.Count; i++)
                {
                    foreach (Stmt statement in Bodies[i]) statement.Exec(interp, scope);
                }
            }
            catch (BreakSignal signal) { if (--signal.Levels > 0) throw; }
        }
    }

    public class BreakStmt : Stmt
    {
        public int Levels = 1;
        public override void Exec(Interp interp, Scope scope) { throw new BreakSignal(Levels); }
    }

    public class ContinueStmt : Stmt
    {
        public int Levels = 1;
        public override void Exec(Interp interp, Scope scope) { throw new ContinueSignal(Levels); }
    }

    public class ReturnStmt : Stmt
    {
        public Expr Value;

        public override void Exec(Interp interp, Scope scope)
        {
            throw new ReturnSignal(Value == null ? null : Value.Eval(interp, scope));
        }
    }

    public class GlobalStmt : Stmt
    {
        public List<string> Names = new List<string>();

        public override void Exec(Interp interp, Scope scope)
        {
            foreach (string name in Names) scope.MarkGlobal(name);
        }
    }

    public class UnsetStmt : Stmt
    {
        public List<Expr> Targets = new List<Expr>();

        public override void Exec(Interp interp, Scope scope)
        {
            foreach (Expr target in Targets)
            {
                VarExpr variable = target as VarExpr;
                if (variable != null) { scope.Unset(variable.Name); continue; }

                IndexExpr index = target as IndexExpr;
                if (index == null || index.Key == null) continue;

                object container = index.Target.Eval(interp, scope);
                PhpArray array = container as PhpArray;
                if (array != null) array.Remove(index.Key.Eval(interp, scope));
            }
        }
    }

    public class FunctionStmt : Stmt
    {
        public PhpFunction Function;

        public override void Exec(Interp interp, Scope scope)
        {
            interp.DeclareFunction(Function);
        }
    }

    public class IncludeStmt : Stmt
    {
        public Expr Path;
        public bool Once;
        public bool Required;

        public override void Exec(Interp interp, Scope scope)
        {
            interp.IncludeFile(PhpOps.ToStr(Path.Eval(interp, scope)), Once, Required, scope, Line);
        }
    }

    /// <summary>Пользовательская функция.</summary>
    public class PhpFunction
    {
        public string Name;
        public List<string> Parameters = new List<string>();
        public List<Expr> Defaults = new List<Expr>();
        public BlockStmt Body;
    }

    // =========================================================================
    //  Область видимости
    // =========================================================================

    public class Scope
    {
        private readonly Dictionary<string, object> locals =
            new Dictionary<string, object>(StringComparer.Ordinal);

        private readonly HashSet<string> globals = new HashSet<string>(StringComparer.Ordinal);
        private readonly Scope globalScope;

        public bool IsGlobal { get { return globalScope == null; } }

        public Scope() { }

        public Scope(Scope globals)
        {
            globalScope = globals;
        }

        private static readonly HashSet<string> Superglobals = new HashSet<string>(StringComparer.Ordinal)
        {
            "GLOBALS", "_GET", "_POST", "_REQUEST", "_SERVER", "_SESSION", "_COOKIE", "_FILES", "_ENV"
        };

        private bool UseGlobal(string name)
        {
            if (globalScope == null) return false;
            return globals.Contains(name) || Superglobals.Contains(name);
        }

        public object Get(string name)
        {
            if (UseGlobal(name)) return globalScope.Get(name);

            object value;
            return locals.TryGetValue(name, out value) ? value : null;
        }

        public void Set(string name, object value)
        {
            if (UseGlobal(name)) { globalScope.Set(name, value); return; }
            locals[name] = value;
        }

        public bool Has(string name)
        {
            if (UseGlobal(name)) return globalScope.Has(name);
            return locals.ContainsKey(name);
        }

        public void Unset(string name)
        {
            if (UseGlobal(name)) { globalScope.Unset(name); return; }
            locals.Remove(name);
        }

        public void MarkGlobal(string name)
        {
            globals.Add(name);
        }

        public IEnumerable<string> Names { get { return locals.Keys; } }
    }
}

namespace LisunOS.Php
{
    // =========================================================================
    //  Парсер
    // =========================================================================

    public class Parser
    {
        private readonly List<Token> tokens;
        private int pos;

        private static readonly HashSet<string> CastTypes = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "int", "integer", "float", "double", "string", "bool", "boolean", "array", "object"
        };

        public Parser(List<Token> tokens)
        {
            this.tokens = tokens;
        }

        public static BlockStmt ParseSource(string source)
        {
            Parser parser = new Parser(new Lexer(source).Tokenize());
            return parser.ParseProgram();
        }

        public static Expr ParseExpression(string code)
        {
            Parser parser = new Parser(new Lexer("<?php " + code + ";").Tokenize());
            parser.Expect(TokType.OpenTag);
            return parser.ParseExpr();
        }

        // ---------- вспомогательное ----------

        private Token Current { get { return tokens[pos]; } }
        private Token Ahead(int offset)
        {
            int index = pos + offset;
            return index < tokens.Count ? tokens[index] : tokens[tokens.Count - 1];
        }

        private bool IsOp(string text)
        {
            return Current.Type == TokType.Op && Current.Text == text;
        }

        private bool IsKeyword(string word)
        {
            return Current.Type == TokType.Ident &&
                   string.Equals(Current.Text, word, StringComparison.OrdinalIgnoreCase);
        }

        private bool TakeOp(string text)
        {
            if (!IsOp(text)) return false;
            pos++;
            return true;
        }

        private bool TakeKeyword(string word)
        {
            if (!IsKeyword(word)) return false;
            pos++;
            return true;
        }

        private Token Expect(TokType type)
        {
            if (Current.Type != type)
                throw new PhpErrorException("ожидалось " + type + ", получено '" + Current.Text + "'", Current.Line);

            return tokens[pos++];
        }

        private void ExpectOp(string text)
        {
            if (!TakeOp(text))
                throw new PhpErrorException("ожидался '" + text + "', получено '" + Current.Text + "'", Current.Line);
        }

        private T At<T>(T node) where T : Node
        {
            node.Line = Current.Line;
            return node;
        }

        // ---------- программа ----------

        public BlockStmt ParseProgram()
        {
            BlockStmt program = new BlockStmt();

            while (Current.Type != TokType.End)
            {
                if (Current.Type == TokType.InlineHtml)
                {
                    InlineHtmlStmt html = At(new InlineHtmlStmt());
                    html.Text = Current.Text;
                    pos++;
                    program.Body.Add(html);
                    continue;
                }

                if (Current.Type == TokType.OpenTag) { pos++; continue; }
                if (Current.Type == TokType.CloseTag) { pos++; continue; }

                if (Current.Type == TokType.OpenEcho)
                {
                    pos++;
                    EchoStmt echo = At(new EchoStmt());
                    echo.Values.Add(ParseExpr());
                    TakeOp(";");
                    program.Body.Add(echo);
                    continue;
                }

                program.Body.Add(ParseStatement());
            }

            return program;
        }

        private BlockStmt ParseBlockUntil(params string[] terminators)
        {
            BlockStmt block = new BlockStmt();

            while (Current.Type != TokType.End)
            {
                if (Current.Type == TokType.Ident)
                {
                    bool stop = false;
                    foreach (string word in terminators)
                    {
                        if (string.Equals(Current.Text, word, StringComparison.OrdinalIgnoreCase)) { stop = true; break; }
                    }
                    if (stop) break;
                }

                if (Current.Type == TokType.InlineHtml)
                {
                    InlineHtmlStmt html = At(new InlineHtmlStmt());
                    html.Text = Current.Text;
                    pos++;
                    block.Body.Add(html);
                    continue;
                }

                if (Current.Type == TokType.OpenTag || Current.Type == TokType.CloseTag) { pos++; continue; }

                if (Current.Type == TokType.OpenEcho)
                {
                    pos++;
                    EchoStmt echo = At(new EchoStmt());
                    echo.Values.Add(ParseExpr());
                    TakeOp(";");
                    block.Body.Add(echo);
                    continue;
                }

                block.Body.Add(ParseStatement());
            }

            return block;
        }

        // ---------- инструкции ----------

        private Stmt ParseStatement()
        {
            if (IsOp("{"))
            {
                pos++;
                BlockStmt block = new BlockStmt();

                while (!IsOp("}") && Current.Type != TokType.End)
                {
                    if (Current.Type == TokType.InlineHtml)
                    {
                        InlineHtmlStmt html = At(new InlineHtmlStmt());
                        html.Text = Current.Text;
                        pos++;
                        block.Body.Add(html);
                        continue;
                    }

                    if (Current.Type == TokType.OpenTag || Current.Type == TokType.CloseTag) { pos++; continue; }
                    block.Body.Add(ParseStatement());
                }

                ExpectOp("}");
                return block;
            }

            if (TakeOp(";")) return new BlockStmt();

            if (Current.Type == TokType.Ident)
            {
                string word = Current.Text.ToLowerInvariant();

                switch (word)
                {
                    case "echo": return ParseEcho();
                    case "print": return ParseEcho();
                    case "if": return ParseIf();
                    case "while": return ParseWhile();
                    case "do": return ParseDoWhile();
                    case "for": return ParseFor();
                    case "foreach": return ParseForeach();
                    case "switch": return ParseSwitch();
                    case "break": return ParseBreakContinue(true);
                    case "continue": return ParseBreakContinue(false);
                    case "return": return ParseReturn();
                    case "function":
                        if (Ahead(1).Type == TokType.Ident) return ParseFunction();
                        break;
                    case "global": return ParseGlobal();
                    case "unset": return ParseUnset();
                    case "include":
                    case "include_once":
                    case "require":
                    case "require_once":
                        return ParseInclude(word);
                    case "declare":
                        {
                            pos++;
                            if (TakeOp("(")) { while (!IsOp(")") && Current.Type != TokType.End) pos++; ExpectOp(")"); }
                            TakeOp(";");
                            return new BlockStmt();
                        }
                }
            }

            ExprStmt statement = At(new ExprStmt());
            statement.Value = ParseExpr();
            TakeOp(";");
            return statement;
        }

        private Stmt ParseEcho()
        {
            EchoStmt echo = At(new EchoStmt());
            pos++;

            bool parens = IsOp("(");
            if (parens) pos++;

            echo.Values.Add(ParseExpr());
            while (TakeOp(",")) echo.Values.Add(ParseExpr());

            if (parens) TakeOp(")");
            TakeOp(";");
            return echo;
        }

        private Stmt ParseIf()
        {
            IfStmt node = At(new IfStmt());
            pos++;

            ExpectOp("(");
            node.Condition = ParseExpr();
            ExpectOp(")");

            // Альтернативный синтаксис: if (...): ... endif;
            if (TakeOp(":"))
            {
                node.Then = ParseBlockUntil("elseif", "else", "endif");

                if (IsKeyword("elseif")) { node.Else = ParseIfAlternative(); return node; }

                if (TakeKeyword("else"))
                {
                    TakeOp(":");
                    node.Else = ParseBlockUntil("endif");
                }

                TakeKeyword("endif");
                TakeOp(";");
                return node;
            }

            node.Then = ParseStatement();

            if (IsKeyword("elseif"))
            {
                node.Else = ParseIf();
                return node;
            }

            if (TakeKeyword("else"))
            {
                node.Else = IsKeyword("if") ? ParseIf() : ParseStatement();
            }

            return node;
        }

        /// <summary>elseif в альтернативном синтаксисе.</summary>
        private Stmt ParseIfAlternative()
        {
            IfStmt node = At(new IfStmt());
            pos++;   // elseif

            ExpectOp("(");
            node.Condition = ParseExpr();
            ExpectOp(")");
            TakeOp(":");

            node.Then = ParseBlockUntil("elseif", "else", "endif");

            if (IsKeyword("elseif")) { node.Else = ParseIfAlternative(); return node; }

            if (TakeKeyword("else"))
            {
                TakeOp(":");
                node.Else = ParseBlockUntil("endif");
            }

            TakeKeyword("endif");
            TakeOp(";");
            return node;
        }

        private Stmt ParseWhile()
        {
            WhileStmt node = At(new WhileStmt());
            pos++;

            ExpectOp("(");
            node.Condition = ParseExpr();
            ExpectOp(")");

            if (TakeOp(":"))
            {
                node.Body = ParseBlockUntil("endwhile");
                TakeKeyword("endwhile");
                TakeOp(";");
                return node;
            }

            node.Body = ParseStatement();
            return node;
        }

        private Stmt ParseDoWhile()
        {
            DoWhileStmt node = At(new DoWhileStmt());
            pos++;

            node.Body = ParseStatement();

            if (!TakeKeyword("while"))
                throw new PhpErrorException("ожидалось while после do", Current.Line);

            ExpectOp("(");
            node.Condition = ParseExpr();
            ExpectOp(")");
            TakeOp(";");
            return node;
        }

        private Stmt ParseFor()
        {
            ForStmt node = At(new ForStmt());
            pos++;

            ExpectOp("(");
            if (!IsOp(";")) { node.Init.Add(ParseExpr()); while (TakeOp(",")) node.Init.Add(ParseExpr()); }
            ExpectOp(";");

            if (!IsOp(";")) { node.Condition.Add(ParseExpr()); while (TakeOp(",")) node.Condition.Add(ParseExpr()); }
            ExpectOp(";");

            if (!IsOp(")")) { node.Step.Add(ParseExpr()); while (TakeOp(",")) node.Step.Add(ParseExpr()); }
            ExpectOp(")");

            if (TakeOp(":"))
            {
                node.Body = ParseBlockUntil("endfor");
                TakeKeyword("endfor");
                TakeOp(";");
                return node;
            }

            node.Body = ParseStatement();
            return node;
        }

        private Stmt ParseForeach()
        {
            ForeachStmt node = At(new ForeachStmt());
            pos++;

            ExpectOp("(");
            node.Source = ParseExpr();

            if (!TakeKeyword("as"))
                throw new PhpErrorException("ожидалось as в foreach", Current.Line);

            TakeOp("&");
            Expr first = ParseExpr();

            if (TakeOp("=>"))
            {
                node.KeyTarget = first;
                TakeOp("&");
                node.ValueTarget = ParseExpr();
            }
            else node.ValueTarget = first;

            ExpectOp(")");

            if (TakeOp(":"))
            {
                node.Body = ParseBlockUntil("endforeach");
                TakeKeyword("endforeach");
                TakeOp(";");
                return node;
            }

            node.Body = ParseStatement();
            return node;
        }

        private Stmt ParseSwitch()
        {
            SwitchStmt node = At(new SwitchStmt());
            pos++;

            ExpectOp("(");
            node.Subject = ParseExpr();
            ExpectOp(")");

            bool alternative = false;
            if (TakeOp(":")) alternative = true;
            else ExpectOp("{");

            while (Current.Type != TokType.End)
            {
                if (!alternative && IsOp("}")) break;
                if (alternative && IsKeyword("endswitch")) break;

                if (Current.Type == TokType.OpenTag || Current.Type == TokType.CloseTag) { pos++; continue; }

                if (TakeKeyword("case"))
                {
                    node.Cases.Add(ParseExpr());
                    if (!TakeOp(":")) TakeOp(";");
                    node.Bodies.Add(ParseCaseBody(alternative));
                    continue;
                }

                if (TakeKeyword("default"))
                {
                    node.Cases.Add(null);
                    if (!TakeOp(":")) TakeOp(";");
                    node.Bodies.Add(ParseCaseBody(alternative));
                    continue;
                }

                pos++;
            }

            if (alternative) { TakeKeyword("endswitch"); TakeOp(";"); }
            else ExpectOp("}");

            return node;
        }

        private List<Stmt> ParseCaseBody(bool alternative)
        {
            List<Stmt> body = new List<Stmt>();

            while (Current.Type != TokType.End)
            {
                if (IsKeyword("case") || IsKeyword("default")) break;
                if (!alternative && IsOp("}")) break;
                if (alternative && IsKeyword("endswitch")) break;

                if (Current.Type == TokType.InlineHtml)
                {
                    InlineHtmlStmt html = At(new InlineHtmlStmt());
                    html.Text = Current.Text;
                    pos++;
                    body.Add(html);
                    continue;
                }

                if (Current.Type == TokType.OpenTag || Current.Type == TokType.CloseTag) { pos++; continue; }
                body.Add(ParseStatement());
            }

            return body;
        }

        private Stmt ParseBreakContinue(bool isBreak)
        {
            int line = Current.Line;
            pos++;

            int levels = 1;
            if (Current.Type == TokType.Number) { levels = (int)PhpOps.ToInt(Current.Value); pos++; }
            TakeOp(";");

            if (isBreak)
            {
                BreakStmt node = new BreakStmt();
                node.Levels = Math.Max(1, levels);
                node.Line = line;
                return node;
            }

            ContinueStmt cont = new ContinueStmt();
            cont.Levels = Math.Max(1, levels);
            cont.Line = line;
            return cont;
        }

        private Stmt ParseReturn()
        {
            ReturnStmt node = At(new ReturnStmt());
            pos++;

            if (!IsOp(";") && Current.Type != TokType.CloseTag && Current.Type != TokType.End)
                node.Value = ParseExpr();

            TakeOp(";");
            return node;
        }

        private Stmt ParseFunction()
        {
            FunctionStmt node = At(new FunctionStmt());
            pos++;   // function

            PhpFunction function = new PhpFunction();
            function.Name = Expect(TokType.Ident).Text;

            ExpectOp("(");
            while (!IsOp(")") && Current.Type != TokType.End)
            {
                // Типы параметров и & игнорируем — значения всегда по копии.
                while (Current.Type == TokType.Ident || IsOp("?") || IsOp("&") || IsOp("...")) pos++;

                string name = Expect(TokType.Variable).Text;
                function.Parameters.Add(name);

                function.Defaults.Add(TakeOp("=") ? ParseExpr() : null);
                if (!TakeOp(",")) break;
            }
            ExpectOp(")");

            // Возвращаемый тип
            if (TakeOp(":")) { TakeOp("?"); if (Current.Type == TokType.Ident) pos++; }

            ExpectOp("{");
            BlockStmt body = new BlockStmt();

            while (!IsOp("}") && Current.Type != TokType.End)
            {
                if (Current.Type == TokType.InlineHtml)
                {
                    InlineHtmlStmt html = At(new InlineHtmlStmt());
                    html.Text = Current.Text;
                    pos++;
                    body.Body.Add(html);
                    continue;
                }

                if (Current.Type == TokType.OpenTag || Current.Type == TokType.CloseTag) { pos++; continue; }
                body.Body.Add(ParseStatement());
            }
            ExpectOp("}");

            function.Body = body;
            node.Function = function;
            return node;
        }

        private Stmt ParseGlobal()
        {
            GlobalStmt node = At(new GlobalStmt());
            pos++;

            node.Names.Add(Expect(TokType.Variable).Text);
            while (TakeOp(",")) node.Names.Add(Expect(TokType.Variable).Text);

            TakeOp(";");
            return node;
        }

        private Stmt ParseUnset()
        {
            UnsetStmt node = At(new UnsetStmt());
            pos++;

            ExpectOp("(");
            node.Targets.Add(ParseExpr());
            while (TakeOp(",")) node.Targets.Add(ParseExpr());
            ExpectOp(")");

            TakeOp(";");
            return node;
        }

        private Stmt ParseInclude(string word)
        {
            IncludeStmt node = At(new IncludeStmt());
            pos++;

            node.Once = word.EndsWith("_once");
            node.Required = word.StartsWith("require");
            node.Path = ParseExpr();

            TakeOp(";");
            return node;
        }

        // ---------- выражения ----------

        public Expr ParseExpr()
        {
            return ParseAssignment();
        }

        private Expr ParseAssignment()
        {
            Expr left = ParseTernary();

            string[] ops = { "=", "+=", "-=", "*=", "/=", ".=", "%=", "**=", "??=", "&=", "|=", "^=", "<<=", ">>=" };

            foreach (string op in ops)
            {
                if (!IsOp(op)) continue;

                int line = Current.Line;
                pos++;

                AssignExpr assign = new AssignExpr();
                assign.Line = line;
                assign.Target = left;
                assign.Op = op == "=" ? "" : op;

                if (op == "??=")
                {
                    // $a ??= $b  →  $a = $a ?? $b
                    BinaryExpr coalesce = new BinaryExpr();
                    coalesce.Line = line;
                    coalesce.Op = "??";
                    coalesce.Left = left;
                    coalesce.Right = ParseAssignment();

                    assign.Op = "";
                    assign.Value = coalesce;
                    return assign;
                }

                assign.Value = ParseAssignment();
                return assign;
            }

            return left;
        }

        private Expr ParseTernary()
        {
            Expr condition = ParseBinary(0);

            if (!IsOp("?")) return condition;

            int line = Current.Line;
            pos++;

            TernaryExpr node = new TernaryExpr();
            node.Line = line;
            node.Condition = condition;

            if (TakeOp(":"))
            {
                node.IfTrue = null;              // короткая форма ?:
                node.IfFalse = ParseAssignment();
                return node;
            }

            node.IfTrue = ParseAssignment();
            ExpectOp(":");
            node.IfFalse = ParseAssignment();
            return node;
        }

        /// <summary>Уровни приоритета, от низшего к высшему.</summary>
        private static readonly string[][] Levels =
        {
            new[] { "or" },
            new[] { "xor" },
            new[] { "and" },
            new[] { "||" },
            new[] { "&&" },
            new[] { "??" },
            new[] { "|" },
            new[] { "^" },
            new[] { "&" },
            new[] { "==", "!=", "===", "!==", "<>", "<=>" },
            new[] { "<", ">", "<=", ">=" },
            new[] { "<<", ">>" },
            new[] { "+", "-", "." },
            new[] { "*", "/", "%" }
        };

        private Expr ParseBinary(int level)
        {
            if (level >= Levels.Length) return ParsePower();

            Expr left = ParseBinary(level + 1);

            while (true)
            {
                string matched = null;

                foreach (string op in Levels[level])
                {
                    bool word = char.IsLetter(op[0]);

                    if (word ? IsKeyword(op) : IsOp(op)) { matched = op; break; }
                }

                if (matched == null) return left;

                int line = Current.Line;
                pos++;

                BinaryExpr node = new BinaryExpr();
                node.Line = line;
                node.Op = matched == "xor" ? "^" : matched;
                node.Left = left;
                node.Right = ParseBinary(level + 1);
                left = node;
            }
        }

        private Expr ParsePower()
        {
            Expr left = ParseUnary();

            if (!IsOp("**")) return left;

            int line = Current.Line;
            pos++;

            BinaryExpr node = new BinaryExpr();
            node.Line = line;
            node.Op = "**";
            node.Left = left;
            node.Right = ParsePower();
            return node;
        }

        private Expr ParseUnary()
        {
            int line = Current.Line;

            if (IsOp("!") || IsOp("-") || IsOp("+") || IsOp("~") || IsOp("@"))
            {
                string op = Current.Text;
                pos++;

                UnaryExpr node = new UnaryExpr();
                node.Line = line;
                node.Op = op;
                node.Operand = ParseUnary();
                return node;
            }

            if (IsOp("++") || IsOp("--"))
            {
                bool increment = Current.Text == "++";
                pos++;

                IncDecExpr node = new IncDecExpr();
                node.Line = line;
                node.Increment = increment;
                node.Prefix = true;
                node.Target = ParseUnary();
                return node;
            }

            // Приведение типа: (int) (string) (array) ...
            if (IsOp("(") && Ahead(1).Type == TokType.Ident && CastTypes.Contains(Ahead(1).Text) &&
                Ahead(2).Type == TokType.Op && Ahead(2).Text == ")")
            {
                string type = Ahead(1).Text.ToLowerInvariant();
                pos += 3;

                CastExpr node = new CastExpr();
                node.Line = line;
                node.Type = type;
                node.Operand = ParseUnary();
                return node;
            }

            if (IsKeyword("new"))
            {
                // Объектов нет: new Имя(...) считаем вызовом функции с тем же именем.
                pos++;
                return ParsePostfix(ParsePrimary());
            }

            if (IsKeyword("print"))
            {
                pos++;

                CallExpr print = new CallExpr();
                print.Line = line;
                print.Name = "print";
                print.Args.Add(ParseAssignment());
                return print;
            }

            if (IsKeyword("clone"))
            {
                pos++;
                return ParseUnary();
            }

            return ParsePostfix(ParsePrimary());
        }

        private Expr ParsePostfix(Expr expr)
        {
            while (true)
            {
                int line = Current.Line;

                if (IsOp("["))
                {
                    pos++;

                    IndexExpr index = new IndexExpr();
                    index.Line = line;
                    index.Target = expr;
                    index.Key = IsOp("]") ? null : ParseExpr();

                    ExpectOp("]");
                    expr = index;
                    continue;
                }

                if (IsOp("{") && (expr is VarExpr || expr is IndexExpr))
                {
                    pos++;

                    IndexExpr index = new IndexExpr();
                    index.Line = line;
                    index.Target = expr;
                    index.Key = ParseExpr();

                    ExpectOp("}");
                    expr = index;
                    continue;
                }

                if (IsOp("++") || IsOp("--"))
                {
                    bool increment = Current.Text == "++";
                    pos++;

                    IncDecExpr node = new IncDecExpr();
                    node.Line = line;
                    node.Increment = increment;
                    node.Prefix = false;
                    node.Target = expr;
                    expr = node;
                    continue;
                }

                // Методы и статические вызовы не поддерживаются: пропускаем обращение.
                if (IsOp("->") || IsOp("::"))
                {
                    pos++;
                    if (Current.Type == TokType.Ident || Current.Type == TokType.Variable) pos++;

                    if (IsOp("("))
                    {
                        pos++;
                        int depth = 1;
                        while (depth > 0 && Current.Type != TokType.End)
                        {
                            if (IsOp("(")) depth++;
                            else if (IsOp(")")) depth--;
                            pos++;
                        }
                    }

                    expr = new LiteralExpr();
                    continue;
                }

                return expr;
            }
        }

        private Expr ParsePrimary()
        {
            int line = Current.Line;

            if (Current.Type == TokType.Number)
            {
                LiteralExpr literal = new LiteralExpr();
                literal.Line = line;
                literal.Value = Current.Value;
                pos++;
                return literal;
            }

            if (Current.Type == TokType.String)
            {
                LiteralExpr literal = new LiteralExpr();
                literal.Line = line;
                literal.Value = Current.Value;
                pos++;
                return literal;
            }

            if (Current.Type == TokType.InterpString)
            {
                InterpExpr node = new InterpExpr();
                node.Line = line;
                node.Parts = Current.Parts;
                pos++;
                return node;
            }

            if (Current.Type == TokType.Variable)
            {
                VarExpr variable = new VarExpr();
                variable.Line = line;
                variable.Name = Current.Text;
                pos++;
                return variable;
            }

            if (IsOp("("))
            {
                pos++;
                Expr inner = ParseExpr();
                ExpectOp(")");
                return inner;
            }

            if (IsOp("["))
            {
                pos++;
                return ParseArrayBody("]", line);
            }

            if (Current.Type == TokType.Ident)
            {
                string word = Current.Text;
                string lower = word.ToLowerInvariant();

                switch (lower)
                {
                    case "array":
                        pos++;
                        if (TakeOp("(")) return ParseArrayBody(")", line);
                        break;

                    case "isset":
                        {
                            pos++;
                            ExpectOp("(");

                            IssetExpr node = new IssetExpr();
                            node.Line = line;
                            node.Targets.Add(ParseExpr());
                            while (TakeOp(",")) node.Targets.Add(ParseExpr());

                            ExpectOp(")");
                            return node;
                        }

                    case "empty":
                        {
                            pos++;
                            ExpectOp("(");

                            EmptyExpr node = new EmptyExpr();
                            node.Line = line;
                            node.Target = ParseExpr();

                            ExpectOp(")");
                            return node;
                        }

                    case "exit":
                    case "die":
                        {
                            pos++;

                            ExitExpr node = new ExitExpr();
                            node.Line = line;

                            if (TakeOp("("))
                            {
                                if (!IsOp(")")) node.Message = ParseExpr();
                                ExpectOp(")");
                            }
                            return node;
                        }

                    case "true":
                        pos++;
                        return Lit(line, true);

                    case "false":
                        pos++;
                        return Lit(line, false);

                    case "null":
                        pos++;
                        return Lit(line, null);

                    case "function":
                    case "fn":
                        {
                            // Анонимные функции не поддерживаются: пропускаем тело.
                            pos++;
                            SkipBalanced("(", ")");
                            if (IsKeyword("use")) SkipBalanced("(", ")");
                            if (TakeOp(":")) { TakeOp("?"); if (Current.Type == TokType.Ident) pos++; }
                            SkipBalanced("{", "}");
                            return Lit(line, null);
                        }

                    case "include":
                    case "include_once":
                    case "require":
                    case "require_once":
                        {
                            pos++;

                            CallExpr call = new CallExpr();
                            call.Line = line;
                            call.Name = "__include";
                            call.Args.Add(ParseExpr());
                            call.Args.Add(Lit(line, lower.EndsWith("_once")));
                            return call;
                        }
                }

                pos++;

                if (IsOp("("))
                {
                    pos++;

                    CallExpr call = new CallExpr();
                    call.Line = line;
                    call.Name = word.TrimStart('\\');

                    while (!IsOp(")") && Current.Type != TokType.End)
                    {
                        TakeOp("&");
                        TakeOp("...");
                        call.Args.Add(ParseExpr());
                        if (!TakeOp(",")) break;
                    }

                    ExpectOp(")");
                    return call;
                }

                ConstExpr constant = new ConstExpr();
                constant.Line = line;
                constant.Name = word.TrimStart('\\');
                return constant;
            }

            throw new PhpErrorException("неожидаемый фрагмент '" + Current.Text + "'", line);
        }

        private void SkipBalanced(string open, string close)
        {
            if (!IsOp(open)) return;

            pos++;
            int depth = 1;

            while (depth > 0 && Current.Type != TokType.End)
            {
                if (IsOp(open)) depth++;
                else if (IsOp(close)) depth--;
                pos++;
            }
        }

        private static LiteralExpr Lit(int line, object value)
        {
            LiteralExpr literal = new LiteralExpr();
            literal.Line = line;
            literal.Value = value;
            return literal;
        }

        private Expr ParseArrayBody(string close, int line)
        {
            ArrayExpr array = new ArrayExpr();
            array.Line = line;

            while (!IsOp(close) && Current.Type != TokType.End)
            {
                TakeOp("...");
                Expr first = ParseExpr();

                if (TakeOp("=>"))
                {
                    array.Keys.Add(first);
                    array.Values.Add(ParseExpr());
                }
                else
                {
                    array.Keys.Add(null);
                    array.Values.Add(first);
                }

                if (!TakeOp(",")) break;
            }

            ExpectOp(close);
            return array;
        }
    }
}

namespace LisunOS.Php
{
    // =========================================================================
    //  Интерпретатор
    // =========================================================================

    /// <summary>Встроенная функция: получает контекст и готовые значения аргументов.</summary>
    public delegate object Builtin(Interp interp, object[] args);

    public class Interp
    {
        public const int LoopLimit = 2000000;

        private readonly Dictionary<string, PhpFunction> functions =
            new Dictionary<string, PhpFunction>(StringComparer.OrdinalIgnoreCase);

        private readonly Dictionary<string, object> constants =
            new Dictionary<string, object>(StringComparer.Ordinal);

        private readonly HashSet<string> included = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        public Scope Globals { get; private set; }
        public StringBuilder Out { get; private set; }
        public PhpContext Context { get; set; }

        private int depth;

        public Interp()
        {
            Globals = new Scope();
            Out = new StringBuilder();

            constants["PHP_EOL"] = "\r\n";
            constants["PHP_VERSION"] = "8.2.0-LisunOS";
            constants["PHP_OS"] = "WINNT";
            constants["PHP_OS_FAMILY"] = "Windows";
            constants["PHP_INT_MAX"] = long.MaxValue;
            constants["PHP_INT_MIN"] = long.MinValue;
            constants["PHP_INT_SIZE"] = 8L;
            constants["PHP_FLOAT_EPSILON"] = double.Epsilon;
            constants["M_PI"] = Math.PI;
            constants["M_E"] = Math.E;
            constants["NAN"] = double.NaN;
            constants["INF"] = double.PositiveInfinity;
            constants["DIRECTORY_SEPARATOR"] = "\\";
            constants["PATH_SEPARATOR"] = ";";

            constants["E_ALL"] = 32767L;
            constants["E_ERROR"] = 1L;
            constants["E_WARNING"] = 2L;
            constants["E_NOTICE"] = 8L;
            constants["E_DEPRECATED"] = 8192L;
            constants["E_STRICT"] = 2048L;

            constants["ENT_QUOTES"] = 3L;
            constants["ENT_HTML5"] = 48L;
            constants["ENT_COMPAT"] = 2L;

            constants["JSON_PRETTY_PRINT"] = 128L;
            constants["JSON_UNESCAPED_SLASHES"] = 64L;
            constants["JSON_UNESCAPED_UNICODE"] = 256L;
            constants["JSON_THROW_ON_ERROR"] = 4194304L;

            constants["SORT_REGULAR"] = 0L;
            constants["SORT_NUMERIC"] = 1L;
            constants["SORT_STRING"] = 2L;

            constants["COUNT_RECURSIVE"] = 1L;
            constants["FILE_APPEND"] = 8L;
            constants["FILE_IGNORE_NEW_LINES"] = 2L;
            constants["FILE_SKIP_EMPTY_LINES"] = 4L;
            constants["LOCK_EX"] = 2L;
            constants["SCANDIR_SORT_ASCENDING"] = 0L;
            constants["STR_PAD_RIGHT"] = 1L;
            constants["STR_PAD_LEFT"] = 0L;
            constants["STR_PAD_BOTH"] = 2L;
            constants["PREG_PATTERN_ORDER"] = 1L;
            constants["PREG_SET_ORDER"] = 2L;
            constants["CASE_LOWER"] = 0L;
            constants["CASE_UPPER"] = 1L;
            constants["FILTER_VALIDATE_EMAIL"] = 274L;
            constants["FILTER_VALIDATE_INT"] = 257L;
            constants["FILTER_VALIDATE_URL"] = 273L;
        }

        // ---------- вывод ----------

        public void Output(string text)
        {
            if (string.IsNullOrEmpty(text)) return;
            Out.Append(text);
        }

        // ---------- константы ----------

        public object GetConstant(string name, int line)
        {
            object value;
            if (constants.TryGetValue(name, out value)) return value;

            // Магические константы считаются на месте: они зависят от того,
            // какой файл исполняется прямо сейчас, а не от таблицы констант.
            switch (name)
            {
                case "__FILE__":
                    return Context == null ? string.Empty : Context.CurrentFile ?? string.Empty;

                case "__DIR__":
                    return CurrentDirectory();

                case "__LINE__":
                    return (long)line;

                case "__FUNCTION__":
                case "__METHOD__":
                    return CurrentFunction ?? string.Empty;

                case "__CLASS__":
                case "__NAMESPACE__":
                    return string.Empty;
            }

            // Неизвестная константа в PHP 8 — ошибка; возвращаем её имя, как делали раньше.
            return name;
        }

        /// <summary>Папка исполняемого файла — значение __DIR__.</summary>
        public string CurrentDirectory()
        {
            if (Context == null) return string.Empty;

            string file = Context.CurrentFile;
            if (string.IsNullOrEmpty(file)) return Context.DocumentRoot ?? string.Empty;

            try
            {
                string directory = System.IO.Path.GetDirectoryName(file);
                return string.IsNullOrEmpty(directory) ? Context.DocumentRoot ?? string.Empty : directory;
            }
            catch { return Context.DocumentRoot ?? string.Empty; }
        }

        /// <summary>Имя функции, которая исполняется сейчас — значение __FUNCTION__.</summary>
        public string CurrentFunction { get; set; }

        public bool HasConstant(string name)
        {
            return constants.ContainsKey(name);
        }

        public void DefineConstant(string name, object value)
        {
            constants[name] = value;
        }

        // ---------- функции ----------

        public void DeclareFunction(PhpFunction function)
        {
            functions[function.Name] = function;
        }

        public bool HasFunction(string name)
        {
            return functions.ContainsKey(name) || PhpLibrary.Has(name);
        }

        public object CallFunction(string name, List<Expr> args, Scope scope, int line)
        {
            PhpFunction function;

            if (functions.TryGetValue(name, out function))
            {
                object[] values = new object[args.Count];
                for (int i = 0; i < args.Count; i++) values[i] = args[i].Eval(this, scope);

                return CallUser(function, values, line);
            }

            if (string.Equals(name, "__include", StringComparison.OrdinalIgnoreCase))
            {
                string path = PhpOps.ToStr(args[0].Eval(this, scope));
                bool once = args.Count > 1 && PhpOps.ToBool(args[1].Eval(this, scope));

                return IncludeFile(path, once, true, scope, line);
            }

            if (string.Equals(name, "compact", StringComparison.OrdinalIgnoreCase))
            {
                PhpArray result = new PhpArray();
                foreach (Expr arg in args)
                {
                    string variable = PhpOps.ToStr(arg.Eval(this, scope));
                    if (scope.Has(variable)) result.Set(variable, scope.Get(variable));
                }
                return result;
            }

            if (string.Equals(name, "extract", StringComparison.OrdinalIgnoreCase))
            {
                PhpArray source = args.Count > 0 ? args[0].Eval(this, scope) as PhpArray : null;
                if (source == null) return 0L;

                long count = 0;
                foreach (object key in source.Keys)
                {
                    if (!(key is string)) continue;
                    scope.Set((string)key, source.Get(key));
                    count++;
                }
                return count;
            }

            // Функции, которым нужен доступ к самим переменным, а не к значениям.
            if (PhpLibrary.NeedsScope(name))
            {
                return PhpLibrary.CallWithScope(this, scope, name, args, line);
            }

            if (PhpLibrary.Has(name))
            {
                object[] values = new object[args.Count];
                for (int i = 0; i < args.Count; i++) values[i] = args[i].Eval(this, scope);

                return PhpLibrary.Call(this, name, values, line);
            }

            throw new PhpErrorException("неизвестная функция " + name + "()", line);
        }

        public object CallUser(PhpFunction function, object[] args, int line)
        {
            if (++depth > 128)
            {
                depth--;
                throw new PhpErrorException("слишком глубокая рекурсия в " + function.Name + "()", line);
            }

            Scope scope = new Scope(Globals);

            for (int i = 0; i < function.Parameters.Count; i++)
            {
                object value = i < args.Length ? args[i] : null;

                if (i >= args.Length && function.Defaults[i] != null)
                    value = function.Defaults[i].Eval(this, scope);

                PhpArray array = value as PhpArray;
                scope.Set(function.Parameters[i], array != null ? array.Clone() : value);
            }

            string previousFunction = CurrentFunction;
            CurrentFunction = function.Name;

            try
            {
                function.Body.Exec(this, scope);
                return null;
            }
            catch (ReturnSignal signal)
            {
                return signal.Value;
            }
            finally
            {
                CurrentFunction = previousFunction;
                depth--;
            }
        }

        /// <summary>Вызов пользовательской функции по имени — для call_user_func и usort.</summary>
        public object CallByName(string name, object[] args, int line)
        {
            PhpFunction function;
            if (functions.TryGetValue(name, out function)) return CallUser(function, args, line);

            if (PhpLibrary.Has(name)) return PhpLibrary.Call(this, name, args, line);

            throw new PhpErrorException("неизвестная функция " + name + "()", line);
        }

        // ---------- подключение файлов ----------

        public object IncludeFile(string path, bool once, bool required, Scope scope, int line)
        {
            if (Context == null) return null;

            string resolved = Context.ResolveInclude(path);

            if (resolved == null)
            {
                if (required) throw new PhpErrorException("не найден файл " + path, line);
                return false;
            }

            if (once && included.Contains(resolved)) return true;
            included.Add(resolved);

            string source;
            try { source = Context.ReadFile(resolved); }
            catch (Exception ex)
            {
                if (required) throw new PhpErrorException("не удалось прочитать " + path + ": " + ex.Message, line);
                return false;
            }

            BlockStmt program = Parser.ParseSource(source);

            string previous = Context.CurrentFile;
            Context.CurrentFile = resolved;

            try
            {
                program.Exec(this, scope);
                return 1L;
            }
            catch (ReturnSignal signal)
            {
                return signal.Value;
            }
            finally
            {
                Context.CurrentFile = previous;
            }
        }

        // ---------- запуск ----------

        public void Run(string source)
        {
            BlockStmt program = Parser.ParseSource(source);

            try
            {
                program.Exec(this, Globals);
            }
            catch (PhpExitException) { }
            catch (ReturnSignal) { }
        }
    }
}
