﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Сеть вообще, а не только Wi-Fi.
    ///
    /// Раньше система знала один способ выйти в сеть — беспроводной, и на
    /// компьютере с кабелем выглядела растерянно: адаптера Wi-Fi нет, сетей
    /// не видно, значит и интернета будто бы нет. На деле кабель работает
    /// ровно так же, просто его никто не спрашивал.
    ///
    /// Здесь собрано то, что общее для любого подключения: какие адаптеры
    /// подняты, какой из них проводной, какие у них адреса и шлюзы. Wi-Fi
    /// остаётся в LisunWifi — там своё: поиск сетей, пароли, профили.
    /// </summary>
    public static class LisunNetwork
    {
        public const string PackageName = "net";

        /// <summary>Один сетевой адаптер так, как его видит система.</summary>
        public sealed class Adapter
        {
            public string Name = string.Empty;
            public string Description = string.Empty;
            public string Kind = string.Empty;          // проводной / беспроводной / иной
            public bool Wired;
            public bool Wireless;

            /// <summary>VPN, виртуальный коммутатор или туннель.</summary>
            public bool Virtual;
            public bool Up;
            public string Address = string.Empty;       // IPv4
            public string Gateway = string.Empty;
            public long Speed;                          // бит/с, 0 — неизвестно

            public override string ToString()
            {
                return Name + " " + Address;
            }
        }

        // =====================================================================
        //  Опрос адаптеров
        // =====================================================================

        /// <summary>Все адаптеры, кроме петлевых и туннельных.</summary>
        public static List<Adapter> Adapters()
        {
            List<Adapter> result = new List<Adapter>();

            NetworkInterface[] list;
            try { list = NetworkInterface.GetAllNetworkInterfaces(); }
            catch { return result; }

            foreach (NetworkInterface item in list)
            {
                if (item.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                if (item.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;

                Adapter adapter = new Adapter();
                adapter.Name = item.Name;
                adapter.Description = item.Description;
                adapter.Up = item.OperationalStatus == OperationalStatus.Up;

                adapter.Wireless = item.NetworkInterfaceType == NetworkInterfaceType.Wireless80211;
                adapter.Wired = item.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                                item.NetworkInterfaceType == NetworkInterfaceType.GigabitEthernet ||
                                item.NetworkInterfaceType == NetworkInterfaceType.FastEthernetT ||
                                item.NetworkInterfaceType == NetworkInterfaceType.FastEthernetFx ||
                                item.NetworkInterfaceType == NetworkInterfaceType.Ethernet3Megabit;

                // Windows называет «ethernet» и VPN, и виртуальные коммутаторы:
                // Radmin, Hamachi, Hyper-V, VMware, TAP. Кабелем они не являются,
                // и если их не отсеять, система решит, что вышла в сеть через
                // VPN-адрес, которого в вашей сети не существует.
                string probe = (adapter.Description + " " + adapter.Name).ToLowerInvariant();

                foreach (string mark in NotRealWired)
                {
                    if (!probe.Contains(mark)) continue;

                    adapter.Wired = false;
                    adapter.Virtual = true;
                    break;
                }

                adapter.Kind = adapter.Wired ? LisunLocale.T("net.kindWired")
                             : adapter.Wireless ? LisunLocale.T("net.kindWireless")
                             : adapter.Virtual ? LisunLocale.T("net.kindVirtual")
                                               : LisunLocale.T("net.kindOther");

                try { adapter.Speed = item.Speed; }
                catch { adapter.Speed = 0; }

                try
                {
                    IPInterfaceProperties properties = item.GetIPProperties();

                    foreach (UnicastIPAddressInformation address in properties.UnicastAddresses)
                    {
                        if (address.Address.AddressFamily != AddressFamily.InterNetwork) continue;

                        string text = address.Address.ToString();

                        // 169.254.x.x — адрес «сам себе выдал», сети за ним нет.
                        if (text.StartsWith("169.254.", StringComparison.Ordinal)) continue;

                        adapter.Address = text;
                        break;
                    }

                    foreach (GatewayIPAddressInformation gateway in properties.GatewayAddresses)
                    {
                        if (gateway.Address == null) continue;
                        if (gateway.Address.AddressFamily != AddressFamily.InterNetwork) continue;

                        string text = gateway.Address.ToString();
                        if (text == "0.0.0.0") continue;

                        adapter.Gateway = text;
                        break;
                    }
                }
                catch { }

                result.Add(adapter);
            }

            return result;
        }

        /// <summary>Поднятые адаптеры с настоящим адресом.</summary>
        public static List<Adapter> Active()
        {
            List<Adapter> result = new List<Adapter>();

            foreach (Adapter adapter in Adapters())
                if (adapter.Up && adapter.Address.Length > 0) result.Add(adapter);

            return result;
        }

        /// <summary>
        /// По этим словам в имени или описании адаптер считается не кабелем:
        /// это VPN, виртуальный коммутатор или туннель.
        /// </summary>
        private static readonly string[] NotRealWired =
        {
            "virtual", "vmware", "virtualbox", "hyper-v", "vethernet", "loopback", "bluetooth",
            "vpn", "radmin", "hamachi", "zerotier", "tailscale", "wireguard", "openvpn",
            "softether", "tap-", "tap0", "tun", "npcap", "pseudo", "docker", "wsl",
            "nordlynx", "proton", "surfshark", "outline", "teredo", "anydesk", "packet scheduler"
        };

        /// <summary>Кабель воткнут и адрес получен.</summary>
        public static bool WiredConnected
        {
            get { return WiredAdapter() != null; }
        }

        public static Adapter WiredAdapter()
        {
            List<Adapter> candidates = new List<Adapter>();

            foreach (Adapter adapter in Adapters())
                if (adapter.Wired && adapter.Up && adapter.Address.Length > 0) candidates.Add(adapter);

            return Best(candidates);
        }

        public static Adapter WirelessAdapter()
        {
            List<Adapter> candidates = new List<Adapter>();

            foreach (Adapter adapter in Adapters())
                if (adapter.Wireless && adapter.Up && adapter.Address.Length > 0) candidates.Add(adapter);

            return Best(candidates);
        }

        /// <summary>
        /// Из нескольких подходящих выбираем тот, через который и правда идёт
        /// сеть: сначала со шлюзом, затем самый быстрый.
        /// </summary>
        private static Adapter Best(List<Adapter> candidates)
        {
            Adapter best = null;

            foreach (Adapter adapter in candidates)
            {
                if (best == null) { best = adapter; continue; }

                bool hasGateway = adapter.Gateway.Length > 0;
                bool bestHasGateway = best.Gateway.Length > 0;

                if (hasGateway != bestHasGateway)
                {
                    if (hasGateway) best = adapter;
                    continue;
                }

                if (adapter.Speed > best.Speed) best = adapter;
            }

            return best;
        }

        /// <summary>
        /// Есть ли вообще связь: шлюз хотя бы у одного адаптера. Это не то же
        /// самое, что интернет, — его проверяет LisunWifi.CheckConnectivity.
        /// </summary>
        public static bool LinkUp
        {
            get
            {
                foreach (Adapter adapter in Adapters())
                    if (adapter.Up && adapter.Address.Length > 0 && adapter.Gateway.Length > 0) return true;

                return false;
            }
        }

        /// <summary>Каким способом система сейчас в сети.</summary>
        public static string Kind()
        {
            if (WiredConnected) return LisunLocale.T("net.kindWired");
            if (WirelessAdapter() != null) return LisunLocale.T("net.kindWireless");

            return LisunLocale.T("net.kindNone");
        }

        /// <summary>Строка для шапки окон: «проводное соединение, 192.168.0.5».</summary>
        public static string Short()
        {
            Adapter wired = WiredAdapter();
            if (wired != null) return LisunLocale.T("net.shortWired", wired.Address);

            Adapter wireless = WirelessAdapter();
            if (wireless != null)
            {
                string ssid;
                try { ssid = LisunWifi.CurrentSsid(); }
                catch { ssid = string.Empty; }

                return ssid.Length > 0
                    ? LisunLocale.T("net.shortWifi", ssid, wireless.Address)
                    : LisunLocale.T("net.shortWireless", wireless.Address);
            }

            return LisunLocale.T("net.shortNone");
        }

        // =====================================================================
        //  Текст
        // =====================================================================

        /// <summary>Таблица адаптеров для команды «net».</summary>
        public static string StatusText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("net.header"));
            sb.AppendLine();

            List<Adapter> list = Adapters();

            if (list.Count == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("net.none"));
                return sb.ToString();
            }

            foreach (Adapter adapter in list)
            {
                string state = adapter.Up
                    ? (adapter.Address.Length > 0 ? LisunLocale.T("net.stateUp") : LisunLocale.T("net.stateNoAddress"))
                    : LisunLocale.T("net.stateDown");

                sb.AppendLine("   " + Pad(adapter.Name, 26) + Pad(adapter.Kind, 16) + state);

                if (adapter.Address.Length > 0)
                    sb.AppendLine("      " + LisunLocale.T("net.address") + adapter.Address +
                        (adapter.Gateway.Length > 0 ? "   " + LisunLocale.T("net.gateway") + adapter.Gateway : string.Empty) +
                        (adapter.Speed > 0 ? "   " + SpeedText(adapter.Speed) : string.Empty));

                if (adapter.Description.Length > 0 &&
                    !string.Equals(adapter.Description, adapter.Name, StringComparison.OrdinalIgnoreCase))
                    sb.AppendLine("      " + adapter.Description);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("net.summary", Kind(),
                LisunWifi.Online ? LisunLocale.T("net.internetYes") : LisunLocale.T("net.internetNo")));

            return sb.ToString();
        }

        /// <summary>Скорость канала человеческими словами.</summary>
        public static string SpeedText(long bitsPerSecond)
        {
            if (bitsPerSecond <= 0) return string.Empty;

            if (bitsPerSecond >= 1000000000L)
                return (bitsPerSecond / 1000000000L) + " " + LisunLocale.T("net.gbit");

            if (bitsPerSecond >= 1000000L)
                return (bitsPerSecond / 1000000L) + " " + LisunLocale.T("net.mbit");

            return (bitsPerSecond / 1000L) + " " + LisunLocale.T("net.kbit");
        }

        /// <summary>Адреса, по которым к системе можно подключиться снаружи.</summary>
        public static List<string> Addresses()
        {
            List<string> result = new List<string>();

            foreach (Adapter adapter in Active())
                if (!result.Contains(adapter.Address)) result.Add(adapter.Address);

            return result;
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value.Substring(0, width - 1) + " " : value.PadRight(width);
        }
    }
}
