﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Небольшой, но полноценный разборщик JSON для манифестов LisunOS.
    /// Поддерживает объекты, массивы, строки с escape-последовательностями,
    /// числа, true/false/null и вложенность любой глубины.
    /// Прежний ParseSimpleJson не умел массивов и ломался на вложенных структурах.
    /// </summary>
    public static class LisunJson
    {
        /// <summary>Разобранное значение: объект, массив, строка, число, bool или null.</summary>
        public sealed class Node
        {
            public Dictionary<string, Node> Object;
            public List<Node> Array;
            public string Text;
            public double Number;
            public bool Boolean;
            public bool IsNull;

            public bool IsObject { get { return Object != null; } }
            public bool IsArray { get { return Array != null; } }
            public bool IsText { get { return Text != null; } }

            public Node Child(string key)
            {
                Node value;
                if (Object != null && Object.TryGetValue(key, out value)) return value;
                return null;
            }

            /// <summary>Значение в виде строки — для любого типа узла.</summary>
            public string AsText()
            {
                if (Text != null) return Text;
                if (IsNull) return string.Empty;
                if (Array != null)
                {
                    List<string> parts = new List<string>();
                    foreach (Node item in Array) parts.Add(item.AsText());
                    return string.Join(",", parts.ToArray());
                }
                if (Object != null) return "{object}";
                if (Number != 0) return Number.ToString(CultureInfo.InvariantCulture);
                return Boolean ? "true" : "false";
            }

            public List<string> AsTextList()
            {
                List<string> result = new List<string>();
                if (Array != null)
                {
                    foreach (Node item in Array)
                    {
                        string text = item.AsText().Trim();
                        if (text.Length > 0) result.Add(text);
                    }
                    return result;
                }

                if (Text != null)
                {
                    foreach (string piece in Text.Split(','))
                    {
                        string text = piece.Trim();
                        if (text.Length > 0) result.Add(text);
                    }
                }
                return result;
            }
        }

        public static Node Parse(string json)
        {
            if (string.IsNullOrEmpty(json)) return null;

            int index = 0;
            try
            {
                Node node = ParseValue(json, ref index);
                return node;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Json] [ОШИБКА] Разбор манифеста: " + ex.Message);
                return null;
            }
        }

        private static Node ParseValue(string s, ref int i)
        {
            SkipWhitespace(s, ref i);
            if (i >= s.Length) throw new FormatException("неожиданный конец данных");

            char c = s[i];

            if (c == '{') return ParseObject(s, ref i);
            if (c == '[') return ParseArray(s, ref i);
            if (c == '"' || c == '\'') return new Node { Text = ParseString(s, ref i) };

            if (Match(s, i, "true")) { i += 4; return new Node { Boolean = true, Text = null }; }
            if (Match(s, i, "false")) { i += 5; return new Node { Boolean = false }; }
            if (Match(s, i, "null")) { i += 4; return new Node { IsNull = true }; }

            return ParseNumber(s, ref i);
        }

        private static Node ParseObject(string s, ref int i)
        {
            Node node = new Node();
            node.Object = new Dictionary<string, Node>(StringComparer.OrdinalIgnoreCase);

            i++; // '{'
            SkipWhitespace(s, ref i);

            if (i < s.Length && s[i] == '}') { i++; return node; }

            while (i < s.Length)
            {
                SkipWhitespace(s, ref i);

                string key;
                if (s[i] == '"' || s[i] == '\'') key = ParseString(s, ref i);
                else key = ParseBareKey(s, ref i);

                // Восстановление после незакрытой кавычки вида  "permissions: [
                // ключ в этом случае приходит склеенным со своим двоеточием.
                int colon = key.IndexOf(':');
                if (colon > 0)
                {
                    string realKey = key.Substring(0, colon).Trim();
                    string rest = key.Substring(colon + 1).Trim();

                    if (rest.StartsWith("["))
                    {
                        Node recovered = new Node();
                        recovered.Array = new List<Node>();

                        while (i < s.Length)
                        {
                            SkipWhitespace(s, ref i);
                            if (i >= s.Length || s[i] == ']') { if (i < s.Length) i++; break; }
                            if (s[i] == ',') { i++; continue; }
                            if (s[i] == '}') break;

                            recovered.Array.Add(ParseValue(s, ref i));
                        }

                        node.Object[realKey] = recovered;

                        SkipWhitespace(s, ref i);
                        if (i < s.Length && s[i] == ',') { i++; continue; }
                        if (i < s.Length && s[i] == '}') { i++; break; }
                        continue;
                    }

                    if (rest.Length > 0)
                    {
                        node.Object[realKey] = new Node { Text = rest };
                        SkipWhitespace(s, ref i);
                        if (i < s.Length && s[i] == ',') { i++; continue; }
                        if (i < s.Length && s[i] == '}') { i++; break; }
                        continue;
                    }

                    key = realKey;
                }

                SkipWhitespace(s, ref i);
                if (i < s.Length && s[i] == ':') i++;

                Node value = ParseValue(s, ref i);
                node.Object[key] = value;

                SkipWhitespace(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == '}') { i++; break; }

                // Пропущенная запятая — частая опечатка в манифестах, продолжаем разбор.
                if (i < s.Length && (s[i] == '"' || s[i] == '\'')) continue;
                break;
            }

            return node;
        }

        private static Node ParseArray(string s, ref int i)
        {
            Node node = new Node();
            node.Array = new List<Node>();

            i++; // '['
            SkipWhitespace(s, ref i);

            if (i < s.Length && s[i] == ']') { i++; return node; }

            while (i < s.Length)
            {
                Node value = ParseValue(s, ref i);
                node.Array.Add(value);

                SkipWhitespace(s, ref i);
                if (i < s.Length && s[i] == ',') { i++; continue; }
                if (i < s.Length && s[i] == ']') { i++; break; }
                break;
            }

            return node;
        }

        private static string ParseString(string s, ref int i)
        {
            char quote = s[i];
            i++;

            StringBuilder builder = new StringBuilder();
            while (i < s.Length)
            {
                char c = s[i];

                if (c == '\\' && i + 1 < s.Length)
                {
                    char next = s[i + 1];
                    i += 2;
                    switch (next)
                    {
                        case 'n': builder.Append('\n'); break;
                        case 'r': builder.Append('\r'); break;
                        case 't': builder.Append('\t'); break;
                        case 'b': builder.Append('\b'); break;
                        case 'f': builder.Append('\f'); break;
                        case '/': builder.Append('/'); break;
                        case '\\': builder.Append('\\'); break;
                        case '"': builder.Append('"'); break;
                        case '\'': builder.Append('\''); break;
                        case 'u':
                            if (i + 4 <= s.Length)
                            {
                                int code;
                                if (int.TryParse(s.Substring(i, 4), NumberStyles.HexNumber,
                                    CultureInfo.InvariantCulture, out code)) builder.Append((char)code);
                                i += 4;
                            }
                            break;
                        default: builder.Append(next); break;
                    }
                    continue;
                }

                if (c == quote) { i++; break; }

                // Незакрытая кавычка (как в "permissions: [) — обрываем строку на переводе строки.
                if (c == '\n' || c == '\r') break;

                builder.Append(c);
                i++;
            }

            return builder.ToString();
        }

        private static string ParseBareKey(string s, ref int i)
        {
            StringBuilder builder = new StringBuilder();
            while (i < s.Length && (char.IsLetterOrDigit(s[i]) || s[i] == '_' || s[i] == '-'))
            {
                builder.Append(s[i]);
                i++;
            }
            return builder.ToString();
        }

        private static Node ParseNumber(string s, ref int i)
        {
            int start = i;
            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '-' || s[i] == '+' ||
                                    s[i] == '.' || s[i] == 'e' || s[i] == 'E')) i++;

            string raw = s.Substring(start, i - start);
            double value;
            double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out value);

            return new Node { Number = value, Text = raw };
        }

        /// <summary>Совпадает ли литерал (true/false/null) в позиции i.</summary>
        private static bool Match(string s, int i, string word)
        {
            if (i + word.Length > s.Length) return false;

            for (int k = 0; k < word.Length; k++)
            {
                if (char.ToLowerInvariant(s[i + k]) != word[k]) return false;
            }
            return true;
        }

        private static void SkipWhitespace(string s, ref int i)
        {
            while (i < s.Length)
            {
                char c = s[i];

                if (char.IsWhiteSpace(c)) { i++; continue; }

                // Комментарии в манифестах допускаются.
                if (c == '/' && i + 1 < s.Length && s[i + 1] == '/')
                {
                    while (i < s.Length && s[i] != '\n') i++;
                    continue;
                }
                if (c == '/' && i + 1 < s.Length && s[i + 1] == '*')
                {
                    i += 2;
                    while (i + 1 < s.Length && !(s[i] == '*' && s[i + 1] == '/')) i++;
                    i += 2;
                    continue;
                }
                break;
            }
        }
    }
}
