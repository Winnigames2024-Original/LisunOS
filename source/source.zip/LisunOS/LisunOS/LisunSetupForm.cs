﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Мастер первого запуска — то, что видно вместо терминала, когда
    /// система запущена впервые.
    ///
    /// Устроен как установщик телефона: слева этапы, справа один вопрос за
    /// раз, внизу «Назад» и «Далее». Этапы идут в том порядке, в каком
    /// вопросы вообще имеют смысл: сначала язык, потом сеть (без неё ничего
    /// не скачать), потом выбор приложений из каталога на сайте, потом сама
    /// установка с полосой прогресса, и в конце — переход в терминал.
    ///
    /// Мастер ничего не делает молча: каждый шаг можно пропустить, а список
    /// приложений приходит с сайта тем же catalog.json, который читает
    /// команда store.
    /// </summary>
    public sealed class LisunSetupForm : Form
    {
        public const string PackageName = "setup";

        private enum Stage
        {
            Welcome = 0,
            Wifi = 1,
            Apps = 2,
            Install = 3,
            Done = 4
        }

        private static readonly Stage[] Order =
        {
            Stage.Welcome, Stage.Wifi, Stage.Apps, Stage.Install, Stage.Done
        };

        private Stage stage = Stage.Welcome;

        // ---------- рамка окна ----------
        private Panel header;
        private Label title;
        private Label subtitle;

        private Panel steps;
        private readonly List<Label> stepLabels = new List<Label>();

        private Panel content;
        private Label status;
        private Button back;
        private Button skip;
        private Button next;

        // ---------- шаг «язык» ----------
        private Label welcomeText;
        private Button russian;
        private Button english;

        // ---------- шаг «сеть» ----------
        private ListView networks;
        private Label networkHint;
        private TextBox password;
        private CheckBox showPassword;
        private Button connect;
        private Button rescan;
        private Label online;
        private readonly List<WifiNetwork> found = new List<WifiNetwork>();
        private bool scanning;

        // ---------- шаг «приложения» ----------
        private Label appsHint;
        private CheckedListBox apps;
        private Button selectAll;
        private Button selectNone;
        private Button refresh;
        private readonly List<LisunStore.StoreItem> catalog = new List<LisunStore.StoreItem>();

        // ---------- шаг «установка» ----------
        private Label installTitle;
        private ProgressBar progress;
        private ListBox journal;
        private bool installing;
        private int installed;
        private int failed;

        private bool closing;

        public LisunSetupForm()
        {
            BuildWindow();
            BuildSteps();
            BuildContent();
            ShowStage(Stage.Welcome);
        }

        /// <summary>Мастер уже проходили на этом компьютере.</summary>
        public static bool Completed
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData != null &&
                    LisunEngine.RegistryData.TryGetValue("setup_done", out value))
                    return value == "1" || string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);

                return false;
            }
            set
            {
                if (LisunEngine.RegistryData == null) return;

                LisunEngine.RegistryData["setup_done"] = value ? "1" : "0";
                LisunEngine.SaveRegistry();
            }
        }

        /// <summary>Показывает мастер и ждёт, пока его закроют.</summary>
        public static void Run(IWin32Window owner)
        {
            using (LisunSetupForm form = new LisunSetupForm())
            {
                if (owner != null) form.ShowDialog(owner);
                else form.ShowDialog();
            }
        }

        // =====================================================================
        //  Рамка
        // =====================================================================

        private void BuildWindow()
        {
            Text = LisunLocale.T("setup.windowTitle");
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = true;
            BackColor = Theme.Background;
            ForeColor = Theme.Text;
            Font = Theme.Ui(9.5f);
            ClientSize = new Size(880, 620);

            header = new Panel();
            header.BackColor = Theme.Surface;
            header.SetBounds(0, 0, 880, 86);
            Controls.Add(header);

            Panel stripe = new Panel();
            stripe.BackColor = Theme.Accent;
            stripe.SetBounds(0, 0, 880, 4);
            header.Controls.Add(stripe);

            title = new Label();
            title.Font = Theme.Ui(16f, FontStyle.Bold);
            title.ForeColor = Theme.Text;
            title.SetBounds(28, 16, 820, 30);
            header.Controls.Add(title);

            subtitle = new Label();
            subtitle.Font = Theme.Ui(9.5f);
            subtitle.ForeColor = Theme.TextDim;
            subtitle.SetBounds(30, 50, 820, 24);
            header.Controls.Add(subtitle);

            steps = new Panel();
            steps.BackColor = Theme.Surface;
            steps.SetBounds(0, 86, 236, 470);
            Controls.Add(steps);

            content = new Panel();
            content.BackColor = Theme.Background;
            content.SetBounds(236, 86, 644, 470);
            Controls.Add(content);

            status = new Label();
            status.Font = Theme.Mono(8.75f);
            status.ForeColor = Theme.TextDim;
            status.SetBounds(28, 566, 560, 20);
            Controls.Add(status);

            back = new Button();
            back.Text = LisunLocale.T("setup.back");
            back.SetBounds(438, 572, 120, 32);
            Theme.StyleButton(back, Theme.SurfaceAlt, Theme.TextDim);
            back.Click += delegate { Step(-1); };
            Controls.Add(back);

            skip = new Button();
            skip.Text = LisunLocale.T("setup.skip");
            skip.SetBounds(568, 572, 140, 32);
            Theme.StyleButton(skip, Theme.SurfaceAlt, Theme.Text);
            skip.Click += delegate { Step(1); };
            Controls.Add(skip);

            next = new Button();
            next.Text = LisunLocale.T("setup.next");
            next.SetBounds(718, 572, 140, 32);
            Theme.StyleButton(next, Theme.AccentDeep, Theme.Text);
            next.Click += delegate { Advance(); };
            Controls.Add(next);

            FormClosing += delegate (object sender, FormClosingEventArgs e)
            {
                if (installing)
                {
                    e.Cancel = true;
                    SetStatus(LisunLocale.T("setup.waitInstall"));
                    return;
                }

                closing = true;
                Completed = true;
            };
        }

        private void BuildSteps()
        {
            string[] names =
            {
                LisunLocale.T("setup.stepWelcome"),
                LisunLocale.T("setup.stepWifi"),
                LisunLocale.T("setup.stepApps"),
                LisunLocale.T("setup.stepInstall"),
                LisunLocale.T("setup.stepDone")
            };

            Label caption = new Label();
            caption.Text = LisunLocale.T("setup.stepsCaption");
            caption.Font = Theme.Ui(9f, FontStyle.Bold);
            caption.ForeColor = Theme.TextDim;
            caption.SetBounds(24, 20, 200, 20);
            steps.Controls.Add(caption);

            for (int index = 0; index < names.Length; index++)
            {
                Label item = new Label();
                item.Text = "  " + (index + 1) + ".  " + names[index];
                item.Font = Theme.Ui(10f);
                item.ForeColor = Theme.TextDim;
                item.TextAlign = ContentAlignment.MiddleLeft;
                item.SetBounds(16, 54 + index * 42, 208, 34);
                steps.Controls.Add(item);
                stepLabels.Add(item);
            }

            Label hint = new Label();
            hint.Text = LisunLocale.T("setup.stepsHint");
            hint.Font = Theme.Ui(8.5f);
            hint.ForeColor = Theme.TextDim;
            hint.SetBounds(20, 300, 204, 150);
            steps.Controls.Add(hint);
        }

        // =====================================================================
        //  Содержимое шагов
        // =====================================================================

        private void BuildContent()
        {
            // ---------- язык ----------
            welcomeText = new Label();
            welcomeText.Font = Theme.Ui(10.5f);
            welcomeText.ForeColor = Theme.Text;
            welcomeText.SetBounds(28, 24, 580, 180);
            content.Controls.Add(welcomeText);

            russian = new Button();
            russian.Text = "Русский";
            russian.SetBounds(28, 220, 180, 40);
            russian.Click += delegate { ChooseLanguage("ru"); };
            content.Controls.Add(russian);

            english = new Button();
            english.Text = "English";
            english.SetBounds(220, 220, 180, 40);
            english.Click += delegate { ChooseLanguage("en"); };
            content.Controls.Add(english);

            // ---------- сеть ----------
            networkHint = new Label();
            networkHint.Font = Theme.Ui(9.5f);
            networkHint.ForeColor = Theme.TextDim;
            networkHint.SetBounds(28, 20, 580, 44);
            content.Controls.Add(networkHint);

            networks = new ListView();
            networks.View = View.Details;
            networks.FullRowSelect = true;
            networks.MultiSelect = false;
            networks.HideSelection = false;
            networks.BackColor = Theme.Surface;
            networks.ForeColor = Theme.Text;
            networks.BorderStyle = BorderStyle.None;
            networks.Font = Theme.Mono(9.5f);
            networks.SetBounds(28, 70, 580, 220);
            networks.Columns.Add(LisunLocale.T("wifiapp.columnSsid"), 250);
            networks.Columns.Add(LisunLocale.T("wifiapp.columnSignal"), 110);
            networks.Columns.Add(LisunLocale.T("wifiapp.columnSecurity"), 120);
            networks.Columns.Add(LisunLocale.T("wifiapp.columnState"), 90);
            networks.SelectedIndexChanged += delegate { NetworkPicked(); };
            networks.DoubleClick += delegate { Connect(); };
            content.Controls.Add(networks);

            Label passwordCaption = new Label();
            passwordCaption.Text = LisunLocale.T("wifiapp.password");
            passwordCaption.Font = Theme.Ui(9f);
            passwordCaption.ForeColor = Theme.TextDim;
            passwordCaption.SetBounds(28, 300, 200, 20);
            content.Controls.Add(passwordCaption);

            password = new TextBox();
            password.UseSystemPasswordChar = true;
            password.BackColor = Theme.SurfaceAlt;
            password.ForeColor = Theme.Text;
            password.BorderStyle = BorderStyle.FixedSingle;
            password.Font = Theme.Mono(10f);
            password.SetBounds(28, 322, 300, 26);
            content.Controls.Add(password);

            showPassword = new CheckBox();
            showPassword.Text = LisunLocale.T("wifiapp.showPassword");
            showPassword.Font = Theme.Ui(8.75f);
            showPassword.ForeColor = Theme.TextDim;
            showPassword.SetBounds(28, 352, 300, 22);
            showPassword.CheckedChanged += delegate
            {
                password.UseSystemPasswordChar = !showPassword.Checked;
            };
            content.Controls.Add(showPassword);

            connect = new Button();
            connect.Text = LisunLocale.T("wifiapp.connect");
            connect.SetBounds(344, 320, 150, 30);
            Theme.StyleButton(connect, Theme.AccentDeep, Theme.Text);
            connect.Click += delegate { Connect(); };
            content.Controls.Add(connect);

            rescan = new Button();
            rescan.Text = LisunLocale.T("wifiapp.scan");
            rescan.SetBounds(504, 320, 104, 30);
            Theme.StyleButton(rescan, Theme.SurfaceAlt, Theme.Text);
            rescan.Click += delegate { Scan(); };
            content.Controls.Add(rescan);

            online = new Label();
            online.Font = Theme.Mono(9f);
            online.ForeColor = Theme.TextDim;
            online.SetBounds(28, 386, 580, 44);
            content.Controls.Add(online);

            // ---------- приложения ----------
            appsHint = new Label();
            appsHint.Font = Theme.Ui(9.5f);
            appsHint.ForeColor = Theme.TextDim;
            appsHint.SetBounds(28, 20, 580, 44);
            content.Controls.Add(appsHint);

            apps = new CheckedListBox();
            apps.BackColor = Theme.Surface;
            apps.ForeColor = Theme.Text;
            apps.BorderStyle = BorderStyle.None;
            apps.Font = Theme.Mono(9.5f);
            apps.CheckOnClick = true;
            apps.ItemHeight = 22;
            apps.SetBounds(28, 70, 580, 286);
            apps.ItemCheck += delegate { BeginInvoke((Action)ShowChosen); };
            content.Controls.Add(apps);

            selectAll = new Button();
            selectAll.Text = LisunLocale.T("setup.selectAll");
            selectAll.SetBounds(28, 368, 170, 30);
            Theme.StyleButton(selectAll, Theme.SurfaceAlt, Theme.Text);
            selectAll.Click += delegate { CheckEvery(true); };
            content.Controls.Add(selectAll);

            selectNone = new Button();
            selectNone.Text = LisunLocale.T("setup.selectNone");
            selectNone.SetBounds(208, 368, 170, 30);
            Theme.StyleButton(selectNone, Theme.SurfaceAlt, Theme.TextDim);
            selectNone.Click += delegate { CheckEvery(false); };
            content.Controls.Add(selectNone);

            refresh = new Button();
            refresh.Text = LisunLocale.T("setup.refresh");
            refresh.SetBounds(388, 368, 220, 30);
            Theme.StyleButton(refresh, Theme.SurfaceAlt, Theme.Text);
            refresh.Click += delegate { LoadCatalog(true); };
            content.Controls.Add(refresh);

            // ---------- установка ----------
            installTitle = new Label();
            installTitle.Font = Theme.Ui(10f);
            installTitle.ForeColor = Theme.Text;
            installTitle.SetBounds(28, 20, 580, 44);
            content.Controls.Add(installTitle);

            progress = new ProgressBar();
            progress.Minimum = 0;
            progress.Maximum = 100;
            progress.SetBounds(28, 70, 580, 18);
            content.Controls.Add(progress);

            journal = new ListBox();
            journal.BackColor = Theme.Surface;
            journal.ForeColor = Theme.Cyan;
            journal.BorderStyle = BorderStyle.None;
            journal.Font = Theme.Mono(9f);
            journal.ItemHeight = 20;
            journal.SetBounds(28, 100, 580, 320);
            content.Controls.Add(journal);
        }

        // =====================================================================
        //  Переключение шагов
        // =====================================================================

        private void ShowStage(Stage value)
        {
            stage = value;

            for (int index = 0; index < stepLabels.Count; index++)
            {
                bool current = Order[index] == stage;
                bool passed = index < IndexOf(stage);

                stepLabels[index].ForeColor = current ? Theme.Text
                                            : passed ? Theme.Success
                                                     : Theme.TextDim;
                stepLabels[index].Font = Theme.Ui(10f, current ? FontStyle.Bold : FontStyle.Regular);
                stepLabels[index].BackColor = current ? Theme.SurfaceHot : Theme.Surface;
            }

            bool welcome = stage == Stage.Welcome;
            bool wifi = stage == Stage.Wifi;
            bool appsStage = stage == Stage.Apps;
            bool install = stage == Stage.Install;
            bool done = stage == Stage.Done;

            welcomeText.Visible = welcome;
            russian.Visible = welcome;
            english.Visible = welcome;

            networkHint.Visible = wifi;
            networks.Visible = wifi;
            password.Visible = wifi;
            showPassword.Visible = wifi;
            connect.Visible = wifi;
            online.Visible = wifi;

            rescan.Visible = wifi;

            appsHint.Visible = appsStage;
            apps.Visible = appsStage;
            selectAll.Visible = appsStage;
            selectNone.Visible = appsStage;
            refresh.Visible = appsStage;

            installTitle.Visible = install || done;
            progress.Visible = install || done;
            journal.Visible = install || done;

            back.Enabled = stage != Stage.Welcome && stage != Stage.Done && !installing;
            skip.Visible = wifi || appsStage;

            next.Text = install ? LisunLocale.T("setup.install")
                      : done ? LisunLocale.T("setup.finish")
                             : LisunLocale.T("setup.next");

            title.Text = Title(stage);
            subtitle.Text = LisunLocale.T("setup.stepOf", IndexOf(stage) + 1, Order.Length) +
                            "   ·   " + Subtitle(stage);

            switch (stage)
            {
                case Stage.Welcome:
                    welcomeText.Text = LisunLocale.T("setup.welcomeBody",
                        LisunEngine.Version, LisunVersions.Current);
                    SetStatus(LisunLocale.T("setup.welcomeStatus"));
                    break;

                case Stage.Wifi:
                    networkHint.Text = LisunLocale.T("setup.wifiHint");
                    ShowOnline();
                    if (networks.Items.Count == 0) Scan();
                    break;

                case Stage.Apps:
                    appsHint.Text = LisunLocale.T("setup.appsHint");
                    if (apps.Items.Count == 0) LoadCatalog(false);
                    ShowChosen();
                    break;

                case Stage.Install:
                    installTitle.Text = LisunLocale.T("setup.installReady", Chosen().Count);
                    SetStatus(LisunLocale.T("setup.installHint"));
                    break;

                case Stage.Done:
                    installTitle.Text = LisunLocale.T("setup.doneBody", installed, failed);
                    SetStatus(LisunLocale.T("setup.doneStatus"));
                    break;
            }
        }

        private static int IndexOf(Stage value)
        {
            for (int index = 0; index < Order.Length; index++)
                if (Order[index] == value) return index;

            return 0;
        }

        private string Title(Stage value)
        {
            switch (value)
            {
                case Stage.Welcome: return LisunLocale.T("setup.titleWelcome");
                case Stage.Wifi: return LisunLocale.T("setup.titleWifi");
                case Stage.Apps: return LisunLocale.T("setup.titleApps");
                case Stage.Install: return LisunLocale.T("setup.titleInstall");
                default: return LisunLocale.T("setup.titleDone");
            }
        }

        private string Subtitle(Stage value)
        {
            switch (value)
            {
                case Stage.Welcome: return LisunLocale.T("setup.subWelcome");
                case Stage.Wifi: return LisunLocale.T("setup.subWifi");
                case Stage.Apps: return LisunLocale.T("setup.subApps");
                case Stage.Install: return LisunLocale.T("setup.subInstall");
                default: return LisunLocale.T("setup.subDone");
            }
        }

        private void Step(int delta)
        {
            int index = IndexOf(stage) + delta;
            if (index < 0) index = 0;
            if (index >= Order.Length) index = Order.Length - 1;

            ShowStage(Order[index]);
        }

        private void Advance()
        {
            if (stage == Stage.Install)
            {
                StartInstall();
                return;
            }

            if (stage == Stage.Done)
            {
                Completed = true;
                Close();
                return;
            }

            Step(1);
        }

        private void SetStatus(string text)
        {
            if (status == null) return;

            status.Text = " " + (text ?? string.Empty).Trim();
        }

        private void OnUi(Action action)
        {
            if (closing || IsDisposed) return;

            try
            {
                if (InvokeRequired) BeginInvoke(action);
                else action();
            }
            catch { }
        }

        // =====================================================================
        //  Шаг «язык»
        // =====================================================================

        private void ChooseLanguage(string code)
        {
            LisunLocale.SetLanguage(code);
            LisunCommandTree.Reset();

            SetStatus(LisunLocale.T("setup.languageSet"));

            // Тексты собраны при создании окна — пересобираем их целиком.
            Text = LisunLocale.T("setup.windowTitle");
            back.Text = LisunLocale.T("setup.back");
            skip.Text = LisunLocale.T("setup.skip");
            connect.Text = LisunLocale.T("wifiapp.connect");
            selectAll.Text = LisunLocale.T("setup.selectAll");
            selectNone.Text = LisunLocale.T("setup.selectNone");
            refresh.Text = LisunLocale.T("setup.refresh");
            showPassword.Text = LisunLocale.T("wifiapp.showPassword");

            for (int index = 0; index < stepLabels.Count; index++)
            {
                string[] names =
                {
                    LisunLocale.T("setup.stepWelcome"),
                    LisunLocale.T("setup.stepWifi"),
                    LisunLocale.T("setup.stepApps"),
                    LisunLocale.T("setup.stepInstall"),
                    LisunLocale.T("setup.stepDone")
                };

                stepLabels[index].Text = "  " + (index + 1) + ".  " + names[index];
            }

            ShowStage(stage);
        }

        // =====================================================================
        //  Шаг «сеть»
        // =====================================================================

        private void Scan()
        {
            if (scanning) return;

            scanning = true;
            SetStatus(LisunLocale.T("wifiapp.scanning"));

            Thread worker = new Thread(delegate ()
            {
                List<WifiNetwork> list;
                try { list = LisunWifi.Scan(); }
                catch { list = new List<WifiNetwork>(); }

                OnUi(delegate
                {
                    scanning = false;
                    FillNetworks(list);
                    ShowOnline();

                    SetStatus(list.Count == 0
                        ? LisunLocale.T("wifiapp.nothingFound")
                        : LisunLocale.T("wifiapp.found", list.Count));
                });
            });

            worker.IsBackground = true;
            worker.Name = "SetupWifiScan";
            worker.Start();
        }

        private void FillNetworks(List<WifiNetwork> list)
        {
            networks.BeginUpdate();
            networks.Items.Clear();
            found.Clear();

            foreach (WifiNetwork network in list)
            {
                ListViewItem row = new ListViewItem(network.Ssid.Length > 0
                    ? network.Ssid
                    : LisunLocale.T("wifiapp.hidden"));

                row.SubItems.Add(Bars(network.Signal) + "  " + network.Signal + " %");
                row.SubItems.Add(network.Enterprise ? LisunLocale.T("wifiapp.secEnterprise")
                                : network.Open ? LisunLocale.T("wifiapp.secOpen")
                                               : LisunLocale.T("wifiapp.secClosed"));
                row.SubItems.Add(network.Connected ? LisunLocale.T("wifiapp.stateConnected") : "—");

                if (network.Connected) row.ForeColor = Theme.Success;

                networks.Items.Add(row);
                found.Add(network);
            }

            networks.EndUpdate();

            if (networks.Items.Count > 0 && networks.SelectedIndices.Count == 0)
                networks.Items[0].Selected = true;
        }

        private static string Bars(int signal)
        {
            int level = signal >= 80 ? 4 : signal >= 60 ? 3 : signal >= 40 ? 2 : signal >= 20 ? 1 : 0;

            StringBuilder sb = new StringBuilder(4);
            for (int index = 0; index < 4; index++) sb.Append(index < level ? '█' : '░');

            return sb.ToString();
        }

        private WifiNetwork Selected()
        {
            if (networks.SelectedIndices.Count == 0) return null;

            int index = networks.SelectedIndices[0];
            if (index < 0 || index >= found.Count) return null;

            return found[index];
        }

        private void NetworkPicked()
        {
            WifiNetwork network = Selected();
            if (network == null) return;

            password.Enabled = !network.Open;

            SetStatus(network.Open
                ? LisunLocale.T("wifiapp.openHint", network.Ssid)
                : LisunLocale.T("wifiapp.closedHint", network.Ssid));
        }

        private void Connect()
        {
            WifiNetwork network = Selected();

            if (network == null)
            {
                SetStatus(LisunLocale.T("wifiapp.pickNetwork"));
                return;
            }

            if (!network.Open && password.Text.Length == 0)
            {
                SetStatus(LisunLocale.T("wifiapp.needPassword", network.Ssid));
                password.Focus();
                return;
            }

            string ssid = network.Ssid;
            string secret = password.Text;

            connect.Enabled = false;
            SetStatus(LisunLocale.T("wifiapp.connecting", ssid));

            Thread worker = new Thread(delegate ()
            {
                string message;
                try { LisunWifi.Connect(ssid, secret, out message); }
                catch (Exception ex) { message = ex.Message; }

                OnUi(delegate
                {
                    connect.Enabled = true;
                    password.Text = string.Empty;

                    SetStatus(message.Trim());
                    ShowOnline();
                    Scan();
                });
            });

            worker.IsBackground = true;
            worker.Name = "SetupWifiConnect";
            worker.Start();
        }

        private void ShowOnline()
        {
            if (LisunWifi.Online)
            {
                online.Text = LisunLocale.T("setup.online");
                online.ForeColor = Theme.Success;
            }
            else
            {
                online.Text = LisunLocale.T("setup.offline");
                online.ForeColor = Theme.TextDim;
            }
        }

        // =====================================================================
        //  Шаг «приложения»
        // =====================================================================

        private void LoadCatalog(bool force)
        {
            SetStatus(LisunLocale.T("setup.catalogReading"));

            refresh.Enabled = false;

            Thread worker = new Thread(delegate ()
            {
                string message = string.Empty;

                if (force || LisunStore.Remote().Count == 0)
                {
                    try { LisunStore.Refresh(PackageName, out message); }
                    catch (Exception ex) { message = ex.Message; }
                }

                List<LisunStore.StoreItem> list;
                try { list = LisunStore.Items(); }
                catch { list = new List<LisunStore.StoreItem>(); }

                OnUi(delegate
                {
                    refresh.Enabled = true;
                    FillApps(list);

                    SetStatus(list.Count == 0
                        ? LisunLocale.T("setup.catalogEmpty")
                        : LisunLocale.T("setup.catalogRead", list.Count));
                });
            });

            worker.IsBackground = true;
            worker.Name = "SetupCatalog";
            worker.Start();
        }

        private void FillApps(List<LisunStore.StoreItem> list)
        {
            apps.BeginUpdate();
            apps.Items.Clear();
            catalog.Clear();

            foreach (LisunStore.StoreItem item in list)
            {
                string label = Pad(item.Name, 16) + Pad(item.Version, 8) +
                               (item.Title.Length > 0 ? item.Title : item.Description);

                if (item.Installed) label += "   " + LisunLocale.T("setup.alreadyInstalled");

                catalog.Add(item);
                apps.Items.Add(label, !item.Installed);
            }

            apps.EndUpdate();
            ShowChosen();
        }

        private void CheckEvery(bool value)
        {
            for (int index = 0; index < apps.Items.Count; index++)
                apps.SetItemChecked(index, value);

            ShowChosen();
        }

        private List<LisunStore.StoreItem> Chosen()
        {
            List<LisunStore.StoreItem> list = new List<LisunStore.StoreItem>();

            for (int index = 0; index < catalog.Count && index < apps.Items.Count; index++)
                if (apps.GetItemChecked(index)) list.Add(catalog[index]);

            return list;
        }

        private void ShowChosen()
        {
            if (stage != Stage.Apps) return;

            SetStatus(LisunLocale.T("setup.chosen", Chosen().Count, catalog.Count));
        }

        // =====================================================================
        //  Шаг «установка»
        // =====================================================================

        private void StartInstall()
        {
            if (installing) return;

            List<LisunStore.StoreItem> chosen = Chosen();

            if (chosen.Count == 0)
            {
                SetStatus(LisunLocale.T("setup.nothingChosen"));
                ShowStage(Stage.Done);
                return;
            }

            installing = true;
            installed = 0;
            failed = 0;

            next.Enabled = false;
            back.Enabled = false;

            journal.Items.Clear();
            progress.Value = 0;

            installTitle.Text = LisunLocale.T("setup.installing", chosen.Count);

            Thread worker = new Thread(delegate ()
            {
                for (int index = 0; index < chosen.Count; index++)
                {
                    LisunStore.StoreItem item = chosen[index];
                    int step = index;

                    OnUi(delegate
                    {
                        journal.Items.Add(LisunLocale.T("setup.installingOne", item.Name));
                        journal.TopIndex = journal.Items.Count - 1;
                        progress.Value = Math.Min(100, step * 100 / Math.Max(1, chosen.Count));
                        SetStatus(LisunLocale.T("setup.installingOne", item.Name));
                    });

                    string message;
                    bool ok;

                    try { ok = LisunStore.Install(item, false, out message); }
                    catch (Exception ex) { ok = false; message = ex.Message; }

                    if (ok) installed++;
                    else failed++;

                    string line = (ok ? "  [OK]  " : "  [--]  ") + item.Name + "   " + message.Trim();

                    OnUi(delegate
                    {
                        journal.Items.Add(line);
                        journal.TopIndex = journal.Items.Count - 1;
                    });
                }

                OnUi(delegate
                {
                    installing = false;
                    next.Enabled = true;
                    progress.Value = 100;

                    ShowStage(Stage.Done);
                });
            });

            worker.IsBackground = true;
            worker.Name = "SetupInstall";
            worker.Start();
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value.Substring(0, width - 1) + " " : value.PadRight(width);
        }
    }
}
