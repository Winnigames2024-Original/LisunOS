﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Сторож отзывчивости.
    ///
    /// Про «тормозит» нельзя спорить словами: нужно знать, что именно и на
    /// сколько задержало окно. Здесь это и измеряется. В потоке окна тикает
    /// таймер на сто миллисекунд; если очередной тик пришёл позже, чем через
    /// треть секунды, значит поток был занят — и мы записываем, чем именно:
    /// то, что в этот момент было отмечено через Mark.
    ///
    /// Команда «perf» показывает, где система зависала, и заодно замеряет
    /// привычные операции: подсказку, опрос адаптеров, список пакетов.
    /// </summary>
    public static class LisunPerf
    {
        /// <summary>Задержка, начиная с которой считаем, что окно подвисло.</summary>
        public const int StallMilliseconds = 350;

        private const int TickMilliseconds = 100;
        private const int Keep = 40;

        /// <summary>Одно подвисание: что делалось и сколько это заняло.</summary>
        public sealed class Stall
        {
            public DateTime When;
            public int Milliseconds;
            public string What = string.Empty;

            public override string ToString()
            {
                return When.ToString("HH:mm:ss") + "  " + Milliseconds + " мс  " + What;
            }
        }

        private static readonly object gate = new object();
        private static readonly List<Stall> stalls = new List<Stall>();
        private static readonly Stopwatch clock = Stopwatch.StartNew();

        private static Timer timer;
        private static long lastTick;
        private static string current = string.Empty;
        private static long currentSince;

        private static long worst;
        private static string worstWhat = string.Empty;
        private static long ticks;

        /// <summary>Включён ли сторож.</summary>
        public static bool Watching
        {
            get { return timer != null; }
        }

        /// <summary>Ставит сторож в поток окна. Вызывается один раз при старте.</summary>
        public static void Attach()
        {
            if (timer != null) return;

            timer = new Timer();
            timer.Interval = TickMilliseconds;
            timer.Tick += delegate { Tick(); };

            lastTick = clock.ElapsedMilliseconds;
            timer.Start();
        }

        public static void Detach()
        {
            if (timer == null) return;

            try { timer.Stop(); timer.Dispose(); }
            catch { }

            timer = null;
        }

        /// <summary>Отмечает, чем система занята прямо сейчас.</summary>
        public static void Mark(string what)
        {
            lock (gate)
            {
                current = what ?? string.Empty;
                currentSince = clock.ElapsedMilliseconds;
            }
        }

        /// <summary>Работа закончена — отметка снимается.</summary>
        public static void Done()
        {
            lock (gate)
            {
                current = string.Empty;
                currentSince = 0;
            }
        }

        /// <summary>Отметка на время блока: using (LisunPerf.Section("…")).</summary>
        public static IDisposable Section(string what)
        {
            Mark(what);
            return new Marker();
        }

        private sealed class Marker : IDisposable
        {
            public void Dispose() { Done(); }
        }

        // =====================================================================
        //  Измерение
        // =====================================================================

        private static void Tick()
        {
            long now = clock.ElapsedMilliseconds;
            long gap = now - lastTick;
            lastTick = now;
            ticks++;

            if (gap < StallMilliseconds) return;

            string what;
            lock (gate)
            {
                what = current.Length > 0
                    ? current
                    : LisunLocale.T("perf.unknown");

                if (gap > worst)
                {
                    worst = gap;
                    worstWhat = what;
                }

                Stall stall = new Stall();
                stall.When = DateTime.Now;
                stall.Milliseconds = (int)gap;
                stall.What = what;

                stalls.Add(stall);
                while (stalls.Count > Keep) stalls.RemoveAt(0);
            }

            // В журнал — только заметные задержки, иначе он зарастёт.
            if (gap >= StallMilliseconds * 2)
                LisunEngine.Log("[perf] " + LisunLocale.T("perf.stall", gap, what).Trim());
        }

        public static List<Stall> Recent()
        {
            lock (gate) return new List<Stall>(stalls);
        }

        public static void Forget()
        {
            lock (gate)
            {
                stalls.Clear();
                worst = 0;
                worstWhat = string.Empty;
            }
        }

        // =====================================================================
        //  Отчёт
        // =====================================================================

        /// <summary>Что подвисало и насколько.</summary>
        public static string ReportText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("perf.header"));
            sb.AppendLine();

            sb.AppendLine("   " + LisunLocale.T("perf.watching",
                Watching ? LisunLocale.T("word.on") : LisunLocale.T("word.off"), StallMilliseconds));
            sb.AppendLine("   " + LisunLocale.T("perf.ticks", ticks));

            List<Stall> list = Recent();

            if (list.Count == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("perf.none"));
            }
            else
            {
                sb.AppendLine("   " + LisunLocale.T("perf.worst", worst, worstWhat));
                sb.AppendLine();
                sb.AppendLine("   " + LisunLocale.T("perf.recent"));

                int start = list.Count > 12 ? list.Count - 12 : 0;

                for (int index = start; index < list.Count; index++)
                    sb.AppendLine("      " + list[index]);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("perf.hint"));

            return sb.ToString();
        }

        /// <summary>Замеряет привычные операции здесь и сейчас.</summary>
        public static string MeasureText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("perf.measureHeader"));
            sb.AppendLine();

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opSuggest"), delegate
            {
                LisunCommandTree.Suggest("wifi connect ");
            }));

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opAdapters"), delegate
            {
                LisunNetwork.Adapters();
            }));

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opWifi"), delegate
            {
                LisunWifi.CurrentSsid();
            }));

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opPackages"), delegate
            {
                LisunOSInstallerShell.InstalledPackageDirectories();
            }));

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opCatalog"), delegate
            {
                LisunStore.Items();
            }));

            sb.AppendLine("   " + Row(LisunLocale.T("perf.opComponents"), delegate
            {
                foreach (LisunComponent component in LisunLibraries.Items())
                    LisunLibraries.Installed(component);
            }));

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("perf.journal", LisunEngine.SystemLog.Count, LisunEngine.LogLimit));
            sb.AppendLine("   " + LisunLocale.T("perf.memory",
                CustomFormUtils.FormatSize(GC.GetTotalMemory(false))));
            sb.AppendLine("   " + LisunLocale.T("perf.apps", FormEngine.ActiveApps.Count));

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("perf.measureHint"));

            return sb.ToString();
        }

        private static string Row(string name, Action action)
        {
            Stopwatch watch = Stopwatch.StartNew();

            try { action(); }
            catch { }

            watch.Stop();

            string value = watch.ElapsedMilliseconds >= 1
                ? watch.ElapsedMilliseconds.ToString(CultureInfo.InvariantCulture) + " " + LisunLocale.T("perf.ms")
                : "<1 " + LisunLocale.T("perf.ms");

            string mark = watch.ElapsedMilliseconds >= StallMilliseconds ? "  ←  " + LisunLocale.T("perf.slow")
                        : watch.ElapsedMilliseconds >= 80 ? "  ←  " + LisunLocale.T("perf.notFast")
                                                          : string.Empty;

            return Pad(name, 34) + Pad(value, 10) + mark;
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value + " " : value.PadRight(width);
        }
    }
}
