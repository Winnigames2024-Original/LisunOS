﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика шаблонного приложения LisunOS (пакет apps/template).
    /// Пример того, как мост связывает контролы из designer-файла
    /// с кодом: обработчики, реестр, разрешения и журнал ядра.
    /// </summary>
    public partial class TemplateLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly TextBox name;
        private readonly CheckBox save;
        private readonly Button hello;
        private readonly Button count;
        private readonly Button clear;
        private readonly ListBox log;
        private readonly Label status;

        public TemplateLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            name = context.Get<TextBox>("txtName");
            save = context.Get<CheckBox>("chkSave");
            hello = context.Get<Button>("btnHello");
            count = context.Get<Button>("btnCount");
            clear = context.Get<Button>("btnClear");
            log = context.Get<ListBox>("lstLog");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("tpl.title");

            if (log != null)
            {
                log.Font = Theme.Mono(9.5f);
                log.ItemHeight = 18;
            }

            if (name != null) name.Font = Theme.Mono(10.5f);
            if (status != null) status.Font = Theme.Mono(9f);

            if (hello != null) Theme.StyleButton(hello, Theme.AccentDeep, Theme.Text);
            if (count != null) Theme.StyleButton(count, Theme.SurfaceAlt, Theme.Text);
            if (clear != null) Theme.StyleButton(clear, Theme.SurfaceAlt, Theme.TextDim);

            // Имя и состояние флажка восстанавливаются из реестра LisunOS.
            string stored;
            if (name != null && LisunEngine.RegistryData.TryGetValue("template_name", out stored))
            {
                name.Text = stored;
                if (save != null) save.Checked = true;
            }

            Append(LisunLocale.T("tpl.ready"));
            UpdateStatus();
        }

        private void Append(string message)
        {
            if (log == null || log.IsDisposed) return;

            log.Items.Insert(0, DateTime.Now.ToString("HH:mm:ss") + "   " + message);
            while (log.Items.Count > 200) log.Items.RemoveAt(log.Items.Count - 1);
        }

        private void UpdateStatus()
        {
            if (status == null) return;

            status.Text = LisunLocale.T("tpl.status", Counter, FormEngine.ActiveApps.Count);
        }

        private long Counter
        {
            get
            {
                string value;
                if (!LisunEngine.RegistryData.TryGetValue("template_counter", out value)) return 0;

                long parsed;
                return long.TryParse(value, out parsed) ? parsed : 0;
            }
        }

        // ---------- обработчики из designer-файла ----------

        private void btnHello_Click(object sender, EventArgs e)
        {
            string person = name == null ? "" : name.Text.Trim();
            if (person.Length == 0) person = LisunEngine.UserName;

            Append(LisunLocale.T("tpl.hello", person));

            // Диалог — право show_dialogs.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ShowDialogs)) return;

            MessageBox.Show(LisunLocale.T("tpl.hello", person), LisunLocale.T("tpl.title"),
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            // Запись в реестр — право edit_settings.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings))
            {
                Append(LisunLocale.T("perm.denied", packageName, LisunPermissions.EditSettings).Trim());
                return;
            }

            long next = Counter + 1;

            LisunEngine.RegistryData["template_counter"] = next.ToString();
            LisunEngine.SaveRegistry();

            Append(LisunLocale.T("tpl.counted", next));
            UpdateStatus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (log != null) log.Items.Clear();
            Append(LisunLocale.T("tpl.cleared"));
        }

        private void chkSave_CheckedChanged(object sender, EventArgs e)
        {
            if (save == null) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings))
            {
                save.Checked = false;
                return;
            }

            if (save.Checked)
            {
                LisunEngine.RegistryData["template_name"] = name == null ? "" : name.Text.Trim();
                Append(LisunLocale.T("tpl.saved"));
            }
            else
            {
                LisunEngine.RegistryData.Remove("template_name");
                Append(LisunLocale.T("tpl.forgotten"));
            }

            LisunEngine.SaveRegistry();
        }
    }
}
