﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика Каталога приложений (пакет apps/storeapp).
    /// Показывает встроенные пакеты и каталог из сети, ставит и удаляет их.
    /// </summary>
    public partial class StoreLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly ListView packages;
        private readonly Label packageName_;
        private readonly Label packageInfo;
        private readonly Label packageRights;
        private readonly Label status;
        private readonly Label title;
        private readonly Label subtitle;
        private readonly Button install;
        private readonly Button remove;
        private readonly Button run;
        private readonly Button refresh;

        private List<LisunStore.StoreItem> items = new List<LisunStore.StoreItem>();
        private bool busy;

        public StoreLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            packages = context.Get<ListView>("lstPackages");
            packageName_ = context.Get<Label>("lblPackageName");
            packageInfo = context.Get<Label>("lblPackageInfo");
            packageRights = context.Get<Label>("lblPackageRights");
            status = context.Get<Label>("lblStatus");
            title = context.Get<Label>("lblTitle");
            subtitle = context.Get<Label>("lblSubtitle");
            install = context.Get<Button>("btnInstall");
            remove = context.Get<Button>("btnRemove");
            run = context.Get<Button>("btnRun");
            refresh = context.Get<Button>("btnRefresh");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("store.windowTitle");
            if (title != null)
            {
                title.Text = LisunLocale.T("store.windowTitle");
                title.Font = Theme.Ui(14f, System.Drawing.FontStyle.Bold);
            }
            if (subtitle != null) subtitle.Text = LisunLocale.T("store.subtitle");

            if (packageName_ != null) packageName_.Font = Theme.Ui(12f, System.Drawing.FontStyle.Bold);
            if (packageInfo != null) packageInfo.Font = Theme.Ui(9f);
            if (packageRights != null) packageRights.Font = Theme.Mono(8.5f);
            if (status != null) status.Font = Theme.Mono(8.75f);

            if (packages != null)
            {
                packages.Font = Theme.Mono(9.5f);
                packages.Columns.Add(LisunLocale.T("store.columnName"), 150);
                packages.Columns.Add(LisunLocale.T("store.columnVersion"), 80);
                packages.Columns.Add(LisunLocale.T("store.columnState"), 120);
                packages.Columns.Add(LisunLocale.T("store.columnTitle"), 160);
            }

            if (install != null) Theme.StyleButton(install, Theme.AccentDeep, Theme.Text);
            if (run != null) Theme.StyleButton(run, Theme.SurfaceAlt, Theme.Text);
            if (remove != null) Theme.StyleButton(remove, Theme.SurfaceAlt, Theme.TextDim);
            if (refresh != null) Theme.StyleButton(refresh, Theme.SurfaceAlt, Theme.Text);

            FillList();
            SetStatus(LisunLocale.T("store.ready"));
        }

        // =====================================================================
        //  Список
        // =====================================================================

        private void FillList()
        {
            if (packages == null) return;

            items = LisunStore.Items();

            packages.BeginUpdate();
            packages.Items.Clear();

            foreach (LisunStore.StoreItem item in items)
            {
                ListViewItem row = new ListViewItem(item.Name);
                row.SubItems.Add(item.Version.Length == 0 ? "—" : item.Version);

                row.SubItems.Add(item.Installed
                    ? LisunLocale.T("store.installed", item.InstalledVersion)
                    : item.BuiltIn ? LisunLocale.T("store.builtIn") : LisunLocale.T("store.available"));

                row.SubItems.Add(item.Title);
                row.Tag = item;

                if (item.Installed) row.ForeColor = Theme.Success;
                else if (!item.BuiltIn) row.ForeColor = Theme.Cyan;

                packages.Items.Add(row);
            }

            packages.EndUpdate();

            if (packages.Items.Count > 0) packages.Items[0].Selected = true;
            ShowCard();
        }

        private LisunStore.StoreItem Selected
        {
            get
            {
                if (packages == null || packages.SelectedItems.Count == 0) return null;
                return packages.SelectedItems[0].Tag as LisunStore.StoreItem;
            }
        }

        private void ShowCard()
        {
            LisunStore.StoreItem item = Selected;

            if (item == null)
            {
                if (packageName_ != null) packageName_.Text = string.Empty;
                if (packageInfo != null) packageInfo.Text = string.Empty;
                if (packageRights != null) packageRights.Text = string.Empty;
                return;
            }

            if (packageName_ != null)
                packageName_.Text = item.Title.Length > 0 ? item.Title : item.Name;

            if (packageInfo != null)
            {
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.AppendLine(item.Description);
                sb.AppendLine();
                sb.AppendLine(LisunLocale.T("store.cardName", item.Name));
                sb.AppendLine(LisunLocale.T("store.cardVersion",
                    item.Version.Length == 0 ? "—" : item.Version));

                if (item.Author.Length > 0) sb.AppendLine(LisunLocale.T("store.cardAuthor", item.Author));
                if (item.Command.Length > 0) sb.AppendLine(LisunLocale.T("store.cardCommand", item.Command));

                sb.AppendLine(LisunLocale.T("store.cardSource",
                    LisunLocale.T(item.BuiltIn ? "store.sourceBuiltIn" : "store.sourceNetwork")));

                packageInfo.Text = sb.ToString().TrimEnd();
            }

            if (packageRights != null)
            {
                packageRights.Text = item.Permissions.Count == 0
                    ? LisunLocale.T("store.noRights")
                    : LisunLocale.T("store.rights", string.Join(", ", item.Permissions.ToArray()));
            }

            if (install != null) install.Enabled = !busy && !item.Installed;
            if (remove != null) remove.Enabled = !busy && item.Installed;
            if (run != null) run.Enabled = !busy && item.Installed && item.Command.Length > 0;
        }

        private void SetStatus(string text)
        {
            if (status != null && !status.IsDisposed) status.Text = (text ?? string.Empty).Trim();
        }

        private void SetBusy(bool state)
        {
            busy = state;

            if (refresh != null) refresh.Enabled = !state;
            if (install != null) install.Enabled = !state;
            if (remove != null) remove.Enabled = !state;
            if (run != null) run.Enabled = !state;
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        private void lstPackages_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowCard();
        }

        private void lstPackages_DoubleClick(object sender, EventArgs e)
        {
            LisunStore.StoreItem item = Selected;
            if (item == null) return;

            if (item.Installed) btnRun_Click(sender, e);
            else btnInstall_Click(sender, e);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (busy) return;

            SetBusy(true);
            SetStatus(LisunLocale.T("store.refreshing"));

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                string message;
                LisunStore.Refresh(packageName, out message);

                LisunEngine.RunOnUi(() =>
                {
                    SetBusy(false);
                    FillList();
                    SetStatus(message);
                });
            });
        }

        private void btnInstall_Click(object sender, EventArgs e)
        {
            LisunStore.StoreItem item = Selected;
            if (item == null || busy)
            {
                SetStatus(LisunLocale.T("store.pickFirst"));
                return;
            }

            SetBusy(true);
            SetStatus(LisunLocale.T("store.installing", item.Name));

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                string message;
                bool ok;

                try { ok = LisunStore.Install(item, false, out message); }
                catch (Exception ex)
                {
                    ok = false;
                    message = " [ERROR] " + ex.Message;
                }

                LisunEngine.RunOnUi(() =>
                {
                    SetBusy(false);
                    FillList();
                    SetStatus(message);

                    if (ok) LisunEngine.RequestSoftRestart();
                });
            });
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            LisunStore.StoreItem item = Selected;
            if (item == null || !item.Installed) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageFiles)) return;

            DialogResult answer = MessageBox.Show(
                LisunLocale.T("store.removeAsk", item.Name),
                LisunLocale.T("store.windowTitle"),
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (answer != DialogResult.Yes) return;

            bool removed = LisunOSInstallerShell.UninstallPackage(item.Name);

            FillList();
            SetStatus(LisunLocale.T(removed ? "store.removed" : "store.removeFailed", item.Name));
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            LisunStore.StoreItem item = Selected;
            if (item == null || !item.Installed) return;

            string command = item.Command.Length > 0 ? item.Command : item.Name.ToLowerInvariant();

            SetStatus(CommandExecutorEngine.Execute(command));
        }
    }
}
