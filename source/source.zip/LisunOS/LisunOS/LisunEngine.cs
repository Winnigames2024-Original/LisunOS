﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using Microsoft.Win32;

namespace LisunOS
{
    public static class LisunEngine
    {
        public const string Version = "1.5.1";
        public const string Codename = "Aurora";

        public static readonly string RootPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "files", "os");
        public static readonly string ServicesPath = Path.Combine(RootPath, "sys", "services");

        public static readonly string RegeditPath = Path.Combine(RootPath, "root", "regedit");
        public static readonly string TempPath = Path.Combine(RootPath, "temp");

        /// <summary>Языковые пакеты интерфейса: /os/sys/locale/</summary>
        public static readonly string LocalePath = Path.Combine(RootPath, "sys", "locale");
        public static readonly string RegConfigFilePath = Path.Combine(RegeditPath, "CONFIG");
        public static readonly string RegDataFilePath = Path.Combine(RegeditPath, "DATA");
        public static readonly string RegCommandsFilePath = Path.Combine(RegeditPath, "COMMANDS");

        public static Dictionary<string, object> Assets { get; private set; }
        public static Dictionary<string, List<string>> RegisteredCommands { get; private set; }
        public static Dictionary<string, string> RegistryConfig { get; private set; }
        public static Dictionary<string, string> RegistryData { get; private set; }

        public static List<string> SystemLog { get; private set; }

        public static event Action<string> OnLogAdded;

        /// <summary>Оболочка подставляет сюда открытие адреса во встроенном браузере.</summary>
        public static Func<string, bool> ShellBrowserOpener { get; set; }
        public static event Action OnSoftRestartRequested;

        private static readonly Stopwatch Uptime = Stopwatch.StartNew();
        private static bool isInitialized;

        /// <summary>Контрол UI-потока. Нужен, чтобы создавать формы сервисов там, где живёт цикл сообщений.</summary>
        public static Control UiHost { get; set; }

        static LisunEngine()
        {
            Assets = new Dictionary<string, object>();
            RegisteredCommands = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            RegistryConfig = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            RegistryData = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            SystemLog = new List<string>();
        }

        public static TimeSpan UptimeValue { get { return Uptime.Elapsed; } }

        public static string UserName
        {
            get
            {
                string value;
                if (RegistryData.TryGetValue("user_name", out value) && !string.IsNullOrEmpty(value)) return value;
                return "user";
            }
        }

        public static void Log(string message)
        {
            string formatted = string.Format("[{0:HH:mm:ss}] {1}", DateTime.Now, message);
            SystemLog.Add(formatted);

            Action<string> handler = OnLogAdded;
            if (handler != null) handler(formatted);
        }

        /// <summary>Выполняет действие в UI-потоке. Безопасно вызывать из любого потока.</summary>
        public static void RunOnUi(Action action)
        {
            if (action == null) return;

            Control host = UiHost;
            if (host == null || host.IsDisposed || !host.IsHandleCreated)
            {
                action();
                return;
            }

            if (host.InvokeRequired) host.Invoke(action);
            else action();
        }

        /// <summary>Открыть адрес во встроенном браузере оболочки, если он доступен.</summary>
        public static bool OpenInShellBrowser(string url)
        {
            Func<string, bool> opener = ShellBrowserOpener;
            if (opener == null || string.IsNullOrEmpty(url)) return false;

            try
            {
                bool opened = false;
                RunOnUi(() => { opened = opener(url); });
                return opened;
            }
            catch { return false; }
        }

        public static void Initialize()
        {
            if (isInitialized)
            {
                Log("[Kernel] Ядро уже инициализировано — повторный запуск пропущен.");
                return;
            }

            Log("Запуск ядра LisunOS " + Version + " \"" + Codename + "\"...");

            SafeCreateDirectory(ServicesPath);
            SafeCreateDirectory(RegeditPath);
            SafeCreateDirectory(TempPath);
            SafeCreateDirectory(LocalePath);

            ClearTempDirectory();
            LoadRegistry();
            ConfigureBrowserEmulation();
            LisunOSInstallerShell.InitializeSecurityTokens();
            LisunPermissions.Load();
            LisunFirewall.Load();
            LisunServiceManager.Load();

            isInitialized = true;
        }

        private static void SafeCreateDirectory(string path)
        {
            try
            {
                if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            }
            catch (Exception ex)
            {
                Log("[Kernel] [ОШИБКА] Не удалось создать " + path + ": " + ex.Message);
            }
        }

        private static void ClearTempDirectory()
        {
            try
            {
                foreach (string file in Directory.GetFiles(TempPath))
                {
                    try { File.Delete(file); } catch { }
                }
                foreach (string dir in Directory.GetDirectories(TempPath))
                {
                    try { Directory.Delete(dir, true); } catch { }
                }
                Log("[Kernel] Директория /os/temp/ очищена.");
            }
            catch (Exception ex)
            {
                Log("[Kernel] [ОШИБКА] Очистка Temp: " + ex.Message);
            }
        }

        private static void LoadRegistry()
        {
            try
            {
                if (!File.Exists(RegConfigFilePath))
                {
                    File.WriteAllText(RegConfigFilePath,
                        "os_version=" + Version + Environment.NewLine +
                        "kernel_type=Core" + Environment.NewLine +
                        "hallapp=LisunOS.lshall" + Environment.NewLine +
                        "max_threads=4");
                }
                if (!File.Exists(RegDataFilePath))
                {
                    File.WriteAllText(RegDataFilePath,
                        "user_name=Administrator" + Environment.NewLine +
                        "theme=Dark");
                }

                ReadKeyValueFile(RegConfigFilePath, RegistryConfig);
                ReadKeyValueFile(RegDataFilePath, RegistryData);

                if (!RegistryConfig.ContainsKey("hallapp")) RegistryConfig["hallapp"] = "LisunOS.lshall";
                RegistryConfig["os_version"] = Version;

                Log("[Kernel] База данных Regedit смонтирована (" +
                    (RegistryConfig.Count + RegistryData.Count) + " ключей).");
            }
            catch (Exception ex)
            {
                Log("[Kernel] [ОШИБКА] Чтение реестра: " + ex.Message);
            }
        }

        private static void ReadKeyValueFile(string path, Dictionary<string, string> target)
        {
            target.Clear();
            if (!File.Exists(path)) return;

            foreach (string raw in File.ReadAllLines(path))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;

                // Split с лимитом 2: значения, содержащие '=', больше не теряются.
                string[] parts = line.Split(new[] { '=' }, 2);
                if (parts.Length == 2) target[parts[0].Trim()] = parts[1].Trim();
            }
        }

        public static void SaveRegistry()
        {
            try
            {
                List<string> cfgLines = new List<string>();
                foreach (KeyValuePair<string, string> kvp in RegistryConfig) cfgLines.Add(kvp.Key + "=" + kvp.Value);
                File.WriteAllLines(RegConfigFilePath, cfgLines);

                List<string> datLines = new List<string>();
                foreach (KeyValuePair<string, string> kvp in RegistryData) datLines.Add(kvp.Key + "=" + kvp.Value);
                File.WriteAllLines(RegDataFilePath, datLines);
            }
            catch (Exception ex)
            {
                Log("[Kernel] [ОШИБКА] Запись реестра: " + ex.Message);
            }
        }

        public static void SaveRegisteredCommands()
        {
            try
            {
                List<string> cmdLines = new List<string>();
                foreach (KeyValuePair<string, List<string>> kvp in RegisteredCommands)
                {
                    cmdLines.Add(kvp.Key + "=" + string.Join(",", kvp.Value.ToArray()));
                }
                File.WriteAllLines(RegCommandsFilePath, cmdLines);
            }
            catch (Exception ex)
            {
                Log("[Kernel] [ОШИБКА] Запись COMMANDS: " + ex.Message);
            }
        }

        /// <summary>
        /// Сканирует /sys/services/ и выполняет .service-сценарии.
        /// Раньше каждый сценарий уходил в Task.Run — формы создавались в потоках пула,
        /// без цикла сообщений. Теперь выполнение последовательное и в UI-потоке.
        /// </summary>
        public static void StartServicesAndBlock()
        {
            try
            {
                if (File.Exists(RegCommandsFilePath)) File.Delete(RegCommandsFilePath);
            }
            catch { }

            if (!Directory.Exists(ServicesPath))
            {
                Log("[Kernel] Каталог сервисов отсутствует — автозапуск пропущен.");
                return;
            }

            int started = 0;
            foreach (string dir in Directory.GetDirectories(ServicesPath))
            {
                string[] serviceFiles;
                try { serviceFiles = Directory.GetFiles(dir, "*.service"); }
                catch { continue; }

                // Службы, отключённые через systemctl disable, при загрузке пропускаем.
                string serviceName = LisunOSInstallerShell.ReadManifest(dir).Name;
                if (!LisunServiceManager.IsEnabled(serviceName))
                {
                    Log("[Kernel] Служба " + serviceName + " отключена (systemctl) — пропущена.");
                    continue;
                }

                foreach (string file in serviceFiles)
                {
                    try
                    {
                        // Чтение через LisunCrypto: работает и с открытыми, и с защищёнными пакетами.
                        string[] lines = LisunCrypto.ReadAllLines(file);
                        string packageDir = dir;
                        RunOnUi(() => FormEngine.ExecuteScript(lines, packageDir, null));
                        started++;
                    }
                    catch (Exception ex)
                    {
                        Log("[Kernel] [ОШИБКА] Сервис " + Path.GetFileName(file) + ": " + ex.Message);
                    }
                }
            }

            Log("[Kernel] Обработано сервисов: " + started + ".");
            SaveRegisteredCommands();
        }

        public static void RequestSoftRestart()
        {
            // Фоновые службы описываются заново при разборе .service,
            // поэтому перед перезапуском подсистем их нужно остановить.
            LisunDaemons.StopAll();

            RunOnUi(() =>
            {
                Log("[Kernel] Мягкий перезапуск подсистем...");

                RegisteredCommands.Clear();
                Assets.Clear();
                FormEngine.ClearAllActiveApps();

                Action handler = OnSoftRestartRequested;
                if (handler != null) handler();
            });
        }

        /// <summary>
        /// Переводит встроенный WebBrowser с режима IE7 на движок IE11.
        /// Без этого почти все современные сайты в браузере LisunOS рассыпаются.
        /// </summary>
        private static void ConfigureBrowserEmulation()
        {
            try
            {
                string exeName = Path.GetFileName(Application.ExecutablePath);
                if (string.IsNullOrEmpty(exeName)) return;

                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(
                    @"Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION"))
                {
                    if (key == null) return;

                    object current = key.GetValue(exeName);
                    if (current == null || Convert.ToInt32(current) != 11001)
                    {
                        key.SetValue(exeName, 11001, RegistryValueKind.DWord);
                        Log("[Kernel] Движок WebView переключён на IE11 (11001).");
                    }
                }
            }
            catch (Exception ex)
            {
                Log("[Kernel] Не удалось настроить движок WebView: " + ex.Message);
            }
        }
    }
}
