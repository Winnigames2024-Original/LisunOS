﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Диспетчер служб LisunOS (команда systemctl).
    /// Служба — каталог пакета в /sys/services/. Состояние автозапуска
    /// хранится в /os/root/regedit/SYSTEMD, текущее состояние берётся из FormEngine.
    /// </summary>
    public static class LisunServiceManager
    {
        public sealed class ServiceInfo
        {
            public string Name;            // техническое имя (name из манифеста)
            public string Folder;          // каталог пакета
            public string Title;
            public string Description;
            public string Version;
            public bool Enabled;           // автозапуск при загрузке
            public bool Running;           // есть загруженное приложение
            public bool Protected;         // пакет зашифрован
            public int Scripts;            // число .service-сценариев
        }

        private static readonly Dictionary<string, bool> AutostartFlags =
            new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);

        private static bool loaded;

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "SYSTEMD"); }
        }

        // =====================================================================
        //  Хранилище
        // =====================================================================

        public static void Load()
        {
            AutostartFlags.Clear();
            loaded = true;

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    string[] parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length != 2) continue;

                    string value = parts[1].Trim().ToLowerInvariant();
                    AutostartFlags[parts[0].Trim()] = value == "enabled" || value == "true" || value == "on";
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Systemd] [ОШИБКА] Чтение SYSTEMD: " + ex.Message);
            }
        }

        public static void Save()
        {
            try
            {
                List<string> lines = new List<string>();
                foreach (KeyValuePair<string, bool> kvp in AutostartFlags)
                    lines.Add(kvp.Key + "=" + (kvp.Value ? "enabled" : "disabled"));

                File.WriteAllLines(StorePath, lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Systemd] [ОШИБКА] Запись SYSTEMD: " + ex.Message);
            }
        }

        private static void EnsureLoaded()
        {
            if (!loaded) Load();
        }

        // =====================================================================
        //  Сведения
        // =====================================================================

        /// <summary>Разрешён ли автозапуск службы. По умолчанию — да.</summary>
        public static bool IsEnabled(string name)
        {
            EnsureLoaded();
            if (string.IsNullOrEmpty(name)) return true;

            bool value;
            return !AutostartFlags.TryGetValue(name, out value) || value;
        }

        public static List<ServiceInfo> All()
        {
            EnsureLoaded();
            List<ServiceInfo> result = new List<ServiceInfo>();

            foreach (string directory in LisunOSInstallerShell.InstalledPackageDirectories())
            {
                LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);

                ServiceInfo info = new ServiceInfo();
                info.Name = manifest.Name;
                info.Folder = directory;
                info.Title = manifest.DisplayName;
                info.Description = manifest.Description;
                info.Version = manifest.Version;
                info.Enabled = IsEnabled(manifest.Name);
                info.Protected = LisunCrypto.IsPackageProtected(directory);
                info.Running = IsRunning(manifest.Name);

                try { info.Scripts = Directory.GetFiles(directory, "*.service").Length; }
                catch { info.Scripts = 0; }

                result.Add(info);
            }

            return result;
        }

        public static ServiceInfo Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            name = name.Trim();

            foreach (ServiceInfo info in All())
            {
                if (info.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return info;
                if (Path.GetFileName(info.Folder).Equals(name, StringComparison.OrdinalIgnoreCase)) return info;
            }
            return null;
        }

        public static bool IsRunning(string packageName)
        {
            if (string.IsNullOrEmpty(packageName)) return false;

            foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
            {
                if (string.Equals(kvp.Value.PackageName, packageName, StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        public static bool Start(string name)
        {
            ServiceInfo info = Find(name);
            if (info == null) return false;

            string[] scripts;
            try { scripts = Directory.GetFiles(info.Folder, "*.service"); }
            catch { return false; }

            if (scripts.Length == 0)
            {
                LisunEngine.Log("[Systemd] В пакете " + info.Name + " нет .service-сценариев.");
                return false;
            }

            foreach (string script in scripts)
            {
                string[] lines = LisunCrypto.ReadAllLines(script);
                string folder = info.Folder;
                string packageName = info.Name;

                LisunEngine.RunOnUi(() => FormEngine.ExecuteScript(lines, folder, packageName));
            }

            LisunEngine.SaveRegisteredCommands();
            LisunEngine.Log("[Systemd] Служба " + info.Name + " запущена.");
            return true;
        }

        public static bool Stop(string name)
        {
            ServiceInfo info = Find(name);
            if (info == null) return false;

            List<string> targets = new List<string>();
            foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
            {
                if (string.Equals(kvp.Value.PackageName, info.Name, StringComparison.OrdinalIgnoreCase))
                    targets.Add(kvp.Key);
            }

            if (targets.Count == 0) return false;

            foreach (string target in targets) FormEngine.CloseApplication(target);

            LisunEngine.Log("[Systemd] Служба " + info.Name + " остановлена (процессов: " + targets.Count + ").");
            return true;
        }

        public static bool Restart(string name)
        {
            ServiceInfo info = Find(name);
            if (info == null) return false;

            Stop(name);
            return Start(name);
        }

        public static bool SetEnabled(string name, bool value)
        {
            ServiceInfo info = Find(name);
            if (info == null) return false;

            EnsureLoaded();
            AutostartFlags[info.Name] = value;
            Save();

            LisunEngine.Log("[Systemd] Автозапуск " + info.Name + ": " + (value ? "включён" : "выключен") + ".");
            return true;
        }

        // =====================================================================
        //  Вывод
        // =====================================================================

        public static string List()
        {
            List<ServiceInfo> services = All();
            if (services.Count == 0) return LisunLocale.T("systemctl.empty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("systemctl.listTitle") + Environment.NewLine);
            sb.AppendLine("   " + "СЛУЖБА".PadRight(18) + "СОСТОЯНИЕ".PadRight(14) + "АВТОЗАПУСК");

            foreach (ServiceInfo info in services)
            {
                string state = info.Running ? LisunLocale.T("systemctl.active") : LisunLocale.T("systemctl.inactive");
                string auto = info.Enabled ? LisunLocale.T("systemctl.enabled") : LisunLocale.T("systemctl.disabled");

                sb.AppendLine("   " + info.Name.PadRight(18) + state.PadRight(14) + auto);
            }

            return sb.ToString().TrimEnd();
        }

        public static string Status(string name)
        {
            ServiceInfo info = Find(name);
            if (info == null) return LisunLocale.T("systemctl.notFound", name);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("   ● " + info.Name + " — " + info.Title);
            if (!string.IsNullOrEmpty(info.Description)) sb.AppendLine("     " + info.Description);
            sb.AppendLine();
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldState") + ": " +
                          (info.Running ? LisunLocale.T("systemctl.active") : LisunLocale.T("systemctl.inactive")));
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldAuto") + ": " +
                          (info.Enabled ? LisunLocale.T("systemctl.enabled") : LisunLocale.T("systemctl.disabled")));
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldVersion") + ": " + info.Version);
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldScripts") + ": " + info.Scripts);
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldProtected") + ": " +
                          (info.Protected ? LisunLocale.T("apt.state") : LisunLocale.T("apt.stateOpen")));
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldPath") + ": " +
                          CustomFormUtils.ToVirtualPath(info.Folder));

            string[] granted = LisunPermissions.GrantedFor(info.Name);
            sb.AppendLine("     " + LisunLocale.T("systemctl.fieldRights") + ": " +
                          (granted.Length == 0 ? "—" : string.Join(", ", granted)));

            return sb.ToString().TrimEnd();
        }
    }
}
