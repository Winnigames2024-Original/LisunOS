﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace LisunOS
{
    /// <summary>
    /// Серверный API на PHP: файлы api.php, serverapi.php и секретный ключ.
    /// Файлы появляются в корне сайта только когда PHP включён,
    /// а строки внутри блоков ~~~NOREMOVE~ ... ~NOREMOVE~~~ защищены от правки.
    /// </summary>
    public static class LisunApiEndpoint
    {
        public const string ApiFileName = "api.php";
        public const string ExampleFileName = "apitest.php";
        public const string KeyFileName = ".api.key";

        public const string BlockStart = "~~~NOREMOVE~";
        public const string BlockEnd = "~NOREMOVE~~~";

        /// <summary>Второй вид защиты: текст внутри нельзя изменять, но файл можно.</summary>
        public const string EditBlockStart = "~~~CANTEDIT~";
        public const string EditBlockEnd = "~CANTEDIT~~~";

        private static readonly Regex BlockPattern =
            new Regex(Regex.Escape(BlockStart) + "(.*?)" + Regex.Escape(BlockEnd),
                RegexOptions.Singleline | RegexOptions.Compiled);

        private static readonly Regex EditBlockPattern =
            new Regex(Regex.Escape(EditBlockStart) + "(.*?)" + Regex.Escape(EditBlockEnd),
                RegexOptions.Singleline | RegexOptions.Compiled);

        // =====================================================================
        //  Секретный ключ
        // =====================================================================

        public static string KeyPath(string rootDirectory)
        {
            return Path.Combine(rootDirectory, KeyFileName);
        }

        /// <summary>Ключ из реестра; при отсутствии создаётся новый.</summary>
        public static string GetOrCreateKey(string rootDirectory)
        {
            string key;
            if (!LisunEngine.RegistryData.TryGetValue("server_api_key", out key) ||
                string.IsNullOrEmpty(key) || key.Length < 16)
            {
                key = GenerateKey();
                LisunEngine.RegistryData["server_api_key"] = key;
                LisunEngine.SaveRegistry();
            }

            WriteKeyFile(rootDirectory, key);
            return key;
        }

        public static string RegenerateKey(string rootDirectory)
        {
            string key = GenerateKey();

            LisunEngine.RegistryData["server_api_key"] = key;
            LisunEngine.SaveRegistry();
            WriteKeyFile(rootDirectory, key);

            LisunEngine.Log("[API] Секретный ключ сервера обновлён.");
            return key;
        }

        public static string GenerateKey()
        {
            const string alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
            byte[] buffer = new byte[32];

            using (RNGCryptoServiceProvider random = new RNGCryptoServiceProvider()) random.GetBytes(buffer);

            StringBuilder sb = new StringBuilder("lsk_");
            foreach (byte value in buffer) sb.Append(alphabet[value % alphabet.Length]);
            return sb.ToString();
        }

        private static void WriteKeyFile(string rootDirectory, string key)
        {
            try
            {
                if (!Directory.Exists(rootDirectory)) Directory.CreateDirectory(rootDirectory);
                File.WriteAllText(KeyPath(rootDirectory), key, new UTF8Encoding(false));
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[API] [ОШИБКА] Запись ключа: " + ex.Message);
            }
        }

        // =====================================================================
        //  Файлы API
        // =====================================================================

        public static bool ApiFilesPresent(string rootDirectory)
        {
            return File.Exists(Path.Combine(rootDirectory, ApiFileName));
        }

        /// <summary>
        /// Создаёт api.php, serverapi.php, пример и ключ.
        /// Существующие файлы не перезаписываются — ваши правки сохраняются.
        /// </summary>
        public static bool EnsureFiles(string rootDirectory)
        {
            try
            {
                if (!Directory.Exists(rootDirectory)) Directory.CreateDirectory(rootDirectory);

                // Утилита ServerAPI живёт внутри api.php — отдельный файл не нужен.
                bool created = false;
                created |= WriteIfMissing(Path.Combine(rootDirectory, ApiFileName), ApiContent());
                created |= WriteIfMissing(Path.Combine(rootDirectory, ExampleFileName), ExampleContent());

                GetOrCreateKey(rootDirectory);

                if (created) LisunEngine.Log("[API] Создан api.php в корне сайта.");
                return created;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[API] [ОШИБКА] Создание файлов: " + ex.Message);
                return false;
            }
        }

        private static bool WriteIfMissing(string path, string content)
        {
            if (File.Exists(path)) return false;

            File.WriteAllText(path, content, new UTF8Encoding(false));
            return true;
        }

        // =====================================================================
        //  Защищённые блоки NOREMOVE
        // =====================================================================

        public static List<string> ProtectedBlocks(string text)
        {
            List<string> blocks = new List<string>();
            if (string.IsNullOrEmpty(text)) return blocks;

            foreach (Match match in BlockPattern.Matches(text)) blocks.Add(match.Value);
            return blocks;
        }

        public static bool HasProtectedBlocks(string text)
        {
            return ProtectedBlocks(text).Count > 0 || ReadOnlyBlocks(text).Count > 0;
        }

        /// <summary>Блоки ~~~CANTEDIT~ ... ~CANTEDIT~~~ — их текст менять нельзя.</summary>
        public static List<string> ReadOnlyBlocks(string text)
        {
            List<string> blocks = new List<string>();
            if (string.IsNullOrEmpty(text)) return blocks;

            foreach (Match match in EditBlockPattern.Matches(text)) blocks.Add(match.Value);
            return blocks;
        }

        public static bool HasReadOnlyBlocks(string text)
        {
            return ReadOnlyBlocks(text).Count > 0;
        }

        /// <summary>Описание защиты файла для подсказки в редакторе.</summary>
        public static string DescribeProtection(string text)
        {
            int noRemove = ProtectedBlocks(text).Count;
            int cantEdit = ReadOnlyBlocks(text).Count;

            if (noRemove > 0 && cantEdit > 0) return LisunLocale.T("api.bothHint", noRemove, cantEdit);
            if (noRemove > 0) return LisunLocale.T("api.protectedHint");
            if (cantEdit > 0) return LisunLocale.T("api.editHint", cantEdit);

            return string.Empty;
        }

        public static bool FileIsProtected(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;
                return HasProtectedBlocks(LisunCrypto.ReadAllText(path));
            }
            catch { return false; }
        }

        /// <summary>
        /// Проверяет, что все защищённые блоки исходного текста целы в новом.
        /// Вне блоков правки разрешены полностью.
        /// </summary>
        public static bool ValidateEdit(string originalText, string newText, out string error)
        {
            error = null;
            if (newText == null) newText = string.Empty;

            List<string> blocks = ProtectedBlocks(originalText);

            for (int i = 0; i < blocks.Count; i++)
            {
                if (newText.IndexOf(blocks[i], StringComparison.Ordinal) >= 0) continue;

                error = LisunLocale.T("api.blockRemoved", i + 1, blocks.Count);
                return false;
            }

            // Блоки CANTEDIT должны остаться дословно: правка внутри них запрещена.
            List<string> readOnly = ReadOnlyBlocks(originalText);

            for (int i = 0; i < readOnly.Count; i++)
            {
                if (newText.IndexOf(readOnly[i], StringComparison.Ordinal) >= 0) continue;

                error = LisunLocale.T("api.editChanged", i + 1, readOnly.Count);
                return false;
            }

            return true;
        }

        /// <summary>Возвращает защищённые блоки на место, если их удалили.</summary>
        public static string RestoreBlocks(string originalText, string newText)
        {
            if (newText == null) newText = string.Empty;

            List<string> blocks = new List<string>();
            blocks.AddRange(ProtectedBlocks(originalText));
            blocks.AddRange(ReadOnlyBlocks(originalText));

            if (blocks.Count == 0) return newText;

            StringBuilder sb = new StringBuilder();
            foreach (string block in blocks)
            {
                if (newText.IndexOf(block, StringComparison.Ordinal) >= 0) continue;

                sb.Append(block).Append(Environment.NewLine).Append(Environment.NewLine);
            }

            if (sb.Length == 0) return newText;
            return sb.ToString() + newText;
        }

        /// <summary>Только NOREMOVE запрещает удаление файла; CANTEDIT — нет.</summary>
        public static bool FileBlocksDeletion(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;
                return ProtectedBlocks(LisunCrypto.ReadAllText(path)).Count > 0;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Содержимое файлов
        // =====================================================================

        private static string ApiContent()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<?php");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  LisunOS Server API  —  и точка входа, и библиотека");
            sb.AppendLine("#");
            sb.AppendLine("#  1) Как запрос:");
            sb.AppendLine("#     api.php?key=<ключ>&action=<действие>&name=<путь>&code=<текст>");
            sb.AppendLine("#");
            sb.AppendLine("#  2) Как библиотека в своём скрипте:");
            sb.AppendLine("#     require_once __DIR__ . '/api.php';");
            sb.AppendLine("#     ServerAPI($key, \"create_file\", \"hello.txt\", \"текст\");");
            sb.AppendLine("#");
            sb.AppendLine("#  Ключ показан в панели «Сервер v2» → кнопка «Ключ API».");
            sb.AppendLine("#");
            sb.AppendLine("#  Код ниже заключён в защищённый блок NOREMOVE: его строки нельзя");
            sb.AppendLine("#  удалить или изменить через редактор LisunOS, а сам файл — удалить.");
            sb.AppendLine("#  Свой код дописывайте ПОСЛЕ закрывающего маркера, в конце файла.");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("");
            sb.AppendLine("# ~~~NOREMOVE~");
            sb.AppendLine("define('LISUN_API_VERSION', '1.1');");
            sb.AppendLine("define('LISUN_ROOT', __DIR__);");
            sb.AppendLine("define('LISUN_KEY_FILE', __DIR__ . DIRECTORY_SEPARATOR . '.api.key');");
            sb.AppendLine("");
            sb.AppendLine("# Файл вызван напрямую как страница — или подключён из другого скрипта.");
            sb.AppendLine("define('LISUN_API_ENTRY', isset($_SERVER['SCRIPT_FILENAME']) &&");
            sb.AppendLine("    @realpath($_SERVER['SCRIPT_FILENAME']) === @realpath(__FILE__));");
            sb.AppendLine("");
            sb.AppendLine("if (!function_exists('ServerAPI')) {");
            sb.AppendLine("");
            sb.AppendLine("    /**");
            sb.AppendLine("     * Запрос к LisunOS Server API из PHP.");
            sb.AppendLine("     *");
            sb.AppendLine("     * @param string $key    секретный ключ из панели «Сервер v2»");
            sb.AppendLine("     * @param string $action ping, list, read_file, create_file, edit_file, append_file,");
            sb.AppendLine("     *                       delete_file, create_folder, delete_folder, move_file,");
            sb.AppendLine("     *                       copy_file, info, actions");
            sb.AppendLine("     * @param string $name   путь к файлу или папке внутри www (можно оставить пустым)");
            sb.AppendLine("     * @param string $code   содержимое файла (можно оставить пустым)");
            sb.AppendLine("     * @param string $target назначение для move_file и copy_file");
            sb.AppendLine("     * @return array  ok, action, data, error, time");
            sb.AppendLine("     */");
            sb.AppendLine("    function ServerAPI($key, $action, $name = '', $code = '', $target = '')");
            sb.AppendLine("    {");
            sb.AppendLine("        $params = array(");
            sb.AppendLine("            'key'    => (string)$key,");
            sb.AppendLine("            'action' => (string)$action,");
            sb.AppendLine("            'name'   => (string)$name,");
            sb.AppendLine("            'code'   => (string)$code,");
            sb.AppendLine("            'target' => (string)$target");
            sb.AppendLine("        );");
            sb.AppendLine("");
            sb.AppendLine("        $endpoint = ServerAPI_Endpoint();");
            sb.AppendLine("        $raw = ServerAPI_Post($endpoint, $params);");
            sb.AppendLine("");
            sb.AppendLine("        if ($raw === false) {");
            sb.AppendLine("            # Сеть недоступна — выполняем действие на месте, без HTTP.");
            sb.AppendLine("            return lisun_handle($params, false);");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        $decoded = json_decode($raw, true);");
            sb.AppendLine("        if (!is_array($decoded)) {");
            sb.AppendLine("            return array('ok' => false, 'action' => $action, 'data' => $raw,");
            sb.AppendLine("                         'error' => 'ответ не является JSON', 'time' => date('Y-m-d H:i:s'));");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        return $decoded;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** Адрес api.php: тот же хост и порт, на котором работает скрипт. */");
            sb.AppendLine("    function ServerAPI_Endpoint()");
            sb.AppendLine("    {");
            sb.AppendLine("        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : null;");
            sb.AppendLine("");
            sb.AppendLine("        if ($host === null) {");
            sb.AppendLine("            $port = isset($_SERVER['SERVER_PORT']) ? $_SERVER['SERVER_PORT'] : '8080';");
            sb.AppendLine("            $host = '127.0.0.1:' . $port;");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        return 'http://' . $host . '/api.php';");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** POST: сначала cURL, затем потоки PHP. */");
            sb.AppendLine("    function ServerAPI_Post($url, array $params)");
            sb.AppendLine("    {");
            sb.AppendLine("        $body = http_build_query($params);");
            sb.AppendLine("");
            sb.AppendLine("        if (function_exists('curl_init')) {");
            sb.AppendLine("            $curl = curl_init($url);");
            sb.AppendLine("            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);");
            sb.AppendLine("            curl_setopt($curl, CURLOPT_POST, true);");
            sb.AppendLine("            curl_setopt($curl, CURLOPT_POSTFIELDS, $body);");
            sb.AppendLine("            curl_setopt($curl, CURLOPT_TIMEOUT, 15);");
            sb.AppendLine("            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));");
            sb.AppendLine("");
            sb.AppendLine("            $result = curl_exec($curl);");
            sb.AppendLine("            curl_close($curl);");
            sb.AppendLine("");
            sb.AppendLine("            if ($result !== false) return $result;");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        $context = stream_context_create(array('http' => array(");
            sb.AppendLine("            'method'        => 'POST',");
            sb.AppendLine("            'header'        => \"Content-Type: application/x-www-form-urlencoded\\r\\n\",");
            sb.AppendLine("            'content'       => $body,");
            sb.AppendLine("            'timeout'       => 15,");
            sb.AppendLine("            'ignore_errors' => true");
            sb.AppendLine("        )));");
            sb.AppendLine("");
            sb.AppendLine("        return @file_get_contents($url, false, $context);");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** Ключ из файла .api.key рядом с api.php. */");
            sb.AppendLine("    function ServerAPI_Key()");
            sb.AppendLine("    {");
            sb.AppendLine("        return is_file(LISUN_KEY_FILE) ? trim((string)file_get_contents(LISUN_KEY_FILE)) : '';");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("if (!function_exists('lisun_reply')) {");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_result($ok, $action, $data = null, $error = null)");
            sb.AppendLine("    {");
            sb.AppendLine("        return array('ok' => (bool)$ok, 'action' => (string)$action, 'data' => $data,");
            sb.AppendLine("                     'error' => $error, 'time' => date('Y-m-d H:i:s'));");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** Ответ наружу (JSON) либо возврат массива при локальном вызове. */");
            sb.AppendLine("    function lisun_reply($ok, $data = null, $error = null)");
            sb.AppendLine("    {");
            sb.AppendLine("        $action = isset($_REQUEST['action']) ? (string)$_REQUEST['action'] : '';");
            sb.AppendLine("        $result = lisun_result($ok, $action, $data, $error);");
            sb.AppendLine("");
            sb.AppendLine("        if (defined('LISUN_LOCAL_CALL') && LISUN_LOCAL_CALL) throw new LisunApiResult($result);");
            sb.AppendLine("");
            sb.AppendLine("        echo json_encode($result, 256 | 64);");
            sb.AppendLine("        exit;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_path($name, $mustExist = false)");
            sb.AppendLine("    {");
            sb.AppendLine("        $name = (string)$name;");
            sb.AppendLine("        if ($name === '') lisun_reply(false, null, 'не указан параметр name');");
            sb.AppendLine("");
            sb.AppendLine("        $name = str_replace('\\\\', '/', $name);");
            sb.AppendLine("        if (strpos($name, '..') !== false) lisun_reply(false, null, 'путь за пределами корня сайта');");
            sb.AppendLine("");
            sb.AppendLine("        $full = LISUN_ROOT . DIRECTORY_SEPARATOR . ltrim($name, '/');");
            sb.AppendLine("        $real = realpath($full);");
            sb.AppendLine("        $root = realpath(LISUN_ROOT);");
            sb.AppendLine("");
            sb.AppendLine("        if ($real !== false && strpos($real, $root) !== 0) lisun_reply(false, null, 'путь за пределами корня сайта');");
            sb.AppendLine("        if ($mustExist && $real === false) lisun_reply(false, null, 'объект не найден: ' . $name);");
            sb.AppendLine("");
            sb.AppendLine("        return $real !== false ? $real : $full;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_relative($path)");
            sb.AppendLine("    {");
            sb.AppendLine("        $root = realpath(LISUN_ROOT);");
            sb.AppendLine("        $real = realpath($path);");
            sb.AppendLine("        if ($real === false) $real = $path;");
            sb.AppendLine("        return ltrim(str_replace($root, '', $real), '\\\\/');");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_protected_blocks($text)");
            sb.AppendLine("    {");
            sb.AppendLine("        $blocks = array();");
            sb.AppendLine("        if (preg_match_all('/~~~NOREMOVE~(.*?)~NOREMOVE~~~/s', (string)$text, $m)) $blocks = $m[0];");
            sb.AppendLine("        return $blocks;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_guard_protected($path, $newText)");
            sb.AppendLine("    {");
            sb.AppendLine("        if (!is_file($path)) return;");
            sb.AppendLine("");
            sb.AppendLine("        $old = (string)file_get_contents($path);");
            sb.AppendLine("        foreach (lisun_protected_blocks($old) as $block) {");
            sb.AppendLine("            if (strpos((string)$newText, $block) === false)");
            sb.AppendLine("                lisun_reply(false, null, 'в файле ' . lisun_relative($path) . ' удалён защищённый блок NOREMOVE');");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_listing($path)");
            sb.AppendLine("    {");
            sb.AppendLine("        $items = array();");
            sb.AppendLine("        foreach (scandir($path) as $entry) {");
            sb.AppendLine("            if ($entry === '.' || $entry === '..') continue;");
            sb.AppendLine("");
            sb.AppendLine("            $full = $path . DIRECTORY_SEPARATOR . $entry;");
            sb.AppendLine("            $items[] = array(");
            sb.AppendLine("                'name'  => $entry,");
            sb.AppendLine("                'type'  => is_dir($full) ? 'dir' : 'file',");
            sb.AppendLine("                'size'  => is_dir($full) ? null : filesize($full),");
            sb.AppendLine("                'mtime' => date('Y-m-d H:i:s', filemtime($full))");
            sb.AppendLine("            );");
            sb.AppendLine("        }");
            sb.AppendLine("        return $items;");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    function lisun_check_key()");
            sb.AppendLine("    {");
            sb.AppendLine("        $expected = ServerAPI_Key();");
            sb.AppendLine("        if ($expected === '') lisun_reply(false, null, 'ключ сервера не настроен');");
            sb.AppendLine("");
            sb.AppendLine("        $given = isset($_REQUEST['key']) ? trim((string)$_REQUEST['key']) : '';");
            sb.AppendLine("");
            sb.AppendLine("        $same = function_exists('hash_equals')");
            sb.AppendLine("            ? hash_equals($expected, $given)");
            sb.AppendLine("            : ($expected === $given);");
            sb.AppendLine("");
            sb.AppendLine("        if ($given === '' || !$same) lisun_reply(false, null, 'неверный ключ');");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** Разбор действия. Общий код для HTTP-запроса и локального вызова. */");
            sb.AppendLine("    function lisun_dispatch()");
            sb.AppendLine("    {");
            sb.AppendLine("        lisun_check_key();");
            sb.AppendLine("");
            sb.AppendLine("        $action = isset($_REQUEST['action']) ? strtolower(trim((string)$_REQUEST['action'])) : '';");
            sb.AppendLine("        $name   = isset($_REQUEST['name'])   ? (string)$_REQUEST['name']   : '';");
            sb.AppendLine("        $code   = isset($_REQUEST['code'])   ? (string)$_REQUEST['code']   : '';");
            sb.AppendLine("        $target = isset($_REQUEST['target']) ? (string)$_REQUEST['target'] : '';");
            sb.AppendLine("");
            sb.AppendLine("        switch ($action) {");
            sb.AppendLine("");
            sb.AppendLine("            case 'ping':");
            sb.AppendLine("                lisun_reply(true, array('server' => 'LisunOS', 'api' => LISUN_API_VERSION,");
            sb.AppendLine("                                        'root' => lisun_relative(LISUN_ROOT)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'list':");
            sb.AppendLine("                $dir = $name === '' ? LISUN_ROOT : lisun_path($name, true);");
            sb.AppendLine("                if (!is_dir($dir)) lisun_reply(false, null, 'это не папка');");
            sb.AppendLine("                lisun_reply(true, array('path' => lisun_relative($dir), 'items' => lisun_listing($dir)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'read_file':");
            sb.AppendLine("                $file = lisun_path($name, true);");
            sb.AppendLine("                if (!is_file($file)) lisun_reply(false, null, 'это не файл');");
            sb.AppendLine("                lisun_reply(true, array('path' => lisun_relative($file), 'content' => file_get_contents($file)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'create_file':");
            sb.AppendLine("                $file = lisun_path($name);");
            sb.AppendLine("                if (file_exists($file)) lisun_reply(false, null, 'файл уже существует');");
            sb.AppendLine("");
            sb.AppendLine("                $dir = dirname($file);");
            sb.AppendLine("                if (!is_dir($dir)) @mkdir($dir, 0777, true);");
            sb.AppendLine("");
            sb.AppendLine("                if (file_put_contents($file, $code) === false) lisun_reply(false, null, 'не удалось создать файл');");
            sb.AppendLine("                lisun_reply(true, array('path' => lisun_relative($file), 'bytes' => strlen($code)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'edit_file':");
            sb.AppendLine("            case 'write_file':");
            sb.AppendLine("                $file = lisun_path($name);");
            sb.AppendLine("                lisun_guard_protected($file, $code);");
            sb.AppendLine("");
            sb.AppendLine("                if (file_put_contents($file, $code) === false) lisun_reply(false, null, 'не удалось записать файл');");
            sb.AppendLine("                lisun_reply(true, array('path' => lisun_relative($file), 'bytes' => strlen($code)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'append_file':");
            sb.AppendLine("                $file = lisun_path($name);");
            sb.AppendLine("                if (file_put_contents($file, $code, FILE_APPEND) === false)");
            sb.AppendLine("                    lisun_reply(false, null, 'не удалось дописать файл');");
            sb.AppendLine("                lisun_reply(true, array('path' => lisun_relative($file), 'bytes' => strlen($code)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'delete_file':");
            sb.AppendLine("                $file = lisun_path($name, true);");
            sb.AppendLine("                if (!is_file($file)) lisun_reply(false, null, 'это не файл');");
            sb.AppendLine("");
            sb.AppendLine("                if (count(lisun_protected_blocks((string)file_get_contents($file))) > 0)");
            sb.AppendLine("                    lisun_reply(false, null, 'файл защищён блоками NOREMOVE и не может быть удалён');");
            sb.AppendLine("");
            sb.AppendLine("                if (!@unlink($file)) lisun_reply(false, null, 'не удалось удалить файл');");
            sb.AppendLine("                lisun_reply(true, array('deleted' => lisun_relative($file)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'create_folder':");
            sb.AppendLine("                $dir = lisun_path($name);");
            sb.AppendLine("                if (is_dir($dir)) lisun_reply(false, null, 'папка уже существует');");
            sb.AppendLine("                if (!@mkdir($dir, 0777, true)) lisun_reply(false, null, 'не удалось создать папку');");
            sb.AppendLine("                lisun_reply(true, array('created' => lisun_relative($dir)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'delete_folder':");
            sb.AppendLine("                $dir = lisun_path($name, true);");
            sb.AppendLine("                if (!is_dir($dir)) lisun_reply(false, null, 'это не папка');");
            sb.AppendLine("                if (realpath($dir) === realpath(LISUN_ROOT)) lisun_reply(false, null, 'корень сайта удалить нельзя');");
            sb.AppendLine("");
            sb.AppendLine("                $removed = 0;");
            sb.AppendLine("                $items = new RecursiveIteratorIterator(");
            sb.AppendLine("                    new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),");
            sb.AppendLine("                    RecursiveIteratorIterator::CHILD_FIRST);");
            sb.AppendLine("");
            sb.AppendLine("                foreach ($items as $item) {");
            sb.AppendLine("                    if ($item->isDir()) { @rmdir($item->getPathname()); }");
            sb.AppendLine("                    else {");
            sb.AppendLine("                        $text = (string)file_get_contents($item->getPathname());");
            sb.AppendLine("                        if (count(lisun_protected_blocks($text)) > 0)");
            sb.AppendLine("                            lisun_reply(false, null, 'внутри есть защищённый файл: ' . lisun_relative($item->getPathname()));");
            sb.AppendLine("");
            sb.AppendLine("                        @unlink($item->getPathname());");
            sb.AppendLine("                    }");
            sb.AppendLine("                    $removed++;");
            sb.AppendLine("                }");
            sb.AppendLine("");
            sb.AppendLine("                if (!@rmdir($dir)) lisun_reply(false, null, 'не удалось удалить папку');");
            sb.AppendLine("                lisun_reply(true, array('deleted' => lisun_relative($dir), 'items' => $removed));");
            sb.AppendLine("");
            sb.AppendLine("            case 'move_file':");
            sb.AppendLine("            case 'rename':");
            sb.AppendLine("                $from = lisun_path($name, true);");
            sb.AppendLine("                if ($target === '') lisun_reply(false, null, 'не указан параметр target');");
            sb.AppendLine("");
            sb.AppendLine("                $to = lisun_path($target);");
            sb.AppendLine("                $dir = dirname($to);");
            sb.AppendLine("                if (!is_dir($dir)) @mkdir($dir, 0777, true);");
            sb.AppendLine("");
            sb.AppendLine("                if (!@rename($from, $to)) lisun_reply(false, null, 'не удалось переместить объект');");
            sb.AppendLine("                lisun_reply(true, array('from' => lisun_relative($from), 'to' => lisun_relative($to)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'copy_file':");
            sb.AppendLine("                $from = lisun_path($name, true);");
            sb.AppendLine("                if ($target === '') lisun_reply(false, null, 'не указан параметр target');");
            sb.AppendLine("");
            sb.AppendLine("                $to = lisun_path($target);");
            sb.AppendLine("                if (!@copy($from, $to)) lisun_reply(false, null, 'не удалось скопировать файл');");
            sb.AppendLine("                lisun_reply(true, array('from' => lisun_relative($from), 'to' => lisun_relative($to)));");
            sb.AppendLine("");
            sb.AppendLine("            case 'info':");
            sb.AppendLine("                $item = lisun_path($name, true);");
            sb.AppendLine("                lisun_reply(true, array(");
            sb.AppendLine("                    'path'      => lisun_relative($item),");
            sb.AppendLine("                    'type'      => is_dir($item) ? 'dir' : 'file',");
            sb.AppendLine("                    'size'      => is_dir($item) ? null : filesize($item),");
            sb.AppendLine("                    'mtime'     => date('Y-m-d H:i:s', filemtime($item)),");
            sb.AppendLine("                    'protected' => is_file($item) ? count(lisun_protected_blocks((string)file_get_contents($item))) : 0");
            sb.AppendLine("                ));");
            sb.AppendLine("");
            sb.AppendLine("            case 'actions':");
            sb.AppendLine("                lisun_reply(true, array('actions' => array(");
            sb.AppendLine("                    'ping', 'list', 'read_file', 'create_file', 'edit_file', 'append_file',");
            sb.AppendLine("                    'delete_file', 'create_folder', 'delete_folder', 'move_file', 'copy_file', 'info'");
            sb.AppendLine("                )));");
            sb.AppendLine("");
            sb.AppendLine("            default:");
            sb.AppendLine("                lisun_reply(false, null, 'неизвестное действие: ' . ($action === '' ? '(пусто)' : $action));");
            sb.AppendLine("        }");
            sb.AppendLine("    }");
            sb.AppendLine("");
            sb.AppendLine("    /** Локальное выполнение без HTTP — когда сеть недоступна. */");
            sb.AppendLine("    function lisun_handle(array $params, $viaHttp = true)");
            sb.AppendLine("    {");
            sb.AppendLine("        if (!class_exists('LisunApiResult', false)) {");
            sb.AppendLine("            eval('class LisunApiResult extends Exception { public $payload;");
            sb.AppendLine("                  public function __construct($p) { $this->payload = $p; parent::__construct(\"lisun\"); } }');");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        $backup = $_REQUEST;");
            sb.AppendLine("        $_REQUEST = array_merge($_REQUEST, $params);");
            sb.AppendLine("");
            sb.AppendLine("        if (!defined('LISUN_LOCAL_CALL')) define('LISUN_LOCAL_CALL', true);");
            sb.AppendLine("");
            sb.AppendLine("        try {");
            sb.AppendLine("            lisun_dispatch();");
            sb.AppendLine("            $result = lisun_result(false, $params['action'], null, 'нет ответа');");
            sb.AppendLine("        } catch (Exception $e) {");
            sb.AppendLine("            $result = isset($e->payload)");
            sb.AppendLine("                ? $e->payload");
            sb.AppendLine("                : lisun_result(false, $params['action'], null, $e->getMessage());");
            sb.AppendLine("        }");
            sb.AppendLine("");
            sb.AppendLine("        $_REQUEST = $backup;");
            sb.AppendLine("        return $result;");
            sb.AppendLine("    }");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("# Прямой вызов страницы — отвечаем JSON. Подключение через require — только функции.");
            sb.AppendLine("if (LISUN_API_ENTRY) {");
            sb.AppendLine("    header('Content-Type: application/json; charset=utf-8');");
            sb.AppendLine("    header('X-Lisun-Api: ' . LISUN_API_VERSION);");
            sb.AppendLine("    lisun_dispatch();");
            sb.AppendLine("}");
            sb.AppendLine("# ~NOREMOVE~~~");
            sb.AppendLine("");
            sb.AppendLine("# ============================================================");
            sb.AppendLine("#  Ниже можно дописывать свой код — эта часть не защищена.");
            sb.AppendLine("# ============================================================");
            return sb.ToString();
        }

        private static string ExampleContent()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<?php");
            sb.AppendLine("// Пример работы с ServerAPI. Файл не защищён — меняйте и удаляйте свободно.");
            sb.AppendLine("require_once __DIR__ . '/api.php';");
            sb.AppendLine("");
            sb.AppendLine("$key = ServerAPI_Key();           // ключ берётся из .api.key");
            sb.AppendLine("header('Content-Type: text/plain; charset=utf-8');");
            sb.AppendLine("");
            sb.AppendLine("print_r(ServerAPI($key, 'ping'));");
            sb.AppendLine("print_r(ServerAPI($key, 'create_file', 'demo/hello.txt', 'Привет из ServerAPI!'));");
            sb.AppendLine("print_r(ServerAPI($key, 'list', 'demo'));");
            sb.AppendLine("print_r(ServerAPI($key, 'read_file', 'demo/hello.txt'));");
            return sb.ToString();
        }
    }
}
