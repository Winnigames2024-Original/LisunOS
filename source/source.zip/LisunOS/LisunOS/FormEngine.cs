﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>Собранная динамическая форма вместе со всеми её контролами по именам.</summary>
    public class DynamicFormContext
    {
        public Form Form { get; set; }
        public string SourcePath { get; set; }
        public string ServiceFolder { get; set; }

        /// <summary>Имя пакета (name из meta.json) — под ним проверяются разрешения.</summary>
        public string PackageName { get; set; }

        public readonly Dictionary<string, object> Components =
            new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

        public T Get<T>(string name) where T : class
        {
            object value;
            if (Components.TryGetValue(name, out value)) return value as T;
            return null;
        }
    }

    public class DynamicApp
    {
        public string Name { get; set; }
        public string Namespace { get; set; }
        public string CustomTitle { get; set; }
        public string Description { get; set; }
        public bool Autostart { get; set; }
        public string PackageName { get; set; }
        public Form Form { get; private set; }
        public DynamicFormContext Context { get; private set; }

        public DynamicApp(string name) { Name = name; }

        public void SetForm(Form form, DynamicFormContext context)
        {
            Form = form;
            Context = context;
        }

        public void Show()
        {
            if (Form == null)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] У приложения '" + Name + "' нет собранной формы.");
                return;
            }
            LisunEngine.RunOnUi(() => FormEngine.RequestShow(this));
        }

        public string Title
        {
            get
            {
                if (!string.IsNullOrEmpty(CustomTitle)) return CustomTitle;
                if (Form != null && !string.IsNullOrEmpty(Form.Text)) return Form.Text;
                if (!string.IsNullOrEmpty(Namespace)) return Namespace;
                return Name;
            }
        }
    }

    /// <summary>
    /// Интерпретатор .service-сценариев и сборщик форм из designer-файлов.
    /// Парсер переписан: теперь свойства реально применяются, контролы попадают
    /// к своим родителям, а события подключаются к классу-логике.
    /// </summary>
    public static class FormEngine
    {
        public static Dictionary<string, DynamicApp> ActiveApps { get; private set; }

        /// <summary>Оболочка подписывается на это событие и встраивает форму во вкладку.</summary>
        public static event Action<DynamicApp> OnAppShowRequested;

        static FormEngine()
        {
            ActiveApps = new Dictionary<string, DynamicApp>(StringComparer.OrdinalIgnoreCase);
        }

        internal static void RequestShow(DynamicApp app)
        {
            if (app == null) return;

            if (app.Form == null || app.Form.IsDisposed)
            {
                LisunEngine.Log("[OS] [ОШИБКА] Окно приложения '" + app.Name +
                                "' закрыто. Выполните 'restart', чтобы пересобрать сервисы.");
                return;
            }

            Action<DynamicApp> handler = OnAppShowRequested;
            if (handler != null)
            {
                handler(app);
                LisunEngine.Log("[OS] Процесс " + app.Title + " развёрнут в оболочке.");
                return;
            }

            try
            {
                app.Form.Show();
                app.Form.BringToFront();
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[OS] [ОШИБКА] Запуск " + app.Name + ": " + ex.Message);
            }
        }

        /// <summary>Закрывает одно приложение и освобождает его форму (команда kill).</summary>
        public static bool CloseApplication(string name)
        {
            DynamicApp app;
            if (string.IsNullOrEmpty(name) || !ActiveApps.TryGetValue(name, out app)) return false;

            LisunEngine.RunOnUi(() =>
            {
                CloseApp(app);
                ActiveApps.Remove(name);
            });
            return true;
        }

        public static void ClearAllActiveApps()
        {
            LisunEngine.RunOnUi(() =>
            {
                foreach (KeyValuePair<string, DynamicApp> kvp in ActiveApps)
                {
                    Form form = kvp.Value.Form;
                    if (form == null || form.IsDisposed) continue;
                    try
                    {
                        if (form.Parent != null) form.Parent.Controls.Remove(form);
                        form.Close();
                        form.Dispose();
                    }
                    catch { }
                }
                ActiveApps.Clear();
            });
        }

        // =====================================================================
        //  Интерпретатор .service
        // =====================================================================

        public static void ExecuteScript(string[] lines, string serviceFolderPath)
        {
            ExecuteScript(lines, serviceFolderPath, null);
        }

        public static void ExecuteScript(string[] lines, string serviceFolderPath, string packageName)
        {
            if (lines == null) return;

            // Имя пакета нужно для проверки разрешений; если не передано — берём из манифеста.
            if (string.IsNullOrEmpty(packageName) && !string.IsNullOrEmpty(serviceFolderPath))
                packageName = ResolvePackageName(serviceFolderPath);

            bool winformsImported = false;              // флаг теперь локальный для каждого сценария
            DynamicApp currentApp = null;
            Dictionary<string, DynamicFormContext> formVariables =
                new Dictionary<string, DynamicFormContext>(StringComparer.OrdinalIgnoreCase);

            // Блок daemon ... end описывает фоновую службу — она работает без окна.
            LisunDaemons.Daemon daemon = null;

            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;

                // ---------- фоновые службы ----------
                Match daemonStart = Regex.Match(line,
                    @"^daemon\s+(?<name>[A-Za-z_][A-Za-z0-9_\-]*)$", RegexOptions.IgnoreCase);
                if (daemonStart.Success)
                {
                    daemon = new LisunDaemons.Daemon();
                    daemon.Name = daemonStart.Groups["name"].Value;
                    daemon.PackageName = packageName ?? string.Empty;
                    continue;
                }

                if (daemon != null)
                {
                    if (line.Equals("end", StringComparison.OrdinalIgnoreCase) ||
                        line.Equals("end daemon", StringComparison.OrdinalIgnoreCase))
                    {
                        LisunDaemons.Register(daemon);
                        daemon = null;
                        continue;
                    }

                    Match property = Regex.Match(line,
                        @"^(?<key>description|run|command|interval|every|autostart|permission|right)\s*=\s*(?<value>.+)$",
                        RegexOptions.IgnoreCase);

                    if (property.Success)
                    {
                        string key = property.Groups["key"].Value.ToLowerInvariant();
                        string value = Clean(property.Groups["value"].Value);

                        switch (key)
                        {
                            case "description": daemon.Description = value; break;

                            case "run":
                            case "command": daemon.Command = value; break;

                            case "interval":
                            case "every":
                            {
                                int seconds;
                                int[] numbers = ExtractNumbers(value);
                                seconds = numbers.Length > 0 ? numbers[0] : 60;

                                // 5m и 2h пишутся короче, чем 300 и 7200.
                                if (value.IndexOf('m') >= 0 && value.IndexOf("ms", StringComparison.OrdinalIgnoreCase) < 0)
                                    seconds *= 60;
                                else if (value.IndexOf('h') >= 0) seconds *= 3600;

                                daemon.IntervalSeconds = seconds;
                                break;
                            }

                            case "autostart": daemon.Autostart = ParseBool(value); break;

                            case "permission":
                            case "right": daemon.Permission = value.ToLowerInvariant(); break;
                        }

                        continue;
                    }

                    // Внутри блока всё остальное игнорируем, чтобы опечатка
                    // не ушла в обычный разбор и не создала лишнее приложение.
                    continue;
                }

                if (line.Equals("import winforms", StringComparison.OrdinalIgnoreCase))
                {
                    winformsImported = true;
                    LisunEngine.Log("[FormEngine] Модуль 'winforms' импортирован.");
                    continue;
                }

                if (line.IndexOf("winforms.", StringComparison.OrdinalIgnoreCase) >= 0 && !winformsImported)
                {
                    LisunEngine.Log("[FormEngine] [ОШИБКА] Модуль 'winforms' не импортирован — сценарий остановлен.");
                    return;
                }

                // log "текст" — вывод в журнал ядра прямо из сценария
                Match logMatch = Regex.Match(line, @"^log\s+(?<text>.+)$", RegexOptions.IgnoreCase);
                if (logMatch.Success)
                {
                    LisunEngine.Log("[Service] " + Clean(logMatch.Groups["text"].Value));
                    continue;
                }

                // set <ключ> = <значение> — запись в реестр DATA
                Match setMatch = Regex.Match(line,
                    @"^set\s+(?<key>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?<value>.+)$", RegexOptions.IgnoreCase);
                if (setMatch.Success)
                {
                    if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) continue;

                    LisunEngine.RegistryData[setMatch.Groups["key"].Value.ToLower()] = Clean(setMatch.Groups["value"].Value);
                    LisunEngine.SaveRegistry();
                    LisunEngine.Log("[Service] Записан ключ реестра: " + setMatch.Groups["key"].Value);
                    continue;
                }

                // winforms.Application myApp = new winforms.Application()
                Match appMatch = Regex.Match(line,
                    @"^winforms\.Application\s+(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*=", RegexOptions.IgnoreCase);
                if (appMatch.Success)
                {
                    string appName = appMatch.Groups["name"].Value;
                    DynamicApp existing;
                    if (ActiveApps.TryGetValue(appName, out existing)) CloseApp(existing);

                    currentApp = new DynamicApp(appName);
                    currentApp.PackageName = packageName;
                    ActiveApps[appName] = currentApp;
                    LisunEngine.Log("[FormEngine] Создан дескриптор приложения: " + appName);
                    continue;
                }

                // winforms.Form Form1 = new winforms.Form("...cs", "...designer.cs")
                Match formMatch = Regex.Match(line,
                    @"^winforms\.Form\s+(?<var>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*new\s+winforms\.Form\s*\((?<args>.*)\)\s*$",
                    RegexOptions.IgnoreCase);
                if (formMatch.Success)
                {
                    DynamicFormContext context = BuildFormFromDeclaration(
                        formMatch.Groups["args"].Value, serviceFolderPath, packageName);

                    if (context != null)
                    {
                        formVariables[formMatch.Groups["var"].Value] = context;
                        if (currentApp != null && currentApp.Form == null)
                            currentApp.SetForm(context.Form, context);
                    }
                    continue;
                }

                // <переменнаяФормы>.<свойство> = <значение>
                Match formProperty = Regex.Match(line,
                    @"^(?<var>[A-Za-z_][A-Za-z0-9_]*)\.(?<prop>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?<value>.+)$");
                if (formProperty.Success)
                {
                    DynamicFormContext targetForm;
                    if (formVariables.TryGetValue(formProperty.Groups["var"].Value, out targetForm))
                    {
                        ApplyFormProperty(targetForm.Form,
                            formProperty.Groups["prop"].Value,
                            Clean(formProperty.Groups["value"].Value));
                        continue;
                    }
                }

                if (currentApp == null)
                {
                    foreach (KeyValuePair<string, DynamicApp> kvp in ActiveApps)
                    {
                        if (line.StartsWith(kvp.Key + ".", StringComparison.OrdinalIgnoreCase))
                        {
                            currentApp = kvp.Value;
                            break;
                        }
                    }
                    if (currentApp == null) continue;
                }

                string prefix = currentApp.Name + ".";
                if (!line.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                string tail = line.Substring(prefix.Length).Trim();

                // program.addForm(Form1)
                Match addForm = Regex.Match(tail, @"^program\.addForm\(\s*(?<var>[A-Za-z0-9_]+)\s*\)", RegexOptions.IgnoreCase);
                if (addForm.Success)
                {
                    DynamicFormContext context;
                    if (formVariables.TryGetValue(addForm.Groups["var"].Value, out context))
                        currentApp.SetForm(context.Form, context);
                    continue;
                }

                // program.setDefaultForm(Form1)
                if (tail.StartsWith("program.setDefaultForm(", StringComparison.OrdinalIgnoreCase))
                {
                    string target = !string.IsNullOrEmpty(currentApp.Namespace) ? currentApp.Namespace : currentApp.Name;
                    LisunEngine.RegistryConfig["hallapp"] = target;
                    LisunEngine.SaveRegistry();
                    LisunEngine.Log("[FormEngine] Оболочка по умолчанию: '" + target + "'.");
                    continue;
                }

                // namespace = "explorer"
                Match nsMatch = Regex.Match(tail, @"^namespace\s*=\s*(?<value>.+)$", RegexOptions.IgnoreCase);
                if (nsMatch.Success)
                {
                    string value = nsMatch.Groups["value"].Value.Trim().Trim('\'', '"', ';').Trim();
                    if (value.Length == 0) continue;

                    currentApp.Namespace = value;
                    string trigger = value.ToLower();

                    if (!LisunEngine.RegisteredCommands.ContainsKey(trigger))
                    {
                        LisunEngine.RegisteredCommands[trigger] = new List<string> { currentApp.Name };
                        LisunEngine.Log("[FormEngine] Зарегистрирована команда запуска: '" + trigger + "'.");
                        LisunEngine.SaveRegisteredCommands();
                    }
                    continue;
                }

                // title / description / autostart / command
                Match appProperty = Regex.Match(tail,
                    @"^(?<prop>title|description|autostart|command|icon)\s*=\s*(?<value>.+)$", RegexOptions.IgnoreCase);
                if (appProperty.Success)
                {
                    string property = appProperty.Groups["prop"].Value.ToLowerInvariant();
                    string value = Clean(appProperty.Groups["value"].Value);

                    switch (property)
                    {
                        case "title":
                            currentApp.CustomTitle = value;
                            if (currentApp.Form != null) currentApp.Form.Text = value;
                            break;

                        case "description":
                            currentApp.Description = value;
                            break;

                        case "autostart":
                            currentApp.Autostart = ParseBool(value) &&
                                LisunPermissions.Demand(packageName, LisunPermissions.Autostart);
                            break;

                        case "command":
                            RegisterCommand(value, currentApp);
                            break;
                    }
                    continue;
                }

                if (tail.Equals("show()", StringComparison.OrdinalIgnoreCase))
                {
                    currentApp.Show();
                    continue;
                }

                if (tail.Equals("hide()", StringComparison.OrdinalIgnoreCase))
                {
                    if (currentApp.Form != null && !currentApp.Form.IsDisposed) currentApp.Form.Visible = false;
                }
            }

            // Приложения с autostart = true разворачиваются сразу после разбора сценария.
            foreach (KeyValuePair<string, DynamicApp> kvp in ActiveApps)
            {
                if (kvp.Value.Autostart && kvp.Value.Form != null) kvp.Value.Show();
            }
        }

        private static void RegisterCommand(string trigger, DynamicApp app)
        {
            if (string.IsNullOrEmpty(trigger) || app == null) return;

            string key = trigger.Trim().ToLowerInvariant();
            if (key.Length == 0) return;

            LisunEngine.RegisteredCommands[key] = new List<string> { app.Name };
            LisunEngine.SaveRegisteredCommands();
            LisunEngine.Log("[FormEngine] Зарегистрирована команда запуска: '" + key + "'.");
        }

        /// <summary>Снимает кавычки, точку с запятой и лишние пробелы со значения сценария.</summary>
        private static string Clean(string value)
        {
            if (value == null) return string.Empty;
            return value.Trim().TrimEnd(';').Trim().Trim('\'', '"').Trim();
        }

        private static bool ParseBool(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            value = value.Trim().ToLowerInvariant();
            return value == "true" || value == "1" || value == "yes" || value == "да" || value == "on";
        }

        /// <summary>
        /// Свойства формы, доступные прямо в .service:
        /// title, size, width, height, minsize, background, foreground,
        /// opacity, topmost, resizable, center, maximized, padding.
        /// </summary>
        private static void ApplyFormProperty(Form form, string property, string value)
        {
            if (form == null || form.IsDisposed) return;

            try
            {
                switch (property.ToLowerInvariant())
                {
                    case "title":
                    case "text":
                        form.Text = value;
                        break;

                    case "size":
                        int[] size = ExtractNumbers(value);
                        if (size.Length >= 2) form.ClientSize = new Size(size[0], size[1]);
                        break;

                    case "minsize":
                        int[] min = ExtractNumbers(value);
                        if (min.Length >= 2) form.MinimumSize = new Size(min[0], min[1]);
                        break;

                    case "width":
                        int[] width = ExtractNumbers(value);
                        if (width.Length >= 1) form.ClientSize = new Size(width[0], form.ClientSize.Height);
                        break;

                    case "height":
                        int[] height = ExtractNumbers(value);
                        if (height.Length >= 1) form.ClientSize = new Size(form.ClientSize.Width, height[0]);
                        break;

                    case "background":
                    case "backcolor":
                    case "bg":
                        Color? background = ParseColorValue(value);
                        if (background.HasValue) form.BackColor = background.Value;
                        break;

                    case "foreground":
                    case "forecolor":
                    case "fg":
                        Color? foreground = ParseColorValue(value);
                        if (foreground.HasValue) form.ForeColor = foreground.Value;
                        break;

                    case "opacity":
                        float[] opacity = ExtractFloats(value);
                        if (opacity.Length >= 1)
                        {
                            double level = opacity[0] > 1 ? opacity[0] / 100.0 : opacity[0];
                            form.Opacity = Math.Max(0.2, Math.Min(1.0, level));
                        }
                        break;

                    case "topmost":
                        form.TopMost = ParseBool(value);
                        break;

                    case "resizable":
                        form.FormBorderStyle = ParseBool(value) ? FormBorderStyle.Sizable : FormBorderStyle.FixedSingle;
                        break;

                    case "center":
                        form.StartPosition = ParseBool(value) ? FormStartPosition.CenterScreen : FormStartPosition.Manual;
                        break;

                    case "maximized":
                        form.WindowState = ParseBool(value) ? FormWindowState.Maximized : FormWindowState.Normal;
                        break;

                    case "padding":
                        int[] padding = ExtractNumbers(value);
                        if (padding.Length >= 1) form.Padding = new Padding(padding[0]);
                        break;

                    default:
                        LisunEngine.Log("[FormEngine] Свойство формы '" + property + "' не поддерживается.");
                        break;
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Свойство '" + property + "': " + ex.Message);
            }
        }

        /// <summary>Цвет в виде #RRGGBB, r,g,b или имени (White, Black...).</summary>
        private static Color? ParseColorValue(string value)
        {
            if (string.IsNullOrEmpty(value)) return null;
            value = value.Trim();

            try
            {
                if (value.StartsWith("#"))
                {
                    string hex = value.Substring(1);
                    if (hex.Length == 6)
                    {
                        return Color.FromArgb(
                            Convert.ToInt32(hex.Substring(0, 2), 16),
                            Convert.ToInt32(hex.Substring(2, 2), 16),
                            Convert.ToInt32(hex.Substring(4, 2), 16));
                    }
                }

                int[] parts = ExtractNumbers(value);
                if (parts.Length >= 3) return Color.FromArgb(parts[0], parts[1], parts[2]);

                Color named = Color.FromName(value);
                if (named.IsKnownColor) return named;
            }
            catch { }

            return null;
        }

        private static void CloseApp(DynamicApp app)
        {
            if (app == null || app.Form == null || app.Form.IsDisposed) return;
            try
            {
                if (app.Form.Parent != null) app.Form.Parent.Controls.Remove(app.Form);
                app.Form.Close();
                app.Form.Dispose();
            }
            catch { }
        }

        /// <summary>Имя пакета из meta.json каталога службы.</summary>
        private static string ResolvePackageName(string serviceFolderPath)
        {
            try
            {
                LisunManifest manifest = LisunManifest.FromFile(Path.Combine(serviceFolderPath, "meta.json"));
                if (!string.IsNullOrEmpty(manifest.Name)) return manifest.Name;
            }
            catch { }

            return Path.GetFileName(serviceFolderPath.TrimEnd(Path.DirectorySeparatorChar));
        }

        private static DynamicFormContext BuildFormFromDeclaration(string args, string serviceFolderPath, string packageName)
        {
            try
            {
                MatchCollection quoted = Regex.Matches(args, "\"([^\"]*)\"");
                if (quoted.Count < 2)
                {
                    LisunEngine.Log("[FormEngine] [ОШИБКА] В описании формы нужно два пути: логика и designer.");
                    return null;
                }

                string assetsPath = Path.Combine(serviceFolderPath ?? string.Empty, "assets");
                string csPath = quoted[0].Groups[1].Value.Replace("%appfiles%", assetsPath);
                string designerPath = quoted[1].Groups[1].Value.Replace("%appfiles%", assetsPath);

                return BuildDynamicForm(designerPath, csPath, serviceFolderPath, packageName);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Чтение метаданных формы: " + ex.Message);
                return null;
            }
        }

        // =====================================================================
        //  Сборка формы из designer-файла
        // =====================================================================

        private class EventBinding
        {
            public string TargetPath;
            public string EventName;
            public string HandlerName;
        }

        public static DynamicFormContext BuildDynamicForm(string designerPath, string csPath, string serviceFolder, string packageName)
        {
            DynamicFormContext context = new DynamicFormContext();
            context.SourcePath = csPath;
            context.ServiceFolder = serviceFolder;
            context.PackageName = packageName;

            Form form = new Form();
            form.StartPosition = FormStartPosition.CenterScreen;
            form.ClientSize = new Size(900, 560);
            form.BackColor = Theme.Background;
            form.ForeColor = Theme.Text;
            form.Font = Theme.Ui(9f);
            form.Text = "Приложение LisunOS";
            context.Form = form;

            if (string.IsNullOrEmpty(designerPath) || !File.Exists(designerPath))
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Designer-файл не найден: " + designerPath);
                return context;
            }

            List<EventBinding> events = new List<EventBinding>();
            List<KeyValuePair<SplitContainer, int>> deferredSplitters = new List<KeyValuePair<SplitContainer, int>>();

            try
            {
                List<string> statements = SplitStatements(LisunCrypto.ReadAllLines(designerPath));

                foreach (string rawStatement in statements)
                {
                    string statement = StripBlockPrefix(rawStatement).Replace("this.this.", "this.").Trim();
                    if (statement.Length == 0) continue;

                    if (TryCreateComponent(statement, context.Components)) continue;
                    if (TryEventBinding(statement, events)) continue;
                    if (TryCollectionCall(statement, form, context.Components)) continue;
                    TryAssignment(statement, form, context.Components, deferredSplitters);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Разбор designer: " + ex.Message);
            }

            Theme.Harmonize(form);

            object logic = CreateLogicBridge(context, csPath, serviceFolder);
            WireEvents(events, form, context.Components, logic);

            if (deferredSplitters.Count > 0)
            {
                form.Shown += (s, e) =>
                {
                    foreach (KeyValuePair<SplitContainer, int> item in deferredSplitters)
                    {
                        try { item.Key.SplitterDistance = item.Value; }
                        catch { }
                    }
                };
            }

            InitializeBridge(logic);

            LisunEngine.Log("[FormEngine] Форма '" + form.Text + "' собрана: контролов " + context.Components.Count +
                            ", событий " + events.Count + ".");
            return context;
        }

        /// <summary>Вызывает Initialize() у встроенной логики формы.</summary>
        private static void InitializeBridge(object logic)
        {
            if (logic == null) return;

            try
            {
                ExplorerLogicBridge explorer = logic as ExplorerLogicBridge;
                if (explorer != null) { explorer.Initialize(); return; }

                ServerLogicBridge server = logic as ServerLogicBridge;
                if (server != null) { server.Initialize(); return; }

                NotepadLogicBridge notepad = logic as NotepadLogicBridge;
                if (notepad != null) { notepad.Initialize(); return; }

                SysMonLogicBridge monitor = logic as SysMonLogicBridge;
                if (monitor != null) { monitor.Initialize(); return; }

                TemplateLogicBridge template = logic as TemplateLogicBridge;
                if (template != null) { template.Initialize(); return; }

                CalcLogicBridge calculator = logic as CalcLogicBridge;
                if (calculator != null) { calculator.Initialize(); return; }

                SettingsLogicBridge settings = logic as SettingsLogicBridge;
                if (settings != null) { settings.Initialize(); return; }

                StoreLogicBridge store = logic as StoreLogicBridge;
                if (store != null) { store.Initialize(); return; }

                SuperUserLogicBridge superUser = logic as SuperUserLogicBridge;
                if (superUser != null) { superUser.Initialize(); return; }

                SshLogicBridge ssh = logic as SshLogicBridge;
                if (ssh != null) { ssh.Initialize(); return; }

                WifiLogicBridge wifi = logic as WifiLogicBridge;
                if (wifi != null) { wifi.Initialize(); return; }

                LogsLogicBridge logs = logic as LogsLogicBridge;
                if (logs != null) logs.Initialize();
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Инициализация логики: " + ex.Message);
            }
        }

        /// <summary>
        /// Отбрасывает обёртку блоков (namespace/class/метод/фигурные скобки),
        /// оставляя только саму инструкцию. Скобки внутри круглых — например в
        /// Items.AddRange(new ToolStripItem[] { ... }) — не затрагиваются.
        /// </summary>
        private static string StripBlockPrefix(string statement)
        {
            if (string.IsNullOrEmpty(statement)) return string.Empty;

            int depth = 0;
            int lastBrace = -1;

            for (int i = 0; i < statement.Length; i++)
            {
                char c = statement[i];
                if (c == '(') depth++;
                else if (c == ')') depth--;
                else if ((c == '{' || c == '}') && depth <= 0) lastBrace = i;
            }

            return lastBrace >= 0 ? statement.Substring(lastBrace + 1).Trim() : statement.Trim();
        }

        /// <summary>Режет файл на инструкции по ';', не разрывая строковые литералы.</summary>
        private static List<string> SplitStatements(string[] lines)
        {
            StringBuilder joined = new StringBuilder();
            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0) continue;
                if (line.StartsWith("//")) continue;
                joined.Append(line);
                joined.Append(' ');
            }

            List<string> statements = new List<string>();
            StringBuilder current = new StringBuilder();
            bool inString = false;
            string all = joined.ToString();

            for (int i = 0; i < all.Length; i++)
            {
                char c = all[i];
                if (c == '"' && (i == 0 || all[i - 1] != '\\')) inString = !inString;

                if (c == ';' && !inString)
                {
                    statements.Add(current.ToString().Trim());
                    current.Length = 0;
                    continue;
                }
                current.Append(c);
            }
            if (current.Length > 0) statements.Add(current.ToString().Trim());
            return statements;
        }

        // ---------- создание контролов ----------

        private static readonly Regex RxFieldDeclaration = new Regex(
            @"^(?:private|public|internal|protected)\s+(?<type>[A-Za-z0-9_\.]+)\s+(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*(?:=\s*null)?$",
            RegexOptions.Compiled);

        private static readonly Regex RxNewAssignment = new Regex(
            @"^this\.(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*new\s+(?<type>[A-Za-z0-9_\.]+)\s*\(",
            RegexOptions.Compiled);

        private static bool TryCreateComponent(string statement, Dictionary<string, object> components)
        {
            Match assignment = RxNewAssignment.Match(statement);
            if (assignment.Success)
            {
                object instance = CreateInstance(assignment.Groups["type"].Value);

                // Только компоненты являются контролами формы. Строки вида
                // this.ClientSize = new System.Drawing.Size(800, 500) — это обычное
                // присваивание свойства формы, и перехватывать его здесь нельзя.
                if (instance is System.ComponentModel.Component)
                {
                    SetComponentName(instance, assignment.Groups["name"].Value);
                    components[assignment.Groups["name"].Value] = instance;
                    return true;
                }
                return false;
            }

            Match field = RxFieldDeclaration.Match(statement);
            if (field.Success)
            {
                string typeName = field.Groups["type"].Value;
                string name = field.Groups["name"].Value;

                if (typeName.IndexOf("IContainer", StringComparison.Ordinal) >= 0) return true;
                if (components.ContainsKey(name)) return true;

                object instance = CreateInstance(typeName);
                if (instance is System.ComponentModel.Component)
                {
                    SetComponentName(instance, name);
                    components[name] = instance;
                }
                return true;
            }

            return false;
        }

        private static void SetComponentName(object instance, string name)
        {
            try
            {
                PropertyInfo property = instance.GetType().GetProperty("Name");
                if (property != null && property.CanWrite && property.PropertyType == typeof(string))
                    property.SetValue(instance, name, null);
            }
            catch { }
        }

        private static object CreateInstance(string fullTypeName)
        {
            if (string.IsNullOrEmpty(fullTypeName)) return null;

            string shortName = fullTypeName;
            int dot = shortName.LastIndexOf('.');
            if (dot >= 0) shortName = shortName.Substring(dot + 1);

            if (shortName == "Container" || shortName == "IContainer") return null;

            Type type = typeof(Form).Assembly.GetType("System.Windows.Forms." + shortName, false, true);
            if (type == null) type = typeof(Point).Assembly.GetType("System.Drawing." + shortName, false, true);
            if (type == null || type.IsAbstract || type.IsInterface) return null;

            try { return Activator.CreateInstance(type); }
            catch { return null; }
        }

        // ---------- события ----------

        private static readonly Regex RxEvent = new Regex(
            @"^this\.(?<path>[A-Za-z0-9_\.]+)\s*\+=\s*new\s+[A-Za-z0-9_\.]+\s*\(\s*this\.(?<handler>[A-Za-z0-9_]+)\s*\)$",
            RegexOptions.Compiled);

        private static bool TryEventBinding(string statement, List<EventBinding> events)
        {
            Match match = RxEvent.Match(statement);
            if (!match.Success) return false;

            string path = match.Groups["path"].Value;
            int dot = path.LastIndexOf('.');

            EventBinding binding = new EventBinding();
            binding.EventName = dot < 0 ? path : path.Substring(dot + 1);
            binding.TargetPath = dot < 0 ? string.Empty : path.Substring(0, dot);
            binding.HandlerName = match.Groups["handler"].Value;

            events.Add(binding);
            return true;
        }

        private static void WireEvents(List<EventBinding> events, Form form,
            Dictionary<string, object> components, object logic)
        {
            if (logic == null)
            {
                if (events.Count > 0)
                    LisunEngine.Log("[FormEngine] Логика формы не найдена — обработчики событий пропущены (" + events.Count + ").");
                return;
            }

            int wired = 0;
            foreach (EventBinding binding in events)
            {
                try
                {
                    object target = ResolveTarget(binding.TargetPath, form, components);
                    if (target == null) continue;

                    EventInfo eventInfo = target.GetType().GetEvent(binding.EventName);
                    if (eventInfo == null) continue;

                    MethodInfo method = logic.GetType().GetMethod(binding.HandlerName,
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    if (method == null) continue;

                    Delegate handler = Delegate.CreateDelegate(eventInfo.EventHandlerType, logic, method, false);
                    if (handler == null) continue;

                    eventInfo.AddEventHandler(target, handler);
                    wired++;
                }
                catch { }
            }

            LisunEngine.Log("[FormEngine] Подключено обработчиков: " + wired + " из " + events.Count + ".");
        }

        /// <summary>
        /// Подбирает встроенную логику для собранной формы: по составу контролов,
        /// а при неоднозначности — по имени файла логики и каталога пакета.
        /// </summary>
        private static object CreateLogicBridge(DynamicFormContext context, string csPath, string serviceFolder)
        {
            string probe = ((csPath ?? string.Empty) + " " + (serviceFolder ?? string.Empty) + " " +
                            (context.PackageName ?? string.Empty)).ToLowerInvariant();

            try
            {
                if (context.Components.ContainsKey("btnStartServer") || probe.Contains("webserver"))
                    return new ServerLogicBridge(context);

                if (context.Components.ContainsKey("txtEditor") || probe.Contains("notepad"))
                    return new NotepadLogicBridge(context);

                if (context.Components.ContainsKey("lstMonProcesses") || probe.Contains("sysmon"))
                    return new SysMonLogicBridge(context);

                if (context.Components.ContainsKey("btnHello") || probe.Contains("template"))
                    return new TemplateLogicBridge(context);

                if (context.Components.ContainsKey("btnEquals") || probe.Contains("calc"))
                    return new CalcLogicBridge(context);

                if (context.Components.ContainsKey("cmbLanguage") || probe.Contains("settings"))
                    return new SettingsLogicBridge(context);

                if (context.Components.ContainsKey("lstWifiNetworks") || probe.Contains("wifi"))
                    return new WifiLogicBridge(context);

                if (context.Components.ContainsKey("lstPackages") || probe.Contains("store"))
                    return new StoreLogicBridge(context);

                if (context.Components.ContainsKey("btnGrantSuper") || probe.Contains("superuser"))
                    return new SuperUserLogicBridge(context);

                if (context.Components.ContainsKey("lstAddresses") || probe.Contains("sshapp"))
                    return new SshLogicBridge(context);

                if (context.Components.ContainsKey("lstLogLines") || probe.Contains("logsapp"))
                    return new LogsLogicBridge(context);

                if ((context.Components.ContainsKey("lstFilesView") && context.Components.ContainsKey("treeDirNodes"))
                    || probe.Contains("explorer"))
                    return new ExplorerLogicBridge(context);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[FormEngine] [ОШИБКА] Логика формы: " + ex.Message);
            }

            return null;
        }

        // ---------- коллекции и родители ----------

        private static readonly Regex RxControlsAdd = new Regex(
            @"^this\.(?:(?<path>[A-Za-z0-9_\.]+)\.)?Controls\.Add\(\s*this\.(?<child>[A-Za-z0-9_]+)\s*\)$",
            RegexOptions.Compiled);

        private static readonly Regex RxCollectionCall = new Regex(
            @"^this\.(?<path>[A-Za-z0-9_\.]+)\.(?<collection>Items|Columns|DropDownItems|TabPages|Nodes)\.(?<op>Add|AddRange)\((?<args>.*)\)$",
            RegexOptions.Compiled);

        private static bool TryCollectionCall(string statement, Form form, Dictionary<string, object> components)
        {
            Match controlsAdd = RxControlsAdd.Match(statement);
            if (controlsAdd.Success)
            {
                object parent = ResolveTarget(controlsAdd.Groups["path"].Value, form, components);
                Control child = ResolveTarget(controlsAdd.Groups["child"].Value, form, components) as Control;

                Control parentControl = parent as Control;
                if (parentControl != null && child != null && child != parentControl)
                {
                    try { parentControl.Controls.Add(child); }
                    catch (Exception ex) { LisunEngine.Log("[FormEngine] Не удалось вложить контрол: " + ex.Message); }
                }
                return true;
            }

            Match collectionCall = RxCollectionCall.Match(statement);
            if (!collectionCall.Success) return false;

            object owner = ResolveTarget(collectionCall.Groups["path"].Value, form, components);
            if (owner == null) return true;

            object collection = GetPropertyValue(owner, collectionCall.Groups["collection"].Value);
            if (collection == null) return true;

            string args = collectionCall.Groups["args"].Value;
            MatchCollection references = Regex.Matches(args, @"this\.(?<name>[A-Za-z_][A-Za-z0-9_]*)");

            if (references.Count > 0)
            {
                foreach (Match reference in references)
                {
                    object item;
                    if (components.TryGetValue(reference.Groups["name"].Value, out item)) CollectionAdd(collection, item);
                }
                return true;
            }

            // Columns.Add("Имя", 200) и Items.Add("строка")
            MatchCollection literals = Regex.Matches(args, "\"([^\"]*)\"");
            ListView listView = owner as ListView;

            if (listView != null && collectionCall.Groups["collection"].Value == "Columns" && literals.Count > 0)
            {
                int width = 150;
                Match widthMatch = Regex.Match(args, @",\s*(?<w>\d+)");
                if (widthMatch.Success) int.TryParse(widthMatch.Groups["w"].Value, out width);

                try { listView.Columns.Add(literals[0].Groups[1].Value, width); }
                catch { }
                return true;
            }

            foreach (Match literal in literals) CollectionAdd(collection, literal.Groups[1].Value);
            return true;
        }

        private static void CollectionAdd(object collection, object item)
        {
            if (collection == null || item == null) return;

            foreach (MethodInfo method in collection.GetType().GetMethods())
            {
                if (method.Name != "Add") continue;

                ParameterInfo[] parameters = method.GetParameters();
                if (parameters.Length != 1) continue;
                if (!parameters[0].ParameterType.IsInstanceOfType(item)) continue;

                try { method.Invoke(collection, new object[] { item }); return; }
                catch { }
            }
        }

        // ---------- присваивание свойств ----------

        private static readonly Regex RxAssignment = new Regex(
            @"^this\.(?<path>[A-Za-z_][A-Za-z0-9_\.]*)\s*=\s*(?<value>.+)$",
            RegexOptions.Compiled);

        private static void TryAssignment(string statement, Form form, Dictionary<string, object> components,
            List<KeyValuePair<SplitContainer, int>> deferredSplitters)
        {
            Match match = RxAssignment.Match(statement);
            if (!match.Success) return;

            string[] path = match.Groups["path"].Value.Split('.');
            string rawValue = match.Groups["value"].Value.Trim();

            object target = form;
            int index = 0;

            object component;
            if (components.TryGetValue(path[0], out component))
            {
                target = component;
                index = 1;
            }

            for (int i = index; i < path.Length - 1; i++)
            {
                target = GetPropertyValue(target, path[i]);
                if (target == null) return;
            }

            string propertyName = path[path.Length - 1];

            PropertyInfo property = target.GetType().GetProperty(propertyName,
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
            if (property == null || !property.CanWrite) return;

            object value = ConvertValue(rawValue, property.PropertyType, components);
            if (value == null) return;

            // SplitterDistance нельзя выставить, пока контрол не получил реальный размер,
            // поэтому такие присваивания откладываются до показа формы.
            SplitContainer splitContainer = target as SplitContainer;
            if (splitContainer != null && propertyName.Equals("SplitterDistance", StringComparison.OrdinalIgnoreCase))
            {
                deferredSplitters.Add(new KeyValuePair<SplitContainer, int>(splitContainer, Convert.ToInt32(value)));
            }

            try { property.SetValue(target, value, null); }
            catch { }
        }

        private static object GetPropertyValue(object target, string propertyName)
        {
            if (target == null) return null;
            try
            {
                PropertyInfo property = target.GetType().GetProperty(propertyName,
                    BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
                if (property == null) return null;
                return property.GetValue(target, null);
            }
            catch { return null; }
        }

        private static object ResolveTarget(string path, Form form, Dictionary<string, object> components)
        {
            if (string.IsNullOrEmpty(path)) return form;

            string[] parts = path.Split('.');
            object target;

            object component;
            int index;
            if (components.TryGetValue(parts[0], out component))
            {
                target = component;
                index = 1;
            }
            else
            {
                target = form;
                index = 0;
            }

            for (int i = index; i < parts.Length; i++)
            {
                target = GetPropertyValue(target, parts[i]);
                if (target == null) return null;
            }
            return target;
        }

        // ---------- преобразование значений ----------

        private static object ConvertValue(string raw, Type targetType, Dictionary<string, object> components)
        {
            if (raw == null) return null;
            string value = raw.Trim().TrimEnd(';').Trim();
            if (value.Length == 0) return null;

            // ссылка на другой контрол: this.ctxExplorerMenu
            Match reference = Regex.Match(value, @"^this\.(?<name>[A-Za-z_][A-Za-z0-9_]*)$");
            if (reference.Success)
            {
                object component;
                if (components.TryGetValue(reference.Groups["name"].Value, out component) &&
                    targetType.IsInstanceOfType(component)) return component;
                return null;
            }

            if (targetType == typeof(string))
            {
                if (value.StartsWith("\"") && value.EndsWith("\"") && value.Length >= 2)
                    return Unescape(value.Substring(1, value.Length - 2));
                return Unescape(value.Trim('"'));
            }

            if (targetType == typeof(bool))
            {
                if (value.IndexOf("true", StringComparison.OrdinalIgnoreCase) >= 0) return true;
                if (value.IndexOf("false", StringComparison.OrdinalIgnoreCase) >= 0) return false;
                return null;
            }

            if (targetType.IsEnum) return ConvertEnum(value, targetType);

            if (targetType == typeof(Color)) return ConvertColor(value);

            if (targetType == typeof(Font)) return ConvertFont(value);

            if (targetType == typeof(Point))
            {
                int[] numbers = ExtractNumbers(value);
                if (numbers.Length >= 2) return new Point(numbers[0], numbers[1]);
                return null;
            }

            if (targetType == typeof(Size))
            {
                int[] numbers = ExtractNumbers(value);
                if (numbers.Length >= 2) return new Size(numbers[0], numbers[1]);
                return null;
            }

            if (targetType == typeof(SizeF))
            {
                float[] numbers = ExtractFloats(value);
                if (numbers.Length >= 2) return new SizeF(numbers[0], numbers[1]);
                return null;
            }

            if (targetType == typeof(Padding))
            {
                int[] numbers = ExtractNumbers(value);
                if (numbers.Length >= 4) return new Padding(numbers[0], numbers[1], numbers[2], numbers[3]);
                if (numbers.Length == 1) return new Padding(numbers[0]);
                return null;
            }

            if (targetType == typeof(int) || targetType == typeof(long) || targetType == typeof(short))
            {
                int[] numbers = ExtractNumbers(value);
                if (numbers.Length == 0) return null;
                try { return Convert.ChangeType(numbers[0], targetType); }
                catch { return null; }
            }

            if (targetType == typeof(float) || targetType == typeof(double) || targetType == typeof(decimal))
            {
                float[] numbers = ExtractFloats(value);
                if (numbers.Length == 0) return null;
                try { return Convert.ChangeType(numbers[0], targetType); }
                catch { return null; }
            }

            if (targetType == typeof(char))
            {
                Match ch = Regex.Match(value, @"'(.)'");
                if (ch.Success) return ch.Groups[1].Value[0];
                return null;
            }

            return null;
        }

        private static object ConvertEnum(string value, Type enumType)
        {
            long accumulated = 0;
            bool found = false;

            foreach (Match token in Regex.Matches(value, @"[A-Za-z_][A-Za-z0-9_]*"))
            {
                string name = token.Value;
                if (!Enum.IsDefined(enumType, name)) continue;

                try
                {
                    accumulated |= Convert.ToInt64(Enum.Parse(enumType, name));
                    found = true;
                }
                catch { }
            }

            if (found) return Enum.ToObject(enumType, accumulated);

            int[] numbers = ExtractNumbers(value);
            if (numbers.Length > 0)
            {
                try { return Enum.ToObject(enumType, numbers[0]); }
                catch { }
            }
            return null;
        }

        private static object ConvertColor(string value)
        {
            int argbIndex = value.IndexOf("FromArgb", StringComparison.Ordinal);
            if (argbIndex >= 0)
            {
                int[] numbers = ExtractNumbers(value.Substring(argbIndex));
                try
                {
                    if (numbers.Length >= 4) return Color.FromArgb(numbers[0], numbers[1], numbers[2], numbers[3]);
                    if (numbers.Length == 3) return Color.FromArgb(numbers[0], numbers[1], numbers[2]);
                    if (numbers.Length == 1) return Color.FromArgb(numbers[0]);
                }
                catch { return null; }
                return null;
            }

            Match named = Regex.Match(value, @"Color\.(?<name>[A-Za-z]+)");
            if (named.Success)
            {
                string name = named.Groups["name"].Value;
                try
                {
                    KnownColor known = (KnownColor)Enum.Parse(typeof(KnownColor), name, true);
                    return Color.FromKnownColor(known);
                }
                catch { }

                Color parsed = Color.FromName(name);
                if (parsed.IsKnownColor) return parsed;
            }
            return null;
        }

        private static object ConvertFont(string value)
        {
            Match match = Regex.Match(value, "\"(?<family>[^\"]*)\"\\s*,\\s*(?<size>[0-9]+(?:[\\.,][0-9]+)?)");
            if (!match.Success) return null;

            string family = match.Groups["family"].Value;
            float size;
            if (!float.TryParse(match.Groups["size"].Value.Replace(',', '.'),
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out size)) size = 9f;

            FontStyle style = FontStyle.Regular;
            foreach (Match token in Regex.Matches(value, @"FontStyle\.(?<name>[A-Za-z]+)"))
            {
                try { style |= (FontStyle)Enum.Parse(typeof(FontStyle), token.Groups["name"].Value, true); }
                catch { }
            }

            try
            {
                FontFamily fontFamily = new FontFamily(family);
                if (!fontFamily.IsStyleAvailable(style)) style = FontStyle.Regular;
                return new Font(fontFamily, size, style);
            }
            catch
            {
                return Theme.Ui(size, style);
            }
        }

        private static int[] ExtractNumbers(string value)
        {
            MatchCollection matches = Regex.Matches(value, @"-?\d+");
            List<int> numbers = new List<int>();
            foreach (Match match in matches)
            {
                int parsed;
                if (int.TryParse(match.Value, out parsed)) numbers.Add(parsed);
            }
            return numbers.ToArray();
        }

        private static float[] ExtractFloats(string value)
        {
            MatchCollection matches = Regex.Matches(value, @"-?\d+(?:\.\d+)?");
            List<float> numbers = new List<float>();
            foreach (Match match in matches)
            {
                float parsed;
                if (float.TryParse(match.Value, System.Globalization.NumberStyles.Float,
                    System.Globalization.CultureInfo.InvariantCulture, out parsed)) numbers.Add(parsed);
            }
            return numbers.ToArray();
        }

        private static string Unescape(string value)
        {
            return value.Replace("\\\\", "\\").Replace("\\\"", "\"").Replace("\\n", "\n").Replace("\\t", "\t");
        }
    }
}
