﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Брандмауэр LisunOS (команда ufw).
    /// Правила хранятся в /os/root/regedit/FIREWALL, применяются ко всем
    /// сетевым службам системы через Allows(port).
    /// </summary>
    public static class LisunFirewall
    {
        private static readonly Dictionary<int, bool> Rules = new Dictionary<int, bool>();
        private static bool enabled;
        private static bool loaded;

        /// <summary>Политика по умолчанию для портов без правила: false — запрещать.</summary>
        public static bool DefaultAllow { get; private set; }

        public static event Action Changed;

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "FIREWALL"); }
        }

        public static bool Enabled
        {
            get { EnsureLoaded(); return enabled; }
        }

        // =====================================================================
        //  Хранилище
        // =====================================================================

        public static void Load()
        {
            Rules.Clear();
            enabled = false;
            DefaultAllow = false;
            loaded = true;

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    string[] parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length != 2) continue;

                    string key = parts[0].Trim().ToLowerInvariant();
                    string value = parts[1].Trim().ToLowerInvariant();

                    if (key == "status") { enabled = value == "enabled" || value == "on" || value == "true"; continue; }
                    if (key == "default") { DefaultAllow = value == "allow"; continue; }

                    int port;
                    if (!int.TryParse(key, out port)) continue;

                    Rules[port] = value == "allow" || value == "enable" || value == "open" || value == "true";
                }

                LisunEngine.Log("[UFW] Брандмауэр " + (enabled ? "включён" : "выключен") +
                                ", правил: " + Rules.Count + ".");
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[UFW] [ОШИБКА] Чтение FIREWALL: " + ex.Message);
            }
        }

        public static void Save()
        {
            try
            {
                List<string> lines = new List<string>();
                lines.Add("status=" + (enabled ? "enabled" : "disabled"));
                lines.Add("default=" + (DefaultAllow ? "allow" : "deny"));

                List<int> ports = new List<int>(Rules.Keys);
                ports.Sort();
                foreach (int port in ports) lines.Add(port + "=" + (Rules[port] ? "allow" : "deny"));

                File.WriteAllLines(StorePath, lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[UFW] [ОШИБКА] Запись FIREWALL: " + ex.Message);
            }
        }

        private static void EnsureLoaded()
        {
            if (!loaded) Load();
        }

        private static void Raise()
        {
            Action handler = Changed;
            if (handler != null) handler();
        }

        // =====================================================================
        //  Управление
        // =====================================================================

        public static void Enable()
        {
            EnsureLoaded();
            enabled = true;
            Save();
            LisunEngine.Log("[UFW] Брандмауэр включён.");
            Raise();
        }

        public static void Disable()
        {
            EnsureLoaded();
            enabled = false;
            Save();
            LisunEngine.Log("[UFW] Брандмауэр выключен.");
            Raise();
        }

        public static void SetDefault(bool allow)
        {
            EnsureLoaded();
            DefaultAllow = allow;
            Save();
            Raise();
        }

        public static void SetPort(int port, bool allow)
        {
            EnsureLoaded();
            Rules[port] = allow;
            Save();
            LisunEngine.Log("[UFW] Порт " + port + ": " + (allow ? "разрешён" : "запрещён") + ".");
            Raise();
        }

        public static bool RemovePort(int port)
        {
            EnsureLoaded();
            if (!Rules.Remove(port)) return false;

            Save();
            Raise();
            return true;
        }

        public static void Reset()
        {
            EnsureLoaded();
            Rules.Clear();
            enabled = false;
            DefaultAllow = false;
            Save();
            Raise();
        }

        // =====================================================================
        //  Проверка
        // =====================================================================

        /// <summary>Разрешён ли порт. Выключенный брандмауэр пропускает всё.</summary>
        public static bool Allows(int port)
        {
            EnsureLoaded();
            if (!enabled) return true;

            bool allow;
            if (Rules.TryGetValue(port, out allow)) return allow;

            return DefaultAllow;
        }

        public static bool HasRule(int port)
        {
            EnsureLoaded();
            return Rules.ContainsKey(port);
        }

        public static string Describe(int port)
        {
            EnsureLoaded();

            if (!enabled) return LisunLocale.T("ufw.offPass");

            bool allow;
            if (Rules.TryGetValue(port, out allow))
                return allow ? LisunLocale.T("ufw.allowed") : LisunLocale.T("ufw.denied");

            return DefaultAllow ? LisunLocale.T("ufw.allowedDefault") : LisunLocale.T("ufw.deniedDefault");
        }

        public static string Status()
        {
            EnsureLoaded();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("ufw.statusTitle"));
            sb.AppendLine("   " + LisunLocale.T("ufw.state") + ": " +
                          (enabled ? LisunLocale.T("ufw.on") : LisunLocale.T("ufw.off")));
            sb.AppendLine("   " + LisunLocale.T("ufw.defaultPolicy") + ": " +
                          (DefaultAllow ? LisunLocale.T("ufw.allowed") : LisunLocale.T("ufw.denied")));

            if (Rules.Count == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("ufw.noRules"));
                return sb.ToString().TrimEnd();
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ufw.rules") + ":");

            List<int> ports = new List<int>(Rules.Keys);
            ports.Sort();

            foreach (int port in ports)
            {
                string state = Rules[port] ? LisunLocale.T("ufw.allowed") : LisunLocale.T("ufw.denied");
                string note = LisunWellKnownPorts.Describe(port);

                sb.AppendLine("     " + port.ToString().PadRight(8) + state.PadRight(12) +
                              (note.Length > 0 ? "— " + note : ""));
            }

            return sb.ToString().TrimEnd();
        }
    }

    /// <summary>Подписи для часто используемых портов — для вывода ufw и панели сервера.</summary>
    public static class LisunWellKnownPorts
    {
        private static readonly Dictionary<int, string> Names = new Dictionary<int, string>
        {
            { 21, "FTP" }, { 22, "SSH" }, { 25, "SMTP" }, { 53, "DNS" },
            { 80, "HTTP" }, { 443, "HTTPS" }, { 3306, "MySQL" }, { 5432, "PostgreSQL" },
            { 6379, "Redis" }, { 8000, "HTTP alt" }, { 8080, "HTTP alt" }, { 8443, "HTTPS alt" },
            { 25565, "Minecraft" }
        };

        public static string Describe(int port)
        {
            string name;
            return Names.TryGetValue(port, out name) ? name : string.Empty;
        }
    }
}
