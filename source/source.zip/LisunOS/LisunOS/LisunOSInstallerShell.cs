﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace LisunOS
{
    public static class LisunOSInstallerShell
    {
        private static readonly string HiddenHallTokenPath = Path.Combine(LisunEngine.RegeditPath, ".hall_token");
        private const string MasterHallKey = "LisunOSHallKey0100101001";
        private const string ManifestName = "install.manifest";

        private sealed class LsiResult
        {
            public bool NeedsRestart;
            public bool Protect = true;     // по умолчанию пакет шифруется после установки
            public bool Aborted;
        }

        // =====================================================================
        //  Токены
        // =====================================================================

        public static void InitializeSecurityTokens()
        {
            try
            {
                if (!File.Exists(HiddenHallTokenPath))
                {
                    string dynamicKey = "Hall_" + Guid.NewGuid().ToString("N").Substring(0, 16).ToUpper();
                    File.WriteAllText(HiddenHallTokenPath, dynamicKey);
                    LisunEngine.RegistryConfig["lisunhallkey"] = dynamicKey;
                    LisunEngine.SaveRegistry();
                }
                else
                {
                    LisunEngine.RegistryConfig["lisunhallkey"] = File.ReadAllText(HiddenHallTokenPath).Trim();
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Installer] [ОШИБКА] Инициализация токенов: " + ex.Message);
            }
        }

        // =====================================================================
        //  Установка
        // =====================================================================

        public static bool InstallPackage(string packagePath)
        {
            return InstallPackage(packagePath, false);
        }

        /// <summary>
        /// elevated = true означает запуск через sudo или из режима root:
        /// разрешена установка оболочек (type = hall) без hall_key
        /// и перезапись уже установленного пакета.
        /// </summary>
        public static bool InstallPackage(string packagePath, bool elevated)
        {
            // Пакет может быть закрыт паролем: тогда внутри lock.json и
            // payload.enc, а настоящий .lnsh появляется только после ввода.
            string unlocked = null;

            if (LisunPackageLock.IsLocked(packagePath))
            {
                string note;
                if (!LisunPackageLock.AskAndUnlock(packagePath, out unlocked, out note))
                {
                    LisunEngine.Log("[Installer] " + note.Trim());
                    return false;
                }

                packagePath = unlocked;
            }

            try
            {
                return InstallUnlockedPackage(packagePath, elevated);
            }
            finally
            {
                try { if (unlocked != null && File.Exists(unlocked)) File.Delete(unlocked); }
                catch { }
            }
        }

        private static bool InstallUnlockedPackage(string packagePath, bool elevated)
        {
            string appName = Path.GetFileNameWithoutExtension(packagePath);
            string extractionTempDir = Path.Combine(LisunEngine.TempPath, "extract_" + appName);

            try
            {
                if (Directory.Exists(extractionTempDir)) Directory.Delete(extractionTempDir, true);
                Directory.CreateDirectory(extractionTempDir);

                LisunEngine.Log("[Installer] Распаковка пакета " + appName +
                                (elevated ? " (режим суперпользователя)" : "") + "...");
                ZipFile.ExtractToDirectory(packagePath, extractionTempDir);

                string metaPath = Path.Combine(extractionTempDir, "meta.json");
                if (!File.Exists(metaPath))
                {
                    LisunEngine.Log("[Installer] [ОШИБКА] Отсутствует манифест meta.json");
                    return false;
                }

                // Манифест может быть одним объектом или массивом локализаций (lang: ruRU / enUS).
                LisunManifest manifest = LisunManifest.FromFile(metaPath);
                if (manifest.IsEmpty)
                {
                    LisunEngine.Log("[Installer] [ОШИБКА] Манифест meta.json не разобран.");
                    return false;
                }

                if (string.IsNullOrEmpty(manifest.Name)) manifest.Name = appName;
                string packageName = manifest.Name;

                List<string> languages = manifest.Languages;
                LisunEngine.Log("[Installer] Пакет: " + manifest.DisplayName + " v" + manifest.Version +
                                (languages.Count > 0 ? "  языки: " + string.Join(", ", languages.ToArray()) : ""));

                if (LisunPackageTypes.NeedsElevation(manifest.Type) &&
                    !elevated && !ValidateHallKey(manifest))
                {
                    LisunEngine.Log("[Installer] " + LisunLocale.T("type.needsSudo", manifest.Type).Trim());
                    return false;
                }

                // Приложение запрашивает объявленные права у пользователя до развёртывания.
                if (manifest.Permissions.Count > 0)
                {
                    bool consent = LisunPermissions.RequestMany(packageName, manifest.Description, manifest.Permissions);
                    if (!consent)
                    {
                        LisunEngine.Log("[Installer] Установка отменена: пользователь отклонил запрос разрешений.");
                        return false;
                    }
                }

                string targetDir = Path.Combine(LisunEngine.ServicesPath, appName);
                if (Directory.Exists(targetDir)) Directory.Delete(targetDir, true);
                Directory.CreateDirectory(targetDir);

                CopyTree(extractionTempDir, targetDir);

                manifest.FolderName = appName;
                manifest.Source = packagePath;
                manifest.WriteInstallManifest(targetDir);

                LsiResult result = new LsiResult();
                string lsiPath = Path.Combine(targetDir, "main.lsi");

                if (File.Exists(lsiPath))
                {
                    LisunEngine.Log("[Installer] Выполнение сценария main.lsi...");
                    result = ExecuteLsiScript(LisunCrypto.ReadAllLines(lsiPath), targetDir, elevated, packageName);
                    if (result.Aborted)
                    {
                        LisunEngine.Log("[Installer] [ОШИБКА] Сценарий установки прерван.");
                        return false;
                    }
                }
                else
                {
                    LisunEngine.Log("[Installer] Предупреждение: main.lsi не найден.");
                }

                if (result.Protect)
                {
                    int encrypted = LisunCrypto.ProtectPackage(targetDir);
                    LisunEngine.Log("[Installer] Пакет защищён: зашифровано файлов — " + encrypted +
                                    " (.service, .lsi, assets).");
                }

                LisunEngine.Log("[Installer] [OK] Пакет " + appName + " установлен.");

                // Служба уже выполнена через register_service, команды
                // зарегистрированы — приложение работает сразу. Перезапуск
                // нужен только оболочке зала: она подменяет само окно системы.
                LisunEngine.SaveRegisteredCommands();

                if (result.NeedsRestart && LisunPackageTypes.NeedsElevation(manifest.Type)) AskForRestart();
                else if (result.NeedsRestart)
                    LisunEngine.Log("[Installer] " + LisunLocale.T("install.noRestart", packageName).Trim());

                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Installer] [ОШИБКА] " + ex.Message);
                return false;
            }
            finally
            {
                try
                {
                    if (Directory.Exists(extractionTempDir)) Directory.Delete(extractionTempDir, true);
                }
                catch { }
            }
        }

        private static void AskForRestart()
        {
            DialogResult answer = MessageBox.Show(
                "Для завершения установки требуется перезапуск подсистем LisunOS. Выполнить сейчас?",
                "LisunOS Installer",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (answer == DialogResult.Yes) LisunEngine.RequestSoftRestart();
        }

        private static bool ValidateHallKey(LisunManifest manifest)
        {
            string providedKey = manifest.HallKey ?? string.Empty;
            string currentSystemKey = string.Empty;

            try
            {
                if (File.Exists(HiddenHallTokenPath)) currentSystemKey = File.ReadAllText(HiddenHallTokenPath).Trim();
            }
            catch { }

            return providedKey == MasterHallKey || (currentSystemKey.Length > 0 && providedKey == currentSystemKey);
        }

        private static void CopyTree(string source, string destination)
        {
            foreach (string dirPath in Directory.GetDirectories(source, "*", SearchOption.AllDirectories))
                Directory.CreateDirectory(dirPath.Replace(source, destination));

            foreach (string filePath in Directory.GetFiles(source, "*.*", SearchOption.AllDirectories))
                File.Copy(filePath, filePath.Replace(source, destination), true);
        }

        // =====================================================================
        //  Сценарии .lsi
        // =====================================================================

        private static LsiResult ExecuteLsiScript(string[] lines, string targetDir, bool elevated, string packageName)
        {
            LsiResult result = new LsiResult();

            foreach (string raw in lines)
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;

                string[] parts = line.Split(new[] { ' ' }, 2);
                string command = parts[0].ToLower().Trim();
                string argument = parts.Length > 1 ? parts[1].Trim().Trim('\'', '"') : string.Empty;

                switch (command)
                {
                    // deploy <тип> [маска] — разложить файлы пакета по месту типа:
                    // языковой пакет в /sys/locale, тему в /sys/themes и так далее.
                    case "deploy":
                    {
                        string[] pieces = argument.Split(new[] { ' ' }, 2);
                        string type = pieces.Length > 0 ? pieces[0].Trim() : string.Empty;
                        string mask = pieces.Length > 1 ? pieces[1].Trim() : "*.*";

                        string destination = LisunPackageTypes.TargetFolder(type);
                        if (destination.Length == 0)
                        {
                            LisunEngine.Log("[LSI] deploy: у типа '" + type + "' нет своей папки.");
                            break;
                        }

                        try
                        {
                            if (!Directory.Exists(destination)) Directory.CreateDirectory(destination);

                            int copied = 0;
                            foreach (string file in Directory.GetFiles(targetDir, mask))
                            {
                                File.Copy(file, Path.Combine(destination, Path.GetFileName(file)), true);
                                copied++;
                            }

                            LisunEngine.Log("[LSI] " + LisunLocale.T("type.deployed", type,
                                CustomFormUtils.ToVirtualPath(destination)).Trim() + " (" + copied + ")");
                        }
                        catch (Exception ex)
                        {
                            LisunEngine.Log("[LSI] [ОШИБКА] deploy: " + ex.Message);
                        }

                        break;
                    }

                    case "register_service":
                    case "run":
                        RegisterService(argument, targetDir, packageName);
                        break;

                    case "request_permission":
                        LisunPermissions.Demand(packageName, argument.Trim().ToLowerInvariant());
                        break;

                    case "download_file":
                        if (!LisunPermissions.Demand(packageName, LisunPermissions.Network)) break;
                        DownloadAsset(argument, targetDir);
                        break;

                    case "unpack":
                        UnpackArchive(argument, targetDir);
                        break;

                    case "copy":
                        CopyInside(argument, targetDir);
                        break;

                    case "mkdir":
                        MakeDirectory(argument);
                        break;

                    case "delete":
                        DeleteInside(argument, targetDir);
                        break;

                    case "set_data":
                        if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) break;
                        AssignRegistry(argument, false);
                        break;

                    case "set_config":
                        if (!elevated)
                        {
                            LisunEngine.Log("[LSI] [ОШИБКА] set_config доступен только при установке через sudo.");
                            break;
                        }
                        if (!LisunPermissions.Demand(packageName, LisunPermissions.EditSettings)) break;
                        AssignRegistry(argument, true);
                        break;

                    case "register_command":
                        RegisterCommandAlias(argument);
                        break;

                    case "require_core":
                        if (!CheckCoreVersion(argument))
                        {
                            LisunEngine.Log("[LSI] [ОШИБКА] Пакету нужна версия ядра " + argument +
                                            ", установлена " + LisunEngine.Version + ".");
                            result.Aborted = true;
                            return result;
                        }
                        break;

                    case "log":
                        LisunEngine.Log("[LSI] " + argument);
                        break;

                    case "message":
                        if (!LisunPermissions.Demand(packageName, LisunPermissions.ShowDialogs)) break;
                        MessageBox.Show(argument, "LisunOS Installer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        break;

                    case "protect":
                        result.Protect = true;
                        break;

                    case "no_protect":
                        result.Protect = false;
                        LisunEngine.Log("[LSI] Пакет помечен как открытый — шифрование отключено.");
                        break;

                    case "request_restart":
                        result.NeedsRestart = true;
                        break;

                    default:
                        LisunEngine.Log("[LSI] Неизвестная директива: " + command);
                        break;
                }
            }

            return result;
        }

        private static void RegisterService(string argument, string targetDir, string packageName)
        {
            string servicePath = Path.Combine(targetDir, argument);
            if (!File.Exists(servicePath))
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Файл службы не найден: " + argument);
                return;
            }

            string[] serviceLines = LisunCrypto.ReadAllLines(servicePath);
            LisunEngine.RunOnUi(() => FormEngine.ExecuteScript(serviceLines, targetDir, packageName));
            LisunEngine.Log("[LSI] Служба зарегистрирована: " + argument);
        }

        private static void RegisterCommandAlias(string argument)
        {
            string[] parts = argument.Split(new[] { "->" }, StringSplitOptions.None);
            if (parts.Length != 2)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Формат: register_command <команда> -> <приложение>");
                return;
            }

            string trigger = parts[0].Trim().ToLowerInvariant();
            string appName = parts[1].Trim();

            LisunEngine.RegisteredCommands[trigger] = new List<string> { appName };
            LisunEngine.SaveRegisteredCommands();
            LisunEngine.Log("[LSI] Команда '" + trigger + "' связана с приложением " + appName + ".");
        }

        private static void AssignRegistry(string argument, bool config)
        {
            string[] parts = argument.Split(new[] { '=' }, 2);
            if (parts.Length != 2)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Формат: set_data <ключ>=<значение>");
                return;
            }

            string key = parts[0].Trim().ToLowerInvariant();
            string value = parts[1].Trim().Trim('\'', '"');

            if (config) LisunEngine.RegistryConfig[key] = value;
            else LisunEngine.RegistryData[key] = value;

            LisunEngine.SaveRegistry();
            LisunEngine.Log("[LSI] Реестр: " + key + " = " + value);
        }

        private static void MakeDirectory(string argument)
        {
            try
            {
                string resolved;
                if (!CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, argument, out resolved))
                {
                    LisunEngine.Log("[LSI] [ОШИБКА] Путь вне корня LisunOS: " + argument);
                    return;
                }

                Directory.CreateDirectory(resolved);
                LisunEngine.Log("[LSI] Создан каталог: " + CustomFormUtils.ToVirtualPath(resolved));
            }
            catch (Exception ex) { LisunEngine.Log("[LSI] [ОШИБКА] mkdir: " + ex.Message); }
        }

        private static void CopyInside(string argument, string targetDir)
        {
            string[] parts = argument.Split(new[] { "->" }, StringSplitOptions.None);
            if (parts.Length != 2)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Формат: copy <источник> -> <назначение>");
                return;
            }

            try
            {
                string source = Path.Combine(targetDir, parts[0].Trim());
                string destination;

                if (!CustomFormUtils.TryResolveInsideRoot(targetDir, parts[1].Trim(), out destination))
                {
                    LisunEngine.Log("[LSI] [ОШИБКА] Назначение вне корня LisunOS.");
                    return;
                }

                string directory = Path.GetDirectoryName(destination);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

                File.Copy(source, destination, true);
                LisunEngine.Log("[LSI] Скопировано: " + parts[1].Trim());
            }
            catch (Exception ex) { LisunEngine.Log("[LSI] [ОШИБКА] copy: " + ex.Message); }
        }

        private static void DeleteInside(string argument, string targetDir)
        {
            try
            {
                string resolved;
                if (!CustomFormUtils.TryResolveInsideRoot(targetDir, argument, out resolved))
                {
                    LisunEngine.Log("[LSI] [ОШИБКА] Путь вне корня LisunOS.");
                    return;
                }

                if (File.Exists(resolved)) File.Delete(resolved);
                else if (Directory.Exists(resolved)) Directory.Delete(resolved, true);

                LisunEngine.Log("[LSI] Удалено: " + argument);
            }
            catch (Exception ex) { LisunEngine.Log("[LSI] [ОШИБКА] delete: " + ex.Message); }
        }

        private static void UnpackArchive(string argument, string targetDir)
        {
            string[] parts = argument.Split(new[] { "->" }, StringSplitOptions.None);
            if (parts.Length != 2)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Формат: unpack <архив.zip> -> <каталог>");
                return;
            }

            try
            {
                string archive = Path.Combine(targetDir, parts[0].Trim());
                string destination = Path.Combine(targetDir, parts[1].Trim());

                if (!File.Exists(archive))
                {
                    LisunEngine.Log("[LSI] [ОШИБКА] Архив не найден: " + parts[0].Trim());
                    return;
                }

                Directory.CreateDirectory(destination);
                ZipFile.ExtractToDirectory(archive, destination);
                LisunEngine.Log("[LSI] Архив распакован в " + parts[1].Trim());
            }
            catch (Exception ex) { LisunEngine.Log("[LSI] [ОШИБКА] unpack: " + ex.Message); }
        }

        private static bool CheckCoreVersion(string required)
        {
            try
            {
                Version needed = new Version(required.Trim());
                Version current = new Version(LisunEngine.Version);
                return current >= needed;
            }
            catch { return true; }
        }

        private static void DownloadAsset(string argument, string targetDir)
        {
            string[] parts = argument.Split(new[] { "->" }, StringSplitOptions.None);
            if (parts.Length != 2)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Формат: download_file <url> -> <файл>");
                return;
            }

            try
            {
                // Без явного TLS 1.2 загрузка с большинства современных сайтов падает.
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                string destination = Path.Combine(targetDir, "assets", parts[1].Trim());
                string directory = Path.GetDirectoryName(destination);
                if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(parts[0].Trim(), destination);
                }
                LisunEngine.Log("[LSI] Загружен ресурс: " + parts[1].Trim());
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[LSI] [ОШИБКА] Загрузка: " + ex.Message);
            }
        }

        // =====================================================================
        //  Работа с установленными пакетами (для apt)
        // =====================================================================

        /// <summary>Читает манифест установленного пакета (meta.json + install.manifest).</summary>
        public static LisunManifest ReadManifest(string packageDirectory)
        {
            LisunManifest manifest = LisunManifest.FromFile(Path.Combine(packageDirectory, "meta.json"));
            manifest.FolderName = Path.GetFileName(packageDirectory);
            manifest.MergeInstallManifest(packageDirectory);

            if (string.IsNullOrEmpty(manifest.Name)) manifest.Name = manifest.FolderName;
            return manifest;
        }

        public static List<string> InstalledPackageDirectories()
        {
            List<string> result = new List<string>();
            try
            {
                if (Directory.Exists(LisunEngine.ServicesPath))
                {
                    result.AddRange(Directory.GetDirectories(LisunEngine.ServicesPath));
                    result.Sort(StringComparer.OrdinalIgnoreCase);
                }
            }
            catch { }
            return result;
        }

        /// <summary>Ищет установленный пакет по name из манифеста или по имени каталога.</summary>
        public static string FindInstalledPackage(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            name = name.Trim();

            foreach (string directory in InstalledPackageDirectories())
            {
                if (Path.GetFileName(directory).Equals(name, StringComparison.OrdinalIgnoreCase)) return directory;

                LisunManifest manifest = ReadManifest(directory);
                if (!string.IsNullOrEmpty(manifest.Name) &&
                    manifest.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return directory;

                if (manifest.DisplayName.Equals(name, StringComparison.OrdinalIgnoreCase)) return directory;
            }

            // superuser = SuperUserApp: второй проход без суффикса и регистра.
            foreach (string directory in InstalledPackageDirectories())
            {
                if (LisunStore.SameName(Path.GetFileName(directory), name)) return directory;

                LisunManifest manifest = ReadManifest(directory);
                if (LisunStore.SameName(manifest.Name, name)) return directory;
                if (LisunStore.SameName(manifest.DisplayName, name)) return directory;
            }

            return null;
        }

        public static bool UninstallPackage(string name)
        {
            string directory = FindInstalledPackage(name);
            if (directory == null) return false;

            try
            {
                LisunManifest manifest = ReadManifest(directory);

                // Снимаем привязанные команды и выданные права.
                List<string> stale = new List<string>();
                foreach (KeyValuePair<string, List<string>> kvp in LisunEngine.RegisteredCommands)
                {
                    if (kvp.Key.Equals(manifest.Name, StringComparison.OrdinalIgnoreCase)) stale.Add(kvp.Key);
                }
                foreach (string key in stale) LisunEngine.RegisteredCommands.Remove(key);

                LisunPermissions.Reset(manifest.Name);

                Directory.Delete(directory, true);
                LisunEngine.SaveRegisteredCommands();
                LisunEngine.Log("[Installer] Пакет " + manifest.Name + " удалён.");
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Installer] [ОШИБКА] Удаление: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Переустановка пакета из источника в install.manifest
        /// либо из URL, указанного в манифесте.
        /// </summary>
        public static bool UpdatePackage(string name, bool elevated, out string message)
        {
            string directory = FindInstalledPackage(name);
            if (directory == null)
            {
                message = "пакет не найден";
                return false;
            }

            LisunManifest manifest = ReadManifest(directory);

            if (!string.IsNullOrEmpty(manifest.Source) && File.Exists(manifest.Source))
            {
                message = Path.GetFileName(manifest.Source);
                return InstallPackage(manifest.Source, elevated);
            }

            if (!string.IsNullOrEmpty(manifest.Url))
            {
                if (!LisunPermissions.Demand(manifest.Name, LisunPermissions.Network))
                {
                    message = "нет права network";
                    return false;
                }

                try
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    string temp = Path.Combine(LisunEngine.TempPath, Path.GetFileName(directory) + ".lnsh");
                    using (WebClient client = new WebClient()) client.DownloadFile(manifest.Url, temp);

                    message = manifest.Url;
                    return InstallPackage(temp, elevated);
                }
                catch (Exception ex)
                {
                    message = "загрузка не удалась — " + ex.Message;
                    return false;
                }
            }

            message = "источник обновления не указан (нет source в install.manifest и url в манифесте)";
            return false;
        }
    }
}
