﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    public enum LisunLanguage
    {
        Russian = 0,
        English = 1
    }

    /// <summary>
    /// Язык интерфейса LisunOS и раскладка клавиатуры.
    /// По умолчанию система русская; выбор сохраняется в реестре (DATA).
    /// </summary>
    public static class LisunLocale
    {
        public static LisunLanguage Language { get; private set; }

        public static event Action LanguageChanged;
        public static event Action LayoutChanged;

        static LisunLocale()
        {
            Language = LisunLanguage.Russian;
        }

        public static string Code
        {
            get { return Language == LisunLanguage.Russian ? "ru" : "en"; }
        }

        public static string DisplayName
        {
            get { return Language == LisunLanguage.Russian ? "Русский" : "English"; }
        }

        /// <summary>Полный тег языка, как он указывается в манифестах пакетов: ruRU / enUS.</summary>
        public static string ManifestTag
        {
            get { return Language == LisunLanguage.Russian ? "ruRU" : "enUS"; }
        }

        // =====================================================================
        //  Язык интерфейса
        // =====================================================================

        public static void LoadFromRegistry()
        {
            string value;
            if (LisunEngine.RegistryData.TryGetValue("language", out value) &&
                value != null && value.Trim().Equals("en", StringComparison.OrdinalIgnoreCase))
            {
                Language = LisunLanguage.English;
            }
            else
            {
                Language = LisunLanguage.Russian;
                LisunEngine.RegistryData["language"] = "ru";
            }

            string layout;
            if (!LisunEngine.RegistryData.TryGetValue("keyboard_layout", out layout) ||
                layout == null || layout.Trim().Length == 0)
            {
                layout = "ru";
                LisunEngine.RegistryData["keyboard_layout"] = "ru";
            }

            LisunEngine.SaveRegistry();

            SetLayout(layout.Trim(), false);
            Raise(LanguageChanged);
        }

        public static bool SetLanguage(string code)
        {
            if (string.IsNullOrEmpty(code)) return false;

            code = code.Trim().ToLowerInvariant().Replace("-", "").Replace("_", "");
            if (code == "ru" || code == "rus" || code == "ruru" || code == "русский") return SetLanguage(LisunLanguage.Russian);
            if (code == "en" || code == "eng" || code == "enus" || code == "engb" || code == "english")
                return SetLanguage(LisunLanguage.English);
            return false;
        }

        public static bool SetLanguage(LisunLanguage language)
        {
            Language = language;

            LisunEngine.RegistryData["language"] = Code;
            LisunEngine.SaveRegistry();

            Raise(LanguageChanged);
            return true;
        }

        public static void ToggleLanguage()
        {
            SetLanguage(Language == LisunLanguage.Russian ? LisunLanguage.English : LisunLanguage.Russian);
        }

        // =====================================================================
        //  Раскладка клавиатуры
        // =====================================================================

        public static string LayoutTag
        {
            get
            {
                try
                {
                    InputLanguage current = InputLanguage.CurrentInputLanguage;
                    if (current == null || current.Culture == null) return "--";
                    return current.Culture.TwoLetterISOLanguageName.ToUpperInvariant();
                }
                catch { return "--"; }
            }
        }

        public static string InstalledLayouts()
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                foreach (InputLanguage language in InputLanguage.InstalledInputLanguages)
                {
                    if (builder.Length > 0) builder.Append(", ");
                    builder.Append(language.Culture.TwoLetterISOLanguageName.ToUpperInvariant());
                }
            }
            catch { }
            return builder.Length == 0 ? "--" : builder.ToString();
        }

        public static bool SetLayout(string twoLetterCode)
        {
            return SetLayout(twoLetterCode, true);
        }

        private static bool SetLayout(string twoLetterCode, bool persist)
        {
            if (string.IsNullOrEmpty(twoLetterCode)) return false;
            twoLetterCode = twoLetterCode.Trim();

            try
            {
                foreach (InputLanguage language in InputLanguage.InstalledInputLanguages)
                {
                    if (!language.Culture.TwoLetterISOLanguageName.Equals(twoLetterCode, StringComparison.OrdinalIgnoreCase))
                        continue;

                    InputLanguage.CurrentInputLanguage = language;

                    if (persist)
                    {
                        LisunEngine.RegistryData["keyboard_layout"] = twoLetterCode.ToLowerInvariant();
                        LisunEngine.SaveRegistry();
                    }

                    Raise(LayoutChanged);
                    return true;
                }
            }
            catch { }

            return false;
        }

        /// <summary>Переключает раскладку на следующую из установленных в Windows.</summary>
        public static bool CycleLayout()
        {
            try
            {
                InputLanguageCollection installed = InputLanguage.InstalledInputLanguages;
                if (installed.Count < 2) return false;

                InputLanguage current = InputLanguage.CurrentInputLanguage;
                int index = 0;

                for (int i = 0; i < installed.Count; i++)
                {
                    if (current != null && installed[i].Culture.LCID == current.Culture.LCID)
                    {
                        index = i;
                        break;
                    }
                }

                InputLanguage next = installed[(index + 1) % installed.Count];
                InputLanguage.CurrentInputLanguage = next;

                LisunEngine.RegistryData["keyboard_layout"] = next.Culture.TwoLetterISOLanguageName.ToLowerInvariant();
                LisunEngine.SaveRegistry();

                Raise(LayoutChanged);
                return true;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Словарь строк
        // =====================================================================

        public static string T(string key)
        {
            string[] variants;
            if (!Strings.TryGetValue(key, out variants)) return key;

            int index = (int)Language;
            if (index < 0 || index >= variants.Length) index = 0;
            return variants[index];
        }

        public static string T(string key, params object[] args)
        {
            string template = T(key);
            try { return string.Format(template, args); }
            catch { return template; }
        }

        private static void Raise(Action handler)
        {
            if (handler != null) handler();
        }

        private static readonly Dictionary<string, string[]> Strings =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "shell.title",        new[] { "LisunOS {0}  ·  Терминал ядра",      "LisunOS {0}  ·  Core Terminal" } },
            { "tab.terminal",       new[] { "Терминал",                           "Terminal" } },
            { "tab.browser",        new[] { "Браузер",                            "Browser" } },
            { "menu.language",      new[] { "Язык системы",                       "System language" } },
            { "menu.layout",        new[] { "Раскладка клавиатуры",               "Keyboard layout" } },
            { "menu.nextLayout",    new[] { "Следующая раскладка (Ctrl+Space)",   "Next layout (Ctrl+Space)" } },
            { "menu.noLayouts",     new[] { "Раскладки не найдены",               "No layouts found" } },
            { "menu.terminal",      new[] { "Вернуться в терминал (Esc)",         "Back to the terminal (Esc)" } },
            { "menu.browser",       new[] { "Открыть браузер",                    "Open the browser" } },
            { "menu.restart",       new[] { "Перезапустить подсистемы",           "Restart the subsystems" } },
            { "menu.exit",          new[] { "Выход",                              "Exit" } },
            { "menu.title",         new[] { "Меню системы",                       "System menu" } },
            { "tab.close",          new[] { "Закрыть вкладку",                    "Close tab" } },
            { "status.apps",        new[] { "приложений",                         "apps" } },
            { "status.layoutHint",  new[] { "Раскладка клавиатуры (Ctrl+Space)",  "Keyboard layout (Ctrl+Space)" } },
            { "status.langHint",    new[] { "Язык системы (Ctrl+Alt+L)",          "System language (Ctrl+Alt+L)" } },

            { "boot.engine",        new[] { "Ядро LisunOS",                       "LisunOS Kernel Engine" } },
            { "boot.prepare",       new[] { "Подготовка виртуального окружения...",
                                            "Preparing the virtual environment..." } },
            { "boot.scan",          new[] { "[BOOT] Сканирование /sys/services/ и запуск сервисов...",
                                            "[BOOT] Scanning /sys/services/ and starting services..." } },
            { "boot.version",       new[] { " LisunOS [Версия {0} \"{1}\"]",       " LisunOS [Version {0} \"{1}\"]" } },
            { "boot.rights",        new[] { " (c) Lisun Core Engine. Все права защищены.",
                                            " (c) Lisun Core Engine. All rights reserved." } },
            { "boot.hint",          new[] { " Консоль готова. 'help' — список команд, 'webview <адрес>' — браузер.",
                                            " Console ready. 'help' lists commands, 'webview <url>' opens the browser." } },
            { "boot.hintEsc",       new[] { " Esc — вернуться в терминал из любого приложения.",
                                            " Esc returns to the terminal from any application." } },
            { "boot.fail",          new[] { " [FATAL] Сбой загрузки: {0}",         " [FATAL] Boot failure: {0}" } },

            { "msg.shutdown",       new[] { " Завершение работы LisunOS...",       " Shutting down LisunOS..." } },
            { "msg.browserOpen",    new[] { " [SYS] Браузер открыт: {0}",          " [SYS] Browser opened: {0}" } },
            { "msg.browserHidden",  new[] { " [SYS] Браузер свёрнут — сессия сохранена во вкладке.",
                                            " [SYS] Browser minimised — the session is kept in its tab." } },
            { "msg.servicesReload", new[] { " [SYS] Подсистемы выгружены. Повторный запуск сервисов...",
                                            " [SYS] Subsystems unloaded. Restarting services..." } },
            { "msg.embedFailed",    new[] { " [ERROR] Не удалось встроить окно приложения: {0}",
                                            " [ERROR] Could not embed the application window: {0}" } },
            { "msg.langChanged",    new[] { " [SYS] Язык системы: {0}",            " [SYS] System language: {0}" } },
            { "msg.layoutChanged",  new[] { " [SYS] Раскладка клавиатуры: {0}",    " [SYS] Keyboard layout: {0}" } },
            { "msg.layoutFailed",   new[] { " [ERROR] Других раскладок не найдено. Добавьте их в параметрах языка Windows.",
                                            " [ERROR] No other layouts found. Add them in the Windows language settings." } },
            { "msg.layoutMissing",  new[] { " [ERROR] Раскладка '{0}' не установлена в Windows.",
                                            " [ERROR] Layout '{0}' is not installed in Windows." } },
            { "msg.langUsage",      new[] { " Язык системы: {0}. Доступно: ru, en.  Пример: lang en",
                                            " System language: {0}. Available: ru, en.  Example: lang en" } },
            { "msg.layoutUsage",    new[] { " Раскладка: {0}. Установленные: {1}.  Пример: layout en  |  layout next",
                                            " Layout: {0}. Installed: {1}.  Example: layout en  |  layout next" } },

            { "browser.go",         new[] { "Перейти",                            "Go" } },
            { "browser.hide",       new[] { "✕  Свернуть",                        "✕  Minimise" } },
            { "browser.ready",      new[] { "Готов",                              "Ready" } },
            { "browser.loading",    new[] { "Загрузка: {0}",                      "Loading: {0}" } },
            { "browser.connecting", new[] { "Подключение...",                     "Connecting..." } },
            { "browser.receiving",  new[] { "Получение данных...",                "Receiving data..." } },
            { "browser.done",       new[] { "Готово",                             "Done" } },
            { "browser.engine",     new[] { "Поисковая система: {0}",             "Search engine: {0}" } },
            { "browser.navError",   new[] { "Ошибка перехода: {0}",               "Navigation error: {0}" } },

            { "explorer.title",     new[] { "Проводник LisunOS",                  "LisunOS Explorer" } },
            { "explorer.colName",   new[] { "Имя",                                "Name" } },
            { "explorer.colType",   new[] { "Тип",                                "Type" } },
            { "explorer.colSize",   new[] { "Размер",                             "Size" } },
            { "explorer.colDate",   new[] { "Изменён",                            "Modified" } },
            { "explorer.folder",    new[] { "Папка",                              "Folder" } },
            { "explorer.file",      new[] { "Файл",                               "File" } },
            { "explorer.fileExt",   new[] { "{0}-файл",                           "{0} file" } },
            { "explorer.rename",    new[] { "Переименовать",                      "Rename" } },
            { "explorer.refresh",   new[] { "Обновить (F5)",                      "Refresh (F5)" } },
            { "explorer.newName",   new[] { "Новое имя:",                         "New name:" } },
            { "explorer.newFile",   new[] { "Имя файла:",                         "File name:" } },
            { "explorer.newFolder", new[] { "Имя папки:",                         "Folder name:" } },
            { "explorer.titleFile", new[] { "Новый файл",                         "New file" } },
            { "explorer.titleDir",  new[] { "Новая папка",                        "New folder" } },
            { "explorer.exists",    new[] { "Объект с таким именем уже существует.",
                                            "An item with this name already exists." } },
            { "explorer.confirm",   new[] { "Удалить \"{0}\"?",                   "Delete \"{0}\"?" } },
            { "explorer.renameErr", new[] { "Не удалось переименовать: {0}",      "Rename failed: {0}" } },
            { "explorer.view",      new[] { "Просмотр: {0}",                      "View: {0}" } },
            { "explorer.chars",     new[] { "{0}   •   символов: {1}",            "{0}   •   characters: {1}" } },

            { "apt.usage",          new[] { " apt list | info <имя> | install <файл.lnsh> | update [имя] | remove <имя> | protect <имя> | unprotect <имя>",
                                            " apt list | info <name> | install <file.lnsh> | update [name] | remove <name> | protect <name> | unprotect <name>" } },
            { "apt.listEmpty",      new[] { " Установленных пакетов нет.",         " No packages installed." } },
            { "apt.listTitle",      new[] { " Установленные пакеты:",              " Installed packages:" } },
            { "apt.notFound",       new[] { " [ERROR] Пакет '{0}' не найден.",     " [ERROR] Package '{0}' not found." } },
            { "apt.updated",        new[] { " [OK] Пакет '{0}' обновлён из {1}",   " [OK] Package '{0}' updated from {1}" } },
            { "apt.updateFailed",   new[] { " [ERROR] Обновление '{0}': {1}",      " [ERROR] Update of '{0}': {1}" } },
            { "apt.removed",        new[] { " [OK] Пакет '{0}' удалён.",           " [OK] Package '{0}' removed." } },
            { "apt.needSudo",       new[] { " [ERROR] Операция требует sudo или режима root.",
                                            " [ERROR] This operation requires sudo or root mode." } },
            { "apt.protected",      new[] { " [OK] Пакет '{0}' зашифрован: файлов — {1}.",
                                            " [OK] Package '{0}' encrypted: {1} files." } },
            { "apt.unprotected",    new[] { " [OK] Пакет '{0}' расшифрован: файлов — {1}.",
                                            " [OK] Package '{0}' decrypted: {1} files." } },
            { "apt.installUsage",   new[] { " [ERROR] Формат: apt install <путь к .lnsh>",
                                            " [ERROR] Usage: apt install <path to .lnsh>" } },
            { "apt.state",          new[] { "защищён",                             "protected" } },
            { "apt.stateOpen",      new[] { "открыт",                              "open" } },
            { "suggest.hint",       new[] { "↑↓ — выбор, Tab или Enter — подставить, Esc — скрыть",
                                            "↑↓ select, Tab or Enter inserts, Esc hides" } },
            { "apt.rights",         new[] { "права",                               "rights" } },
            { "ps.title",           new[] { " Активные процессы:",                 " Active processes:" } },
            { "ps.empty",           new[] { " Активных процессов нет.",             " No active processes." } },
            { "ps.running",         new[] { "работает",                            "running" } },
            { "ps.idle",            new[] { "свёрнут",                             "idle" } },
            { "ps.noForm",          new[] { "форма не собрана",                    "form not built" } },
            { "kill.usage",         new[] { " Формат: kill <приложение>  (список: ps)",
                                            " Usage: kill <application>  (see: ps)" } },
            { "kill.done",          new[] { " [OK] Процесс '{0}' завершён.",        " [OK] Process '{0}' terminated." } },
            { "kill.notFound",      new[] { " [ERROR] Процесс '{0}' не найден.",    " [ERROR] Process '{0}' not found." } },
            { "sysinfo.title",      new[] { " Сведения о системе:",                 " System information:" } },
            { "calc.usage",         new[] { " Формат: calc <выражение>   например: calc (12+8)*3^2",
                                            " Usage: calc <expression>   e.g. calc (12+8)*3^2" } },
            { "calc.bad",           new[] { " [ERROR] Не удалось вычислить: {0}",   " [ERROR] Could not evaluate: {0}" } },
            { "grep.usage",         new[] { " Формат: grep <текст> <файл>",          " Usage: grep <text> <file>" } },
            { "grep.none",          new[] { " Совпадений с '{0}' не найдено.",      " No matches for '{0}'." } },
            { "grep.found",         new[] { "   Найдено строк: {0}",                "   Lines found: {0}" } },
            { "wc.usage",           new[] { " Формат: wc <файл>",                    " Usage: wc <file>" } },
            { "wc.result",          new[] { " строк: {0}   слов: {1}   символов: {2}",
                                            " lines: {0}   words: {1}   characters: {2}" } },
            { "notify.usage",       new[] { " Формат: notify <текст>",               " Usage: notify <text>" } },
            { "notify.done",        new[] { " [OK] Уведомление показано.",           " [OK] Notification shown." } },
            { "alias.usage",        new[] { " Формат: alias <имя> <команда>  |  unalias <имя>",
                                            " Usage: alias <name> <command>  |  unalias <name>" } },
            { "alias.title",        new[] { " Псевдонимы команд:",                   " Command aliases:" } },
            { "alias.empty",        new[] { " Псевдонимов нет. Пример: alias ll ls",
                                            " No aliases yet. Example: alias ll ls" } },
            { "alias.set",          new[] { " [OK] Псевдоним '{0}' → {1}",           " [OK] Alias '{0}' → {1}" } },
            { "alias.removed",      new[] { " [OK] Псевдоним '{0}' удалён.",         " [OK] Alias '{0}' removed." } },
            { "alias.notFound",     new[] { " [ERROR] Псевдоним '{0}' не найден.",   " [ERROR] Alias '{0}' not found." } },
            { "alias.reserved",     new[] { " [ERROR] Это имя занято системой.",     " [ERROR] That name is reserved." } },
            { "ufw.usage",          new[] { " ufw status | enable | disable | port <порт> <enable|disable|remove> | allow <порт> | deny <порт> | default <allow|deny> | reset",
                                            " ufw status | enable | disable | port <port> <enable|disable|remove> | allow <port> | deny <port> | default <allow|deny> | reset" } },
            { "ufw.statusTitle",    new[] { " Брандмауэр LisunOS",                 " LisunOS firewall" } },
            { "ufw.state",          new[] { "состояние",                          "state" } },
            { "ufw.on",             new[] { "включён",                            "enabled" } },
            { "ufw.off",            new[] { "выключен",                           "disabled" } },
            { "ufw.defaultPolicy",  new[] { "политика по умолчанию",               "default policy" } },
            { "ufw.rules",          new[] { "правила",                            "rules" } },
            { "ufw.noRules",        new[] { "правил нет — действует политика по умолчанию",
                                            "no rules — the default policy applies" } },
            { "ufw.allowed",        new[] { "разрешён",                           "allowed" } },
            { "ufw.denied",         new[] { "запрещён",                           "denied" } },
            { "ufw.allowedDefault", new[] { "разрешён (по умолчанию)",             "allowed (default)" } },
            { "ufw.deniedDefault",  new[] { "запрещён (по умолчанию)",             "denied (default)" } },
            { "ufw.offPass",        new[] { "брандмауэр выключен — порт открыт",   "firewall off — port open" } },
            { "ufw.enabled",        new[] { " [OK] Брандмауэр включён.",           " [OK] Firewall enabled." } },
            { "ufw.disabled",       new[] { " [OK] Брандмауэр выключен.",          " [OK] Firewall disabled." } },
            { "ufw.resetDone",      new[] { " [OK] Правила сброшены.",             " [OK] Rules reset." } },
            { "ufw.defaultSet",     new[] { " [OK] Политика по умолчанию: {0}",    " [OK] Default policy: {0}" } },
            { "ufw.portAllowed",    new[] { " [OK] Порт {0} разрешён.",            " [OK] Port {0} allowed." } },
            { "ufw.portDenied",     new[] { " [OK] Порт {0} запрещён.",            " [OK] Port {0} denied." } },
            { "ufw.portRemoved",    new[] { " [OK] Правило для порта {0} удалено.", " [OK] Rule for port {0} removed." } },
            { "ufw.noPortRule",     new[] { " Для порта {0} правила нет.",         " No rule for port {0}." } },
            { "ufw.portState",      new[] { " Порт {0}: {1}",                      " Port {0}: {1}" } },
            { "ufw.badPort",        new[] { " [ERROR] Некорректный порт: {0}",     " [ERROR] Invalid port: {0}" } },
            { "ufw.needSudo",       new[] { " [ERROR] Управление брандмауэром требует sudo или режима root.",
                                            " [ERROR] Managing the firewall requires sudo or root mode." } },

            { "systemctl.usage",    new[] { " systemctl list | status <служба> | start | stop | restart | enable | disable <служба>",
                                            " systemctl list | status <service> | start | stop | restart | enable | disable <service>" } },
            { "systemctl.listTitle",new[] { " Службы LisunOS:",                    " LisunOS services:" } },
            { "systemctl.empty",    new[] { " Установленных служб нет.",           " No services installed." } },
            { "systemctl.active",   new[] { "активна",                            "active" } },
            { "systemctl.inactive", new[] { "остановлена",                        "inactive" } },
            { "systemctl.enabled",  new[] { "включён",                            "enabled" } },
            { "systemctl.disabled", new[] { "выключен",                           "disabled" } },
            { "systemctl.started",  new[] { " [OK] Служба '{0}' запущена.",        " [OK] Service '{0}' started." } },
            { "systemctl.stopped",  new[] { " [OK] Служба '{0}' остановлена.",     " [OK] Service '{0}' stopped." } },
            { "systemctl.restarted",new[] { " [OK] Служба '{0}' перезапущена.",    " [OK] Service '{0}' restarted." } },
            { "systemctl.enabledNow",  new[] { " [OK] Автозапуск '{0}' включён.",  " [OK] Autostart of '{0}' enabled." } },
            { "systemctl.disabledNow", new[] { " [OK] Автозапуск '{0}' выключен.", " [OK] Autostart of '{0}' disabled." } },
            { "systemctl.notFound", new[] { " [ERROR] Служба '{0}' не найдена.",   " [ERROR] Service '{0}' not found." } },
            { "systemctl.notRunning",new[] { " Служба '{0}' не запущена.",         " Service '{0}' is not running." } },
            { "systemctl.needSudo", new[] { " [ERROR] Изменение автозапуска требует sudo.",
                                            " [ERROR] Changing autostart requires sudo." } },
            { "systemctl.fieldState",    new[] { "состояние",                     "state" } },
            { "systemctl.fieldAuto",     new[] { "автозапуск",                    "autostart" } },
            { "systemctl.fieldVersion",  new[] { "версия",                        "version" } },
            { "systemctl.fieldScripts",  new[] { "сценариев",                     "scripts" } },
            { "systemctl.fieldProtected",new[] { "пакет",                         "package" } },
            { "systemctl.fieldPath",     new[] { "путь",                          "path" } },
            { "systemctl.fieldRights",   new[] { "права",                         "rights" } },

            { "repo.title",         new[] { " Системный каталог LisunOS:",         " LisunOS system catalog:" } },
            { "repo.installed",     new[] { "установлен",                         "installed" } },
            { "repo.available",     new[] { "доступен",                           "available" } },
            { "repo.hint",          new[] { "   Установка: apt install <имя>",     "   Install with: apt install <name>" } },
            { "repo.notFound",      new[] { " [ERROR] В каталоге нет библиотеки '{0}'. Список: apt catalog",
                                            " [ERROR] No library '{0}' in the catalog. See: apt catalog" } },
            { "repo.installOk",     new[] { " [OK] Библиотека '{0}' установлена. Запуск командой: {1}",
                                            " [OK] Library '{0}' installed. Launch it with: {1}" } },
            { "repo.installFailed", new[] { " [ERROR] Установка '{0}' не завершена — подробности в журнале.",
                                            " [ERROR] Installation of '{0}' did not finish — see the log." } },

            { "srv.title",          new[] { "Сервер LisunOS",                     "LisunOS Server" } },
            { "srv.ready",          new[] { "Панель готова. Укажите порт и нажмите «Запустить».",
                                            "Panel ready. Set a port and press Start." } },
            { "srv.stateOn",        new[] { "Сервер работает на порту {0}",        "Server running on port {0}" } },
            { "srv.stateOff",       new[] { "Сервер остановлен",                  "Server stopped" } },
            { "srv.started",        new[] { "Запущен на порту {0}, адрес {1}",     "Started on port {0}, address {1}" } },
            { "srv.stopped",        new[] { "Сервер остановлен",                  "Server stopped" } },
            { "srv.alreadyRunning", new[] { "Сервер уже запущен",                 "The server is already running" } },
            { "srv.badPort",        new[] { "Некорректный порт",                  "Invalid port" } },
            { "srv.portBusy",       new[] { "Порт {0} занят другой программой",    "Port {0} is already in use" } },
            { "srv.blockedByUfw",   new[] { "Порт {0} закрыт брандмауэром ufw",    "Port {0} is blocked by ufw" } },
            { "srv.noAddresses",    new[] { "сервер остановлен",                  "server stopped" } },
            { "srv.stats",          new[] { "запросов: {0}   ошибок: {1}   время: {2}   ufw: {3}",
                                            "requests: {0}   errors: {1}   uptime: {2}   ufw: {3}" } },
            { "srv.opening",        new[] { "Открываю {0}",                       "Opening {0}" } },
            { "srv.folderOpened",   new[] { "Открыта папка {0}",                  "Opened folder {0}" } },
            { "srv.remoteOn",       new[] { "Подключения из локальной сети разрешены",
                                            "Local network connections allowed" } },
            { "srv.remoteOff",      new[] { "Только локальные подключения (127.0.0.1)",
                                            "Local connections only (127.0.0.1)" } },
            { "srv.ufwOpened",      new[] { "Порт {0} открыт в ufw",               "Port {0} opened in ufw" } },
            { "srv.ufwState",       new[] { "Брандмауэр ufw: {0}",                 "Firewall ufw: {0}" } },

            { "srv.autostartOn",    new[] { "Автозапуск сервера включён — сайт поднимется при загрузке LisunOS.",
                                            "Server autostart enabled — the site will come up when LisunOS boots." } },
            { "srv.autostartOff",   new[] { "Автозапуск сервера выключен.",          "Server autostart disabled." } },
            { "srv.autostartDone",  new[] { "Автозапуск: сервер поднят на порту {0}.",
                                            "Autostart: server is up on port {0}." } },
            { "srv.autostartFailed",new[] { "Автозапуск не удался: {0}",             "Autostart failed: {0}" } },
            { "srv.autostartNoPerm",new[] { "Автозапуск пропущен: приложению не выдано право network.",
                                            "Autostart skipped: the application lacks the network permission." } },
            { "srv.panel",          new[] { "Веб-панель",                          "Web panel" } },
            { "srv.panelTitle",     new[] { "Веб-панель управления",                "Web management panel" } },
            { "srv.panelHint",      new[] { "Панель открывается в браузере по адресу {0}\r\nВход по паролю; файлы, правка и смена пароля — внутри панели.",
                                            "The panel opens in a browser at {0}\r\nPassword login; files, editing and password change are inside the panel." } },
            { "srv.panelPass",      new[] { "Пароль панели:",                        "Panel password:" } },
            { "srv.panelSet",       new[] { "Задать пароль",                         "Set password" } },
            { "srv.panelRandom",    new[] { "Случайный",                             "Random" } },
            { "srv.panelOpen",      new[] { "Открыть панель",                        "Open panel" } },
            { "srv.panelSaved",     new[] { "Пароль веб-панели сохранён.",            "The web panel password was saved." } },
            { "srv.panelShort",     new[] { "Пароль должен быть не короче четырёх символов.",
                                            "The password must be at least four characters." } },
            { "srv.panelNoPass",    new[] { "Пароль не задан — панель не пустит внутрь. Задайте его здесь.",
                                            "No password set — the panel will not let anyone in. Set one here." } },
            { "srv.panelNoPhp",     new[] { "Панель написана на PHP. Подключите PHP: apt install php-frm",
                                            "The panel is written in PHP. Connect PHP with: apt install php-frm" } },
            { "srv.panelNeedRun",   new[] { "Сервер остановлен — запустите его, чтобы открыть панель.",
                                            "The server is stopped — start it to open the panel." } },
            { "srv.panelCreated",   new[] { "Создан panel.php в корне сайта.",        "panel.php was created in the site root." } },
            { "php.notFound",       new[] { " [ERROR] PHP не найден на этом компьютере.\r\n   Установите PHP для Windows (windows.php.net), затем повторите\r\n   apt install php-frm, либо укажите путь явно:\r\n   apt install php-frm C:\\php\\php-cgi.exe",
                                            " [ERROR] PHP was not found on this computer.\r\n   Install PHP for Windows (windows.php.net) and repeat\r\n   apt install php-frm, or give the path explicitly:\r\n   apt install php-frm C:\\php\\php-cgi.exe" } },
            { "php.sourceBuiltIn", new[] { "   Работает наш встроенный движок PHP (PHP.cs + PHPExecuter.cs),\r\n   внешний php-cgi.exe не требуется.",
                                            "   Running our own built-in PHP engine (PHP.cs + PHPExecuter.cs);\r\n   no external php-cgi.exe required." } },
            { "php.engineName",     new[] { "встроенный движок LisunOS",            "built-in LisunOS engine" } },
            { "php.installed",      new[] { " [OK] PHP подключён: {0}",             " [OK] PHP connected: {0}" } },
            { "php.apiReady",       new[] { "   Файлы .php теперь исполняются, создан api.php с ключом.",
                                            "   .php files now execute, api.php with a key was created." } },
            { "php.configFailed",   new[] { " [ERROR] Не удалось записать .htaccess.",
                                            " [ERROR] Could not write .htaccess." } },
            { "php.removed",        new[] { " [OK] Обработка PHP выключена. Файлы .php теперь открываются как HTML.",
                                            " [OK] PHP handling disabled. .php files are now served as HTML." } },
            { "php.panelReady",     new[] { "   Веб-панель: panel.php — {0}",       "   Web panel: panel.php — {0}" } },
            { "php.panelHasPass",   new[] { "пароль задан",                        "password set" } },
            { "php.panelNoPass",    new[] { "задайте пароль в «Сервер v2» → «Веб-панель»",
                                            "set the password in Server v2 → Web panel" } },
            { "php.sourceOwn",      new[] { "   Используется свой PHP внутри LisunOS (/os/sys/php).",
                                            "   Using the PHP bundled inside LisunOS (/os/sys/php)." } },
            { "php.sourceSystem",   new[] { "   Используется PHP, установленный в системе.",
                                            "   Using the PHP installed on the system." } },
            { "php.sourceBuiltInShort", new[] { "встроенный движок",               "built-in engine" } },
            { "php.fieldMirrors",   new[] { "зеркал",                            "mirrors" } },
            { "php.sourceOwnShort", new[] { "свой (внутри LisunOS)",               "own (inside LisunOS)" } },
            { "php.sourceSystemShort", new[] { "системный",                        "system" } },
            { "php.fieldSource",    new[] { "источник",                            "source" } },
            { "php.fieldOwnDir",    new[] { "свой каталог",                        "own folder" } },
            { "php.notInstalledHere", new[] { "пусто",                             "empty" } },
            { "php.badArgument",    new[] { " [ERROR] Не найден путь: {0}\r\n   Укажите архив .zip, папку с PHP или php-cgi.exe.",
                                            " [ERROR] Path not found: {0}\r\n   Give a .zip archive, a PHP folder or php-cgi.exe." } },
            { "php.imported",       new[] { "   PHP развёрнут внутри LisunOS: {0}",  "   PHP deployed inside LisunOS: {0}" } },
            { "php.zipNoBinary",    new[] { "   В архиве нет php-cgi.exe или php.exe.",
                                            "   The archive has no php-cgi.exe or php.exe." } },
            { "php.folderNoBinary", new[] { "   В папке {0} нет php-cgi.exe или php.exe.",
                                            "   Folder {0} has no php-cgi.exe or php.exe." } },
            { "php.downloadTitle",  new[] { "php-frm — загрузка PHP",               "php-frm — download PHP" } },
            { "php.downloadAsk",    new[] { "Своего PHP в LisunOS пока нет.\r\n\r\nСкачать сборку PHP для Windows (около 30 МБ) и развернуть её внутри LisunOS?\r\n\r\n{0}\r\n\r\nПосле этого PHP будет свой: он не зависит от того, что установлено в системе.",
                                            "LisunOS has no bundled PHP yet.\r\n\r\nDownload a PHP build for Windows (about 30 MB) and deploy it inside LisunOS?\r\n\r\n{0}\r\n\r\nAfter that PHP is ours: it no longer depends on what the system has." } },
            { "php.downloadSkipped",new[] { "   Загрузка отменена — ищем PHP в системе.",
                                            "   Download cancelled — looking for a system PHP." } },
            { "php.downloaded",     new[] { "   Архив PHP загружен ({0}).",          "   PHP archive downloaded ({0})." } },
            { "php.downloadFailed", new[] { "   Загрузка не удалась: {0}",           "   Download failed: {0}" } },
            { "php.statusTitle",    new[] { " Модуль php-frm:",                     " php-frm module:" } },
            { "php.fieldState",     new[] { "состояние",                            "state" } },
            { "php.fieldBinary",    new[] { "интерпретатор",                        "interpreter" } },
            { "php.fieldConfig",    new[] { "конфигурация",                         "configuration" } },
            { "php.fieldApi",       new[] { "api",                                  "api" } },
            { "php.on",             new[] { "подключён",                            "connected" } },
            { "php.off",            new[] { "выключен",                             "disabled" } },
            { "php.catalogLine",    new[] { "Подключение PHP к серверу: исполнение .php и api.php",
                                            "Connects PHP to the server: .php execution and api.php" } },
            { "api.blockRemoved",   new[] { "Удалён защищённый блок NOREMOVE ({0} из {1}). Эти строки менять нельзя — верните их и сохраните снова.",
                                            "A protected NOREMOVE block was removed ({0} of {1}). Those lines cannot be changed — restore them and save again." } },
            { "api.editHint",       new[] { "В файле {0} защищённых блоков CANTEDIT — их текст изменять нельзя, остальное свободно.",
                                            "This file has {0} protected CANTEDIT blocks — their text cannot be changed, the rest is free." } },
            { "api.bothHint",       new[] { "Защищено: блоков NOREMOVE — {0}, блоков CANTEDIT — {1}.",
                                            "Protected: {0} NOREMOVE blocks, {1} CANTEDIT blocks." } },
            { "api.editChanged",    new[] { "Изменён защищённый блок CANTEDIT ({0} из {1}). Этот текст менять нельзя — верните его как было.",
                                            "A protected CANTEDIT block was changed ({0} of {1}). That text must stay as it was." } },
            { "api.protectedHint",  new[] { "В файле есть защищённые блоки NOREMOVE — их строки изменять нельзя.",
                                            "This file has protected NOREMOVE blocks — those lines cannot be changed." } },
            { "api.restoreAsk",     new[] { "Защищённые строки удалены. Вернуть их автоматически и сохранить?",
                                            "Protected lines were removed. Restore them automatically and save?" } },
            { "api.fileProtected",  new[] { "Файл {0} защищён блоками NOREMOVE и не может быть удалён.",
                                            "The file {0} is protected by NOREMOVE blocks and cannot be deleted." } },
            { "srv.apiKey",         new[] { "Ключ API",                             "API key" } },
            { "srv.apiTitle",       new[] { "Секретный ключ Server API",            "Server API secret key" } },
            { "srv.apiHint",        new[] { "Ключ нужен в запросах к api.php:\r\napi.php?key=<ключ>&action=<действие>&name=<файл>\r\n\r\nВ PHP: ServerAPI($key, \"create_file\", \"hello.txt\", \"текст\")",
                                            "The key is required in api.php requests:\r\napi.php?key=<key>&action=<action>&name=<file>\r\n\r\nIn PHP: ServerAPI($key, \"create_file\", \"hello.txt\", \"text\")" } },
            { "srv.apiCopy",        new[] { "Копировать",                           "Copy" } },
            { "srv.apiRegenerate",  new[] { "Новый ключ",                           "New key" } },
            { "srv.apiCopied",      new[] { "Ключ скопирован в буфер обмена.",       "Key copied to the clipboard." } },
            { "srv.apiRegenerated", new[] { "Ключ обновлён — старый больше не работает.",
                                            "Key regenerated — the old one no longer works." } },
            { "srv.apiNoPhp",       new[] { "PHP выключен, поэтому api.php не создан. Включите блок location ~ \\.php$ в .htaccess.",
                                            "PHP is off, so api.php was not created. Enable the location ~ \\.php$ block in .htaccess." } },
            { "srv.apiCreated",     new[] { "PHP включён — созданы api.php и serverapi.php",
                                            "PHP enabled — api.php and serverapi.php were created" } },
            { "fm.title",           new[] { "Управление файлами",                 "File management" } },
            { "fm.up",              new[] { "Каталог выше (Backspace)",           "Parent folder (Backspace)" } },
            { "fm.refresh",         new[] { "Обновить (F5)",                      "Refresh (F5)" } },
            { "fm.newFile",         new[] { "Новый файл",                         "New file" } },
            { "fm.newFolder",       new[] { "Новая папка",                        "New folder" } },
            { "fm.rename",          new[] { "Переименовать (F2)",                 "Rename (F2)" } },
            { "fm.delete",          new[] { "Удалить",                            "Delete" } },
            { "fm.edit",            new[] { "Изменить",                           "Edit" } },
            { "fm.openItem",        new[] { "Открыть",                            "Open" } },
            { "fm.save",            new[] { "Сохранить",                          "Save" } },
            { "fm.namePrompt",      new[] { "Имя:",                               "Name:" } },
            { "fm.status",          new[] { "папок: {0}   файлов: {1}",            "folders: {0}   files: {1}" } },
            { "fm.outside",         new[] { "Путь за пределами папки сайта.",      "Path is outside the site folder." } },
            { "fm.createFailed",    new[] { "Не удалось создать объект.",          "Could not create the item." } },
            { "fm.deleteFailed",    new[] { "Не удалось удалить объект.",          "Could not delete the item." } },
            { "fm.saveFailed",      new[] { "Не удалось сохранить файл.",          "Could not save the file." } },
            { "fm.confirmFolder",   new[] { "Удалить папку \"{0}\" со всем содержимым?",
                                            "Delete the folder \"{0}\" and everything in it?" } },
            { "fm.editing",         new[] { "Правка: {0}",                         "Editing: {0}" } },
            { "fm.tooBig",          new[] { "Файл слишком большой для правки ({0}).",
                                            "The file is too large to edit ({0})." } },
            { "srv.manageFiles",    new[] { "Управлять файлами",                   "Manage files" } },
            { "srv.filesTitle",     new[] { "Файлы сайта — {0}",                   "Site files — {0}" } },
            { "srv.filesOpened",    new[] { "Открыто управление файлами: {0}",      "File management opened: {0}" } },
            { "pad.title",          new[] { "Блокнот LisunOS",                    "LisunOS Notepad" } },
            { "pad.newFile",        new[] { "новый файл",                         "new file" } },
            { "pad.status",         new[] { "строк: {0}   символов: {1}",          "lines: {0}   characters: {1}" } },
            { "pad.openTitle",      new[] { "Открыть файл",                       "Open file" } },
            { "pad.openPrompt",     new[] { "Путь внутри LisunOS:",               "Path inside LisunOS:" } },
            { "pad.saveTitle",      new[] { "Сохранить файл",                     "Save file" } },
            { "pad.savePrompt",     new[] { "Куда сохранить:",                     "Save to:" } },
            { "pad.notFound",       new[] { "Файл не найден: {0}",                "File not found: {0}" } },
            { "pad.outsideRoot",    new[] { "Путь за пределами корня LisunOS.",    "Path is outside the LisunOS root." } },
            { "pad.saveFailed",     new[] { "Не удалось сохранить файл.",          "Could not save the file." } },
            { "pad.discard",        new[] { "Изменения не сохранены. Продолжить?", "Unsaved changes. Continue?" } },

            { "tpl.title",          new[] { "Шаблон приложения",                  "Application template" } },
            { "tpl.ready",          new[] { "Шаблон запущен. Правьте template.service и Form1.designer.cs.",
                                            "Template started. Edit template.service and Form1.designer.cs." } },
            { "tpl.status",         new[] { "счётчик: {0}   приложений в системе: {1}",
                                            "counter: {0}   applications running: {1}" } },
            { "tpl.hello",          new[] { "Здравствуйте, {0}!",                   "Hello, {0}!" } },
            { "tpl.counted",        new[] { "Счётчик увеличен до {0} и сохранён в реестре.",
                                            "Counter raised to {0} and stored in the registry." } },
            { "tpl.cleared",        new[] { "Журнал очищен.",                       "Log cleared." } },
            { "tpl.saved",          new[] { "Имя сохранено в реестре LisunOS.",      "Name stored in the LisunOS registry." } },
            { "tpl.forgotten",      new[] { "Имя удалено из реестра.",              "Name removed from the registry." } },
            { "mon.title",          new[] { "Монитор системы",                    "System Monitor" } },
            { "mon.uptime",         new[] { "время работы",                       "uptime" } },
            { "mon.memory",         new[] { "память",                             "memory" } },
            { "mon.apps",           new[] { "процессов",                          "processes" } },
            { "mon.services",       new[] { "служб",                              "services" } },
            { "mon.commands",       new[] { "команд",                             "commands" } },
            { "mon.pick",           new[] { "выберите процесс в списке",           "select a process in the list" } },
            { "mon.selected",       new[] { "выбран: {0}",                        "selected: {0}" } },

            { "perm.dialogTitle",   new[] { "LisunOS — запрос разрешений",        "LisunOS — permission request" } },
            { "perm.askInstall",    new[] { "Приложению «{0}» требуются разрешения:",
                                            "The application \"{0}\" requests permissions:" } },
            { "perm.askSingle",     new[] { "Приложение «{0}» запрашивает доступ:",
                                            "The application \"{0}\" requests access:" } },
            { "perm.note",          new[] { "Снимите флажок, чтобы не выдавать это право.",
                                            "Clear a checkbox to withhold that permission." } },
            { "perm.allow",         new[] { "Разрешить",                               "Allow" } },
            { "perm.deny",          new[] { "Отклонить",                               "Deny" } },
            { "perm.unknown",       new[] { "неизвестное разрешение",                  "unknown permission" } },
            { "perm.denied",        new[] { " [ОТКАЗ] Приложению «{0}» не выдано право '{1}'.",
                                            " [DENIED] The application \"{0}\" lacks the '{1}' permission." } },
            { "perm.usage",         new[] { " perm list | app <имя> | grant <имя> <право> | revoke <имя> <право> | reset <имя> | all",
                                            " perm list | app <name> | grant <name> <right> | revoke <name> <right> | reset <name> | all" } },
            { "perm.listEmpty",     new[] { " Ни одному приложению ещё не выданы права.",
                                            " No application has been granted rights yet." } },
            { "perm.listTitle",     new[] { " Выданные разрешения:",                   " Granted permissions:" } },
            { "perm.allTitle",      new[] { " Все разрешения LisunOS:",                " All LisunOS permissions:" } },
            { "perm.appTitle",      new[] { " Разрешения приложения «{0}»:",           " Permissions of \"{0}\":" } },
            { "perm.appNone",       new[] { " Приложению «{0}» не выдано ни одного права.",
                                            " No rights granted to \"{0}\"." } },
            { "perm.granted",       new[] { " [OK] «{0}»: выдано право '{1}'.",        " [OK] \"{0}\": granted '{1}'." } },
            { "perm.revoked",       new[] { " [OK] «{0}»: отозвано право '{1}'.",      " [OK] \"{0}\": revoked '{1}'." } },
            { "perm.resetDone",     new[] { " [OK] Все права приложения «{0}» сброшены.",
                                            " [OK] All rights of \"{0}\" were reset." } },
            { "perm.badName",       new[] { " [ERROR] Неизвестное право '{0}'. Список: perm all",
                                            " [ERROR] Unknown permission '{0}'. See: perm all" } },
            { "perm.needSudo",      new[] { " [ERROR] Управление правами требует sudo или режима root.",
                                            " [ERROR] Managing permissions requires sudo or root mode." } },
            { "php.progress",        new[] { "   Загрузка PHP: {0}%  ({1})",
                                            "   Downloading PHP: {0}%  ({1})" } },
            { "php.progressUnknown",  new[] { "   Загрузка PHP: получено {0}",
                                            "   Downloading PHP: received {0}" } },
            { "php.stageStart",      new[] { "подготовка загрузки",
                                            "preparing the download" } },
            { "php.stageMirror",     new[] { "зеркало {0} из {1}",
                                            "mirror {0} of {1}" } },
            { "php.stageUnpack",     new[] { "распаковка архива",
                                            "unpacking the archive" } },
            { "php.stageDone",       new[] { "PHP готов",
                                            "PHP is ready" } },
            { "php.stageFailed",     new[] { "загрузка не удалась",
                                            "the download failed" } },
            { "php.tryMirror",       new[] { "Зеркало {0}/{1}: {2}",
                                            "Mirror {0}/{1}: {2}" } },
            { "php.tooSmall",        new[] { "Файл слишком мал ({0}) — это не сборка PHP.",
                                            "The file is too small ({0}) — not a PHP build." } },
            { "php.notArchive",      new[] { "Вместо архива пришло что-то другое.",
                                            "Something other than an archive arrived." } },
            { "php.mirrorFailed",    new[] { "Зеркало недоступно: {0}",
                                            "Mirror unavailable: {0}" } },
            { "php.allMirrorsFailed",  new[] { "Ни одно зеркало не ответило. Работает встроенный движок.",
                                            "No mirror responded. The built-in engine stays in charge." } },
            { "php.autoStart",       new[] { "Автозагрузка PHP началась.",
                                            "Automatic PHP download started." } },
            { "php.autoFailed",      new[] { "Автозагрузка не удалась — остаётся встроенный движок.",
                                            "Automatic download failed — the built-in engine stays in charge." } },
            { "php.autoQueued",      new[] { "   PHP докачивается в фоне и подключится сам.",
                                            "   PHP is downloading in the background and will attach itself." } },
            { "php.autoWatch",       new[] { "   Прямой эфир установки: {0}",
                                            "   Live setup feed: {0}" } },
            { "php.attached",        new[] { "PHP подключён: {0}",
                                            "PHP attached: {0}" } },
            { "php.ownMissing",      new[] { " [ERROR] Своего PHP в LisunOS нет.",
                                            " [ERROR] LisunOS has no own PHP." } },
            { "php.ownRemoved",      new[] { " [OK] Свой PHP удалён, работает встроенный движок.",
                                            " [OK] Own PHP removed, the built-in engine is in charge." } },
            { "php.usage",           new[] { " php-frm status | download | update | remove | use builtin|own|system | auto on|off | mirrors",
                                            " php-frm status | download | update | remove | use builtin|own|system | auto on|off | mirrors" } },
            { "php.mirrorsTitle",    new[] { " Зеркала загрузки PHP:",
                                            " PHP download mirrors:" } },
            { "php.autoOn",          new[] { " [OK] Автозагрузка PHP включена.",
                                            " [OK] Automatic PHP download is on." } },
            { "php.autoOff",         new[] { " [OK] Автозагрузка PHP выключена.",
                                            " [OK] Automatic PHP download is off." } },
            { "php.busy",            new[] { " [INFO] Загрузка уже идёт: {0}",
                                            " [INFO] A download is already running: {0}" } },
            { "php.useBuiltIn",      new[] { " [OK] Выбран встроенный движок LisunOS.",
                                            " [OK] Switched to the built-in LisunOS engine." } },
            { "php.useFailed",       new[] { " [ERROR] Такого источника PHP нет: {0}",
                                            " [ERROR] No such PHP source: {0}" } },
            { "php.fieldAuto",       new[] { "автозагрузка",
                                            "auto download" } },
            { "php.fieldProgress",   new[] { "ход загрузки",
                                            "download progress" } },
            { "sys.usage",           new[] { " system start | stop | status | open",
                                            " system start | stop | status | open" } },
            { "sys.already",         new[] { " [INFO] Системный порт {0} уже открыт.",
                                            " [INFO] System port {0} is already open." } },
            { "sys.needHall",        new[] { " [ERROR] Нужен доступ зала: выдайте право 'hall' приложению «{0}».",
                                            " [ERROR] Hall access required: grant the 'hall' right to \"{0}\"." } },
            { "sys.started",         new[] { "Системный порт {0} открыт.",
                                            "System port {0} is open." } },
            { "sys.startedFull",     new[] { " [OK] Системный порт {0} открыт.\r\n   Прямой эфир установки: {1}",
                                            " [OK] System port {0} is open.\r\n   Live setup feed: {1}" } },
            { "sys.portBusy",        new[] { " [ERROR] Порт {0} занят: {1}",
                                            " [ERROR] Port {0} is busy: {1}" } },
            { "sys.stopped",         new[] { "Системный порт {0} закрыт.",
                                            "System port {0} is closed." } },
            { "sys.notRunning",      new[] { " [INFO] Системный порт закрыт.",
                                            " [INFO] The system port is closed." } },
            { "sys.statusTitle",     new[] { " Системный порт LisunOS:",
                                            " LisunOS system port:" } },
            { "sys.fieldState",      new[] { "состояние",
                                            "state" } },
            { "sys.fieldPort",       new[] { "порт",
                                            "port" } },
            { "sys.fieldHall",       new[] { "право hall",
                                            "hall right" } },
            { "sys.fieldApp",        new[] { "приложение зала",
                                            "hall application" } },
            { "sys.fieldRequests",   new[] { "запросов",
                                            "requests" } },
            { "sys.fieldUptime",     new[] { "в работе",
                                            "uptime" } },
            { "sys.fieldPage",       new[] { "страница",
                                            "page" } },
            { "sys.open",            new[] { "открыт",
                                            "open" } },
            { "sys.closed",          new[] { "закрыт",
                                            "closed" } },
            { "sys.granted",         new[] { "выдано",
                                            "granted" } },
            { "sys.denied",          new[] { "не выдано",
                                            "not granted" } },
            { "sys.opened",          new[] { " [OK] Страница открыта: {0}",
                                            " [OK] Page opened: {0}" } },
            { "wifi.title",          new[] { "Wi-Fi",
                                            "Wi-Fi" } },
            { "wifi.usage",          new[] { " wifi list | connect <сеть> [пароль] | disconnect | forget <сеть> | status | portal | form",
                                            " wifi list | connect <network> [password] | disconnect | forget <network> | status | portal | form" } },
            { "wifi.openShort",      new[] { "без пароля",
                                            "open" } },
            { "wifi.savedMark",      new[] { "сохранена",
                                            "saved" } },
            { "wifi.noAdapter",      new[] { " [ERROR] Адаптер Wi-Fi не найден.",
                                            " [ERROR] No Wi-Fi adapter found." } },
            { "wifi.nothingFound",   new[] { " [INFO] Сетей вокруг не найдено.",
                                            " [INFO] No networks around." } },
            { "wifi.listTitle",      new[] { " Сети вокруг ({0}):",
                                            " Networks around ({0}):" } },
            { "wifi.noSsid",         new[] { " [ERROR] Укажите имя сети.",
                                            " [ERROR] Give the network name." } },
            { "wifi.needNetwork",    new[] { " [ERROR] Нужно право 'network'.",
                                            " [ERROR] The 'network' right is required." } },
            { "wifi.needPassword",   new[] { " [ERROR] Сеть «{0}» защищена — нужен пароль.",
                                            " [ERROR] Network \"{0}\" is protected — a password is required." } },
            { "wifi.connecting",     new[] { "Подключение к «{0}»…",
                                            "Connecting to \"{0}\"…" } },
            { "wifi.connected",      new[] { "Подключено: «{0}».",
                                            "Connected: \"{0}\"." } },
            { "wifi.connectFailed",  new[] { " [ERROR] Не удалось подключиться к «{0}»: {1}",
                                            " [ERROR] Could not connect to \"{0}\": {1}" } },
            { "wifi.onlineNow",      new[] { " [OK] «{0}» подключена, интернет есть.",
                                            " [OK] \"{0}\" connected, the internet is up." } },
            { "wifi.noInternet",     new[] { " [WARN] «{0}» подключена, но интернета нет.",
                                            " [WARN] \"{0}\" connected, but there is no internet." } },
            { "wifi.portalFound",    new[] { " [INFO] «{0}» требует входа. Открываю страницу: {1}",
                                            " [INFO] \"{0}\" requires sign-in. Opening the page: {1}" } },
            { "wifi.disconnected",   new[] { " [OK] Отключено от сети Wi-Fi.",
                                            " [OK] Disconnected from Wi-Fi." } },
            { "wifi.forgotten",      new[] { " [OK] Профиль сети «{0}» удалён.",
                                            " [OK] Profile of \"{0}\" removed." } },
            { "wifi.profileFailed",  new[] { " [ERROR] Профиль сети не создан: {0}",
                                            " [ERROR] The profile was not created: {0}" } },
            { "wifi.openingPortal",  new[] { "Открываю страницу входа: {0}",
                                            "Opening the sign-in page: {0}" } },
            { "wifi.wentOnline",     new[] { "Интернет появился.",
                                            "The internet is up." } },
            { "wifi.wentOffline",    new[] { "Интернет пропал.",
                                            "The internet is down." } },
            { "wifi.statusTitle",    new[] { " Сеть LisunOS:",
                                            " LisunOS network:" } },
            { "wifi.fieldAdapter",   new[] { "адаптер",
                                            "adapter" } },
            { "wifi.fieldNetwork",   new[] { "сеть",
                                            "network" } },
            { "wifi.fieldInternet",  new[] { "интернет",
                                            "internet" } },
            { "wifi.fieldPortal",    new[] { "страница входа",
                                            "sign-in page" } },
            { "wifi.present",        new[] { "есть",
                                            "present" } },
            { "wifi.absent",         new[] { "нет",
                                            "absent" } },
            { "wifi.stateOnline",    new[] { "есть",
                                            "up" } },
            { "wifi.statePortal",    new[] { "нужен вход",
                                            "sign-in required" } },
            { "wifi.stateOffline",   new[] { "нет",
                                            "down" } },
            { "wifi.scanning",       new[] { "поиск сетей…",
                                            "scanning for networks…" } },
            { "wifi.scan",           new[] { "Найти сети",
                                            "Scan" } },
            { "wifi.connect",        new[] { "Подключиться",
                                            "Connect" } },
            { "wifi.disconnect",     new[] { "Отключиться",
                                            "Disconnect" } },
            { "wifi.forget",         new[] { "Забыть",
                                            "Forget" } },
            { "wifi.openPortalButton",  new[] { "Страница входа",
                                            "Sign-in page" } },
            { "wifi.openSetup",      new[] { "Прямой эфир php-frm",
                                            "php-frm live feed" } },
            { "wifi.password",       new[] { "Пароль сети",
                                            "Network password" } },
            { "wifi.passwordFor",    new[] { "Пароль сети «{0}»",
                                            "Password for \"{0}\"" } },
            { "wifi.passwordNotNeeded",  new[] { "Пароль не нужен — сеть открытая",
                                            "No password needed — the network is open" } },
            { "wifi.passwordEnterprise",  new[] { "Сеть предприятия — вход откроется в браузере",
                                            "Enterprise network — sign-in opens in the browser" } },
            { "wifi.showPassword",   new[] { "показать",
                                            "show" } },
            { "wifi.columnName",     new[] { "Сеть",
                                            "Network" } },
            { "wifi.columnSignal",   new[] { "Сигнал",
                                            "Signal" } },
            { "wifi.columnSecurity",  new[] { "Защита",
                                            "Security" } },
            { "wifi.columnSaved",    new[] { "Профиль",
                                            "Profile" } },
            { "wifi.headerConnected",  new[] { "подключена «{0}» · сетей вокруг: {1}",
                                            "connected to \"{0}\" · networks around: {1}" } },
            { "wifi.headerFree",     new[] { "не подключена · сетей вокруг: {0}",
                                            "not connected · networks around: {0}" } },
            { "wifi.selectFirst",    new[] { "Выберите сеть в списке.",
                                            "Select a network from the list." } },
            { "wifi.setupOpened",    new[] { "Прямой эфир открыт: {0}",
                                            "Live feed opened: {0}" } },
            { "boot.network",       new[] { "  Сеть: слежение за интернетом включено.",
                                            "  Network: internet watcher is on." } },
            { "boot.hallHint",      new[] { "системный порт 8989 закрыт: нужно право 'hall' (команда: system start)",
                                            "system port 8989 is closed: the 'hall' right is required (command: system start)" } },
            { "dialog.ok",          new[] { "OK",                                 "OK" } },
            { "dialog.cancel",      new[] { "Отмена",                             "Cancel" } }
        };
    }
}
