﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    public enum LisunLanguage
    {
        Russian = 0,
        English = 1
    }

    /// <summary>
    /// Язык интерфейса LisunOS и раскладка клавиатуры.
    /// По умолчанию система русская; выбор сохраняется в реестре (DATA).
    /// </summary>
    public static class LisunLocale
    {
        public static LisunLanguage Language { get; private set; }

        public static event Action LanguageChanged;
        public static event Action LayoutChanged;

        static LisunLocale()
        {
            Language = LisunLanguage.Russian;
        }

        // =====================================================================
        //  Языковые пакеты: любое число языков
        // =====================================================================

        /// <summary>Один язык интерфейса, загруженный из /os/sys/locale/&lt;код&gt;.json.</summary>
        public class LanguagePack
        {
            public string Code = string.Empty;
            public string Name = string.Empty;
            public string Layout = string.Empty;
            public string ManifestTag = string.Empty;
            public bool BasedOnRussian;

            public readonly Dictionary<string, string> Strings =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            /// <summary>Доля переведённых строк, 0..100.</summary>
            public int Completeness
            {
                get
                {
                    int total = LisunLocale.Strings.Count;
                    if (total == 0) return 100;

                    int done = 0;
                    foreach (string key in LisunLocale.Strings.Keys)
                        if (Strings.ContainsKey(key)) done++;

                    return (int)Math.Round(done * 100.0 / total);
                }
            }
        }

        private static readonly Dictionary<string, LanguagePack> packs =
            new Dictionary<string, LanguagePack>(StringComparer.OrdinalIgnoreCase);

        private static LanguagePack active;

        /// <summary>Папка языковых пакетов: /os/sys/locale/</summary>
        public static string PacksDirectory
        {
            get { return LisunEngine.LocalePath; }
        }

        /// <summary>Код текущего языка: ru, en или код любого установленного пакета.</summary>
        public static string Code
        {
            get
            {
                if (active != null) return active.Code;
                return Language == LisunLanguage.Russian ? "ru" : "en";
            }
        }

        public static string DisplayName
        {
            get
            {
                if (active != null) return active.Name;
                return Language == LisunLanguage.Russian ? "Русский" : "English";
            }
        }

        /// <summary>Полный тег языка, как он указывается в манифестах пакетов: ruRU / enUS.</summary>
        public static string ManifestTag
        {
            get
            {
                if (active != null && active.ManifestTag.Length > 0) return active.ManifestTag;
                if (active != null) return active.Code + active.Code.ToUpperInvariant();

                return Language == LisunLanguage.Russian ? "ruRU" : "enUS";
            }
        }

        /// <summary>
        /// Читает все пакеты из /os/sys/locale. Пакет — файл &lt;код&gt;.json:
        /// { "name": "Deutsch", "layout": "de", "manifest": "deDE",
        ///   "base": "en", "strings": { "ключ": "перевод", ... } }
        /// </summary>
        public static int LoadPacks()
        {
            packs.Clear();

            try
            {
                if (!Directory.Exists(PacksDirectory)) Directory.CreateDirectory(PacksDirectory);

                foreach (string file in Directory.GetFiles(PacksDirectory, "*.json"))
                {
                    LanguagePack pack = ReadPack(file);
                    if (pack != null) packs[pack.Code] = pack;
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Locale] [ОШИБКА] Чтение языков: " + ex.Message);
            }

            return packs.Count;
        }

        private static LanguagePack ReadPack(string file)
        {
            try
            {
                LisunJson.Node root = LisunJson.Parse(LisunCrypto.ReadAllText(file));
                if (root == null || !root.IsObject) return null;

                LanguagePack pack = new LanguagePack();

                pack.Code = Text(root, "code", Path.GetFileNameWithoutExtension(file)).ToLowerInvariant();
                if (pack.Code.Length == 0) return null;

                pack.Name = Text(root, "name", pack.Code.ToUpperInvariant());
                pack.Layout = Text(root, "layout", pack.Code);
                pack.ManifestTag = Text(root, "manifest", string.Empty);
                pack.BasedOnRussian = Text(root, "base", "en")
                    .Equals("ru", StringComparison.OrdinalIgnoreCase);

                LisunJson.Node strings = root.Child("strings");
                if (strings != null && strings.IsObject)
                {
                    foreach (KeyValuePair<string, LisunJson.Node> item in strings.Object)
                    {
                        string value = item.Value == null ? string.Empty : item.Value.AsText();
                        if (value.Length > 0) pack.Strings[item.Key] = value;
                    }
                }

                return pack;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Locale] [ОШИБКА] " + Path.GetFileName(file) + ": " + ex.Message);
                return null;
            }
        }

        private static string Text(LisunJson.Node node, string key, string fallback)
        {
            LisunJson.Node child = node.Child(key);
            if (child == null) return fallback;

            string value = child.AsText().Trim();
            return value.Length == 0 ? fallback : value;
        }

        /// <summary>Все доступные языки: два встроенных плюс все найденные пакеты.</summary>
        public static List<LanguagePack> Available()
        {
            List<LanguagePack> result = new List<LanguagePack>();

            LanguagePack russian = new LanguagePack();
            russian.Code = "ru";
            russian.Name = "Русский";
            russian.Layout = "ru";
            russian.ManifestTag = "ruRU";
            russian.BasedOnRussian = true;
            result.Add(russian);

            LanguagePack english = new LanguagePack();
            english.Code = "en";
            english.Name = "English";
            english.Layout = "en";
            english.ManifestTag = "enUS";
            result.Add(english);

            foreach (LanguagePack pack in packs.Values)
                if (pack.Code != "ru" && pack.Code != "en") result.Add(pack);

            result.Sort((left, right) => string.CompareOrdinal(left.Code, right.Code));
            return result;
        }

        /// <summary>Таблица языков для команды «lang list».</summary>
        public static string ListText()
        {
            StringBuilder sb = new StringBuilder(T("lang.listTitle") + Environment.NewLine);

            foreach (LanguagePack pack in Available())
            {
                bool current = pack.Code.Equals(Code, StringComparison.OrdinalIgnoreCase);
                bool builtIn = pack.Code == "ru" || pack.Code == "en";

                sb.AppendLine("   " + (current ? "●" : " ") + " " +
                              pack.Code.PadRight(6) +
                              pack.Name.PadRight(22) +
                              (builtIn ? T("lang.builtIn")
                                       : T("lang.translated", pack.Completeness)));
            }

            sb.AppendLine();
            sb.AppendLine("   " + T("lang.folder", CustomFormUtils.ToVirtualPath(PacksDirectory)));
            return sb.ToString().TrimEnd();
        }

        /// <summary>
        /// Выкладывает шаблон перевода: все строки системы с английскими
        /// значениями. Достаточно перевести значения и сохранить файл.
        /// </summary>
        public static bool ExportTemplate(string code, out string path)
        {
            code = (code ?? "new").Trim().ToLowerInvariant();
            if (code.Length == 0) code = "new";

            path = Path.Combine(PacksDirectory, code + ".json");

            try
            {
                if (!Directory.Exists(PacksDirectory)) Directory.CreateDirectory(PacksDirectory);

                LanguagePack existing;
                packs.TryGetValue(code, out existing);

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("{");
                sb.AppendLine("    \"code\": " + Quote(code) + ",");
                sb.AppendLine("    \"name\": " + Quote(existing != null ? existing.Name : code.ToUpperInvariant()) + ",");
                sb.AppendLine("    \"layout\": " + Quote(existing != null ? existing.Layout : code) + ",");
                sb.AppendLine("    \"manifest\": " + Quote(existing != null && existing.ManifestTag.Length > 0
                                                            ? existing.ManifestTag
                                                            : code + code.ToUpperInvariant()) + ",");
                sb.AppendLine("    \"base\": \"en\",");
                sb.AppendLine("    \"strings\": {");

                List<string> keys = new List<string>(Strings.Keys);
                keys.Sort(StringComparer.Ordinal);

                for (int index = 0; index < keys.Count; index++)
                {
                    string key = keys[index];

                    string value;
                    if (existing == null || !existing.Strings.TryGetValue(key, out value))
                        value = Strings[key].Length > 1 ? Strings[key][1] : Strings[key][0];

                    sb.Append("        ").Append(Quote(key)).Append(": ").Append(Quote(value));
                    sb.AppendLine(index + 1 < keys.Count ? "," : "");
                }

                sb.AppendLine("    }");
                sb.AppendLine("}");

                return CustomFormUtils.WriteFileText(path, sb.ToString());
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Locale] [ОШИБКА] Шаблон: " + ex.Message);
                return false;
            }
        }

        private static string Quote(string value)
        {
            if (value == null) return "\"\"";

            StringBuilder sb = new StringBuilder("\"");
            foreach (char symbol in value)
            {
                switch (symbol)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (symbol < ' ') sb.Append("\\u").Append(((int)symbol).ToString("x4"));
                        else sb.Append(symbol);
                        break;
                }
            }
            return sb.Append('"').ToString();
        }


        // =====================================================================
        //  Язык интерфейса
        // =====================================================================

        public static void LoadFromRegistry()
        {
            LoadPacks();

            string value;
            if (!LisunEngine.RegistryData.TryGetValue("language", out value) || value == null)
                value = string.Empty;

            value = value.Trim().ToLowerInvariant();

            if (value.Equals("en", StringComparison.OrdinalIgnoreCase))
            {
                active = null;
                Language = LisunLanguage.English;
            }
            else if (value.Length > 0 && value != "ru" && packs.ContainsKey(value))
            {
                active = packs[value];
                Language = active.BasedOnRussian ? LisunLanguage.Russian : LisunLanguage.English;
            }
            else
            {
                active = null;
                Language = LisunLanguage.Russian;
                LisunEngine.RegistryData["language"] = "ru";
            }

            string layout;
            if (!LisunEngine.RegistryData.TryGetValue("keyboard_layout", out layout) ||
                layout == null || layout.Trim().Length == 0)
            {
                layout = active != null && active.Layout.Length > 0 ? active.Layout : Code;
                LisunEngine.RegistryData["keyboard_layout"] = layout;
            }

            LisunEngine.SaveRegistry();

            SetLayout(layout.Trim(), false);
            Raise(LanguageChanged);
        }

        /// <summary>
        /// Переключает язык по коду. Встроенные ru и en работают всегда,
        /// остальные — если в /os/sys/locale лежит пакет с таким кодом.
        /// </summary>
        public static bool SetLanguage(string code)
        {
            if (string.IsNullOrEmpty(code)) return false;

            code = code.Trim().ToLowerInvariant().Replace("-", "").Replace("_", "");

            if (code == "ru" || code == "rus" || code == "ruru" || code == "русский")
                return SetLanguage(LisunLanguage.Russian);

            if (code == "en" || code == "eng" || code == "enus" || code == "engb" || code == "english")
                return SetLanguage(LisunLanguage.English);

            if (packs.Count == 0) LoadPacks();

            LanguagePack pack;
            if (!packs.TryGetValue(code, out pack))
            {
                // Пакет мог появиться после загрузки системы — перечитаем папку.
                LoadPacks();
                if (!packs.TryGetValue(code, out pack)) return false;
            }

            active = pack;

            // Непереведённые строки берутся из встроенного языка-основы.
            Language = pack.BasedOnRussian ? LisunLanguage.Russian : LisunLanguage.English;

            LisunEngine.RegistryData["language"] = pack.Code;
            LisunEngine.SaveRegistry();

            if (pack.Layout.Length > 0) SetLayout(pack.Layout, true);

            Raise(LanguageChanged);
            return true;
        }

        public static bool SetLanguage(LisunLanguage language)
        {
            active = null;
            Language = language;

            LisunEngine.RegistryData["language"] = Code;
            LisunEngine.SaveRegistry();

            Raise(LanguageChanged);
            return true;
        }

        public static void ToggleLanguage()
        {
            SetLanguage(Language == LisunLanguage.Russian ? LisunLanguage.English : LisunLanguage.Russian);
        }

        // =====================================================================
        //  Раскладка клавиатуры
        // =====================================================================

        public static string LayoutTag
        {
            get
            {
                try
                {
                    InputLanguage current = InputLanguage.CurrentInputLanguage;
                    if (current == null || current.Culture == null) return "--";
                    return current.Culture.TwoLetterISOLanguageName.ToUpperInvariant();
                }
                catch { return "--"; }
            }
        }

        public static string InstalledLayouts()
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                foreach (InputLanguage language in InputLanguage.InstalledInputLanguages)
                {
                    if (builder.Length > 0) builder.Append(", ");
                    builder.Append(language.Culture.TwoLetterISOLanguageName.ToUpperInvariant());
                }
            }
            catch { }
            return builder.Length == 0 ? "--" : builder.ToString();
        }

        public static bool SetLayout(string twoLetterCode)
        {
            return SetLayout(twoLetterCode, true);
        }

        private static bool SetLayout(string twoLetterCode, bool persist)
        {
            if (string.IsNullOrEmpty(twoLetterCode)) return false;
            twoLetterCode = twoLetterCode.Trim();

            try
            {
                foreach (InputLanguage language in InputLanguage.InstalledInputLanguages)
                {
                    if (!language.Culture.TwoLetterISOLanguageName.Equals(twoLetterCode, StringComparison.OrdinalIgnoreCase))
                        continue;

                    InputLanguage.CurrentInputLanguage = language;

                    if (persist)
                    {
                        LisunEngine.RegistryData["keyboard_layout"] = twoLetterCode.ToLowerInvariant();
                        LisunEngine.SaveRegistry();
                    }

                    Raise(LayoutChanged);
                    return true;
                }
            }
            catch { }

            return false;
        }

        /// <summary>Переключает раскладку на следующую из установленных в Windows.</summary>
        public static bool CycleLayout()
        {
            try
            {
                InputLanguageCollection installed = InputLanguage.InstalledInputLanguages;
                if (installed.Count < 2) return false;

                InputLanguage current = InputLanguage.CurrentInputLanguage;
                int index = 0;

                for (int i = 0; i < installed.Count; i++)
                {
                    if (current != null && installed[i].Culture.LCID == current.Culture.LCID)
                    {
                        index = i;
                        break;
                    }
                }

                InputLanguage next = installed[(index + 1) % installed.Count];
                InputLanguage.CurrentInputLanguage = next;

                LisunEngine.RegistryData["keyboard_layout"] = next.Culture.TwoLetterISOLanguageName.ToLowerInvariant();
                LisunEngine.SaveRegistry();

                Raise(LayoutChanged);
                return true;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Словарь строк
        // =====================================================================

        /// <summary>
        /// Строка интерфейса. Порядок поиска: активный языковой пакет →
        /// встроенный язык-основа → английский → сам ключ.
        /// Так частично переведённый пакет не оставляет пустых мест.
        /// </summary>
        public static string T(string key)
        {
            if (active != null)
            {
                string translated;
                if (active.Strings.TryGetValue(key, out translated) && translated.Length > 0)
                    return translated;
            }

            string[] variants;
            if (!Strings.TryGetValue(key, out variants)) return key;

            int index = (int)Language;
            if (index < 0 || index >= variants.Length) index = 0;

            string value = variants[index];
            if (value.Length == 0 && variants.Length > 1) value = variants[1];

            return value;
        }

        public static string T(string key, params object[] args)
        {
            string template = T(key);
            try { return string.Format(template, args); }
            catch { return template; }
        }

        private static void Raise(Action handler)
        {
            if (handler != null) handler();
        }

        internal static readonly Dictionary<string, string[]> Strings =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "shell.title",        new[] { "LisunOS {0}  ·  Терминал ядра",      "LisunOS {0}  ·  Core Terminal" } },
            { "tab.terminal",       new[] { "Терминал",                           "Terminal" } },
            { "tab.browser",        new[] { "Браузер",                            "Browser" } },
            { "menu.language",      new[] { "Язык системы",                       "System language" } },
            { "menu.layout",        new[] { "Раскладка клавиатуры",               "Keyboard layout" } },
            { "menu.nextLayout",    new[] { "Следующая раскладка (Ctrl+Space)",   "Next layout (Ctrl+Space)" } },
            { "menu.noLayouts",     new[] { "Раскладки не найдены",               "No layouts found" } },
            { "menu.terminal",      new[] { "Вернуться в терминал (Esc)",         "Back to the terminal (Esc)" } },
            { "menu.browser",       new[] { "Открыть браузер",                    "Open the browser" } },
            { "menu.restart",       new[] { "Перезапустить подсистемы",           "Restart the subsystems" } },
            { "menu.exit",          new[] { "Выход",                              "Exit" } },
            { "menu.title",         new[] { "Меню системы",                       "System menu" } },
            { "tab.close",          new[] { "Закрыть вкладку",                    "Close tab" } },
            { "status.apps",        new[] { "приложений",                         "apps" } },
            { "status.layoutHint",  new[] { "Раскладка клавиатуры (Ctrl+Space)",  "Keyboard layout (Ctrl+Space)" } },
            { "status.langHint",    new[] { "Язык системы (Ctrl+Alt+L)",          "System language (Ctrl+Alt+L)" } },

            { "boot.engine",        new[] { "Ядро LisunOS",                       "LisunOS Kernel Engine" } },
            { "boot.prepare",       new[] { "Подготовка виртуального окружения...",
                                            "Preparing the virtual environment..." } },
            { "boot.scan",          new[] { "[BOOT] Сканирование /sys/services/ и запуск сервисов...",
                                            "[BOOT] Scanning /sys/services/ and starting services..." } },
            { "boot.version",       new[] { " LisunOS [Версия {0} \"{1}\"]",       " LisunOS [Version {0} \"{1}\"]" } },
            { "boot.rights",        new[] { " (c) Lisun Core Engine. Все права защищены.",
                                            " (c) Lisun Core Engine. All rights reserved." } },
            { "boot.hint",          new[] { " Консоль готова. 'help' — список команд, 'webview <адрес>' — браузер.",
                                            " Console ready. 'help' lists commands, 'webview <url>' opens the browser." } },
            { "boot.hintEsc",       new[] { " Esc — вернуться в терминал из любого приложения.",
                                            " Esc returns to the terminal from any application." } },
            { "boot.fail",          new[] { " [FATAL] Сбой загрузки: {0}",         " [FATAL] Boot failure: {0}" } },

            { "msg.shutdown",       new[] { " Завершение работы LisunOS...",       " Shutting down LisunOS..." } },
            { "msg.browserOpen",    new[] { " [SYS] Браузер открыт: {0}",          " [SYS] Browser opened: {0}" } },
            { "msg.browserHidden",  new[] { " [SYS] Браузер свёрнут — сессия сохранена во вкладке.",
                                            " [SYS] Browser minimised — the session is kept in its tab." } },
            { "msg.servicesReload", new[] { " [SYS] Подсистемы выгружены. Повторный запуск сервисов...",
                                            " [SYS] Subsystems unloaded. Restarting services..." } },
            { "msg.embedFailed",    new[] { " [ERROR] Не удалось встроить окно приложения: {0}",
                                            " [ERROR] Could not embed the application window: {0}" } },
            { "msg.langChanged",    new[] { " [SYS] Язык системы: {0}",            " [SYS] System language: {0}" } },
            { "msg.layoutChanged",  new[] { " [SYS] Раскладка клавиатуры: {0}",    " [SYS] Keyboard layout: {0}" } },
            { "msg.layoutFailed",   new[] { " [ERROR] Других раскладок не найдено. Добавьте их в параметрах языка Windows.",
                                            " [ERROR] No other layouts found. Add them in the Windows language settings." } },
            { "msg.layoutMissing",  new[] { " [ERROR] Раскладка '{0}' не установлена в Windows.",
                                            " [ERROR] Layout '{0}' is not installed in Windows." } },
            { "msg.langUsage",      new[] { " Язык системы: {0}. Список языков: lang list",
                                            " System language: {0}. Language list: lang list" } },
            { "msg.layoutUsage",    new[] { " Раскладка: {0}. Установленные: {1}.  Пример: layout en  |  layout next",
                                            " Layout: {0}. Installed: {1}.  Example: layout en  |  layout next" } },

            { "browser.go",         new[] { "Перейти",                            "Go" } },
            { "browser.hide",       new[] { "✕  Свернуть",                        "✕  Minimise" } },
            { "browser.ready",      new[] { "Готов",                              "Ready" } },
            { "browser.loading",    new[] { "Загрузка: {0}",                      "Loading: {0}" } },
            { "browser.connecting", new[] { "Подключение...",                     "Connecting..." } },
            { "browser.receiving",  new[] { "Получение данных...",                "Receiving data..." } },
            { "browser.done",       new[] { "Готово",                             "Done" } },
            { "browser.engine",     new[] { "Поисковая система: {0}",             "Search engine: {0}" } },
            { "browser.navError",   new[] { "Ошибка перехода: {0}",               "Navigation error: {0}" } },

            { "explorer.title",     new[] { "Проводник LisunOS",                  "LisunOS Explorer" } },
            { "explorer.colName",   new[] { "Имя",                                "Name" } },
            { "explorer.colType",   new[] { "Тип",                                "Type" } },
            { "explorer.colSize",   new[] { "Размер",                             "Size" } },
            { "explorer.colDate",   new[] { "Изменён",                            "Modified" } },
            { "explorer.folder",    new[] { "Папка",                              "Folder" } },
            { "explorer.file",      new[] { "Файл",                               "File" } },
            { "explorer.fileExt",   new[] { "{0}-файл",                           "{0} file" } },
            { "explorer.rename",    new[] { "Переименовать",                      "Rename" } },
            { "explorer.refresh",   new[] { "Обновить (F5)",                      "Refresh (F5)" } },
            { "explorer.newName",   new[] { "Новое имя:",                         "New name:" } },
            { "explorer.newFile",   new[] { "Имя файла:",                         "File name:" } },
            { "explorer.newFolder", new[] { "Имя папки:",                         "Folder name:" } },
            { "explorer.titleFile", new[] { "Новый файл",                         "New file" } },
            { "explorer.titleDir",  new[] { "Новая папка",                        "New folder" } },
            { "explorer.exists",    new[] { "Объект с таким именем уже существует.",
                                            "An item with this name already exists." } },
            { "explorer.confirm",   new[] { "Удалить \"{0}\"?",                   "Delete \"{0}\"?" } },
            { "explorer.renameErr", new[] { "Не удалось переименовать: {0}",      "Rename failed: {0}" } },
            { "explorer.view",      new[] { "Просмотр: {0}",                      "View: {0}" } },
            { "explorer.chars",     new[] { "{0}   •   символов: {1}",            "{0}   •   characters: {1}" } },

            { "apt.usage",          new[] { " apt list | info <имя> | install <файл.lnsh> | update [имя] | remove <имя> | protect <имя> | unprotect <имя>",
                                            " apt list | info <name> | install <file.lnsh> | update [name] | remove <name> | protect <name> | unprotect <name>" } },
            { "apt.listEmpty",      new[] { " Установленных пакетов нет.",         " No packages installed." } },
            { "apt.listTitle",      new[] { " Установленные пакеты:",              " Installed packages:" } },
            { "apt.notFound",       new[] { " [ERROR] Пакет '{0}' не найден.",     " [ERROR] Package '{0}' not found." } },
            { "apt.updated",        new[] { " [OK] Пакет '{0}' обновлён из {1}",   " [OK] Package '{0}' updated from {1}" } },
            { "apt.updateFailed",   new[] { " [ERROR] Обновление '{0}': {1}",      " [ERROR] Update of '{0}': {1}" } },
            { "apt.removed",        new[] { " [OK] Пакет '{0}' удалён.",           " [OK] Package '{0}' removed." } },
            { "apt.needSudo",       new[] { " [ERROR] Операция требует sudo или режима root.",
                                            " [ERROR] This operation requires sudo or root mode." } },
            { "apt.protected",      new[] { " [OK] Пакет '{0}' зашифрован: файлов — {1}.",
                                            " [OK] Package '{0}' encrypted: {1} files." } },
            { "apt.unprotected",    new[] { " [OK] Пакет '{0}' расшифрован: файлов — {1}.",
                                            " [OK] Package '{0}' decrypted: {1} files." } },
            { "apt.installUsage",   new[] { " [ERROR] Формат: apt install <имя пакета> | <путь к .lnsh>\r\n   Имя берётся из каталога: store — список, apt install webserverv2 — скачать с сайта.",
                                            " [ERROR] Usage: apt install <package name> | <path to .lnsh>\r\n   Names come from the catalog: store lists them, apt install webserverv2 downloads from the site." } },
            { "apt.state",          new[] { "защищён",                             "protected" } },
            { "apt.stateOpen",      new[] { "открыт",                              "open" } },
            { "suggest.hint",       new[] { "↑↓ — выбор, Tab или Enter — подставить, Esc — скрыть",
                                            "↑↓ select, Tab or Enter inserts, Esc hides" } },
            { "apt.rights",         new[] { "права",                               "rights" } },
            { "ps.title",           new[] { " Активные процессы:",                 " Active processes:" } },
            { "ps.empty",           new[] { " Активных процессов нет.",             " No active processes." } },
            { "ps.running",         new[] { "работает",                            "running" } },
            { "ps.idle",            new[] { "свёрнут",                             "idle" } },
            { "ps.noForm",          new[] { "форма не собрана",                    "form not built" } },
            { "kill.usage",         new[] { " Формат: kill <приложение>  (список: ps)",
                                            " Usage: kill <application>  (see: ps)" } },
            { "kill.done",          new[] { " [OK] Процесс '{0}' завершён.",        " [OK] Process '{0}' terminated." } },
            { "kill.notFound",      new[] { " [ERROR] Процесс '{0}' не найден.",    " [ERROR] Process '{0}' not found." } },
            { "sysinfo.title",      new[] { " Сведения о системе:",                 " System information:" } },
            { "calc.usage",         new[] { " Формат: calc <выражение>   например: calc (12+8)*3^2",
                                            " Usage: calc <expression>   e.g. calc (12+8)*3^2" } },
            { "calc.bad",           new[] { " [ERROR] Не удалось вычислить: {0}",   " [ERROR] Could not evaluate: {0}" } },
            { "grep.usage",         new[] { " Формат: grep <текст> <файл>",          " Usage: grep <text> <file>" } },
            { "grep.none",          new[] { " Совпадений с '{0}' не найдено.",      " No matches for '{0}'." } },
            { "grep.found",         new[] { "   Найдено строк: {0}",                "   Lines found: {0}" } },
            { "wc.usage",           new[] { " Формат: wc <файл>",                    " Usage: wc <file>" } },
            { "wc.result",          new[] { " строк: {0}   слов: {1}   символов: {2}",
                                            " lines: {0}   words: {1}   characters: {2}" } },
            { "notify.usage",       new[] { " Формат: notify <текст>",               " Usage: notify <text>" } },
            { "notify.done",        new[] { " [OK] Уведомление показано.",           " [OK] Notification shown." } },
            { "alias.usage",        new[] { " Формат: alias <имя> <команда>  |  unalias <имя>",
                                            " Usage: alias <name> <command>  |  unalias <name>" } },
            { "alias.title",        new[] { " Псевдонимы команд:",                   " Command aliases:" } },
            { "alias.empty",        new[] { " Псевдонимов нет. Пример: alias ll ls",
                                            " No aliases yet. Example: alias ll ls" } },
            { "alias.set",          new[] { " [OK] Псевдоним '{0}' → {1}",           " [OK] Alias '{0}' → {1}" } },
            { "alias.removed",      new[] { " [OK] Псевдоним '{0}' удалён.",         " [OK] Alias '{0}' removed." } },
            { "alias.notFound",     new[] { " [ERROR] Псевдоним '{0}' не найден.",   " [ERROR] Alias '{0}' not found." } },
            { "alias.reserved",     new[] { " [ERROR] Это имя занято системой.",     " [ERROR] That name is reserved." } },
            { "ufw.usage",          new[] { " ufw status | enable | disable | port <порт> <enable|disable|remove> | allow <порт> | deny <порт> | default <allow|deny> | reset",
                                            " ufw status | enable | disable | port <port> <enable|disable|remove> | allow <port> | deny <port> | default <allow|deny> | reset" } },
            { "ufw.statusTitle",    new[] { " Брандмауэр LisunOS",                 " LisunOS firewall" } },
            { "ufw.state",          new[] { "состояние",                          "state" } },
            { "ufw.on",             new[] { "включён",                            "enabled" } },
            { "ufw.off",            new[] { "выключен",                           "disabled" } },
            { "ufw.defaultPolicy",  new[] { "политика по умолчанию",               "default policy" } },
            { "ufw.rules",          new[] { "правила",                            "rules" } },
            { "ufw.noRules",        new[] { "правил нет — действует политика по умолчанию",
                                            "no rules — the default policy applies" } },
            { "ufw.allowed",        new[] { "разрешён",                           "allowed" } },
            { "ufw.denied",         new[] { "запрещён",                           "denied" } },
            { "ufw.allowedDefault", new[] { "разрешён (по умолчанию)",             "allowed (default)" } },
            { "ufw.deniedDefault",  new[] { "запрещён (по умолчанию)",             "denied (default)" } },
            { "ufw.offPass",        new[] { "брандмауэр выключен — порт открыт",   "firewall off — port open" } },
            { "ufw.enabled",        new[] { " [OK] Брандмауэр включён.",           " [OK] Firewall enabled." } },
            { "ufw.disabled",       new[] { " [OK] Брандмауэр выключен.",          " [OK] Firewall disabled." } },
            { "ufw.resetDone",      new[] { " [OK] Правила сброшены.",             " [OK] Rules reset." } },
            { "ufw.defaultSet",     new[] { " [OK] Политика по умолчанию: {0}",    " [OK] Default policy: {0}" } },
            { "ufw.portAllowed",    new[] { " [OK] Порт {0} разрешён.",            " [OK] Port {0} allowed." } },
            { "ufw.portDenied",     new[] { " [OK] Порт {0} запрещён.",            " [OK] Port {0} denied." } },
            { "ufw.portRemoved",    new[] { " [OK] Правило для порта {0} удалено.", " [OK] Rule for port {0} removed." } },
            { "ufw.noPortRule",     new[] { " Для порта {0} правила нет.",         " No rule for port {0}." } },
            { "ufw.portState",      new[] { " Порт {0}: {1}",                      " Port {0}: {1}" } },
            { "ufw.badPort",        new[] { " [ERROR] Некорректный порт: {0}",     " [ERROR] Invalid port: {0}" } },
            { "ufw.needSudo",       new[] { " [ERROR] Управление брандмауэром требует sudo или режима root.",
                                            " [ERROR] Managing the firewall requires sudo or root mode." } },

            { "systemctl.usage",    new[] { " systemctl list | status <служба> | start | stop | restart | enable | disable <служба>",
                                            " systemctl list | status <service> | start | stop | restart | enable | disable <service>" } },
            { "systemctl.listTitle",new[] { " Службы LisunOS:",                    " LisunOS services:" } },
            { "systemctl.empty",    new[] { " Установленных служб нет.",           " No services installed." } },
            { "systemctl.active",   new[] { "активна",                            "active" } },
            { "systemctl.inactive", new[] { "остановлена",                        "inactive" } },
            { "systemctl.enabled",  new[] { "включён",                            "enabled" } },
            { "systemctl.disabled", new[] { "выключен",                           "disabled" } },
            { "systemctl.started",  new[] { " [OK] Служба '{0}' запущена.",        " [OK] Service '{0}' started." } },
            { "systemctl.stopped",  new[] { " [OK] Служба '{0}' остановлена.",     " [OK] Service '{0}' stopped." } },
            { "systemctl.restarted",new[] { " [OK] Служба '{0}' перезапущена.",    " [OK] Service '{0}' restarted." } },
            { "systemctl.enabledNow",  new[] { " [OK] Автозапуск '{0}' включён.",  " [OK] Autostart of '{0}' enabled." } },
            { "systemctl.disabledNow", new[] { " [OK] Автозапуск '{0}' выключен.", " [OK] Autostart of '{0}' disabled." } },
            { "systemctl.notFound", new[] { " [ERROR] Служба '{0}' не найдена.",   " [ERROR] Service '{0}' not found." } },
            { "systemctl.notRunning",new[] { " Служба '{0}' не запущена.",         " Service '{0}' is not running." } },
            { "systemctl.needSudo", new[] { " [ERROR] Изменение автозапуска требует sudo.",
                                            " [ERROR] Changing autostart requires sudo." } },
            { "systemctl.fieldState",    new[] { "состояние",                     "state" } },
            { "systemctl.fieldAuto",     new[] { "автозапуск",                    "autostart" } },
            { "systemctl.fieldVersion",  new[] { "версия",                        "version" } },
            { "systemctl.fieldScripts",  new[] { "сценариев",                     "scripts" } },
            { "systemctl.fieldProtected",new[] { "пакет",                         "package" } },
            { "systemctl.fieldPath",     new[] { "путь",                          "path" } },
            { "systemctl.fieldRights",   new[] { "права",                         "rights" } },

            { "repo.title",         new[] { " Системный каталог LisunOS:",         " LisunOS system catalog:" } },
            { "repo.installed",     new[] { "установлен",                         "installed" } },
            { "repo.available",     new[] { "доступен",                           "available" } },
            { "repo.hint",          new[] { "   Установка: apt install <имя>",     "   Install with: apt install <name>" } },
            { "repo.notFound",      new[] { " [ERROR] В каталоге нет библиотеки '{0}'. Список: apt catalog",
                                            " [ERROR] No library '{0}' in the catalog. See: apt catalog" } },
            { "repo.installOk",     new[] { " [OK] Библиотека '{0}' установлена. Запуск командой: {1}",
                                            " [OK] Library '{0}' installed. Launch it with: {1}" } },
            { "repo.installFailed", new[] { " [ERROR] Установка '{0}' не завершена — подробности в журнале.",
                                            " [ERROR] Installation of '{0}' did not finish — see the log." } },

            { "srv.title",          new[] { "Сервер LisunOS",                     "LisunOS Server" } },
            { "srv.ready",          new[] { "Панель готова. Укажите порт и нажмите «Запустить».",
                                            "Panel ready. Set a port and press Start." } },
            { "srv.stateOn",        new[] { "Сервер работает на порту {0}",        "Server running on port {0}" } },
            { "srv.stateOff",       new[] { "Сервер остановлен",                  "Server stopped" } },
            { "srv.started",        new[] { "Запущен на порту {0}, адрес {1}",     "Started on port {0}, address {1}" } },
            { "srv.stopped",        new[] { "Сервер остановлен",                  "Server stopped" } },
            { "srv.alreadyRunning", new[] { "Сервер уже запущен",                 "The server is already running" } },
            { "srv.badPort",        new[] { "Некорректный порт",                  "Invalid port" } },
            { "srv.portBusy",       new[] { "Порт {0} занят другой программой",    "Port {0} is already in use" } },
            { "srv.blockedByUfw",   new[] { "Порт {0} закрыт брандмауэром ufw",    "Port {0} is blocked by ufw" } },
            { "srv.noAddresses",    new[] { "сервер остановлен",                  "server stopped" } },
            { "srv.stats",          new[] { "запросов: {0}   ошибок: {1}   время: {2}   ufw: {3}",
                                            "requests: {0}   errors: {1}   uptime: {2}   ufw: {3}" } },
            { "srv.opening",        new[] { "Открываю {0}",                       "Opening {0}" } },
            { "srv.folderOpened",   new[] { "Открыта папка {0}",                  "Opened folder {0}" } },
            { "srv.remoteOn",       new[] { "Подключения из локальной сети разрешены",
                                            "Local network connections allowed" } },
            { "srv.remoteOff",      new[] { "Только локальные подключения (127.0.0.1)",
                                            "Local connections only (127.0.0.1)" } },
            { "srv.ufwOpened",      new[] { "Порт {0} открыт в ufw",               "Port {0} opened in ufw" } },
            { "srv.ufwState",       new[] { "Брандмауэр ufw: {0}",                 "Firewall ufw: {0}" } },

            { "srv.autostartOn",    new[] { "Автозапуск сервера включён — сайт поднимется при загрузке LisunOS.",
                                            "Server autostart enabled — the site will come up when LisunOS boots." } },
            { "srv.autostartOff",   new[] { "Автозапуск сервера выключен.",          "Server autostart disabled." } },
            { "srv.autostartDone",  new[] { "Автозапуск: сервер поднят на порту {0}.",
                                            "Autostart: server is up on port {0}." } },
            { "srv.autostartFailed",new[] { "Автозапуск не удался: {0}",             "Autostart failed: {0}" } },
            { "srv.autostartNoPerm",new[] { "Автозапуск пропущен: приложению не выдано право network.",
                                            "Autostart skipped: the application lacks the network permission." } },
            { "srv.panel",          new[] { "Веб-панель",                          "Web panel" } },
            { "srv.panelTitle",     new[] { "Веб-панель управления",                "Web management panel" } },
            { "srv.panelHint",      new[] { "Панель открывается в браузере по адресу {0}\r\nВход по паролю; файлы, правка и смена пароля — внутри панели.",
                                            "The panel opens in a browser at {0}\r\nPassword login; files, editing and password change are inside the panel." } },
            { "srv.panelPass",      new[] { "Пароль панели:",                        "Panel password:" } },
            { "srv.panelSet",       new[] { "Задать пароль",                         "Set password" } },
            { "srv.panelRandom",    new[] { "Случайный",                             "Random" } },
            { "srv.panelOpen",      new[] { "Открыть панель",                        "Open panel" } },
            { "srv.panelSaved",     new[] { "Пароль веб-панели сохранён.",            "The web panel password was saved." } },
            { "srv.panelShort",     new[] { "Пароль должен быть не короче четырёх символов.",
                                            "The password must be at least four characters." } },
            { "srv.panelNoPass",    new[] { "Пароль не задан — панель не пустит внутрь. Задайте его здесь.",
                                            "No password set — the panel will not let anyone in. Set one here." } },
            { "srv.panelNoPhp",     new[] { "Панель написана на PHP. Подключите PHP: apt install php-frm",
                                            "The panel is written in PHP. Connect PHP with: apt install php-frm" } },
            { "srv.panelNeedRun",   new[] { "Сервер остановлен — запустите его, чтобы открыть панель.",
                                            "The server is stopped — start it to open the panel." } },
            { "srv.panelCreated",   new[] { "Создан panel.php в корне сайта.",        "panel.php was created in the site root." } },
            { "php.notFound",       new[] { " [ERROR] PHP не найден на этом компьютере.\r\n   Установите PHP для Windows (windows.php.net), затем повторите\r\n   apt install php-frm, либо укажите путь явно:\r\n   apt install php-frm C:\\php\\php-cgi.exe",
                                            " [ERROR] PHP was not found on this computer.\r\n   Install PHP for Windows (windows.php.net) and repeat\r\n   apt install php-frm, or give the path explicitly:\r\n   apt install php-frm C:\\php\\php-cgi.exe" } },
            { "php.sourceBuiltIn", new[] { "   Работает наш встроенный движок PHP (PHP.cs + PHPExecuter.cs),\r\n   внешний php-cgi.exe не требуется.",
                                            "   Running our own built-in PHP engine (PHP.cs + PHPExecuter.cs);\r\n   no external php-cgi.exe required." } },
            { "php.engineName",     new[] { "встроенный движок LisunOS",            "built-in LisunOS engine" } },
            { "php.installed",      new[] { " [OK] PHP подключён: {0}",             " [OK] PHP connected: {0}" } },
            { "php.apiReady",       new[] { "   Файлы .php теперь исполняются, создан api.php с ключом.",
                                            "   .php files now execute, api.php with a key was created." } },
            { "php.configFailed",   new[] { " [ERROR] Не удалось записать .htaccess.",
                                            " [ERROR] Could not write .htaccess." } },
            { "php.removed",        new[] { " [OK] Обработка PHP выключена. Файлы .php теперь открываются как HTML.",
                                            " [OK] PHP handling disabled. .php files are now served as HTML." } },
            { "php.panelReady",     new[] { "   Веб-панель: panel.php — {0}",       "   Web panel: panel.php — {0}" } },
            { "php.panelHasPass",   new[] { "пароль задан",                        "password set" } },
            { "php.panelNoPass",    new[] { "задайте пароль в «Сервер v2» → «Веб-панель»",
                                            "set the password in Server v2 → Web panel" } },
            { "php.sourceOwn",      new[] { "   Используется свой PHP внутри LisunOS (/os/sys/php).",
                                            "   Using the PHP bundled inside LisunOS (/os/sys/php)." } },
            { "php.sourceSystem",   new[] { "   Используется PHP, установленный в системе.",
                                            "   Using the PHP installed on the system." } },
            { "php.sourceBuiltInShort", new[] { "встроенный движок",               "built-in engine" } },
            { "php.fieldMirrors",   new[] { "зеркал",                            "mirrors" } },
            { "php.sourceOwnShort", new[] { "свой (внутри LisunOS)",               "own (inside LisunOS)" } },
            { "php.sourceSystemShort", new[] { "системный",                        "system" } },
            { "php.fieldSource",    new[] { "источник",                            "source" } },
            { "php.fieldOwnDir",    new[] { "свой каталог",                        "own folder" } },
            { "php.notInstalledHere", new[] { "пусто",                             "empty" } },
            { "php.badArgument",    new[] { " [ERROR] Не найден путь: {0}\r\n   Укажите архив .zip, папку с PHP или php-cgi.exe.",
                                            " [ERROR] Path not found: {0}\r\n   Give a .zip archive, a PHP folder or php-cgi.exe." } },
            { "php.imported",       new[] { "   PHP развёрнут внутри LisunOS: {0}",  "   PHP deployed inside LisunOS: {0}" } },
            { "php.zipNoBinary",    new[] { "   В архиве нет php-cgi.exe или php.exe.",
                                            "   The archive has no php-cgi.exe or php.exe." } },
            { "php.folderNoBinary", new[] { "   В папке {0} нет php-cgi.exe или php.exe.",
                                            "   Folder {0} has no php-cgi.exe or php.exe." } },
            { "php.downloadTitle",  new[] { "php-frm — загрузка PHP",               "php-frm — download PHP" } },
            { "php.downloadAsk",    new[] { "Своего PHP в LisunOS пока нет.\r\n\r\nСкачать сборку PHP для Windows (около 30 МБ) и развернуть её внутри LisunOS?\r\n\r\n{0}\r\n\r\nПосле этого PHP будет свой: он не зависит от того, что установлено в системе.",
                                            "LisunOS has no bundled PHP yet.\r\n\r\nDownload a PHP build for Windows (about 30 MB) and deploy it inside LisunOS?\r\n\r\n{0}\r\n\r\nAfter that PHP is ours: it no longer depends on what the system has." } },
            { "php.downloadSkipped",new[] { "   Загрузка отменена — ищем PHP в системе.",
                                            "   Download cancelled — looking for a system PHP." } },
            { "php.downloaded",     new[] { "   Архив PHP загружен ({0}).",          "   PHP archive downloaded ({0})." } },
            { "php.downloadFailed", new[] { "   Загрузка не удалась: {0}",           "   Download failed: {0}" } },
            { "php.statusTitle",    new[] { " Модуль php-frm:",                     " php-frm module:" } },
            { "php.fieldState",     new[] { "состояние",                            "state" } },
            { "php.fieldBinary",    new[] { "интерпретатор",                        "interpreter" } },
            { "php.fieldConfig",    new[] { "конфигурация",                         "configuration" } },
            { "php.fieldApi",       new[] { "api",                                  "api" } },
            { "php.on",             new[] { "подключён",                            "connected" } },
            { "php.off",            new[] { "выключен",                             "disabled" } },
            { "php.catalogLine",    new[] { "Подключение PHP к серверу: исполнение .php и api.php",
                                            "Connects PHP to the server: .php execution and api.php" } },
            { "api.blockRemoved",   new[] { "Удалён защищённый блок NOREMOVE ({0} из {1}). Эти строки менять нельзя — верните их и сохраните снова.",
                                            "A protected NOREMOVE block was removed ({0} of {1}). Those lines cannot be changed — restore them and save again." } },
            { "api.editHint",       new[] { "В файле {0} защищённых блоков CANTEDIT — их текст изменять нельзя, остальное свободно.",
                                            "This file has {0} protected CANTEDIT blocks — their text cannot be changed, the rest is free." } },
            { "api.bothHint",       new[] { "Защищено: блоков NOREMOVE — {0}, блоков CANTEDIT — {1}.",
                                            "Protected: {0} NOREMOVE blocks, {1} CANTEDIT blocks." } },
            { "api.editChanged",    new[] { "Изменён защищённый блок CANTEDIT ({0} из {1}). Этот текст менять нельзя — верните его как было.",
                                            "A protected CANTEDIT block was changed ({0} of {1}). That text must stay as it was." } },
            { "api.protectedHint",  new[] { "В файле есть защищённые блоки NOREMOVE — их строки изменять нельзя.",
                                            "This file has protected NOREMOVE blocks — those lines cannot be changed." } },
            { "api.restoreAsk",     new[] { "Защищённые строки удалены. Вернуть их автоматически и сохранить?",
                                            "Protected lines were removed. Restore them automatically and save?" } },
            { "api.fileProtected",  new[] { "Файл {0} защищён блоками NOREMOVE и не может быть удалён.",
                                            "The file {0} is protected by NOREMOVE blocks and cannot be deleted." } },
            { "srv.apiKey",         new[] { "Ключ API",                             "API key" } },
            { "srv.apiTitle",       new[] { "Секретный ключ Server API",            "Server API secret key" } },
            { "srv.apiHint",        new[] { "Ключ нужен в запросах к api.php:\r\napi.php?key=<ключ>&action=<действие>&name=<файл>\r\n\r\nВ PHP: ServerAPI($key, \"create_file\", \"hello.txt\", \"текст\")",
                                            "The key is required in api.php requests:\r\napi.php?key=<key>&action=<action>&name=<file>\r\n\r\nIn PHP: ServerAPI($key, \"create_file\", \"hello.txt\", \"text\")" } },
            { "srv.apiCopy",        new[] { "Копировать",                           "Copy" } },
            { "srv.apiRegenerate",  new[] { "Новый ключ",                           "New key" } },
            { "srv.apiCopied",      new[] { "Ключ скопирован в буфер обмена.",       "Key copied to the clipboard." } },
            { "srv.apiRegenerated", new[] { "Ключ обновлён — старый больше не работает.",
                                            "Key regenerated — the old one no longer works." } },
            { "srv.apiNoPhp",       new[] { "PHP выключен, поэтому api.php не создан. Включите блок location ~ \\.php$ в .htaccess.",
                                            "PHP is off, so api.php was not created. Enable the location ~ \\.php$ block in .htaccess." } },
            { "srv.apiCreated",     new[] { "PHP включён — созданы api.php и serverapi.php",
                                            "PHP enabled — api.php and serverapi.php were created" } },
            { "fm.title",           new[] { "Управление файлами",                 "File management" } },
            { "fm.up",              new[] { "Каталог выше (Backspace)",           "Parent folder (Backspace)" } },
            { "fm.refresh",         new[] { "Обновить (F5)",                      "Refresh (F5)" } },
            { "fm.newFile",         new[] { "Новый файл",                         "New file" } },
            { "fm.newFolder",       new[] { "Новая папка",                        "New folder" } },
            { "fm.rename",          new[] { "Переименовать (F2)",                 "Rename (F2)" } },
            { "fm.delete",          new[] { "Удалить",                            "Delete" } },
            { "fm.edit",            new[] { "Изменить",                           "Edit" } },
            { "fm.openItem",        new[] { "Открыть",                            "Open" } },
            { "fm.save",            new[] { "Сохранить",                          "Save" } },
            { "fm.namePrompt",      new[] { "Имя:",                               "Name:" } },
            { "fm.status",          new[] { "папок: {0}   файлов: {1}",            "folders: {0}   files: {1}" } },
            { "fm.outside",         new[] { "Путь за пределами папки сайта.",      "Path is outside the site folder." } },
            { "fm.createFailed",    new[] { "Не удалось создать объект.",          "Could not create the item." } },
            { "fm.deleteFailed",    new[] { "Не удалось удалить объект.",          "Could not delete the item." } },
            { "fm.saveFailed",      new[] { "Не удалось сохранить файл.",          "Could not save the file." } },
            { "fm.confirmFolder",   new[] { "Удалить папку \"{0}\" со всем содержимым?",
                                            "Delete the folder \"{0}\" and everything in it?" } },
            { "fm.editing",         new[] { "Правка: {0}",                         "Editing: {0}" } },
            { "fm.tooBig",          new[] { "Файл слишком большой для правки ({0}).",
                                            "The file is too large to edit ({0})." } },
            { "srv.manageFiles",    new[] { "Управлять файлами",                   "Manage files" } },
            { "srv.filesTitle",     new[] { "Файлы сайта — {0}",                   "Site files — {0}" } },
            { "srv.filesOpened",    new[] { "Открыто управление файлами: {0}",      "File management opened: {0}" } },
            { "pad.title",          new[] { "Блокнот LisunOS",                    "LisunOS Notepad" } },
            { "pad.newFile",        new[] { "новый файл",                         "new file" } },
            { "pad.status",         new[] { "строк: {0}   символов: {1}",          "lines: {0}   characters: {1}" } },
            { "pad.openTitle",      new[] { "Открыть файл",                       "Open file" } },
            { "pad.openPrompt",     new[] { "Путь внутри LisunOS:",               "Path inside LisunOS:" } },
            { "pad.saveTitle",      new[] { "Сохранить файл",                     "Save file" } },
            { "pad.savePrompt",     new[] { "Куда сохранить:",                     "Save to:" } },
            { "pad.notFound",       new[] { "Файл не найден: {0}",                "File not found: {0}" } },
            { "pad.outsideRoot",    new[] { "Путь за пределами корня LisunOS.",    "Path is outside the LisunOS root." } },
            { "pad.saveFailed",     new[] { "Не удалось сохранить файл.",          "Could not save the file." } },
            { "pad.discard",        new[] { "Изменения не сохранены. Продолжить?", "Unsaved changes. Continue?" } },

            { "tpl.title",          new[] { "Шаблон приложения",                  "Application template" } },
            { "tpl.ready",          new[] { "Шаблон запущен. Правьте template.service и Form1.designer.cs.",
                                            "Template started. Edit template.service and Form1.designer.cs." } },
            { "tpl.status",         new[] { "счётчик: {0}   приложений в системе: {1}",
                                            "counter: {0}   applications running: {1}" } },
            { "tpl.hello",          new[] { "Здравствуйте, {0}!",                   "Hello, {0}!" } },
            { "tpl.counted",        new[] { "Счётчик увеличен до {0} и сохранён в реестре.",
                                            "Counter raised to {0} and stored in the registry." } },
            { "tpl.cleared",        new[] { "Журнал очищен.",                       "Log cleared." } },
            { "tpl.saved",          new[] { "Имя сохранено в реестре LisunOS.",      "Name stored in the LisunOS registry." } },
            { "tpl.forgotten",      new[] { "Имя удалено из реестра.",              "Name removed from the registry." } },
            { "mon.title",          new[] { "Монитор системы",                    "System Monitor" } },
            { "mon.uptime",         new[] { "время работы",                       "uptime" } },
            { "mon.memory",         new[] { "память",                             "memory" } },
            { "mon.apps",           new[] { "процессов",                          "processes" } },
            { "mon.services",       new[] { "служб",                              "services" } },
            { "mon.commands",       new[] { "команд",                             "commands" } },
            { "mon.pick",           new[] { "выберите процесс в списке",           "select a process in the list" } },
            { "mon.selected",       new[] { "выбран: {0}",                        "selected: {0}" } },

            { "perm.dialogTitle",   new[] { "LisunOS — запрос разрешений",        "LisunOS — permission request" } },
            { "perm.askInstall",    new[] { "Приложению «{0}» требуются разрешения:",
                                            "The application \"{0}\" requests permissions:" } },
            { "perm.askSingle",     new[] { "Приложение «{0}» запрашивает доступ:",
                                            "The application \"{0}\" requests access:" } },
            { "perm.note",          new[] { "Снимите флажок, чтобы не выдавать это право.",
                                            "Clear a checkbox to withhold that permission." } },
            { "perm.allow",         new[] { "Разрешить",                               "Allow" } },
            { "perm.deny",          new[] { "Отклонить",                               "Deny" } },
            { "perm.unknown",       new[] { "неизвестное разрешение",                  "unknown permission" } },
            { "perm.denied",        new[] { " [ОТКАЗ] Приложению «{0}» не выдано право '{1}'.",
                                            " [DENIED] The application \"{0}\" lacks the '{1}' permission." } },
            { "perm.usage",         new[] { " perm list | app <имя> | grant <имя> <право> | revoke <имя> <право> | reset <имя> | all",
                                            " perm list | app <name> | grant <name> <right> | revoke <name> <right> | reset <name> | all" } },
            { "perm.listEmpty",     new[] { " Ни одному приложению ещё не выданы права.",
                                            " No application has been granted rights yet." } },
            { "perm.listTitle",     new[] { " Выданные разрешения:",                   " Granted permissions:" } },
            { "perm.allTitle",      new[] { " Все разрешения LisunOS:",                " All LisunOS permissions:" } },
            { "perm.appTitle",      new[] { " Разрешения приложения «{0}»:",           " Permissions of \"{0}\":" } },
            { "perm.appNone",       new[] { " Приложению «{0}» не выдано ни одного права.",
                                            " No rights granted to \"{0}\"." } },
            { "perm.granted",       new[] { " [OK] «{0}»: выдано право '{1}'.",        " [OK] \"{0}\": granted '{1}'." } },
            { "perm.revoked",       new[] { " [OK] «{0}»: отозвано право '{1}'.",      " [OK] \"{0}\": revoked '{1}'." } },
            { "perm.resetDone",     new[] { " [OK] Все права приложения «{0}» сброшены.",
                                            " [OK] All rights of \"{0}\" were reset." } },
            { "perm.badName",       new[] { " [ERROR] Неизвестное право '{0}'. Список: perm all",
                                            " [ERROR] Unknown permission '{0}'. See: perm all" } },
            { "perm.needSudo",      new[] { " [ERROR] Управление правами требует sudo или режима root.",
                                            " [ERROR] Managing permissions requires sudo or root mode." } },
            { "php.progress",        new[] { "   Загрузка PHP: {0}%  ({1})",
                                            "   Downloading PHP: {0}%  ({1})" } },
            { "php.progressUnknown",  new[] { "   Загрузка PHP: получено {0}",
                                            "   Downloading PHP: received {0}" } },
            { "php.stageStart",      new[] { "подготовка загрузки",
                                            "preparing the download" } },
            { "php.stageMirror",     new[] { "зеркало {0} из {1}",
                                            "mirror {0} of {1}" } },
            { "php.stageUnpack",     new[] { "распаковка архива",
                                            "unpacking the archive" } },
            { "php.stageDone",       new[] { "PHP готов",
                                            "PHP is ready" } },
            { "php.stageFailed",     new[] { "загрузка не удалась",
                                            "the download failed" } },
            { "php.tryMirror",       new[] { "Зеркало {0}/{1}: {2}",
                                            "Mirror {0}/{1}: {2}" } },
            { "php.tooSmall",        new[] { "Файл слишком мал ({0}) — это не сборка PHP.",
                                            "The file is too small ({0}) — not a PHP build." } },
            { "php.notArchive",      new[] { "Вместо архива пришло что-то другое.",
                                            "Something other than an archive arrived." } },
            { "php.mirrorFailed",    new[] { "Зеркало недоступно: {0}",
                                            "Mirror unavailable: {0}" } },
            { "php.allMirrorsFailed",  new[] { "Ни одно зеркало не ответило. Работает встроенный движок.",
                                            "No mirror responded. The built-in engine stays in charge." } },
            { "php.autoStart",       new[] { "Автозагрузка PHP началась.",
                                            "Automatic PHP download started." } },
            { "php.autoFailed",      new[] { "Автозагрузка не удалась — остаётся встроенный движок.",
                                            "Automatic download failed — the built-in engine stays in charge." } },
            { "php.autoQueued",      new[] { "   PHP докачивается в фоне и подключится сам.",
                                            "   PHP is downloading in the background and will attach itself." } },
            { "php.autoWatch",       new[] { "   Прямой эфир установки: {0}",
                                            "   Live setup feed: {0}" } },
            { "php.attached",        new[] { "PHP подключён: {0}",
                                            "PHP attached: {0}" } },
            { "php.ownMissing",      new[] { " [ERROR] Своего PHP в LisunOS нет.",
                                            " [ERROR] LisunOS has no own PHP." } },
            { "php.ownRemoved",      new[] { " [OK] Свой PHP удалён, работает встроенный движок.",
                                            " [OK] Own PHP removed, the built-in engine is in charge." } },
            { "php.usage",           new[] { " php-frm status | download | update | remove | use builtin|own|system | auto on|off | mirrors",
                                            " php-frm status | download | update | remove | use builtin|own|system | auto on|off | mirrors" } },
            { "php.mirrorsTitle",    new[] { " Зеркала загрузки PHP:",
                                            " PHP download mirrors:" } },
            { "php.autoOn",          new[] { " [OK] Автозагрузка PHP включена.",
                                            " [OK] Automatic PHP download is on." } },
            { "php.autoOff",         new[] { " [OK] Автозагрузка PHP выключена.",
                                            " [OK] Automatic PHP download is off." } },
            { "php.busy",            new[] { " [INFO] Загрузка уже идёт: {0}",
                                            " [INFO] A download is already running: {0}" } },
            { "php.useBuiltIn",      new[] { " [OK] Выбран встроенный движок LisunOS.",
                                            " [OK] Switched to the built-in LisunOS engine." } },
            { "php.useFailed",       new[] { " [ERROR] Такого источника PHP нет: {0}",
                                            " [ERROR] No such PHP source: {0}" } },
            { "php.fieldAuto",       new[] { "автозагрузка",
                                            "auto download" } },
            { "php.fieldProgress",   new[] { "ход загрузки",
                                            "download progress" } },
            { "sys.usage",           new[] { " system start | stop | status | open",
                                            " system start | stop | status | open" } },
            { "sys.already",         new[] { " [INFO] Системный порт {0} уже открыт.",
                                            " [INFO] System port {0} is already open." } },
            { "sys.needHall",        new[] { " [ERROR] Нужен доступ зала: выдайте право 'hall' приложению «{0}».",
                                            " [ERROR] Hall access required: grant the 'hall' right to \"{0}\"." } },
            { "sys.started",         new[] { "Системный порт {0} открыт.",
                                            "System port {0} is open." } },
            { "sys.startedFull",     new[] { " [OK] Системный порт {0} открыт.\r\n   Прямой эфир установки: {1}",
                                            " [OK] System port {0} is open.\r\n   Live setup feed: {1}" } },
            { "sys.portBusy",        new[] { " [ERROR] Порт {0} занят: {1}",
                                            " [ERROR] Port {0} is busy: {1}" } },
            { "sys.stopped",         new[] { "Системный порт {0} закрыт.",
                                            "System port {0} is closed." } },
            { "sys.notRunning",      new[] { " [INFO] Системный порт закрыт.",
                                            " [INFO] The system port is closed." } },
            { "sys.statusTitle",     new[] { " Системный порт LisunOS:",
                                            " LisunOS system port:" } },
            { "sys.fieldState",      new[] { "состояние",
                                            "state" } },
            { "sys.fieldPort",       new[] { "порт",
                                            "port" } },
            { "sys.fieldHall",       new[] { "право hall",
                                            "hall right" } },
            { "sys.fieldApp",        new[] { "приложение зала",
                                            "hall application" } },
            { "sys.fieldRequests",   new[] { "запросов",
                                            "requests" } },
            { "sys.fieldUptime",     new[] { "в работе",
                                            "uptime" } },
            { "sys.fieldPage",       new[] { "страница",
                                            "page" } },
            { "sys.open",            new[] { "открыт",
                                            "open" } },
            { "sys.closed",          new[] { "закрыт",
                                            "closed" } },
            { "sys.granted",         new[] { "выдано",
                                            "granted" } },
            { "sys.denied",          new[] { "не выдано",
                                            "not granted" } },
            { "sys.opened",          new[] { " [OK] Страница открыта: {0}",
                                            " [OK] Page opened: {0}" } },
            { "wifi.title",          new[] { "Wi-Fi",
                                            "Wi-Fi" } },
            { "wifi.usage",          new[] { " wifi list | connect <сеть> [пароль] | disconnect | forget <сеть> | status | portal | form",
                                            " wifi list | connect <network> [password] | disconnect | forget <network> | status | portal | form" } },
            { "wifi.openShort",      new[] { "без пароля",
                                            "open" } },
            { "wifi.savedMark",      new[] { "сохранена",
                                            "saved" } },
            { "wifi.noAdapter",      new[] { " [ERROR] Адаптер Wi-Fi не найден.",
                                            " [ERROR] No Wi-Fi adapter found." } },
            { "wifi.nothingFound",   new[] { " [INFO] Сетей вокруг не найдено.",
                                            " [INFO] No networks around." } },
            { "wifi.listTitle",      new[] { " Сети вокруг ({0}):",
                                            " Networks around ({0}):" } },
            { "wifi.noSsid",         new[] { " [ERROR] Укажите имя сети.",
                                            " [ERROR] Give the network name." } },
            { "wifi.needNetwork",    new[] { " [ERROR] Нужно право 'network'.",
                                            " [ERROR] The 'network' right is required." } },
            { "wifi.needPassword",   new[] { " [ERROR] Сеть «{0}» защищена — нужен пароль.",
                                            " [ERROR] Network \"{0}\" is protected — a password is required." } },
            { "wifi.connecting",     new[] { "Подключение к «{0}»…",
                                            "Connecting to \"{0}\"…" } },
            { "wifi.connected",      new[] { "Подключено: «{0}».",
                                            "Connected: \"{0}\"." } },
            { "wifi.connectFailed",  new[] { " [ERROR] Не удалось подключиться к «{0}»: {1}",
                                            " [ERROR] Could not connect to \"{0}\": {1}" } },
            { "wifi.onlineNow",      new[] { " [OK] «{0}» подключена, интернет есть.",
                                            " [OK] \"{0}\" connected, the internet is up." } },
            { "wifi.noInternet",     new[] { " [WARN] «{0}» подключена, но интернета нет.",
                                            " [WARN] \"{0}\" connected, but there is no internet." } },
            { "wifi.portalFound",    new[] { " [INFO] «{0}» требует входа. Открываю страницу: {1}",
                                            " [INFO] \"{0}\" requires sign-in. Opening the page: {1}" } },
            { "wifi.disconnected",   new[] { " [OK] Отключено от сети Wi-Fi.",
                                            " [OK] Disconnected from Wi-Fi." } },
            { "wifi.forgotten",      new[] { " [OK] Профиль сети «{0}» удалён.",
                                            " [OK] Profile of \"{0}\" removed." } },
            { "wifi.profileFailed",  new[] { " [ERROR] Профиль сети не создан: {0}",
                                            " [ERROR] The profile was not created: {0}" } },
            { "wifi.openingPortal",  new[] { "Открываю страницу входа: {0}",
                                            "Opening the sign-in page: {0}" } },
            { "wifi.wentOnline",     new[] { "Интернет появился.",
                                            "The internet is up." } },
            { "wifi.wentOffline",    new[] { "Интернет пропал.",
                                            "The internet is down." } },
            { "wifi.statusTitle",    new[] { " Сеть LisunOS:",
                                            " LisunOS network:" } },
            { "wifi.fieldAdapter",   new[] { "адаптер",
                                            "adapter" } },
            { "wifi.fieldNetwork",   new[] { "сеть",
                                            "network" } },
            { "wifi.fieldInternet",  new[] { "интернет",
                                            "internet" } },
            { "wifi.fieldPortal",    new[] { "страница входа",
                                            "sign-in page" } },
            { "wifi.present",        new[] { "есть",
                                            "present" } },
            { "wifi.absent",         new[] { "нет",
                                            "absent" } },
            { "wifi.stateOnline",    new[] { "есть",
                                            "up" } },
            { "wifi.statePortal",    new[] { "нужен вход",
                                            "sign-in required" } },
            { "wifi.stateOffline",   new[] { "нет",
                                            "down" } },
            { "wifi.scanning",       new[] { "поиск сетей…",
                                            "scanning for networks…" } },
            { "wifi.scan",           new[] { "Найти сети",
                                            "Scan" } },
            { "wifi.connect",        new[] { "Подключиться",
                                            "Connect" } },
            { "wifi.disconnect",     new[] { "Отключиться",
                                            "Disconnect" } },
            { "wifi.forget",         new[] { "Забыть",
                                            "Forget" } },
            { "wifi.openPortalButton",  new[] { "Страница входа",
                                            "Sign-in page" } },
            { "wifi.openSetup",      new[] { "Прямой эфир php-frm",
                                            "php-frm live feed" } },
            { "wifi.password",       new[] { "Пароль сети",
                                            "Network password" } },
            { "wifi.passwordFor",    new[] { "Пароль сети «{0}»",
                                            "Password for \"{0}\"" } },
            { "wifi.passwordNotNeeded",  new[] { "Пароль не нужен — сеть открытая",
                                            "No password needed — the network is open" } },
            { "wifi.passwordEnterprise",  new[] { "Сеть предприятия — вход откроется в браузере",
                                            "Enterprise network — sign-in opens in the browser" } },
            { "wifi.showPassword",   new[] { "показать",
                                            "show" } },
            { "wifi.columnName",     new[] { "Сеть",
                                            "Network" } },
            { "wifi.columnSignal",   new[] { "Сигнал",
                                            "Signal" } },
            { "wifi.columnSecurity",  new[] { "Защита",
                                            "Security" } },
            { "wifi.columnSaved",    new[] { "Профиль",
                                            "Profile" } },
            { "wifi.headerConnected",  new[] { "подключена «{0}» · сетей вокруг: {1}",
                                            "connected to \"{0}\" · networks around: {1}" } },
            { "wifi.headerFree",     new[] { "не подключена · сетей вокруг: {0}",
                                            "not connected · networks around: {0}" } },
            { "wifi.selectFirst",    new[] { "Выберите сеть в списке.",
                                            "Select a network from the list." } },
            { "wifi.setupOpened",    new[] { "Прямой эфир открыт: {0}",
                                            "Live feed opened: {0}" } },
            { "boot.network",       new[] { "  Сеть: слежение за интернетом включено.",
                                            "  Network: internet watcher is on." } },
            { "boot.hallHint",      new[] { "системный порт 8989 закрыт: нужно право 'hall' (команда: system start)",
                                            "system port 8989 is closed: the 'hall' right is required (command: system start)" } },
            { "lang.listTitle",     new[] { " Языки интерфейса:",                   " Interface languages:" } },
            { "lang.builtIn",       new[] { "встроенный",                          "built in" } },
            { "lang.translated",    new[] { "пакет, переведено {0}%",              "pack, {0}% translated" } },
            { "lang.folder",        new[] { "Пакеты языков: {0}",                  "Language packs: {0}" } },
            { "lang.usage",         new[] { " lang | lang list | lang <код> | lang export <код> | lang reload",
                                            " lang | lang list | lang <code> | lang export <code> | lang reload" } },
            { "lang.unknown",       new[] { " [ERROR] Языка '{0}' нет. Список: lang list",
                                            " [ERROR] No language '{0}'. See: lang list" } },
            { "lang.exported",      new[] { " [OK] Шаблон перевода создан: {0}\r\n   Переведите значения, затем: lang reload и lang {1}",
                                            " [OK] Translation template created: {0}\r\n   Translate the values, then: lang reload and lang {1}" } },
            { "lang.exportFailed",  new[] { " [ERROR] Не удалось создать шаблон перевода.",
                                            " [ERROR] Could not create the translation template." } },
            { "lang.reloaded",      new[] { " [OK] Перечитано языковых пакетов: {0}",
                                            " [OK] Language packs reloaded: {0}" } },
            { "tool.outsideRoot",    new[] { " [ERROR] Доступ за пределы корня запрещён.",
                                            " [ERROR] Access outside the root is denied." } },
            { "tool.noFile",         new[] { " [ERROR] Файл не найден: {0}",
                                            " [ERROR] File not found: {0}" } },
            { "tool.needWrite",      new[] { " [ERROR] Нужно право 'write_files'.",
                                            " [ERROR] The 'write_files' right is required." } },
            { "tool.needNetwork",    new[] { " [ERROR] Нужно право 'network'.",
                                            " [ERROR] The 'network' right is required." } },
            { "tool.tailUsage",      new[] { " tail <файл> [строк]  — последние строки файла",
                                            " tail <file> [lines]  — the last lines of a file" } },
            { "tool.sortUsage",      new[] { " sort <файл> [-r] [-n]  — отсортировать строки",
                                            " sort <file> [-r] [-n]  — sort the lines" } },
            { "tool.uniqUsage",      new[] { " uniq <файл> [-c]  — убрать повторы, -c считает их",
                                            " uniq <file> [-c]  — drop repeats, -c counts them" } },
            { "tool.diffUsage",      new[] { " diff <файл1> <файл2>  — построчное сравнение",
                                            " diff <file1> <file2>  — compare line by line" } },
            { "tool.diffSame",       new[] { " [OK] Файлы совпадают.",
                                            " [OK] The files are identical." } },
            { "tool.diffCount",      new[] { " Различий: {0}",
                                            " Differences: {0}" } },
            { "tool.diffMore",       new[] { "… остальные различия не показаны",
                                            "… further differences are not shown" } },
            { "tool.hashUsage",      new[] { " hash <файл> [md5|sha1|sha256|sha512]  — контрольная сумма",
                                            " hash <file> [md5|sha1|sha256|sha512]  — checksum" } },
            { "tool.hashUnknown",    new[] { " [ERROR] Неизвестный алгоритм: {0}",
                                            " [ERROR] Unknown algorithm: {0}" } },
            { "tool.base64Usage",    new[] { " base64 encode|decode <текст или файл>",
                                            " base64 encode|decode <text or file>" } },
            { "tool.zipUsage",       new[] { " zip <архив.zip> <файл или папка>",
                                            " zip <archive.zip> <file or folder>" } },
            { "tool.zipDone",        new[] { " [OK] Архив собран: {0}  ({1})",
                                            " [OK] Archive created: {0}  ({1})" } },
            { "tool.unzipUsage",     new[] { " unzip <архив.zip> [папка]",
                                            " unzip <archive.zip> [folder]" } },
            { "tool.unzipDone",      new[] { " [OK] Распаковано файлов: {0}  →  {1}",
                                            " [OK] Files extracted: {0}  →  {1}" } },
            { "tool.dfTitle",        new[] { " Место на диске:",
                                            " Disk space:" } },
            { "tool.dfDrive",        new[] { "диск",
                                            "drive" } },
            { "tool.dfUsed",         new[] { "занято",
                                            "used" } },
            { "tool.dfFree",         new[] { "свободно",
                                            "free" } },
            { "tool.dfTotal",        new[] { "всего",
                                            "total" } },
            { "tool.dfSystem",       new[] { "под LisunOS",
                                            "used by LisunOS" } },
            { "tool.freeTitle",      new[] { " Память:",
                                            " Memory:" } },
            { "tool.freeWorking",    new[] { "рабочий набор",
                                            "working set" } },
            { "tool.freePrivate",    new[] { "закрытая память",
                                            "private memory" } },
            { "tool.freeManaged",    new[] { "управляемая куча",
                                            "managed heap" } },
            { "tool.freeThreads",    new[] { "потоков",
                                            "threads" } },
            { "tool.freeHandles",    new[] { "дескрипторов",
                                            "handles" } },
            { "tool.envTitle",       new[] { " Переменные системы:",
                                            " System variables:" } },
            { "tool.whichUsage",     new[] { " which <команда>  — откуда берётся команда",
                                            " which <command>  — where a command comes from" } },
            { "tool.whichBuiltIn",   new[] { " '{0}' — встроенная команда ядра.",
                                            " '{0}' is a built-in kernel command." } },
            { "tool.whichApp",       new[] { " '{0}' — команда приложения: {1}",
                                            " '{0}' is an application command: {1}" } },
            { "tool.whichAlias",     new[] { " '{0}' — псевдоним для: {1}",
                                            " '{0}' is an alias for: {1}" } },
            { "tool.whichNone",      new[] { " [ERROR] Команда '{0}' не найдена.",
                                            " [ERROR] Command '{0}' not found." } },
            { "tool.curlUsage",      new[] { " curl <адрес> [файл]  — скачать страницу или файл",
                                            " curl <url> [file]  — download a page or a file" } },
            { "tool.curlHead",       new[] { " {0}  {1}  {2}",
                                            " {0}  {1}  {2}" } },
            { "tool.curlSaved",      new[] { " [OK] Сохранено: {0}  ({1})  код {2}",
                                            " [OK] Saved: {0}  ({1})  status {2}" } },
            { "tool.curlTrimmed",    new[] { "… ответ обрезан, сохраните в файл: curl <адрес> <файл>",
                                            "… response trimmed, save it to a file: curl <url> <file>" } },
            { "tool.curlFailed",     new[] { " [ERROR] Запрос не удался: {0}",
                                            " [ERROR] The request failed: {0}" } },
            { "calcapp.title",      new[] { "Калькулятор",                        "Calculator" } },
            { "calcapp.ready",      new[] { "Введите выражение или нажимайте клавиши.",
                                            "Type an expression or use the keys." } },
            { "calcapp.error",      new[] { "ошибка",                             "error" } },
            { "calcapp.badExpression", new[] { "Выражение не разобрано.",         "The expression could not be parsed." } },
            { "calcapp.memoryCleared", new[] { "Память очищена.",                 "Memory cleared." } },
            { "calcapp.memoryAdded", new[] { "В памяти: {0}",                     "In memory: {0}" } },
            { "settings.title",     new[] { "Параметры системы",                  "System settings" } },
            { "settings.subtitle",  new[] { "Язык, раскладка, разрешения приложений, сервер и PHP",
                                            "Language, layout, application permissions, server and PHP" } },
            { "settings.ready",     new[] { "Двойной щелчок по праву переключает его.",
                                            "Double-click a right to toggle it." } },
            { "settings.columnRight", new[] { "Право",                            "Right" } },
            { "settings.columnState", new[] { "Состояние",                        "State" } },
            { "settings.columnWhat",  new[] { "Что открывает",                    "What it opens" } },
            { "settings.pickRight", new[] { "Выберите приложение и право.",       "Pick an application and a right." } },
            { "settings.resetAsk",  new[] { "Сбросить все права приложения «{0}»?",
                                            "Reset every right of \"{0}\"?" } },
            { "settings.refreshed", new[] { "Сведения обновлены.",                "Information refreshed." } },
            { "settings.phpLine",   new[] { "PHP: {0}   —   {1}",                 "PHP: {0}   —   {1}" } },
            { "settings.portLine",  new[] { "Системный порт {0}: {1},   право hall: {2}",
                                            "System port {0}: {1},   hall right: {2}" } },
            { "settings.netLine",   new[] { "Интернет: {0},   сеть: {1}",         "Internet: {0},   network: {1}" } },
            { "suapp.windowTitle",  new[] { "SuperUser — выдача прав", "SuperUser — granting rights" } },
            { "suapp.warning",      new[] { "Право superuser открывает пакету всю систему: файлы, реестр, сеть и другие пакеты. Выдавайте его только тем, кому доверяете.",
                                            "The superuser right opens the whole system to a package: files, registry, network and other packages. Grant it only to what you trust." } },
            { "suapp.ready",        new[] { "Выберите пакет в списке.", "Pick a package in the list." } },
            { "suapp.columnPackage", new[] { "Пакет", "Package" } },
            { "suapp.columnType",   new[] { "Тип", "Type" } },
            { "suapp.columnSuper",  new[] { "superuser", "superuser" } },
            { "suapp.columnRights", new[] { "Прав", "Rights" } },
            { "suapp.typeSystem",   new[] { "система", "system" } },
            { "suapp.yes",          new[] { "есть", "yes" } },
            { "suapp.no",           new[] { "нет", "no" } },
            { "suapp.grant",        new[] { "Выдать superuser", "Grant superuser" } },
            { "suapp.revoke",       new[] { "Отозвать", "Revoke" } },
            { "suapp.enableMode",   new[] { "Включить режим", "Enable mode" } },
            { "suapp.disableMode",  new[] { "Выключить", "Disable" } },
            { "suapp.understand",   new[] { "Я понимаю, что пакет получит полный доступ", "I understand the package gets full access" } },
            { "suapp.nothing",      new[] { "Пакет не выбран", "No package selected" } },
            { "suapp.explainEmpty", new[] { "Выберите пакет слева, чтобы увидеть его права.",
                                            "Pick a package on the left to see its rights." } },
            { "suapp.explain",      new[] { "Выдача записывается в реестр прав и действует после перезапуска пакета.",
                                            "The grant is written to the rights registry and applies after the package restarts." } },
            { "suapp.hasSuper",     new[] { "У пакета уже есть право superuser.", "This package already has the superuser right." } },
            { "suapp.noSuper",      new[] { "У пакета нет права superuser.", "This package has no superuser right." } },
            { "suapp.rightsLabel",  new[] { "Выданные права:", "Granted rights:" } },
            { "suapp.noRights",     new[] { "(ни одного)", "(none)" } },
            { "suapp.pickFirst",    new[] { "Сначала выберите пакет.", "Pick a package first." } },
            { "suapp.confirmFirst", new[] { "Отметьте флажок подтверждения.", "Tick the confirmation box." } },
            { "suapp.askTitle",     new[] { "Выдать право superuser?", "Grant the superuser right?" } },
            { "suapp.askBody",      new[] { "Пакет «{0}» получит полный доступ к системе: файлы, реестр, сеть, другие пакеты.\r\n\r\nВыдать право superuser?",
                                            "The package \u00ab{0}\u00bb will get full access to the system: files, registry, network, other packages.\r\n\r\nGrant the superuser right?" } },
            { "suapp.cancelled",    new[] { "Выдача отменена.", "Granting cancelled." } },
            { "suapp.granted",      new[] { "Право superuser выдано пакету «{0}».", "The superuser right was granted to \u00ab{0}\u00bb." } },
            { "suapp.revoked",      new[] { "Право superuser отозвано у пакета «{0}».", "The superuser right was revoked from \u00ab{0}\u00bb." } },
            { "suapp.alreadySuper", new[] { "У пакета «{0}» право уже есть.", "\u00ab{0}\u00bb already has the right." } },
            { "suapp.notSuper",     new[] { "У пакета «{0}» этого права нет.", "\u00ab{0}\u00bb does not have that right." } },
            { "suapp.modeOn",       new[] { "Режим суперпользователя: включён", "Superuser mode: on" } },
            { "suapp.modeOff",      new[] { "Режим суперпользователя: выключен", "Superuser mode: off" } },
            { "suapp.modeEnabled",  new[] { "Режим включён пакетом «{0}».", "Mode enabled by \u00ab{0}\u00bb." } },
            { "suapp.modeRefused",  new[] { "Пакет «{0}» не имеет права superuser.", "\u00ab{0}\u00bb has no superuser right." } },
            { "suapp.modeDisabled", new[] { "Режим суперпользователя выключен.", "Superuser mode disabled." } },
            { "suapp.usage",        new[] { " superuser — открыть приложение выдачи прав",
                                            " superuser — open the rights granting application" } },
            { "suapp.opened",       new[] { " Приложение SuperUser запущено.", " The SuperUser application is running." } },
            { "suapp.missing",      new[] { " [ERROR] Приложение SuperUser не установлено.\r\n   superuser install      — поставить из встроенного каталога, сеть не нужна\r\n   apt install superuser  — взять свежую сборку с сайта",
                                            " [ERROR] The SuperUser application is not installed.\r\n   superuser install      — install it from the built-in catalog, no network needed\r\n   apt install superuser  — take the fresh build from the site" } },
            { "tree.types",         new[] { "типы пакетов", "package types" } },
            { "tree.user",          new[] { "учётные записи для входа по ssh", "accounts for ssh sign-in" } },
            { "tree.userCreate",    new[] { "создать пользователя", "create a user" } },
            { "tree.userRemove",    new[] { "удалить пользователя", "remove a user" } },
            { "tree.userEdit",      new[] { "сменить пароль", "change the password" } },
            { "tree.userList",      new[] { "список пользователей", "list the users" } },
            { "tree.ssh",           new[] { "сервер ssh: адрес для подключения", "the ssh server: the address to connect to" } },
            { "tree.sshStart",      new[] { "запустить сервер", "start the server" } },
            { "tree.sshStop",       new[] { "остановить сервер", "stop the server" } },
            { "tree.sshStatus",     new[] { "состояние сервера", "the server state" } },
            { "tree.superuser",     new[] { "приложение выдачи права superuser", "the superuser granting application" } },
            { "arg.user",           new[] { "пользователь", "user" } },
            { "apt.alreadyInstalled", new[] { " Пакет «{0}» уже установлен. Обновить: apt update {0}",
                                              " The package \u00ab{0}\u00bb is already installed. Update it: apt update {0}" } },
            { "apt.fromSite",       new[] { " Пакет «{0}» {1} скачивается с сайта каталога…",
                                            " Downloading \u00ab{0}\u00bb {1} from the catalog site\u2026" } },
            { "apt.fromBuiltIn",    new[] { " Каталог с сайта недоступен — ставится встроенная копия «{0}».",
                                            " The catalog site is unreachable \u2014 installing the built-in copy of \u00ab{0}\u00bb." } },
            { "sshapp.windowTitle", new[] { "Доступ по сети", "Network access" } },
            { "sshapp.subtitle",    new[] { "Подключение к оболочке LisunOS с телефона или другого ПК — через PuTTY (Raw или Telnet) либо nc",
                                            "Connect to the LisunOS shell from a phone or another PC \u2014 with PuTTY (Raw or Telnet) or nc" } },
            { "sshapp.addressHint", new[] { "Этот адрес вводят на телефоне или другом компьютере.\r\nПорт указывается отдельным полем клиента.",
                                            "Enter this address on the phone or the other computer.\r\nThe port goes in the client's own field." } },
            { "sshapp.noAddress",   new[] { "сеть недоступна", "no network" } },
            { "sshapp.port",        new[] { "Порт", "Port" } },
            { "sshapp.start",       new[] { "Включить", "Start" } },
            { "sshapp.stop",        new[] { "Выключить", "Stop" } },
            { "sshapp.copy",        new[] { "Копировать", "Copy" } },
            { "sshapp.stateOn",     new[] { "Сервер работает: порт {0}, подключений {1}",
                                            "The server is running: port {0}, {1} connection(s)" } },
            { "sshapp.stateOff",    new[] { "Сервер выключен.", "The server is off." } },
            { "sshapp.stopped",     new[] { "Сервер остановлен.", "The server was stopped." } },
            { "sshapp.ready",       new[] { "Выберите адрес и нажмите «Включить».", "Pick an address and press Start." } },
            { "sshapp.firstUser",   new[] { "Сначала создайте пользователя — без него подключиться не получится.",
                                            "Create a user first \u2014 there is no way to sign in without one." } },
            { "sshapp.pickAddress", new[] { "Выберите адрес в списке.", "Pick an address in the list." } },
            { "sshapp.copied",      new[] { "Скопировано: {0}", "Copied: {0}" } },
            { "sshapp.needClipboard", new[] { "Нужно право clipboard.", "The clipboard right is required." } },
            { "sshapp.usersCaption", new[] { "Пользователи", "Users" } },
            { "sshapp.columnUser",  new[] { "Имя", "Name" } },
            { "sshapp.columnState", new[] { "Состояние", "State" } },
            { "sshapp.columnLogins", new[] { "Входов", "Logins" } },
            { "sshapp.columnLast",  new[] { "Последний", "Last" } },
            { "sshapp.userOn",      new[] { "включён", "enabled" } },
            { "sshapp.userOff",     new[] { "выключен", "disabled" } },
            { "sshapp.user",        new[] { "Имя", "Name" } },
            { "sshapp.password",    new[] { "Пароль", "Password" } },
            { "sshapp.userCreate",  new[] { "Создать", "Create" } },
            { "sshapp.userPassword", new[] { "Сменить пароль", "Change password" } },
            { "sshapp.userRemove",  new[] { "Удалить", "Remove" } },
            { "sshapp.needUsers",   new[] { "Нужно право manage_users.", "The manage_users right is required." } },
            { "sshapp.pickUser",    new[] { "Выберите пользователя.", "Pick a user." } },
            { "sshapp.removeTitle", new[] { "Удалить пользователя?", "Remove the user?" } },
            { "sshapp.removeBody",  new[] { "Пользователь «{0}» больше не сможет подключаться. Удалить?",
                                            "\u00ab{0}\u00bb will no longer be able to connect. Remove?" } },
            { "sshapp.removeCancelled", new[] { "Удаление отменено.", "Removal cancelled." } },
            { "sshapp.logCaption",  new[] { "Журнал подключений", "Connection log" } },
            { "sshapp.logEmpty",    new[] { "   пока пусто", "   nothing yet" } },
            { "logs.windowTitle",   new[] { "Журнал", "Journal" } },
            { "logs.find",          new[] { "Поиск", "Find" } },
            { "logs.source",        new[] { "Источник", "Source" } },
            { "logs.onlyErrors",    new[] { "Только ошибки", "Errors only" } },
            { "logs.follow",        new[] { "Следить", "Follow" } },
            { "logs.refresh",       new[] { "Обновить", "Refresh" } },
            { "logs.save",          new[] { "Сохранить в файл", "Save to a file" } },
            { "logs.copy",          new[] { "Копировать строку", "Copy the line" } },
            { "logs.ready",         new[] { "Фильтр пуст — показаны все записи.", "No filter \u2014 every entry is shown." } },
            { "logs.refreshed",     new[] { "Журнал перечитан.", "The journal was re-read." } },
            { "logs.count",         new[] { "Показано {0} из {1} записей", "Showing {0} of {1} entries" } },
            { "logs.nothingToSave", new[] { "Нечего сохранять.", "Nothing to save." } },
            { "logs.needWrite",     new[] { "Нужно право write_files.", "The write_files right is required." } },
            { "logs.saved",         new[] { "Сохранено: {0} ({1} строк)", "Saved: {0} ({1} lines)" } },
            { "logs.pickLine",      new[] { "Выберите строку.", "Pick a line." } },
            { "logs.needClipboard", new[] { "Нужно право clipboard.", "The clipboard right is required." } },
            { "logs.copied",        new[] { "Строка скопирована.", "The line was copied." } },
            { "explorer.hintBack",  new[] { "Назад (Alt+←)", "Back (Alt+Left)" } },
            { "explorer.hintForward", new[] { "Вперёд (Alt+→)", "Forward (Alt+Right)" } },
            { "explorer.hintUp",    new[] { "На уровень выше (Backspace)", "One level up (Backspace)" } },
            { "explorer.hintHome",  new[] { "В корень системы", "To the system root" } },
            { "explorer.hintRefresh", new[] { "Обновить (F5)", "Refresh (F5)" } },
            { "explorer.hintFilter", new[] { "Фильтр по имени (Ctrl+F)", "Filter by name (Ctrl+F)" } },
            { "explorer.hintAddress", new[] { "Путь: введите и нажмите Enter (Ctrl+L)",
                                              "Path: type it and press Enter (Ctrl+L)" } },
            { "explorer.ctxOpen",   new[] { "Открыть", "Open" } },
            { "explorer.ctxCreateFolder", new[] { "Создать папку", "New folder" } },
            { "explorer.ctxCreateFile", new[] { "Создать файл .txt", "New .txt file" } },
            { "explorer.ctxCopy",   new[] { "Копировать (Ctrl+C)", "Copy (Ctrl+C)" } },
            { "explorer.ctxCut",    new[] { "Вырезать (Ctrl+X)", "Cut (Ctrl+X)" } },
            { "explorer.ctxPaste",  new[] { "Вставить (Ctrl+V)", "Paste (Ctrl+V)" } },
            { "explorer.ctxZip",    new[] { "Упаковать в .zip", "Pack into .zip" } },
            { "explorer.ctxUnzip",  new[] { "Распаковать", "Unpack" } },
            { "explorer.ctxProperties", new[] { "Свойства", "Properties" } },
            { "explorer.ctxDelete", new[] { "Удалить (Delete)", "Delete (Delete)" } },
            { "explorer.statusCounts", new[] { "Папок: {0}   файлов: {1}   объём: {2}",
                                               "Folders: {0}   files: {1}   size: {2}" } },
            { "explorer.statusHidden", new[] { "скрыто фильтром: {0}", "hidden by the filter: {0}" } },
            { "explorer.statusCopied", new[] { "в буфере: {0} (копирование)", "in the buffer: {0} (copy)" } },
            { "explorer.statusCut",    new[] { "в буфере: {0} (перемещение)", "in the buffer: {0} (move)" } },
            { "explorer.statusOne",    new[] { "{0}   —   {1}", "{0}   \u2014   {1}" } },
            { "explorer.statusMany",   new[] { "Выбрано объектов: {0}   объём: {1}",
                                               "Selected: {0}   size: {1}" } },
            { "explorer.noSuchPath",   new[] { "Путь не найден: {0}", "No such path: {0}" } },
            { "explorer.confirmMany",  new[] { "Удалить выбранные объекты ({0})? Это нельзя отменить.",
                                               "Delete the selected items ({0})? This cannot be undone." } },
            { "explorer.deletePartial", new[] { "Удалено {0} из {1} — остальные заняты или защищены.",
                                                "Deleted {0} of {1} \u2014 the rest are busy or protected." } },
            { "explorer.pasteDone",    new[] { "Вставлено объектов: {0}", "Pasted: {0}" } },
            { "explorer.pasteFailed",  new[] { "Не удалось вставить: {0}", "Could not paste: {0}" } },
            { "explorer.zipTitle",     new[] { "Упаковать в архив", "Pack into an archive" } },
            { "explorer.zipLabel",     new[] { "Имя архива:", "Archive name:" } },
            { "explorer.zipDone",      new[] { "Создан архив {0} ({1})", "Created the archive {0} ({1})" } },
            { "explorer.zipFailed",    new[] { "Не удалось упаковать: {0}", "Packing failed: {0}" } },
            { "explorer.unzipDone",    new[] { "Распаковано в {0}: файлов {1}", "Unpacked into {0}: {1} file(s)" } },
            { "explorer.unzipFailed",  new[] { "Не удалось распаковать: {0}", "Unpacking failed: {0}" } },
            { "explorer.propTitle",    new[] { "Свойства", "Properties" } },
            { "explorer.propName",     new[] { "Имя: {0}", "Name: {0}" } },
            { "explorer.propPath",     new[] { "Путь: {0}", "Path: {0}" } },
            { "explorer.propKindFolder", new[] { "Тип: папка", "Kind: folder" } },
            { "explorer.propKindFile", new[] { "Тип: файл {0}", "Kind: {0} file" } },
            { "explorer.propContent",  new[] { "Внутри: папок {0}, файлов {1}", "Inside: {0} folder(s), {1} file(s)" } },
            { "explorer.propSize",     new[] { "Размер: {0}", "Size: {0}" } },
            { "explorer.propChanged",  new[] { "Изменён: {0:dd.MM.yyyy HH:mm}", "Changed: {0:dd.MM.yyyy HH:mm}" } },
            { "explorer.propReadOnly", new[] { "Только чтение: {0}", "Read-only: {0}" } },
            { "explorer.propEncrypted", new[] { "Защищён шифром: {0}", "Encrypted: {0}" } },
            { "explorer.propNoRemove", new[] { "Запрет удаления (NOREMOVE): {0}", "Deletion blocked (NOREMOVE): {0}" } },
            { "explorer.yes",          new[] { "да", "yes" } },
            { "explorer.no",           new[] { "нет", "no" } },
            { "srv.stats2",         new[] { "запросов: {0}   ошибок: {1}   время: {2}   отдано: {3}   ufw: {4}",
                                            "requests: {0}   errors: {1}   uptime: {2}   sent: {3}   ufw: {4}" } },
            { "srv.hostsCaption",   new[] { "УЗЛЫ КОНФИГУРАЦИИ", "CONFIGURATION HOSTS" } },
            { "srv.hostName",       new[] { "Узел", "Host" } },
            { "srv.hostPort",       new[] { "Порт", "Port" } },
            { "srv.hostRoot",       new[] { "Корень", "Root" } },
            { "srv.hostMain",       new[] { "(основной)", "(main)" } },
            { "srv.hostNone",       new[] { "конфигурация не прочитана", "the configuration was not read" } },
            { "srv.reloadButton",   new[] { "Перечитать конфиг", "Reload config" } },
            { "srv.editConfigButton", new[] { "Открыть конфиг", "Open config" } },
            { "srv.clearLogButton", new[] { "Очистить", "Clear" } },
            { "srv.logCleared",     new[] { " Журнал очищен.", " The log was cleared." } },
            { "srv.configTitle",    new[] { "Конфигурация сайта — {0}", "Site configuration \u2014 {0}" } },
            { "srv.reloaded",       new[] { " Конфигурация перечитана: {0}, узлов {1}.",
                                            " The configuration was reloaded: {0}, {1} host(s)." } },
            { "srv.reloadFailed",   new[] { " [ERROR] Не удалось перечитать конфигурацию: {0}",
                                            " [ERROR] Could not reload the configuration: {0}" } },
            { "srv.reloadNotRunning", new[] { " [SYS] Сервер не запущен — перечитывать нечего.",
                                              " [SYS] The server is not running \u2014 there is nothing to reload." } },
            { "ssh.windowHere",     new[] { " [SYS] Окно «{0}» открыто в LisunOS на компьютере — в текстовом канале форму не показать.",
                                            " [SYS] The \u00ab{0}\u00bb window opened in LisunOS on the computer \u2014 a form cannot be shown over a text channel." } },
            { "ssh.outsideRoot",    new[] { " [ERROR] По сети доступна только файловая система LisunOS: пути диска Windows закрыты.",
                                            " [ERROR] Only the LisunOS file system is reachable over the network: Windows drive paths are closed." } },
            { "ssh.sessionHeader",  new[] { " Сеансы по сети ({0}):", " Network sessions ({0}):" } },
            { "ssh.sessionRow",     new[] { "   {0}  с {1}  команд: {2}  в сети: {3}",
                                            "   {0}  from {1}  commands: {2}  online: {3}" } },
            { "ssh.sessionNone",    new[] { " Сейчас по сети никто не подключён.", " Nobody is connected over the network right now." } },
            { "ssh.tooMany",        new[] { "Слишком много подключений, попробуйте позже.", "Too many connections, try again later." } },
            { "ssh.noHistory",      new[] { " Истории ещё нет.", " There is no history yet." } },
            { "ssh.helpTitle",      new[] { " Особенности сеанса по сети:", " How a network session differs:" } },
            { "ssh.helpBody",       new[] { "   • команды те же, что в терминале, включая установленные приложениями\r\n   • окна открываются в LisunOS на компьютере, сюда приходит только строка\r\n   • видна только файловая система LisunOS, пути Windows закрыты\r\n   • своя текущая папка: cd здесь не трогает терминал\r\n   • clear — очистить экран, !! — повторить прошлую команду, exit — выйти",
                                            "   \u2022 the same commands as in the terminal, including ones added by applications\r\n   \u2022 windows open in LisunOS on the computer, only a line arrives here\r\n   \u2022 only the LisunOS file system is visible, Windows paths are closed\r\n   \u2022 a directory of its own: cd here does not move the terminal\r\n   \u2022 clear \u2014 wipe the screen, !! \u2014 repeat the last command, exit \u2014 log out" } },
            { "tree.sshWho",        new[] { "кто подключён по сети", "who is connected over the network" } },
            { "tree.sshHelp",       new[] { "чем сеанс по сети отличается", "how a network session differs" } },
            { "user.currentIs",     new[] { " Текущий пользователь: {0}", " Current user: {0}" } },
            { "user.currentSet",     new[] { " Теперь команды идут от имени {0}.", " Commands now run as {0}." } },
            { "user.currentUsage",   new[] { " [ERROR] Формат: user current | user current set <имя>",
                                             " [ERROR] Usage: user current | user current set <name>" } },
            { "user.onlyRoot",       new[] { " [ERROR] Это может только root.", " [ERROR] Only root can do that." } },
            { "user.rootFree",       new[] { " root не ограничивают: это сама система.",
                                             " root is never limited: it is the system itself." } },
            { "user.disabledUser",   new[] { " [ERROR] Учётная запись «{0}» выключена.",
                                             " [ERROR] The \u00ab{0}\u00bb account is disabled." } },
            { "user.markSuperNow",   new[] { "   (режим суперпользователя включён)", "   (superuser mode is on)" } },
            { "user.areasTitle",     new[] { " Области, которые можно закрыть:", " Areas you can close:" } },
            { "user.badArea",        new[] { " [ERROR] Нет такой области: {0}. Список — user areas",
                                             " [ERROR] No such area: {0}. See user areas" } },
            { "user.limitUsage",     new[] { " [ERROR] Формат: user limit <имя> [add | remove <область> | clear]",
                                             " [ERROR] Usage: user limit <name> [add | remove <area> | clear]" } },
            { "user.limitTitle",     new[] { " Ограничения «{0}» ({1}):", " Limits for \u00ab{0}\u00bb ({1}):" } },
            { "user.limitNone",      new[] { " У «{0}» ограничений нет.", " \u00ab{0}\u00bb has no limits." } },
            { "user.limitAdded",     new[] { " «{0}»: закрыта область {1} — {2}.", " \u00ab{0}\u00bb: area {1} closed \u2014 {2}." } },
            { "user.limitRemoved",   new[] { " «{0}»: область {1} снова открыта.", " \u00ab{0}\u00bb: area {1} is open again." } },
            { "user.limitCleared",   new[] { " «{0}»: все ограничения сняты.", " \u00ab{0}\u00bb: every limit was removed." } },
            { "user.limitAlready",   new[] { " У «{0}» область {1} уже закрыта.", " Area {1} is already closed for \u00ab{0}\u00bb." } },
            { "user.limitMissing",   new[] { " У «{0}» область {1} и так открыта.", " Area {1} is already open for \u00ab{0}\u00bb." } },
            { "user.denied",         new[] { " [ERROR] Пользователю «{0}» закрыто: {1}.\r\n   Снять: user limit {0} remove {2} — от имени root.",
                                             " [ERROR] Closed for \u00ab{0}\u00bb: {1}.\r\n   Remove it: user limit {0} remove {2} \u2014 as root." } },
            { "tree.userCurrent",   new[] { "кто сейчас и смена пользователя", "who is active and switching user" } },
            { "tree.userLimit",     new[] { "ограничения пользователя", "a user's limits" } },
            { "tree.userAreas",     new[] { "какие области можно закрыть", "which areas can be closed" } },
            { "arg.area",           new[] { "область", "area" } },
            { "ssh.clientIs",       new[] { "клиент {0} с {1}", "client {0} from {1}" } },
            { "ssh.sessionFailed",  new[] { "сеанс с {0} прерван: {1}", "the session from {0} broke: {1}" } },
            { "ssh.fingerprint",    new[] { "отпечаток ключа", "key fingerprint" } },
            { "ssh.protocolNote",      new[] { "Подключается обычный клиент ssh: обмен ключами и шифрование настоящие. Пароль по сети не ходит открытым текстом.",
                                            "A regular ssh client connects: the key exchange and the encryption are real. The password does not travel in the clear." } },
            { "ssh.alsoPlain",         new[] { "Работает и простой текстовый режим — telnet, nc или PuTTY Raw на том же порту:",
                                            "A plain text mode also works \u2014 telnet, nc or PuTTY Raw on the same port:" } },
            { "user.tokenRequest",  new[] { "разрешение приложению просить: {0}", "letting an application ask for: {0}" } },
            { "user.requestTokens", new[] { "Для приложений — право ПОПРОСИТЬ возможность:",
                                            "For applications \u2014 the right to ASK for a capability:" } },
            { "user.createdNoPassword", new[] { " Создан «{0}» без пароля: локально работает, по сети не войдёт.",
                                                " Created \u00ab{0}\u00bb with no password: it works locally but cannot sign in over the network." } },
            { "user.passwordSet",   new[] { " Пароль для «{0}» задан.", " The password for \u00ab{0}\u00bb is set." } },
            { "user.webCreated",    new[] { " Заведена учётная запись сайта «{0}».", " The site account \u00ab{0}\u00bb was created." } },
            { "user.webKept",       new[] { " [ERROR] «{0}» — учётная запись сайта, её не удаляют.",
                                            " [ERROR] \u00ab{0}\u00bb is the site account, it is not removed." } },
            { "perm.askWho",        new[] { "Текущий пользователь: {0}", "Current user: {0}" } },
            { "perm.askBlocked",    new[] { "«{0}» не может просить право {1}: запрос закрыт ограничением.",
                                            "\u00ab{0}\u00bb cannot ask for {1}: the request is closed by a limit." } },
            { "web.denied",         new[] { "Сайту ({0}) закрыто: {1}", "Closed for the site ({0}): {1}" } },
            { "web.deniedJson",     new[] { "пользователю {0} закрыта область {1}", "area {1} is closed for user {0}" } },
            { "elev.title",         new[] { "Подтверждение LisunOS", "LisunOS confirmation" } },
            { "elev.header",        new[] { "Разрешить это действие?", "Allow this action?" } },
            { "elev.body",          new[] { "Пользователю «{0}» эта возможность закрыта. Подтвердите действие, чтобы выполнить его один раз.",
                                            "This capability is closed for \u00ab{0}\u00bb. Confirm to run it once." } },
            { "elev.detail",        new[] { "команда {0}   ·   {1}", "command {0}   \u00b7   {1}" } },
            { "elev.passwordCaption", new[] { "Пароль администратора:", "Administrator password:" } },
            { "elev.hint",          new[] { "Разрешение действует пять минут, потом окно спросит снова.",
                                            "The permission lasts five minutes, then the window asks again." } },
            { "elev.wrong",         new[] { "Пароль не подошёл. Попыток осталось: {0}.", "Wrong password. Attempts left: {0}." } },
            { "elev.yes",           new[] { "Разрешить", "Allow" } },
            { "elev.no",            new[] { "Отмена", "Cancel" } },
            { "elev.allowed",       new[] { "«{0}» разрешил действие {1}.", "\u00ab{0}\u00bb allowed the action {1}." } },
            { "elev.refused",       new[] { "Действие {1} для «{0}» не подтверждено.", "The action {1} for \u00ab{0}\u00bb was not confirmed." } },
            { "elev.setupTitle",    new[] { "Пароль администратора", "Administrator password" } },
            { "elev.setupBody",     new[] { "Задайте пароль администратора. Его спросят, когда понадобится разрешить действие, закрытое ограничением. Можно пропустить — тогда система будет просто переспрашивать.",
                                            "Set the administrator password. It is asked when an action closed by a limit needs to be allowed. You can skip it \u2014 then the system will simply ask for confirmation." } },
            { "elev.setupSkipped",  new[] { "Пароль администратора не задан.", "No administrator password was set." } },
            { "elev.repeat",        new[] { "Введите пароль дважды. Не короче четырёх знаков.",
                                            "Type the password twice. At least four characters." } },
            { "elev.tooShort",      new[] { "Слишком короткий пароль: нужно хотя бы четыре знака.",
                                            "Too short: at least four characters are needed." } },
            { "elev.mismatch",      new[] { "Пароли не совпали.", "The passwords do not match." } },
            { "elev.save",          new[] { "Сохранить", "Save" } },
            { "elev.skip",          new[] { "Пропустить", "Skip" } },
            { "tree.userPassword",  new[] { "пароль администратора", "the administrator password" } },
            { "store.windowTitle",  new[] { "Каталог приложений",                 "Application catalog" } },
            { "store.subtitle",     new[] { "Встроенные пакеты и каталог из сети", "Built-in packages and the network catalog" } },
            { "store.ready",        new[] { "Двойной щелчок ставит или запускает пакет.",
                                            "Double-click installs or launches a package." } },
            { "store.title",        new[] { " Каталог приложений ({0}):",          " Application catalog ({0}):" } },
            { "store.usage",        new[] { " store | store refresh | store install <имя> | store open",
                                            " store | store refresh | store install <name> | store open" } },
            { "store.columnName",   new[] { "Пакет",                              "Package" } },
            { "store.columnVersion",new[] { "Версия",                             "Version" } },
            { "store.columnState",  new[] { "Состояние",                          "State" } },
            { "store.columnTitle",  new[] { "Название",                           "Title" } },
            { "store.installed",    new[] { "установлен v{0}",                     "installed v{0}" } },
            { "store.builtIn",      new[] { "встроенный",                         "built in" } },
            { "store.available",    new[] { "доступен",                           "available" } },
            { "store.cardName",     new[] { "пакет: {0}",                         "package: {0}" } },
            { "store.cardVersion",  new[] { "версия: {0}",                        "version: {0}" } },
            { "store.cardAuthor",   new[] { "автор: {0}",                         "author: {0}" } },
            { "store.cardCommand",  new[] { "команда: {0}",                       "command: {0}" } },
            { "store.cardSource",   new[] { "источник: {0}",                      "source: {0}" } },
            { "store.sourceBuiltIn",new[] { "встроенный каталог",                 "built-in catalog" } },
            { "store.sourceNetwork",new[] { "каталог из сети",                    "network catalog" } },
            { "store.rights",       new[] { "права: {0}",                         "rights: {0}" } },
            { "store.noRights",     new[] { "права не запрашиваются",              "no rights requested" } },
            { "store.pickFirst",    new[] { "Выберите пакет в списке.",            "Pick a package from the list." } },
            { "store.refreshing",   new[] { "Читаю каталог…",                      "Reading the catalog…" } },
            { "store.refreshed",    new[] { " [OK] Каталог прочитан, пакетов в сети: {0}",
                                            " [OK] Catalog read, packages online: {0}" } },
            { "store.refreshFailed",new[] { " [ERROR] Каталог недоступен: {0}",    " [ERROR] The catalog is unavailable: {0}" } },
            { "store.needNetwork",  new[] { " [ERROR] Нужно право 'network'.",     " [ERROR] The 'network' right is required." } },
            { "store.noUrl",        new[] { " [ERROR] У пакета «{0}» нет ссылки на архив.",
                                            " [ERROR] Package \"{0}\" has no archive link." } },
            { "store.notPackage",   new[] { " [ERROR] По ссылке «{0}» пришёл не пакет .lnsh.",
                                            " [ERROR] The link for \"{0}\" did not return a .lnsh package." } },
            { "store.downloaded",   new[] { " Пакет {0} загружен ({1}).",          " Package {0} downloaded ({1})." } },
            { "store.installing",   new[] { "Устанавливаю {0}…",                   "Installing {0}…" } },
            { "store.installDone",  new[] { " [OK] Пакет «{0}» установлен.",       " [OK] Package \"{0}\" installed." } },
            { "store.installFailed",new[] { " [ERROR] Установка не удалась: {0}",  " [ERROR] The installation failed: {0}" } },
            { "store.removeAsk",    new[] { "Удалить пакет «{0}»?",                "Remove package \"{0}\"?" } },
            { "store.removed",      new[] { " [OK] Пакет «{0}» удалён.",           " [OK] Package \"{0}\" removed." } },
            { "store.removeFailed", new[] { " [ERROR] Не удалось удалить «{0}».",  " [ERROR] Could not remove \"{0}\"." } },
            { "store.notFound",     new[] { " [ERROR] Пакета «{0}» нет в каталоге.", " [ERROR] Package \"{0}\" is not in the catalog." } },
            { "daemon.usage",       new[] { " daemon list | status <имя> | start <имя> | stop <имя> | restart <имя> | run <имя> | enable <имя> | disable <имя>",
                                            " daemon list | status <name> | start <name> | stop <name> | restart <name> | run <name> | enable <name> | disable <name>" } },
            { "daemon.empty",       new[] { " [INFO] Фоновых служб нет. Их описывает блок daemon в .service.",
                                            " [INFO] No background services. They are declared by a daemon block in .service." } },
            { "daemon.listTitle",   new[] { " Фоновые службы ({0}, работает {1}):",
                                            " Background services ({0}, running {1}):" } },
            { "daemon.statusTitle", new[] { " Фоновая служба «{0}»:",                " Background service \"{0}\":" } },
            { "daemon.stateRunning",new[] { "работает",                             "running" } },
            { "daemon.stateStopped",new[] { "остановлена",                          "stopped" } },
            { "daemon.in",          new[] { "следующий запуск через {0} с",          "next run in {0} s" } },
            { "daemon.fieldState",  new[] { "состояние",                            "state" } },
            { "daemon.fieldPackage",new[] { "пакет",                                "package" } },
            { "daemon.fieldCommand",new[] { "команда",                              "command" } },
            { "daemon.fieldInterval",new[] { "интервал",                            "interval" } },
            { "daemon.fieldAutostart",new[] { "автозапуск",                          "autostart" } },
            { "daemon.fieldRight",  new[] { "требует право",                        "requires right" } },
            { "daemon.fieldRuns",   new[] { "запусков",                             "runs" } },
            { "daemon.fieldNext",   new[] { "следующий запуск",                     "next run" } },
            { "daemon.fieldLast",   new[] { "последний запуск",                     "last run" } },
            { "daemon.fieldOutput", new[] { "последний ответ",                      "last output" } },
            { "daemon.failures",    new[] { "ошибок: {0}",                          "failures: {0}" } },
            { "daemon.registered",  new[] { " Служба {0} описана, интервал {1} с.",  " Service {0} declared, interval {1} s." } },
            { "daemon.started",     new[] { " [OK] Фоновая служба «{0}» запущена.",  " [OK] Background service \"{0}\" started." } },
            { "daemon.stopped",     new[] { " [OK] Фоновая служба «{0}» остановлена.", " [OK] Background service \"{0}\" stopped." } },
            { "daemon.restarted",   new[] { " [OK] Фоновая служба «{0}» перезапущена.", " [OK] Background service \"{0}\" restarted." } },
            { "daemon.notFound",    new[] { " [ERROR] Фоновой службы «{0}» нет.",    " [ERROR] No background service \"{0}\"." } },
            { "daemon.notRunning",  new[] { " [INFO] Служба «{0}» и так остановлена.", " [INFO] Service \"{0}\" is already stopped." } },
            { "daemon.enabledNow",  new[] { " [OK] Автозапуск «{0}» включён.",       " [OK] Autostart of \"{0}\" is on." } },
            { "daemon.disabledNow", new[] { " [OK] Автозапуск «{0}» выключен.",      " [OK] Autostart of \"{0}\" is off." } },
            { "daemon.allStopped",  new[] { " [OK] Все фоновые службы остановлены.", " [OK] Every background service stopped." } },
            { "daemon.ranNow",      new[] { " [OK] «{0}» выполнена: {1}",            " [OK] \"{0}\" ran: {1}" } },
            { "daemon.noRight",     new[] { "нет права {0}",                        "right {0} is missing" } },
            { "daemon.stoppedNoRight", new[] { " Служба {0} остановлена: нет права {1}.",
                                            " Service {0} stopped: the {1} right is missing." } },
            { "conf.usage",         new[] { " conf test | show | reload | sample | path",
                                            " conf test | show | reload | sample | path" } },
            { "conf.title",         new[] { " Конфигурация сервера:",                 " Server configuration:" } },
            { "conf.fieldFile",     new[] { "файл",                                  "file" } },
            { "conf.fieldIncluded", new[] { "подключено",                            "included" } },
            { "conf.fieldCharset",  new[] { "кодировка",                             "charset" } },
            { "conf.fieldIndex",    new[] { "индексные файлы",                       "index files" } },
            { "conf.fieldMaxBody",  new[] { "предел тела запроса",                   "request body limit" } },
            { "conf.fieldHosts",    new[] { "блоков server: {0}",                    "server blocks: {0}" } },
            { "conf.fieldLocations",new[] { "блоков location: {0}",                  "location blocks: {0}" } },
            { "conf.ok",            new[] { "[OK] Замечаний нет — конфигурация разобрана.",
                                            "[OK] No warnings — the configuration parsed cleanly." } },
            { "conf.warnings",      new[] { "[WARN] Замечаний: {0}",                 "[WARN] Warnings: {0}" } },
            { "conf.missing",       new[] { " [ERROR] Файл настроек не найден. Запустите сервер — он создаст его.",
                                            " [ERROR] The configuration file is missing. Start the server and it will create one." } },
            { "conf.reloaded",      new[] { " [OK] Конфигурация перечитана.",         " [OK] Configuration reloaded." } },
            { "conf.sampleWritten", new[] { " [OK] Пример записан: {0}",              " [OK] Sample written: {0}" } },
            { "conf.path",          new[] { " Настройки: {0}\r\n Папка include: {1}",
                                            " Configuration: {0}\r\n Include folder: {1}" } },
            { "arg.package",           new[] { "пакет",                             "package" } },
            { "arg.packageOrFile",     new[] { "пакет или файл.lnsh",               "package or file.lnsh" } },
            { "arg.network",           new[] { "сеть",                              "network" } },
            { "arg.password",          new[] { "пароль",                            "password" } },
            { "arg.langCode",          new[] { "код языка",                         "language code" } },
            { "arg.application",       new[] { "приложение",                        "application" } },
            { "arg.right",             new[] { "право",                             "right" } },
            { "arg.service",           new[] { "служба",                            "service" } },
            { "arg.daemon",            new[] { "фоновая служба",                    "background service" } },
            { "arg.port",              new[] { "порт",                              "port" } },
            { "arg.folder",            new[] { "папка",                             "folder" } },
            { "arg.file",              new[] { "файл",                              "file" } },
            { "arg.lines",             new[] { "строк",                             "lines" } },
            { "arg.archive",           new[] { "архив.zip",                         "archive.zip" } },
            { "arg.path",              new[] { "путь",                              "path" } },
            { "arg.from",              new[] { "откуда",                            "from" } },
            { "arg.to",                new[] { "куда",                              "to" } },
            { "arg.text",              new[] { "текст",                             "text" } },
            { "arg.url",               new[] { "адрес",                             "url" } },
            { "arg.urlOrQuery",        new[] { "адрес или запрос",                  "url or query" } },
            { "arg.command",           new[] { "команда",                           "command" } },
            { "arg.filter",            new[] { "фильтр",                            "filter" } },
            { "arg.expression",        new[] { "выражение",                         "expression" } },
            { "arg.layout",            new[] { "раскладка",                         "layout" } },
            { "arg.name",              new[] { "имя",                               "name" } },
            { "arg.textOrFile",        new[] { "текст или файл",                    "text or file" } },
            { "tree.apt",              new[] { "пакеты системы",                    "system packages" } },
            { "tree.aptList",          new[] { "что установлено",                   "what is installed" } },
            { "tree.aptInfo",          new[] { "сведения о пакете",                 "package details" } },
            { "tree.aptInstall",       new[] { "установить",                        "install" } },
            { "tree.aptUpdate",        new[] { "обновить",                          "update" } },
            { "tree.aptRemove",        new[] { "удалить",                           "remove" } },
            { "tree.aptProtect",       new[] { "зашифровать",                       "encrypt" } },
            { "tree.aptUnprotect",     new[] { "снять шифрование",                  "decrypt" } },
            { "tree.store",            new[] { "каталог приложений",                "application catalog" } },
            { "tree.storeList",        new[] { "список пакетов",                    "list the packages" } },
            { "tree.storeRefresh",     new[] { "перечитать каталог",                "reload the catalog" } },
            { "tree.storeInstall",     new[] { "поставить из каталога",             "install from the catalog" } },
            { "tree.storeOpen",        new[] { "открыть окно",                      "open the window" } },
            { "tree.wifi",             new[] { "сети Wi-Fi",                        "Wi-Fi networks" } },
            { "tree.wifiList",         new[] { "сети вокруг",                       "networks around" } },
            { "tree.wifiStatus",       new[] { "состояние сети",                    "network state" } },
            { "tree.wifiForm",         new[] { "окно выбора сети",                  "network picker window" } },
            { "tree.wifiPortal",       new[] { "страница входа",                    "sign-in page" } },
            { "tree.wifiDisconnect",   new[] { "отключиться",                       "disconnect" } },
            { "tree.wifiConnect",      new[] { "подключиться",                      "connect" } },
            { "tree.wifiForget",       new[] { "забыть сеть",                       "forget a network" } },
            { "tree.lang",             new[] { "язык интерфейса",                   "interface language" } },
            { "tree.langList",         new[] { "список языков",                     "list the languages" } },
            { "tree.langReload",       new[] { "перечитать пакеты",                 "reload the packs" } },
            { "tree.langExport",       new[] { "шаблон перевода",                   "translation template" } },
            { "tree.langSwitch",       new[] { "переключить язык",                  "switch the language" } },
            { "tree.perm",             new[] { "разрешения приложений",             "application permissions" } },
            { "tree.permList",         new[] { "кому что выдано",                   "who was granted what" } },
            { "tree.permAll",          new[] { "все права системы",                 "every right" } },
            { "tree.permApp",          new[] { "права приложения",                  "rights of an application" } },
            { "tree.permGrant",        new[] { "выдать право",                      "grant a right" } },
            { "tree.permRevoke",       new[] { "отозвать право",                    "revoke a right" } },
            { "tree.permReset",        new[] { "сбросить права",                    "reset the rights" } },
            { "tree.systemctl",        new[] { "службы приложений",                 "application services" } },
            { "tree.systemctl.list",   new[] { "список служб",                      "list the services" } },
            { "tree.systemctl.status",  new[] { "состояние",                         "state" } },
            { "tree.systemctl.start",  new[] { "запустить",                         "start" } },
            { "tree.systemctl.stop",   new[] { "остановить",                        "stop" } },
            { "tree.systemctl.restart",  new[] { "перезапустить",                     "restart" } },
            { "tree.systemctl.enable",  new[] { "в автозапуск",                      "add to autostart" } },
            { "tree.systemctl.disable",  new[] { "убрать из автозапуска",             "remove from autostart" } },
            { "tree.daemon",           new[] { "фоновые службы",                    "background services" } },
            { "tree.daemonList",       new[] { "список служб",                      "list the services" } },
            { "tree.daemon.status",    new[] { "состояние",                         "state" } },
            { "tree.daemon.start",     new[] { "запустить",                         "start" } },
            { "tree.daemon.stop",      new[] { "остановить",                        "stop" } },
            { "tree.daemon.restart",   new[] { "перезапустить",                     "restart" } },
            { "tree.daemon.run",       new[] { "выполнить сейчас",                  "run right now" } },
            { "tree.daemon.enable",    new[] { "в автозапуск",                      "add to autostart" } },
            { "tree.daemon.disable",   new[] { "убрать из автозапуска",             "remove from autostart" } },
            { "tree.daemonStopAll",    new[] { "остановить все",                    "stop every one" } },
            { "tree.conf",             new[] { "настройки сервера",                 "server configuration" } },
            { "tree.confTest",         new[] { "проверить конфигурацию",            "check the configuration" } },
            { "tree.confShow",         new[] { "показать файл",                     "show the file" } },
            { "tree.confReload",       new[] { "перечитать",                        "reload" } },
            { "tree.confSample",       new[] { "записать пример",                   "write a sample" } },
            { "tree.confPath",         new[] { "где лежит",                         "where it lives" } },
            { "tree.php",              new[] { "модуль PHP",                        "the PHP module" } },
            { "tree.phpStatus",        new[] { "сводка",                            "summary" } },
            { "tree.phpDownload",      new[] { "скачать сборку",                    "download a build" } },
            { "tree.phpUpdate",        new[] { "перекачать",                        "download again" } },
            { "tree.phpRemove",        new[] { "удалить свой PHP",                  "remove the own PHP" } },
            { "tree.phpMirrors",       new[] { "зеркала загрузки",                  "download mirrors" } },
            { "tree.phpAuto",          new[] { "автозагрузка",                      "automatic download" } },
            { "tree.phpUse",           new[] { "выбрать источник",                  "pick the source" } },
            { "tree.phpUseBuiltIn",    new[] { "встроенный движок",                 "the built-in engine" } },
            { "tree.phpUseOwn",        new[] { "скачанный PHP",                     "the downloaded PHP" } },
            { "tree.phpUseSystem",     new[] { "PHP из Windows",                    "the PHP from Windows" } },
            { "tree.system",           new[] { "системный порт 8989",               "system port 8989" } },
            { "tree.systemStart",      new[] { "открыть порт",                      "open the port" } },
            { "tree.systemStop",       new[] { "закрыть порт",                      "close the port" } },
            { "tree.systemStatus",     new[] { "состояние порта",                   "port state" } },
            { "tree.systemOpen",       new[] { "открыть страницу",                  "open the page" } },
            { "tree.ufw",              new[] { "брандмауэр",                        "firewall" } },
            { "tree.ufwEnable",        new[] { "включить",                          "turn it on" } },
            { "tree.ufwDisable",       new[] { "выключить",                         "turn it off" } },
            { "tree.ufwStatus",        new[] { "правила",                           "rules" } },
            { "tree.ufwPort",          new[] { "правило для порта",                 "a rule for a port" } },
            { "tree.ufwOpen",          new[] { "открыть",                           "open" } },
            { "tree.ufwClose",         new[] { "закрыть",                           "close" } },
            { "tree.cd",               new[] { "сменить папку",                     "change folder" } },
            { "tree.ls",               new[] { "список файлов",                     "list files" } },
            { "tree.cat",              new[] { "показать файл",                     "show a file" } },
            { "tree.head",             new[] { "начало файла",                      "the start of a file" } },
            { "tree.tail",             new[] { "конец файла",                       "the end of a file" } },
            { "tree.sort",             new[] { "отсортировать строки",              "sort the lines" } },
            { "tree.sortReverse",      new[] { "в обратном порядке",                "in reverse" } },
            { "tree.sortNumeric",      new[] { "как числа",                         "as numbers" } },
            { "tree.uniq",             new[] { "убрать повторы",                    "drop repeats" } },
            { "tree.uniqCount",        new[] { "считать повторы",                   "count the repeats" } },
            { "tree.diff",             new[] { "сравнить файлы",                    "compare files" } },
            { "tree.hash",             new[] { "контрольная сумма",                 "checksum" } },
            { "tree.base64",           new[] { "кодирование base64",                "base64 encoding" } },
            { "tree.base64Encode",     new[] { "закодировать",                      "encode" } },
            { "tree.base64Decode",     new[] { "раскодировать",                     "decode" } },
            { "tree.zip",              new[] { "упаковать",                         "pack" } },
            { "tree.unzip",            new[] { "распаковать",                       "unpack" } },
            { "tree.rm",               new[] { "удалить",                           "delete" } },
            { "tree.mkdir",            new[] { "создать папку",                     "create a folder" } },
            { "tree.cp",               new[] { "скопировать",                       "copy" } },
            { "tree.mv",               new[] { "переместить",                       "move" } },
            { "tree.grep",             new[] { "искать в файле",                    "search in a file" } },
            { "tree.curl",             new[] { "скачать по адресу",                 "download from a url" } },
            { "tree.which",            new[] { "откуда команда",                    "where a command comes from" } },
            { "tree.env",              new[] { "переменные системы",                "system variables" } },
            { "tree.calc",             new[] { "вычислить",                         "calculate" } },
            { "tree.echo",             new[] { "вывести текст",                     "print text" } },
            { "tree.webview",          new[] { "открыть браузер",                   "open the browser" } },
            { "tree.layout",           new[] { "раскладка клавиатуры",              "keyboard layout" } },
            { "tree.kill",             new[] { "закрыть приложение",                "close an application" } },
            { "tree.alias",            new[] { "создать псевдоним",                 "create an alias" } },
            { "tree.unalias",          new[] { "убрать псевдоним",                  "remove an alias" } },
            { "suggest.usage",         new[] { "подсказка команды",                 "command hint" } },
            { "type.title",         new[] { " Типы пакетов LisunOS:",                " LisunOS package types:" } },
            { "type.unknown",       new[] { "неизвестный тип",                      "unknown type" } },
            { "type.needsSudo",     new[] { " [ERROR] Пакет типа '{0}' ставится только через sudo.",
                                            " [ERROR] A '{0}' package can only be installed with sudo." } },
            { "type.deployed",      new[] { " Файлы типа '{0}' разложены в {1}.",    " Files of type '{0}' placed into {1}." } },
            { "user.usage",            new[] { " user list | create <имя> [пароль] | edit <имя> <пароль> | remove <имя> | enable <имя> | disable <имя>\r\n user current [set <имя>] | user password | user areas\r\n user limit <имя> add PERMISSION_CREATE_FILES | user limit <имя> remove <токен> | user limit <имя> clear",
                                            " user list | create <name> [password] | edit <name> <password> | remove <name> | enable <name> | disable <name>\r\n user current [set <name>] | user password | user areas\r\n user limit <name> add PERMISSION_CREATE_FILES | user limit <name> remove <token> | user limit <name> clear" } },
            { "user.empty",            new[] { " [INFO] Учётных записей нет. Создайте: user create имя пароль",
                                            " [INFO] No accounts yet. Create one: user create name password" } },
            { "user.listTitle",        new[] { " Учётные записи ({0}):",
                                            " User accounts ({0}):" } },
            { "user.markSuper",        new[] { "superuser",
                                            "superuser" } },
            { "user.logins",           new[] { "входов: {0}",
                                            "logins: {0}" } },
            { "user.badName",          new[] { " [ERROR] Имя: 2–32 знака, буквы, цифры, дефис и подчёркивание.",
                                            " [ERROR] Name: 2–32 characters, letters, digits, hyphen and underscore." } },
            { "user.exists",           new[] { " [ERROR] Пользователь «{0}» уже есть.",
                                            " [ERROR] User \"{0}\" already exists." } },
            { "user.shortPassword",    new[] { " [ERROR] Пароль короче четырёх знаков.",
                                            " [ERROR] The password is shorter than four characters." } },
            { "user.created",          new[] { " [OK] Пользователь «{0}» создан.",
                                            " [OK] User \"{0}\" created." } },
            { "user.notFound",         new[] { " [ERROR] Пользователя «{0}» нет.",
                                            " [ERROR] No user \"{0}\"." } },
            { "user.passwordChanged",  new[] { " [OK] Пароль пользователя «{0}» изменён.",
                                            " [OK] Password of \"{0}\" changed." } },
            { "user.removed",          new[] { " [OK] Пользователь «{0}» удалён.",
                                            " [OK] User \"{0}\" removed." } },
            { "user.enabled",          new[] { " [OK] Вход для «{0}» разрешён.",
                                            " [OK] Login for \"{0}\" is allowed." } },
            { "user.disabled",         new[] { " [OK] Вход для «{0}» закрыт.",
                                            " [OK] Login for \"{0}\" is closed." } },
            { "user.needRight",        new[] { " [ERROR] Нужно право 'manage_users'.",
                                            " [ERROR] The 'manage_users' right is required." } },
            { "ssh.usage",             new[] { " ssh | status | start [порт] | stop | who | help | log",
                                            " ssh | status | start [port] | stop | who | help | log" } },
            { "ssh.statusTitle",       new[] { " Удалённый вход LisunOS:",
                                            " LisunOS remote shell:" } },
            { "ssh.fieldState",        new[] { "состояние",
                                            "state" } },
            { "ssh.fieldPort",         new[] { "порт",
                                            "port" } },
            { "ssh.fieldUsers",        new[] { "учётных записей",
                                            "accounts" } },
            { "ssh.fieldSessions",     new[] { "сессий принято",
                                            "sessions accepted" } },
            { "ssh.fieldUptime",       new[] { "в работе",
                                            "uptime" } },
            { "ssh.minutes",           new[] { "мин",
                                            "min" } },
            { "ssh.howTo",             new[] { "Подключайтесь с компьютера или телефона:",
                                            "Connect from a computer or a phone:" } },
            { "ssh.already",           new[] { " [INFO] Удалённый вход уже открыт на порту {0}.",
                                            " [INFO] The remote shell is already open on port {0}." } },
            { "ssh.noUsers",           new[] { " [ERROR] Сначала создайте пользователя: user create имя пароль",
                                            " [ERROR] Create a user first: user create name password" } },
            { "ssh.needListen",        new[] { " [ERROR] Нужно право 'listen'.",
                                            " [ERROR] The 'listen' right is required." } },
            { "ssh.started",           new[] { "Удалённый вход открыт на порту {0}.",
                                            "Remote shell opened on port {0}." } },
            { "ssh.startedFull",       new[] { " [OK] Удалённый вход открыт на порту {0}. Подключайтесь:",
                                            " [OK] Remote shell opened on port {0}. Connect with:" } },
            { "ssh.portBusy",          new[] { " [ERROR] Порт {0} занят: {1}",
                                            " [ERROR] Port {0} is busy: {1}" } },
            { "ssh.stopped",           new[] { " [OK] Удалённый вход закрыт.",
                                            " [OK] The remote shell is closed." } },
            { "ssh.notRunning",        new[] { " [INFO] Удалённый вход и так закрыт.",
                                            " [INFO] The remote shell is already closed." } },
            { "ssh.greeting",          new[] { "Вход в систему. Учётная запись создаётся командой user create.",
                                            "System login. Accounts are created with the user create command." } },
            { "ssh.askUser",           new[] { "Пользователь",
                                            "User" } },
            { "ssh.askPassword",       new[] { "Пароль",
                                            "Password" } },
            { "ssh.denied",            new[] { "Неверные имя или пароль.",
                                            "Wrong name or password." } },
            { "ssh.welcome",           new[] { "Здравствуйте, {0}.",
                                            "Hello, {0}." } },
            { "ssh.hint",              new[] { "Команды те же, что в терминале. Выход — exit.",
                                            "The commands are the same as in the terminal. Type exit to leave." } },
            { "ssh.bye",               new[] { "До связи.",
                                            "Goodbye." } },
            { "ssh.busy",              new[] { " [ERROR] Система занята, команда не выполнена.",
                                            " [ERROR] The system is busy, the command did not run." } },
            { "ssh.connected",         new[] { "Вошёл {0} с адреса {1}.",
                                            "{0} signed in from {1}." } },
            { "ssh.disconnected",      new[] { "Отключился {0} ({1}).",
                                            "{0} disconnected ({1})." } },
            { "ssh.rejectedFrom",      new[] { "Отказ: {0} пытался войти как «{1}».",
                                            "Rejected: {0} tried to sign in as \"{1}\"." } },
            { "ssh.logTitle",          new[] { " Журнал удалённого входа:",
                                            " Remote shell log:" } },
            { "ssh.logEmpty",          new[] { " [INFO] Журнал пуст.",
                                            " [INFO] The log is empty." } },
            { "su.useApp",          new[] { " [ERROR] Права суперпользователя из терминала не выдаются.\r\n   Откройте приложение SuperUser: команда superuser — там выберите пакет и выдайте ему право.",
                                            " [ERROR] Superuser rights are not granted from the terminal.\r\n   Open the SuperUser application: run superuser, pick a package and grant it the right." } },
            { "su.turnedOff",       new[] { " [SYS] Режим суперпользователя отключён.", " [SYS] Superuser mode is off." } },
            { "su.granted",         new[] { " Режим суперпользователя включён приложением «{0}».",
                                            " Superuser mode enabled by \"{0}\"." } },
            { "dialog.ok",          new[] { "OK",                                 "OK" } },
            { "dialog.cancel",      new[] { "Отмена",                             "Cancel" } },

            // =====================================================================
            //  1.8.0: загрузки, компоненты, обновление и приложение Wi-Fi
            // =====================================================================
            { "dl.usage",                 new[] { " download <адрес> [файл] | list | history | cancel | clear\r\n   Качает файл в текущую папку: зеркала, докачка, sha256.",
                                          " download <url> [file] | list | history | cancel | clear\r\n   Downloads a file into the current folder: mirrors, resume, sha256." } },
            { "dl.noUrl",                 new[] { "адрес не указан",
                                          "no address given" } },
            { "dl.noTarget",              new[] { "не указано, куда сохранять",
                                             "no destination given" } },
            { "dl.started",               new[] { "Качаю {0} — {1}",
                                            "Downloading {0} — {1}" } },
            { "dl.mirror",                new[] { "Зеркало {0} из {1}: {2}",
                                           "Mirror {0} of {1}: {2}" } },
            { "dl.canceled",              new[] { " [INFO] Загрузка {0} отменена.",
                                             " [INFO] The download {0} was canceled." } },
            { "dl.hashMismatch",          new[] { "отпечаток не совпал: ждали {0}, получили {1}",
                                                 "the checksum does not match: expected {0}, got {1}" } },
            { "dl.done",                  new[] { " [OK] {0}: {1}, {2}",
                                         " [OK] {0}: {1}, {2}" } },
            { "dl.retry",                 new[] { "Попытка {0} из {1} не удалась: {2}",
                                          "Attempt {0} of {1} failed: {2}" } },
            { "dl.failed",                new[] { " [ERROR] {0}: {1}",
                                           " [ERROR] {0}: {1}" } },
            { "dl.resumed",               new[] { "Продолжаю {0} с {1}",
                                            "Resuming {0} at {1}" } },
            { "dl.progress",              new[] { "{0}: {1} % ({2}, {3})",
                                             "{0}: {1} % ({2}, {3})" } },
            { "dl.short",                 new[] { "файл пришёл короче обещанного: {0} из {1}",
                                          "the file is shorter than promised: {0} of {1}" } },
            { "dl.perSecond",             new[] { "/с",
                                              "/s" } },
            { "dl.stateQueued",           new[] { "в очереди",
                                                "queued" } },
            { "dl.stateRunning",          new[] { "идёт",
                                                 "running" } },
            { "dl.stateDone",             new[] { "готово",
                                              "done" } },
            { "dl.stateCanceled",         new[] { "отменено",
                                                  "canceled" } },
            { "dl.stateFailed",           new[] { "ошибка",
                                                "failed" } },
            { "dl.left",                  new[] { "осталось {0}",
                                         "{0} left" } },
            { "dl.activeHeader",          new[] { " Загрузки:",
                                                 " Downloads:" } },
            { "dl.noActive",              new[] { "сейчас ничего не качается",
                                             "nothing is downloading right now" } },
            { "dl.into",                  new[] { "в {0}",
                                         "into {0}" } },
            { "dl.historyHeader",         new[] { " История загрузок LisunOS {0}:",
                                                  " LisunOS {0} download history:" } },
            { "dl.historyEmpty",          new[] { "история пуста",
                                                 "the history is empty" } },
            { "dl.totalSession",          new[] { "за этот запуск скачано: {0}",
                                                 "downloaded since start: {0}" } },
            { "dl.noDns",                 new[] { "имя не разрешилось — похоже, интернета нет",
                                          "the name did not resolve — there seems to be no internet" } },
            { "dl.noConnect",             new[] { "соединение не установилось",
                                              "the connection could not be established" } },
            { "dl.timeout",               new[] { "сервер не ответил вовремя",
                                            "the server did not answer in time" } },
            { "dl.tls",                   new[] { "не удалось договориться о шифровании (TLS)",
                                        "could not agree on encryption (TLS)" } },
            { "dl.noActive2",             new[] { " [INFO] Отменять нечего — загрузок нет.",
                                              " [INFO] Nothing to cancel — there are no downloads." } },
            { "dl.cancelledCount",        new[] { " [OK] Отменено загрузок: {0}.",
                                                   " [OK] Downloads canceled: {0}." } },
            { "dl.historyCleared",        new[] { " [OK] История загрузок очищена.",
                                                   " [OK] The download history is cleared." } },
            { "dl.historyKeep",           new[] { " [ERROR] Не удалось очистить историю.",
                                                " [ERROR] Could not clear the history." } },
            { "dl.sha",                   new[] { "sha256: {0}",
                                        "sha256: {0}" } },
            { "lib.usage",                new[] { " lib list | info <имя> | install <имя> | remove <имя> | check | update | auto on|off | path <имя>",
                                           " lib list | info <name> | install <name> | remove <name> | check | update | auto on|off | path <name>" } },
            { "lib.phpTitle",             new[] { "Сборка PHP для Windows",
                                              "The PHP build for Windows" } },
            { "lib.phpDescription",       new[] { "Нужна веб-серверу, чтобы запускать .php через php-cgi. Качается с php.net.",
                                                    "The web server needs it to run .php through php-cgi. Downloaded from php.net." } },
            { "lib.docsTitle",            new[] { "Документация",
                                               "Documentation" } },
            { "lib.docsDescription",      new[] { "Установка и справка на русском и английском из архива выпуска.",
                                                     "Setup and reference in Russian and English from the release archive." } },
            { "lib.appsTitle",            new[] { "Каталог приложений",
                                               "The application catalog" } },
            { "lib.appsDescription",      new[] { "Список пакетов с сайта: из него работают «apt install» и магазин.",
                                                     "The package list from the site: both \"apt install\" and the store read it." } },
            { "lib.systemTitle",          new[] { "Сам LisunOS",
                                                 "LisunOS itself" } },
            { "lib.systemDescription",    new[] { "Новые выпуски: проверка и обновление командой update.",
                                                       "New releases: checked and installed with the update command." } },
            { "lib.sshTitle",             new[] { "Удалённый вход (SSH-2)",
                                              "Remote login (SSH-2)" } },
            { "lib.sshDescription",       new[] { "Сервер ssh внутри ядра: обмен ключами, шифрование, сеансы.",
                                                    "The ssh server inside the kernel: key exchange, encryption, sessions." } },
            { "lib.sshNote",              new[] { "Встроено в ядро — качать нечего.",
                                             "Built into the kernel — there is nothing to download." } },
            { "lib.wifiTitle",            new[] { "Wi-Fi",
                                               "Wi-Fi" } },
            { "lib.wifiDescription",      new[] { "Поиск сетей и подключение средствами Windows.",
                                                     "Scanning and connecting through Windows itself." } },
            { "lib.wifiNote",             new[] { "Встроено — качать нечего.",
                                              "Built in — there is nothing to download." } },
            { "lib.engineTitle",          new[] { "Движок PHP",
                                                 "The PHP engine" } },
            { "lib.engineDescription",    new[] { "Свой лексер и интерпретатор PHP внутри LisunOS.",
                                                       "LisunOS has its own PHP lexer and interpreter." } },
            { "lib.engineNote",           new[] { "Встроено — работает и без сборки с php.net.",
                                                "Built in — it works without the build from php.net." } },
            { "lib.needNetwork",          new[] { " [ERROR] Нет разрешения на сеть.",
                                                 " [ERROR] No permission for the network." } },
            { "lib.catalogFailed",        new[] { " [ERROR] Каталог компонентов не прочитан: {0}",
                                                   " [ERROR] The component catalog was not read: {0}" } },
            { "lib.catalogOk",            new[] { " [OK] Каталог компонентов обновлён: {0}.",
                                               " [OK] The component catalog is updated: {0}." } },
            { "lib.unknown",              new[] { " [ERROR] Компонент «{0}» неизвестен. Список: lib list",
                                             " [ERROR] Unknown component \"{0}\". The list: lib list" } },
            { "lib.builtinNothing",       new[] { " [INFO] {0} уже внутри системы. {1}",
                                                    " [INFO] {0} is already inside the system. {1}" } },
            { "lib.notArchive",           new[] { " [ERROR] Вместо архива {0} пришло что-то другое.",
                                                " [ERROR] Something other than the {0} archive arrived." } },
            { "lib.runtimeNoBinary",      new[] { " [ERROR] В архиве нет php-cgi.exe.",
                                                     " [ERROR] The archive has no php-cgi.exe." } },
            { "lib.installed",            new[] { " [OK] {0} установлен: {1} ({2}).",
                                               " [OK] {0} is installed: {1} ({2})." } },
            { "lib.noTarget",             new[] { " [ERROR] Для {0} не задана папка установки.",
                                              " [ERROR] No install folder is set for {0}." } },
            { "lib.unpackFailed",         new[] { " [ERROR] {0}: распаковка не удалась — {1}",
                                                  " [ERROR] {0}: unpacking failed — {1}" } },
            { "lib.unpacked",             new[] { "{0}: распаковано файлов — {1}.",
                                              "{0}: files unpacked — {1}." } },
            { "lib.notRemovable",         new[] { " [ERROR] {0} убрать нельзя.",
                                                  " [ERROR] {0} cannot be removed." } },
            { "lib.notInstalled",         new[] { " [INFO] {0} не установлен.",
                                                  " [INFO] {0} is not installed." } },
            { "lib.removed",              new[] { " [OK] {0} убран.",
                                             " [OK] {0} is removed." } },
            { "lib.removeFailed",         new[] { " [ERROR] {0}: {1}",
                                                  " [ERROR] {0}: {1}" } },
            { "lib.already",              new[] { " [INFO] {0} уже на месте.",
                                             " [INFO] {0} is already in place." } },
            { "lib.autoOffHint",          new[] { " [INFO] {0} не установлен, а автодокачка выключена: lib auto on или lib install {0}.",
                                                 " [INFO] {0} is missing and auto-download is off: lib auto on, or lib install {0}." } },
            { "lib.autoFetch",            new[] { "{0} не найден — качаю сам.",
                                               "{0} is missing — downloading it." } },
            { "lib.listHeader",           new[] { " Компоненты LisunOS:",
                                                " LisunOS components:" } },
            { "lib.stateBuiltIn",         new[] { "встроено",
                                                  "built in" } },
            { "lib.stateInstalled",       new[] { "установлен",
                                                    "installed" } },
            { "lib.stateMissing",         new[] { "не установлен",
                                                  "missing" } },
            { "lib.autoState",            new[] { "автодокачка: {0}",
                                               "auto-download: {0}" } },
            { "lib.catalogState",         new[] { "каталог: {0} (прочитан {1})",
                                                  "catalog: {0} (read at {1})" } },
            { "lib.hint",                 new[] { "lib install <имя> — поставить, lib info <имя> — подробнее, lib check — чего не хватает",
                                          "lib install <name> to install, lib info <name> for details, lib check for what is missing" } },
            { "lib.infoHeader",           new[] { " Компонент {0}:",
                                                " Component {0}:" } },
            { "lib.fieldTitle",           new[] { "название     : ",
                                                "name         : " } },
            { "lib.fieldKind",            new[] { "вид          : ",
                                               "kind         : " } },
            { "lib.fieldVersion",         new[] { "версия       : ",
                                                  "version      : " } },
            { "lib.fieldState",           new[] { "состояние    : ",
                                                "state        : " } },
            { "lib.fieldNeeded",          new[] { "нужен для    : ",
                                                 "needed by    : " } },
            { "lib.fieldPath",            new[] { "папка        : ",
                                               "folder       : " } },
            { "lib.pathNone",             new[] { "ещё не установлен",
                                              "not installed yet" } },
            { "lib.fieldSize",            new[] { "размер       : ",
                                               "size         : " } },
            { "lib.fieldHash",            new[] { "sha256       : ",
                                               "sha256       : " } },
            { "lib.fieldUrls",            new[] { "откуда качать:",
                                               "downloaded from:" } },
            { "lib.checkHeader",          new[] { " Проверка компонентов:",
                                                 " Component check:" } },
            { "lib.checkAllOk",           new[] { "всё на месте.",
                                                "everything is in place." } },
            { "lib.checkMissing",         new[] { "не хватает компонентов: {0}.",
                                                  "components missing: {0}." } },
            { "upd.usage",                new[] { " update status | check | download | install",
                                           " update status | check | download | install" } },
            { "upd.needNetwork",          new[] { " [ERROR] Нет разрешения на сеть.",
                                                 " [ERROR] No permission for the network." } },
            { "upd.checkFailed",          new[] { " [ERROR] Проверка обновлений не удалась: {0}",
                                                 " [ERROR] The update check failed: {0}" } },
            { "upd.badJson",              new[] { "список выпусков не разобран",
                                             "the release list could not be parsed" } },
            { "upd.available",            new[] { " [OK] Есть версия {0} — у вас {1} ({2}).",
                                               " [OK] Version {0} is out — you have {1} ({2})." } },
            { "upd.current",              new[] { " [OK] Установлена последняя версия: {0}.",
                                             " [OK] You have the latest version: {0}." } },
            { "upd.noAsset",              new[] { " [ERROR] В выпуске {0} нет LisunOS.exe.",
                                             " [ERROR] Release {0} has no LisunOS.exe." } },
            { "upd.notExe",               new[] { " [ERROR] Пришёл не exe.",
                                            " [ERROR] What arrived is not an exe." } },
            { "upd.wrongSize",            new[] { " [ERROR] Размер не совпал: {0} вместо {1}.",
                                               " [ERROR] The size does not match: {0} instead of {1}." } },
            { "upd.downloaded",           new[] { " [OK] Версия {0} скачана: {1} ({2}). Установка: update install",
                                                " [OK] Version {0} is downloaded: {1} ({2}). To install: update install" } },
            { "upd.noSelf",               new[] { " [ERROR] Не нашёл собственный exe: {0}",
                                            " [ERROR] Could not find my own exe: {0}" } },
            { "upd.scriptFailed",         new[] { " [ERROR] Не удалось записать сценарий обновления: {0}",
                                                  " [ERROR] Could not write the update script: {0}" } },
            { "upd.startFailed",          new[] { " [ERROR] Не удалось запустить обновление: {0}",
                                                 " [ERROR] Could not start the update: {0}" } },
            { "upd.installing",           new[] { " [OK] Ставлю {0}. LisunOS закроется и откроется заново, прежний файл останется рядом как {1}.",
                                                " [OK] Installing {0}. LisunOS will close and reopen; the old file stays next to it as {1}." } },
            { "upd.header",               new[] { " Обновление LisunOS:",
                                            " LisunOS update:" } },
            { "upd.fieldInstalled",       new[] { "установлено : ",
                                                    "installed : " } },
            { "upd.fieldLatest",          new[] { "на сайте    : ",
                                                 "on the site: " } },
            { "upd.notChecked",           new[] { "ещё не проверяли — update check",
                                                "not checked yet — update check" } },
            { "upd.hint",                 new[] { "update check — узнать, update download — скачать, update install — поставить",
                                          "update check to look, update download to fetch, update install to apply" } },
            { "upd.fieldSize",            new[] { "размер      : ",
                                               "size      : " } },
            { "upd.fieldState",           new[] { "состояние   : ",
                                                "state     : " } },
            { "upd.stateNewer",           new[] { "есть версия новее",
                                                "a newer version is out" } },
            { "upd.stateSame",            new[] { "у вас последняя",
                                               "yours is the latest" } },
            { "upd.fieldChecked",         new[] { "проверено   : ",
                                                  "checked   : " } },
            { "upd.fieldFile",            new[] { "файл        : ",
                                               "file      : " } },
            { "upd.whatsNew",             new[] { "что нового:",
                                              "what is new:" } },
            { "upd.declined",             new[] { " [ERROR] Обновление не подтверждено.",
                                              " [ERROR] The update was not confirmed." } },
            { "wifiapp.windowTitle",      new[] { "Wi-Fi",
                                                     "Wi-Fi" } },
            { "wifiapp.networksCaption",  new[] { "Доступные сети",
                                                         "Available networks" } },
            { "wifiapp.columnSsid",       new[] { "Сеть",
                                                    "Network" } },
            { "wifiapp.columnSignal",     new[] { "Сигнал",
                                                      "Signal" } },
            { "wifiapp.columnSecurity",   new[] { "Защита",
                                                        "Security" } },
            { "wifiapp.columnState",      new[] { "Состояние",
                                                     "State" } },
            { "wifiapp.signalHint",       new[] { "Двойной щелчок по сети — подключиться. Голубым отмечены сети, пароль которых уже сохранён.",
                                                    "Double-click a network to connect. Cyan marks networks whose password is already saved." } },
            { "wifiapp.connectCaption",   new[] { "Подключение",
                                                        "Connection" } },
            { "wifiapp.password",         new[] { "Пароль сети",
                                                  "Network password" } },
            { "wifiapp.passwordNotNeeded",  new[] { "Пароль не нужен",
                                                           "No password needed" } },
            { "wifiapp.showPassword",     new[] { "Показывать пароль",
                                                      "Show the password" } },
            { "wifiapp.scan",             new[] { "Обновить",
                                              "Refresh" } },
            { "wifiapp.autoScan",         new[] { "Искать само",
                                                  "Keep looking" } },
            { "wifiapp.connect",          new[] { "Подключиться",
                                                 "Connect" } },
            { "wifiapp.disconnect",       new[] { "Отключиться",
                                                    "Disconnect" } },
            { "wifiapp.forget",           new[] { "Забыть сеть",
                                                "Forget" } },
            { "wifiapp.portal",           new[] { "Страница входа",
                                                "Sign-in page" } },
            { "wifiapp.downloadsCaption",  new[] { "Загрузки",
                                                          "Downloads" } },
            { "wifiapp.components",       new[] { "Докачать нужное",
                                                    "Download what is missing" } },
            { "wifiapp.cancel",           new[] { "Отменить",
                                                "Cancel" } },
            { "wifiapp.noAdapter",        new[] { "Адаптер Wi-Fi не найден — сети искать нечем.",
                                                   "No Wi-Fi adapter — there is nothing to scan with." } },
            { "wifiapp.scanning",         new[] { "Ищу сети…",
                                                  "Looking for networks…" } },
            { "wifiapp.nothingFound",     new[] { "Сетей не видно. Попробуйте ещё раз.",
                                                      "No networks in sight. Try again." } },
            { "wifiapp.found",            new[] { "Найдено сетей: {0}.",
                                               "Networks found: {0}." } },
            { "wifiapp.hidden",           new[] { "(без имени)",
                                                "(no name)" } },
            { "wifiapp.secEnterprise",    new[] { "802.1X",
                                                       "802.1X" } },
            { "wifiapp.secOpen",          new[] { "открытая",
                                                 "open" } },
            { "wifiapp.secClosed",        new[] { "с паролем",
                                                   "password" } },
            { "wifiapp.stateConnected",   new[] { "подключена",
                                                        "connected" } },
            { "wifiapp.stateSaved",       new[] { "сохранена",
                                                    "saved" } },
            { "wifiapp.connectedTo",      new[] { "Подключено: {0}",
                                                     "Connected: {0}" } },
            { "wifiapp.notConnected",     new[] { "Сеть не подключена",
                                                      "Not connected to a network" } },
            { "wifiapp.online",           new[] { "Интернет есть.",
                                                "The internet works." } },
            { "wifiapp.portalFound",      new[] { "Нужен вход на странице сети: {0}",
                                                     "The network asks you to sign in: {0}" } },
            { "wifiapp.offline",          new[] { "Интернета нет.",
                                                 "No internet." } },
            { "wifiapp.noDownloads",      new[] { "загрузок нет",
                                                     "no downloads" } },
            { "wifiapp.componentsOk",     new[] { "Все компоненты на месте.",
                                                      "Every component is in place." } },
            { "wifiapp.componentsMissing",  new[] { "Не хватает компонентов: {0} ({1}).",
                                                           "Components missing: {0} ({1})." } },
            { "wifiapp.needNetwork",      new[] { "Приложению не разрешена сеть.",
                                                     "The application has no permission for the network." } },
            { "wifiapp.autoOn",           new[] { "Буду искать сети сам.",
                                                "I will keep looking for networks." } },
            { "wifiapp.autoOff",          new[] { "Искать сети только по кнопке.",
                                                 "Networks will be scanned only on the button." } },
            { "wifiapp.enterpriseHint",   new[] { "{0}: сеть предприятия — пароля мало, вход через страницу.",
                                                        "{0}: an enterprise network — a password is not enough, sign in on the page." } },
            { "wifiapp.openHint",         new[] { "{0}: открытая сеть, пароль не нужен.",
                                                  "{0}: an open network, no password needed." } },
            { "wifiapp.closedHint",       new[] { "{0}: нужен пароль сети.",
                                                    "{0}: the network password is required." } },
            { "wifiapp.pickNetwork",      new[] { "Выберите сеть в списке.",
                                                     "Pick a network in the list." } },
            { "wifiapp.wait",             new[] { "Подождите, идёт работа с сетью.",
                                              "Hold on, the network is busy." } },
            { "wifiapp.needPassword",     new[] { "{0}: введите пароль сети.",
                                                      "{0}: enter the network password." } },
            { "wifiapp.connecting",       new[] { "Подключаюсь к {0}…",
                                                    "Connecting to {0}…" } },
            { "wifiapp.forgetTitle",      new[] { "Забыть сеть",
                                                     "Forget the network" } },
            { "wifiapp.forgetBody",       new[] { "Удалить сохранённый пароль сети «{0}»?",
                                                    "Delete the saved password for \"{0}\"?" } },
            { "wifiapp.forgetCancelled",  new[] { "Сеть осталась сохранённой.",
                                                         "The network is still saved." } },
            { "wifiapp.noPortal",         new[] { "Страница входа не найдена.",
                                                  "No sign-in page was found." } },
            { "wifiapp.openingPortal",    new[] { "Открываю {0}",
                                                       "Opening {0}" } },
            { "wifiapp.alreadyDownloading",  new[] { "Уже качаю — дождитесь конца.",
                                                            "Already downloading — wait for it to finish." } },
            { "wifiapp.downloadingComponents",  new[] { "Качаю компоненты: {0}.",
                                                               "Downloading components: {0}." } },
            { "wifiapp.componentOk",      new[] { "готово",
                                                     "done" } },
            { "wifiapp.cancelled",        new[] { "Отменено загрузок: {0}.",
                                                   "Downloads canceled: {0}." } },
            { "word.on",                  new[] { "включена",
                                         "on" } },
            { "word.off",                 new[] { "выключена",
                                          "off" } },
            { "arg.component",            new[] { "компонент",
                                               "component" } },
            { "tree.download",            new[] { "скачать файл",
                                               "download a file" } },
            { "tree.downloadList",        new[] { "что качается",
                                                   "what is downloading" } },
            { "tree.downloadHistory",     new[] { "история загрузок",
                                                      "the download history" } },
            { "tree.downloadCancel",      new[] { "отменить загрузки",
                                                     "cancel the downloads" } },
            { "tree.downloadClear",       new[] { "очистить историю",
                                                    "clear the history" } },
            { "tree.lib",                 new[] { "компоненты системы",
                                          "system components" } },
            { "tree.libList",             new[] { "список компонентов",
                                              "list the components" } },
            { "tree.libInfo",             new[] { "подробно о компоненте",
                                              "details about a component" } },
            { "tree.libInstall",          new[] { "поставить компонент",
                                                 "install a component" } },
            { "tree.libRemove",           new[] { "убрать компонент",
                                                "remove a component" } },
            { "tree.libCheck",            new[] { "чего не хватает",
                                               "what is missing" } },
            { "tree.libUpdate",           new[] { "перечитать каталог",
                                                "re-read the catalog" } },
            { "tree.libAuto",             new[] { "докачивать самой",
                                              "download on demand" } },
            { "tree.libPath",             new[] { "папка компонента",
                                              "the component folder" } },
            { "tree.update",              new[] { "обновление системы",
                                             "the system update" } },
            { "tree.updateStatus",        new[] { "что установлено",
                                                   "what is installed" } },
            { "tree.updateCheck",         new[] { "узнать о новой версии",
                                                  "look for a new version" } },
            { "tree.updateDownload",      new[] { "скачать новую версию",
                                                     "download the new version" } },
            { "tree.updateInstall",       new[] { "поставить новую версию",
                                                    "install the new version" } },


            // =====================================================================
            //  1.8.2: версии со словами, пароли на пакеты, мастер первого запуска
            // =====================================================================
            { "ver.header",                 new[] { " Версии LisunOS — у каждой своё слово:",
                                              " LisunOS versions — each one has a word of its own:" } },
            { "ver.planned",                new[] { "слова, занятые вперёд:",
                                               "words reserved for what comes next:" } },
            { "ver.rule",                   new[] { "Номер растёт по младшей части: после 1.8.1 идёт 1.8.2, а не 1.9.0.",
                                            "The number grows in its last part: 1.8.1 is followed by 1.8.2, not 1.9.0." } },
            { "ver.kernel",                 new[] { "Ядро: ",
                                              "Kernel: " } },
            { "ver.hall",                   new[] { "Оболочка по умолчанию: ",
                                            "Default shell: " } },
            { "ver.hint",                   new[] { "ver list — все версии и их слова",
                                            "ver list — every version and its word" } },
            { "pack.usage",                 new[] { " pack <папка> [файл.lnsh] [пароль] [подсказка]\r\n   Собирает пакет из папки. С паролем пакет закрывается замком.",
                                              " pack <folder> [file.lnsh] [password] [hint]\r\n   Builds a package from a folder. With a password it is locked." } },
            { "pack.noFolder",              new[] { " [ERROR] Папки «{0}» нет.",
                                                 " [ERROR] There is no folder \"{0}\"." } },
            { "pack.noMeta",                new[] { " [ERROR] В «{0}» нет meta.json — это не пакет.",
                                               " [ERROR] \"{0}\" has no meta.json — that is not a package." } },
            { "pack.done",                  new[] { " [OK] Пакет собран: {0} ({1} файлов, {2}).",
                                             " [OK] The package is built: {0} ({1} files, {2})." } },
            { "pack.doneLocked",            new[] { " [OK] Пакет собран и закрыт паролем: {0} ({1} файлов, {2}).\r\n   Без пароля его не установить и не прочитать.",
                                                   " [OK] The package is built and locked: {0} ({1} files, {2}).\r\n   Without the password it cannot be installed or read." } },
            { "pack.failed",                new[] { " [ERROR] Пакет не собран: {0}",
                                               " [ERROR] The package was not built: {0}" } },
            { "lock.title",                 new[] { "Пакет под паролем",
                                              "The package is locked" } },
            { "lock.body",                  new[] { "Пакет «{0}» закрыт паролем. Подсказка: {1}",
                                             "The package \"{0}\" is locked. Hint: {1}" } },
            { "lock.noHint",                new[] { "её не оставили",
                                               "none was left" } },
            { "lock.notLocked",             new[] { " [INFO] Этот пакет не закрыт паролем.",
                                                  " [INFO] This package is not locked." } },
            { "lock.badLock",               new[] { " [ERROR] Замок пакета не разобран.",
                                                " [ERROR] The package lock could not be read." } },
            { "lock.wrongPassword",         new[] { " [ERROR] Пароль не подошёл.",
                                                      " [ERROR] The password does not fit." } },
            { "lock.badPayload",            new[] { " [ERROR] Внутри замка не пакет.",
                                                   " [ERROR] What is inside the lock is not a package." } },
            { "lock.opened",                new[] { " [OK] Пакет «{0}» открыт.",
                                               " [OK] The package \"{0}\" is unlocked." } },
            { "lock.failed",                new[] { " [ERROR] Пакет не открыт: {0}",
                                               " [ERROR] The package was not unlocked: {0}" } },
            { "lock.remote",                new[] { " [ERROR] Пакет под паролем ставится только за компьютером: окно ввода по сети не показать.",
                                               " [ERROR] A locked package installs only at the computer: the password window cannot be shown over the network." } },
            { "lock.cancelled",             new[] { " [INFO] Установка отменена: пароль не введён.",
                                                  " [INFO] The install was cancelled: no password was entered." } },
            { "store.allHeader",            new[] { " Устанавливаю всё из каталога:",
                                                   " Installing everything from the catalog:" } },
            { "store.allSkip",              new[] { "уже установлен",
                                                 "already installed" } },
            { "store.allDone",              new[] { "поставлено: {0}, пропущено: {1}, не удалось: {2}.",
                                                 "installed: {0}, skipped: {1}, failed: {2}." } },
            { "setup.windowTitle",          new[] { "Настройка LisunOS",
                                                     "Setting up LisunOS" } },
            { "setup.back",                 new[] { "Назад",
                                              "Back" } },
            { "setup.skip",                 new[] { "Пропустить",
                                              "Skip" } },
            { "setup.next",                 new[] { "Далее",
                                              "Next" } },
            { "setup.install",              new[] { "Установить",
                                                 "Install" } },
            { "setup.finish",               new[] { "В терминал",
                                                "To the terminal" } },
            { "setup.stepsCaption",         new[] { "ЭТАПЫ",
                                                      "STEPS" } },
            { "setup.stepsHint",            new[] { "Любой этап можно пропустить: сеть и приложения настраиваются потом командами wifi, store и apt.",
                                                   "Any step can be skipped: the network and the applications can be set up later with wifi, store and apt." } },
            { "setup.stepWelcome",          new[] { "Язык",
                                                     "Language" } },
            { "setup.stepWifi",             new[] { "Сеть",
                                                  "Network" } },
            { "setup.stepApps",             new[] { "Приложения",
                                                  "Applications" } },
            { "setup.stepInstall",          new[] { "Установка",
                                                     "Install" } },
            { "setup.stepDone",             new[] { "Готово",
                                                  "Done" } },
            { "setup.stepOf",               new[] { "Этап {0} из {1}",
                                                "Step {0} of {1}" } },
            { "setup.titleWelcome",         new[] { "Здравствуйте",
                                                      "Hello" } },
            { "setup.titleWifi",            new[] { "Подключение к сети",
                                                   "Connecting to a network" } },
            { "setup.titleApps",            new[] { "Что поставить",
                                                   "What to install" } },
            { "setup.titleInstall",         new[] { "Установка",
                                                      "Installing" } },
            { "setup.titleDone",            new[] { "Всё готово",
                                                   "All set" } },
            { "setup.subWelcome",           new[] { "выберите язык системы",
                                                    "pick the system language" } },
            { "setup.subWifi",              new[] { "без сети приложения не скачать",
                                                 "without a network nothing can be downloaded" } },
            { "setup.subApps",              new[] { "список приходит с сайта проекта",
                                                 "the list comes from the project site" } },
            { "setup.subInstall",           new[] { "качаю и ставлю выбранное",
                                                    "downloading and installing what you picked" } },
            { "setup.subDone",              new[] { "можно открывать терминал",
                                                 "the terminal is ready" } },
            { "setup.welcomeBody",          new[] { "Это LisunOS {0} «{1}» — виртуальная операционная система: свой терминал, файловая система, пакеты, веб-сервер и вход по сети.\r\n\r\nСейчас пройдём четыре этапа: язык, сеть, выбор приложений и установка. Это занимает пару минут, и всё можно пропустить.",
                                                     "This is LisunOS {0} \"{1}\" — a virtual operating system: its own terminal, file system, packages, web server and network login.\r\n\r\nFour steps follow: the language, the network, the applications and the install. It takes a couple of minutes, and every step can be skipped." } },
            { "setup.welcomeStatus",        new[] { "Выберите язык и нажмите «Далее».",
                                                       "Pick a language and press Next." } },
            { "setup.wifiHint",             new[] { "Выберите сеть и введите пароль. Если компьютер уже в сети — просто нажмите «Далее».",
                                                  "Pick a network and enter the password. If the computer is already online, just press Next." } },
            { "setup.online",               new[] { "Интернет есть — приложения скачаются.",
                                                "The internet works — the applications will download." } },
            { "setup.offline",              new[] { "Интернета нет. Можно пропустить этот этап и поставить приложения позже.",
                                                 "No internet. You can skip this step and install the applications later." } },
            { "setup.appsHint",             new[] { "Отмечены приложения, которых ещё нет в системе. Список берётся с сайта — тот же, что у команды store.",
                                                  "The applications you do not have yet are ticked. The list comes from the site — the same one the store command reads." } },
            { "setup.selectAll",            new[] { "Отметить все",
                                                   "Tick every one" } },
            { "setup.selectNone",           new[] { "Снять все",
                                                    "Untick all" } },
            { "setup.refresh",              new[] { "Перечитать каталог",
                                                 "Re-read the catalog" } },
            { "setup.alreadyInstalled",     new[] { "— уже стоит",
                                                          "— already installed" } },
            { "setup.catalogReading",       new[] { "Читаю каталог приложений…",
                                                        "Reading the application catalog…" } },
            { "setup.catalogRead",          new[] { "В каталоге приложений: {0}.",
                                                     "Applications in the catalog: {0}." } },
            { "setup.catalogEmpty",         new[] { "Каталог пуст — похоже, нет сети.",
                                                      "The catalog is empty — there seems to be no network." } },
            { "setup.chosen",               new[] { "Выбрано: {0} из {1}.",
                                                "Picked: {0} of {1}." } },
            { "setup.nothingChosen",        new[] { "Ничего не выбрано — пропускаю установку.",
                                                       "Nothing is picked — skipping the install." } },
            { "setup.installReady",         new[] { "Готов поставить приложений: {0}. Нажмите «Установить».",
                                                      "Ready to install {0} application(s). Press Install." } },
            { "setup.installHint",          new[] { "Каждое приложение качается с сайта и ставится обычным установщиком.",
                                                     "Each application is downloaded from the site and installed by the usual installer." } },
            { "setup.installing",           new[] { "Ставлю приложений: {0}…",
                                                    "Installing {0} application(s)…" } },
            { "setup.installingOne",        new[] { "{0}: качаю и ставлю…",
                                                       "{0}: downloading and installing…" } },
            { "setup.waitInstall",          new[] { "Идёт установка — дождитесь конца.",
                                                     "The install is running — wait for it to finish." } },
            { "setup.doneBody",             new[] { "Поставлено приложений: {0}. Не удалось: {1}.\r\n\r\nДальше — терминал: help покажет все команды, store — каталог приложений, ssh — вход с телефона.",
                                                  "Applications installed: {0}. Failed: {1}.\r\n\r\nNext is the terminal: help lists every command, store shows the catalog, ssh lets you sign in from a phone." } },
            { "setup.doneStatus",           new[] { "Нажмите «В терминал».",
                                                    "Press \"To the terminal\"." } },
            { "setup.languageSet",          new[] { "Язык выбран.",
                                                     "The language is set." } },
            { "setup.reset",                new[] { " [OK] Мастер первого запуска покажется снова при следующем запуске.",
                                               " [OK] The first-run wizard will appear again on the next start." } },
            { "setup.statusDone",           new[] { "Мастер первого запуска уже пройден.",
                                                    "The first-run wizard has been completed." } },
            { "setup.statusPending",        new[] { "Мастер первого запуска ещё не проходили.",
                                                       "The first-run wizard has not been run yet." } },
            { "tree.pack",                  new[] { "собрать пакет из папки",
                                             "build a package from a folder" } },
            { "tree.setup",                 new[] { "мастер первого запуска",
                                              "the first-run wizard" } },
            { "tree.setupReset",            new[] { "показать мастер снова",
                                                   "show the wizard again" } },
            { "tree.setupStatus",           new[] { "пройден ли мастер",
                                                    "whether the wizard has run" } },
            { "tree.verList",               new[] { "версии и их слова",
                                                "versions and their words" } },
            { "tree.storeAll",              new[] { "поставить всё из каталога",
                                                 "install everything from the catalog" } },


            // =====================================================================
            //  1.8.3: проводная сеть, ключи su, установка без перезагрузки
            // =====================================================================
            { "net.header",                 new[] { " Сетевые адаптеры:",
                                              " Network adapters:" } },
            { "net.none",                   new[] { "адаптеров не видно",
                                            "no adapters in sight" } },
            { "net.kindWired",              new[] { "проводной",
                                                 "wired" } },
            { "net.kindWireless",           new[] { "Wi-Fi",
                                                    "Wi-Fi" } },
            { "net.kindVirtual",        new[] { "виртуальный",
                                                  "virtual" } },
            { "net.kindOther",              new[] { "другой",
                                                 "other" } },
            { "net.kindNone",               new[] { "нет подключения",
                                                "not connected" } },
            { "net.stateUp",                new[] { "подключён",
                                               "up" } },
            { "net.stateNoAddress",         new[] { "поднят, адреса нет",
                                                      "up, no address" } },
            { "net.stateDown",              new[] { "отключён",
                                                 "down" } },
            { "net.address",                new[] { "адрес: ",
                                               "address: " } },
            { "net.gateway",                new[] { "шлюз: ",
                                               "gateway: " } },
            { "net.gbit",                   new[] { "Гбит/с",
                                            "Gbit/s" } },
            { "net.mbit",                   new[] { "Мбит/с",
                                            "Mbit/s" } },
            { "net.kbit",                   new[] { "Кбит/с",
                                            "Kbit/s" } },
            { "net.summary",                new[] { "сейчас в сети: {0}; интернет: {1}",
                                               "connected via: {0}; internet: {1}" } },
            { "net.internetYes",            new[] { "есть",
                                                   "yes" } },
            { "net.internetNo",             new[] { "нет",
                                                  "no" } },
            { "net.shortWired",             new[] { "проводное соединение, {0}",
                                                  "wired connection, {0}" } },
            { "net.shortWifi",              new[] { "Wi-Fi «{0}», {1}",
                                                 "Wi-Fi \"{0}\", {1}" } },
            { "net.shortWireless",          new[] { "Wi-Fi, {0}",
                                                     "Wi-Fi, {0}" } },
            { "net.shortNone",              new[] { "подключения нет",
                                                 "no connection" } },
            { "net.wiredYes",               new[] { "подключён, {0} ({1})",
                                                "connected, {0} ({1})" } },
            { "net.wiredNo",                new[] { "кабель не подключён",
                                               "no cable" } },
            { "su.notRemote",               new[] { " [ERROR] По сети su не включается: окно подтверждения показать некому.",
                                                " [ERROR] su is not enabled over the network: there is nobody to show the confirmation to." } },
            { "su.declined",                new[] { " [ERROR] Повышение не подтверждено.",
                                               " [ERROR] The elevation was not confirmed." } },
            { "su.enabledBy",               new[] { " [SYS] Режим суперпользователя включён ключом приложения «{0}».",
                                                " [SYS] Superuser mode enabled by the key of \"{0}\"." } },
            { "perm.trusted",               new[] { "{0}: права выданы при установке из доверенного источника — {1}.",
                                                "{0}: rights granted on install from a trusted source — {1}." } },
            { "install.noRestart",          new[] { "{0} готов к работе сразу, перезапуск не нужен.",
                                                     "{0} is ready right away, no restart needed." } },
            { "suapp.installedNow",         new[] { " [OK] SuperUser поставлен из встроенного каталога. Запуск: superuser",
                                                      " [OK] SuperUser is installed from the built-in catalog. Run it with: superuser" } },
            { "setup.onlineWired",          new[] { "Интернет есть — проводное соединение, {0} ({1}).",
                                                     "The internet works — a wired connection, {0} ({1})." } },
            { "setup.wiredNoInternet",      new[] { "Кабель подключён ({0}), но интернета нет. Можно идти дальше и поставить приложения позже.",
                                                         "The cable is connected ({0}) but there is no internet. You can move on and install the applications later." } },
            { "setup.wifiHintWired",        new[] { "Компьютер уже в сети по кабелю — этот этап можно пройти мимо. Wi-Fi нужен, только если хотите ещё и беспроводную сеть.",
                                                       "The computer is already online over the cable — you can walk past this step. Wi-Fi is only needed if you want a wireless network too." } },
            { "wifiapp.wiredOnly",          new[] { "Адаптера Wi-Fi нет, но {0}",
                                                     "No Wi-Fi adapter, but {0}" } },
            { "wifi.fieldWired",            new[] { "Кабель",
                                                   "Cable" } },
            { "tree.net",                   new[] { "сетевые адаптеры",
                                            "network adapters" } },


            // =====================================================================
            //  1.8.4: автозапуск удалённого входа
            // =====================================================================
            { "ssh.autoState",              new[] { "автозапуск: {0}, порт {1}",
                                                 "autostart: {0}, port {1}" } },
            { "ssh.autoOn",                 new[] { " [OK] Удалённый вход будет подниматься при запуске системы, порт {0}.",
                                              " [OK] The remote login will start with the system, port {0}." } },
            { "ssh.autoOff",                new[] { " [OK] Автозапуск удалённого входа выключен (порт {0} запомнен).",
                                               " [OK] Autostart of the remote login is off (port {0} is remembered)." } },
            { "ssh.autoStarted",            new[] { "Удалённый вход поднят при запуске, порт {0}.",
                                                   "The remote login started with the system, port {0}." } },
            { "ssh.autoFailed",             new[] { "Автозапуск удалённого входа не удался: {0}",
                                                  "Autostart of the remote login failed: {0}" } },
            { "tree.sshAutostart",          new[] { "поднимать при запуске",
                                                     "start it with the system" } },


            // =====================================================================
            //  1.8.6: сторож отзывчивости и SystemOptimizer
            // =====================================================================
            { "perf.header",                new[] { " Отзывчивость системы:",
                                               " System responsiveness:" } },
            { "perf.watching",              new[] { "сторож: {0}, порог {1} мс",
                                                 "watchdog: {0}, threshold {1} ms" } },
            { "perf.ticks",                 new[] { "проверок сделано: {0}",
                                              "checks made: {0}" } },
            { "perf.none",                  new[] { "подвисаний не было",
                                             "there were no stalls" } },
            { "perf.worst",                 new[] { "самое долгое: {0} мс — {1}",
                                              "the longest: {0} ms — {1}" } },
            { "perf.recent",                new[] { "последние подвисания:",
                                               "recent stalls:" } },
            { "perf.unknown",               new[] { "(неизвестно чем)",
                                                "(unknown)" } },
            { "perf.stall",                 new[] { "окно подвисло на {0} мс: {1}",
                                              "the window stalled for {0} ms: {1}" } },
            { "perf.hint",                  new[] { "perf test — замерить операции прямо сейчас, perf clear — забыть накопленное",
                                             "perf test measures the operations right now, perf clear forgets what piled up" } },
            { "perf.cleared",               new[] { " [OK] Накопленные подвисания забыты.",
                                                " [OK] The recorded stalls are forgotten." } },
            { "perf.measureHeader",         new[] { " Замер операций:",
                                                      " Operation timings:" } },
            { "perf.opSuggest",             new[] { "подсказка «wifi connect»",
                                                  "the \"wifi connect\" suggestion" } },
            { "perf.opAdapters",            new[] { "список сетевых адаптеров",
                                                   "the network adapter list" } },
            { "perf.opWifi",                new[] { "имя текущей сети Wi-Fi",
                                               "the current Wi-Fi network name" } },
            { "perf.opPackages",            new[] { "список установленных пакетов",
                                                   "the installed package list" } },
            { "perf.opCatalog",             new[] { "каталог приложений",
                                                  "the application catalog" } },
            { "perf.opComponents",          new[] { "проверка компонентов",
                                                     "the component check" } },
            { "perf.ms",                    new[] { "мс",
                                           "ms" } },
            { "perf.slow",                  new[] { "это и есть подвисание",
                                             "this is a stall" } },
            { "perf.notFast",               new[] { "заметно",
                                                "noticeable" } },
            { "perf.journal",               new[] { "журнал ядра: {0} строк из {1}",
                                                "kernel journal: {0} lines of {1}" } },
            { "perf.memory",                new[] { "память: {0}",
                                               "memory: {0}" } },
            { "perf.apps",                  new[] { "приложений загружено: {0}",
                                             "applications loaded: {0}" } },
            { "perf.measureHint",           new[] { "Если что-то здесь занимает больше 350 мс — окно на это время замирает.",
                                                    "Anything here above 350 ms freezes the window for that long." } },
            { "perf.markCommand",           new[] { "команда: {0}",
                                                    "command: {0}" } },
            { "perf.markSuggest",           new[] { "подсказки в терминале",
                                                    "terminal suggestions" } },
            { "opt.header",                 new[] { " Что работает в системе:",
                                              " What is running in the system:" } },
            { "opt.kindApp",                new[] { "приложение",
                                               "application" } },
            { "opt.kindDaemon",             new[] { "демон",
                                                  "daemon" } },
            { "opt.kindService",            new[] { "служба",
                                                   "service" } },
            { "opt.kindServer",             new[] { "сервер",
                                                  "server" } },
            { "opt.titleSsh",               new[] { "удалённый вход по ssh",
                                                "the ssh remote login" } },
            { "opt.titleSystem",            new[] { "системный порт 8989",
                                                   "the 8989 system port" } },
            { "opt.stateWorking",           new[] { "работает",
                                                    "working" } },
            { "opt.stateIdle",              new[] { "вхолостую",
                                                 "idle" } },
            { "opt.stateStopped",           new[] { "остановлено",
                                                    "stopped" } },
            { "opt.whyOpen",                new[] { "окно открыто",
                                               "the window is open" } },
            { "opt.whyHidden",              new[] { "окно закрыто, приложение осталось в памяти",
                                                 "the window is closed, the application stayed in memory" } },
            { "opt.whyNoWindow",            new[] { "окна нет",
                                                   "there is no window" } },
            { "opt.whyWorking",             new[] { "используется",
                                                  "in use" } },
            { "opt.whyDisabled",            new[] { "автозапуск выключен",
                                                   "autostart is off" } },
            { "opt.whyStopped",             new[] { "не запущено",
                                                  "not running" } },
            { "opt.whySessions",            new[] { "подключено сеансов: {0}",
                                                   "sessions connected: {0}" } },
            { "opt.whyNoSessions",          new[] { "поднят, но никто не подключён",
                                                     "up, but nobody is connected" } },
            { "opt.whyIdlePort",            new[] { "порт открыт, установка не идёт",
                                                   "the port is open, no setup is running" } },
            { "opt.stopWith",               new[] { "остановить: {0}",
                                                "stop it with: {0}" } },
            { "opt.backWith",               new[] { "вернуть: {0}",
                                                "bring it back with: {0}" } },
            { "opt.wouldStop",              new[] { "будет выполнено: {0}",
                                                 "would run: {0}" } },
            { "opt.summary",                new[] { "всего записей: {0}, работает: {1}, вхолостую: {2}",
                                               "entries: {0}, working: {1}, idle: {2}" } },
            { "opt.hint",                   new[] { "optimize plan — что будет остановлено, optimize run — остановить, optimize start <имя> — вернуть",
                                            "optimize plan shows what would stop, optimize run stops it, optimize start <name> brings it back" } },
            { "opt.usage",                  new[] { " optimize list | plan | run | stop <имя> | start <имя> | open",
                                             " optimize list | plan | run | stop <name> | start <name> | open" } },
            { "opt.unknown",                new[] { " [ERROR] Запись «{0}» не найдена. Список: optimize list",
                                               " [ERROR] No entry \"{0}\". The list: optimize list" } },
            { "opt.alreadyStopped",         new[] { " [INFO] {0} уже остановлено. Вернуть: {1}",
                                                      " [INFO] {0} is already stopped. Bring it back with: {1}" } },
            { "opt.stopped",                new[] { "{0} остановлено, вернуть можно командой: {1}",
                                               "{0} stopped, bring it back with: {1}" } },
            { "opt.noCommand",              new[] { " [ERROR] Для этой записи нет команды.",
                                                 " [ERROR] This entry has no command." } },
            { "opt.planHeader",             new[] { " Что работает вхолостую:",
                                                  " What is running for nothing:" } },
            { "opt.runHeader",              new[] { " Останавливаю то, что работает вхолостую:",
                                                 " Stopping what runs for nothing:" } },
            { "opt.nothing",                new[] { "всё занято делом — останавливать нечего",
                                               "everything is busy — there is nothing to stop" } },
            { "opt.planCount",              new[] { "вхолостую работает записей: {0}",
                                                 "entries running for nothing: {0}" } },
            { "opt.doneCount",              new[] { "остановлено записей: {0}",
                                                 "entries stopped: {0}" } },
            { "opt.applyHint",              new[] { "optimize run — остановить их; каждую можно вернуть её же командой",
                                                 "optimize run stops them; each one comes back with its own command" } },
            { "opt.appMissing",             new[] { " [ERROR] Приложение SystemOptimizer не установлено: apt install sysoptapp",
                                                  " [ERROR] The SystemOptimizer application is not installed: apt install sysoptapp" } },
            { "optapp.windowTitle",         new[] { "SystemOptimizer",
                                                      "SystemOptimizer" } },
            { "optapp.subtitle",            new[] { "что работает вхолостую и чем это вернуть",
                                                   "what runs for nothing and how to bring it back" } },
            { "optapp.counters",            new[] { "записей: {0}, вхолостую: {1}",
                                                   "entries: {0}, idle: {1}" } },
            { "optapp.columnName",          new[] { "Что",
                                                     "What" } },
            { "optapp.columnKind",          new[] { "Вид",
                                                     "Kind" } },
            { "optapp.columnState",         new[] { "Состояние",
                                                      "State" } },
            { "optapp.columnWhy",           new[] { "Почему",
                                                    "Why" } },
            { "optapp.commands",            new[] { "остановить: {0}      вернуть: {1}",
                                                   "stop: {0}      back: {1}" } },
            { "optapp.refresh",             new[] { "Обновить",
                                                  "Refresh" } },
            { "optapp.stop",                new[] { "Остановить",
                                               "Stop" } },
            { "optapp.start",               new[] { "Запустить обратно",
                                                "Start again" } },
            { "optapp.optimize",            new[] { "Завершить ненужное",
                                                   "Stop the idle ones" } },
            { "optapp.report",              new[] { "Где подвисало",
                                                 "Where it stalled" } },
            { "optapp.ready",               new[] { "Список собран. Красным отмечено то, что работает вхолостую.",
                                                "The list is ready. The idle ones are marked." } },
            { "optapp.refreshed",           new[] { "Список перечитан.",
                                                    "The list has been re-read." } },
            { "optapp.pick",                new[] { "Выберите строку в списке.",
                                               "Pick a row in the list." } },
            { "optapp.stoppedOne",          new[] { "{0} остановлено. Вернуть: {1}",
                                                     "{0} stopped. Bring it back: {1}" } },
            { "optapp.startedOne",          new[] { "{0} запущено обратно.",
                                                     "{0} has been started again." } },
            { "optapp.confirmTitle",        new[] { "Завершить ненужное",
                                                       "Stop the idle ones" } },
            { "optapp.confirmBody",         new[] { "Остановить всё, что работает вхолостую? Каждую запись можно вернуть её же командой — они показаны в списке.",
                                                      "Stop everything that runs for nothing? Each entry comes back with its own command — they are shown in the list." } },
            { "optapp.cancelled",           new[] { "Ничего не остановлено.",
                                                    "Nothing was stopped." } },
            { "optapp.optimized",           new[] { "Готово. В журнале видно, чем вернуть каждую запись.",
                                                    "Done. The log shows how to bring each entry back." } },
            { "optapp.reportDone",          new[] { "Отчёт о подвисаниях добавлен в журнал.",
                                                     "The stall report is in the log." } },
            { "tree.perf",                  new[] { "где система подвисала",
                                             "where the system stalled" } },
            { "tree.perfTest",              new[] { "замерить операции",
                                                 "measure the operations" } },
            { "tree.optimize",              new[] { "холостая работа",
                                                 "idle work" } },
            { "tree.optimizePlan",          new[] { "что будет остановлено",
                                                     "what would be stopped" } },
            { "tree.optimizeRun",           new[] { "остановить ненужное",
                                                    "stop the idle ones" } },
            { "tree.optimizeStart",         new[] { "вернуть обратно",
                                                      "bring it back" } },

        };
    }
}
