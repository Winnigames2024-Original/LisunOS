﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    public static class CommandExecutorEngine
    {
        private static string currentVirtualDir;

        public static bool IsSuperUser { get; private set; }

        /// <summary>Список известных команд — используется автодополнением по Tab и справкой.</summary>
        public static readonly string[] KnownCommands =
        {
            "help", "ver", "whoami", "hostname", "uptime", "date", "echo", "clear", "banner",
            "pwd", "cd", "ls", "dir", "tree", "cat", "head", "stat", "du", "find",
            "touch", "write", "append", "mkdir", "rm", "rmdir", "cp", "mv",
            "apps", "services", "install", "restart", "regedit", "su", "sudo", "webview", "history", "exit",
            "lang", "layout", "apt", "perm", "ps", "kill", "sysinfo", "calc", "grep", "wc", "notify", "alias", "unalias", "ufw", "systemctl",
            "wifi", "wlan", "php-frm", "system", "service",
            "tail", "sort", "uniq", "diff", "hash", "base64", "zip", "unzip",
            "df", "free", "env", "which", "curl", "store", "daemon", "conf", "types", "user", "ssh",
            "superuser"
        };

        static CommandExecutorEngine()
        {
            currentVirtualDir = LisunEngine.RootPath;
            IsSuperUser = false;
        }

        public static string CurrentDirectory
        {
            get { return currentVirtualDir; }
        }


        // =====================================================================
        //  Сеанс по сети
        //
        //  Команды из ssh выполняет то же ядро, что и терминал, — иначе их
        //  пришлось бы писать дважды. Отличий ровно три, и все они здесь:
        //    1) у каждого сеанса своя текущая папка, чтобы cd одного клиента
        //       не уводил терминал и других клиентов;
        //    2) окна открываются на компьютере, в LisunOS, а по сети приходит
        //       только строка об этом — показать форму в текстовом канале нельзя;
        //    3) наружу из корня системы сеанс не выходит: пути Windows
        //       отклоняются, остальное и так держит TryResolveInsideRoot.
        // =====================================================================

        public sealed class RemoteSession
        {
            public string User = string.Empty;
            public string Address = string.Empty;

            /// <summary>Текущая папка этого сеанса.</summary>
            public string Directory = string.Empty;

            public DateTime Started = DateTime.Now;
            public long Commands;
        }

        /// <summary>Сеанс, от имени которого идёт команда, либо null для терминала.</summary>
        public static RemoteSession CurrentRemote { get; private set; }

        public static bool IsRemote
        {
            get { return CurrentRemote != null; }
        }

        /// <summary>
        /// Выполняет команду от имени сетевого сеанса.
        /// Вызывать только из UI-потока: ядро работает с формами.
        /// </summary>
        public static string ExecuteRemote(RemoteSession session, string input)
        {
            if (session == null) return Execute(input);

            string savedDirectory = currentVirtualDir;
            CurrentRemote = session;

            if (!string.IsNullOrEmpty(session.Directory) && Directory.Exists(session.Directory))
                currentVirtualDir = session.Directory;
            else
                session.Directory = currentVirtualDir;

            try
            {
                session.Commands++;
                return Execute(input);
            }
            finally
            {
                // Папку сеанса запоминаем, а терминалу возвращаем его собственную.
                session.Directory = currentVirtualDir;
                currentVirtualDir = savedDirectory;
                CurrentRemote = null;
            }
        }

        /// <summary>Путь текущего сеанса для приглашения в ssh.</summary>
        public static string RemotePrompt(RemoteSession session)
        {
            string path = session == null || string.IsNullOrEmpty(session.Directory)
                ? LisunEngine.RootPath
                : session.Directory;

            return CustomFormUtils.ToVirtualPath(path);
        }

        /// <summary>
        /// Окно открылось на компьютере. По сети отдаём строку вместо формы.
        /// </summary>
        private static string WindowNote(string what)
        {
            return LisunLocale.T("ssh.windowHere", what);
        }

        /// <summary>
        /// Указывает ли аргумент на файл вне виртуальной системы — диск Windows
        /// или сетевую шару. Для сеанса по сети такие пути закрыты.
        /// </summary>
        private static bool PointsOutsideRoot(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;

            string path = value.Trim().Trim('"');
            if (path.StartsWith("\\\\")) return true;
            if (path.Length > 1 && path[1] == ':') return true;

            return false;
        }

        /// <summary>
        /// От чьего имени идёт команда: в терминале — текущий пользователь,
        /// по сети — тот, кто вошёл в сеанс.
        /// </summary>
        public static string ActiveUser
        {
            get { return CurrentRemote != null ? CurrentRemote.User : LisunUsers.Current; }
        }

        /// <summary>
        /// Область, к которой относится команда. Пустая строка — область не
        /// назначена: такие команды (ls, cat, help) доступны всем.
        /// </summary>
        private static string AreaOf(string command)
        {
            switch (command)
            {
                case "touch": case "write": case "append": case "mkdir": case "rm": case "rmdir":
                case "cp": case "mv": case "zip": case "unzip": case "install":
                    return "files";

                case "apt": case "store":
                    return "packages";

                case "curl": case "wifi": case "wlan": case "webview": case "system":
                case "ssh": case "ufw": case "php-frm":
                    return "network";

                case "user":
                    return "users";

                case "regedit": case "restart": case "exit": case "systemctl": case "service":
                case "daemon": case "conf": case "lang": case "layout": case "kill": case "perm":
                    return "system";

                case "su": case "sudo": case "superuser":
                    return "superuser";

                default:
                    return string.Empty;
            }
        }

        /// <summary>
        /// Проверяет ограничение до выполнения команды. root не ограничен.
        /// </summary>
        private static string DenyByLimit(string command, bool registeredApp)
        {
            string user = ActiveUser;
            if (LisunUsers.IsRoot(user)) return null;

            string area = registeredApp ? "apps" : AreaOf(command);
            if (area.Length == 0) return null;

            if (LisunUsers.IsAllowed(user, area)) return null;

            return LisunLocale.T("user.denied", user, LisunUsers.DescribeArea(area), area);
        }

        public static string Execute(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return string.Empty;

            bool usedSudo = false;
            string line = ExpandAlias(input.Trim());
            if (line.StartsWith("sudo ", StringComparison.OrdinalIgnoreCase))
            {
                usedSudo = true;
                line = line.Substring(5).Trim();
            }

            string[] tokens = line.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (tokens.Length == 0) return string.Empty;

            string commandName = tokens[0].ToLower().Trim();

            // sudo больше не повышает права сам по себе: он лишь говорит,
            // что команду нужно выполнить в уже включённом режиме.
            // Включает режим только приложение SuperUser.
            if (usedSudo && !IsSuperUser) return LisunLocale.T("su.useApp");

            bool previousSuperUser = IsSuperUser;

            try
            {
                bool registeredApp = LisunEngine.RegisteredCommands.ContainsKey(commandName);

                // Ограничение проверяем до выполнения: иначе команда успела бы
                // изменить файл и только потом получила бы отказ.
                string denied = DenyByLimit(commandName, registeredApp);
                if (denied != null) return denied;

                string launched = TryLaunchRegisteredApp(commandName);
                if (launched != null) return launched;

                List<string> rawParams = new List<string>();
                Dictionary<string, string> namedArgs = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                for (int i = 1; i < tokens.Length; i++)
                {
                    string token = tokens[i];
                    if (token.StartsWith("-") && token.Contains(":"))
                    {
                        string[] argParts = token.TrimStart('-').Split(new[] { ':' }, 2);
                        if (argParts.Length == 2) namedArgs[argParts[0].Trim()] = argParts[1].Trim();
                    }
                    else rawParams.Add(token);
                }

                string combinedText = string.Join(" ", rawParams.ToArray());
                return Dispatch(commandName, combinedText, rawParams, namedArgs, usedSudo);
            }
            catch (Exception ex)
            {
                return " [ERROR] " + commandName + ": " + ex.Message;
            }
            finally
            {
                // Прежняя версия восстанавливала флаг ВСЕГДА — из-за этого команда su
                // сбрасывалась сразу же и режим root никогда не включался.
                // Теперь откат делается только после разового повышения через sudo.
                if (usedSudo) IsSuperUser = previousSuperUser;
            }
        }

        private static string TryLaunchRegisteredApp(string commandName)
        {
            List<string> appList;
            if (!LisunEngine.RegisteredCommands.TryGetValue(commandName, out appList)) return null;
            if (appList == null || appList.Count == 0) return null;

            string appVarName = appList[0];
            DynamicApp app;
            if (!FormEngine.ActiveApps.TryGetValue(appVarName, out app)) return null;

            app.Show();

            // Форма открывается в LisunOS на компьютере; по сети уходит строка.
            return IsRemote
                ? WindowNote(commandName)
                : " [SYS] Запущено приложение: " + commandName;
        }

        private static string Dispatch(string commandName, string combinedText,
            List<string> rawParams, Dictionary<string, string> namedArgs, bool usedSudo)
        {
            switch (commandName)
            {
                case "help": return BuildHelp();
                case "lang": return CommandLang(combinedText);
                case "layout": return CommandLayout(combinedText);
                case "banner": return BuildBanner();

                case "ver":
                case "version":
                    return " LisunOS " + LisunEngine.Version + " \"" + LisunEngine.Codename + "\"" + Environment.NewLine +
                           " Ядро: " + GetConfig("kernel_type", "Core") + Environment.NewLine +
                           " Оболочка по умолчанию: " + GetConfig("hallapp", "—");

                case "hostname": return " lisun-core";

                case "uptime":
                    TimeSpan up = LisunEngine.UptimeValue;
                    return string.Format(" Система работает: {0} ч {1} мин {2} с", (int)up.TotalHours, up.Minutes, up.Seconds);

                case "date":
                case "time":
                    return " " + DateTime.Now.ToString("dddd, dd MMMM yyyy — HH:mm:ss");

                case "echo": return " " + combinedText;

                case "clear": return "clear";

                case "whoami":
                    return " " + ActiveUser + (IsSuperUser ? LisunLocale.T("user.markSuperNow") : string.Empty);

                case "su": return CommandSu(rawParams, namedArgs, usedSudo);

                case "pwd": return " " + CustomFormUtils.ToVirtualPath(currentVirtualDir);

                case "cd": return CommandCd(combinedText);

                case "ls":
                case "dir":
                    return CommandLs();

                case "tree": return CommandTree();

                case "cat":
                case "type":
                    return CommandCat(combinedText, int.MaxValue);

                case "head": return CommandCat(combinedText, 20);

                case "stat": return CommandStat(combinedText);

                case "du": return CommandDu();

                case "find": return CommandFind(combinedText);

                case "touch": return CommandTouch(combinedText);

                case "write": return CommandWrite(rawParams, false);

                case "append": return CommandWrite(rawParams, true);

                case "mkdir": return CommandMkdir(combinedText);

                case "rm":
                case "del":
                    return CommandRemove(combinedText, false);

                case "rmdir": return CommandRemove(combinedText, true);

                case "cp": return CommandCopy(rawParams);

                case "mv":
                case "ren":
                    return CommandMove(rawParams);

                case "apps": return CommandApps();

                case "services": return CommandServices();

                case "install": return CommandInstall(combinedText);

                case "apt": return CommandApt(rawParams);

                case "perm": return CommandPerm(rawParams);

                case "ufw": return CommandUfw(rawParams);

                case "wifi":
                case "wlan":
                    return CommandWifi(rawParams);

                case "store":
                case "apps-store":
                    return CommandStore(rawParams);

                case "daemon":
                case "daemons":
                    return CommandDaemon(rawParams);

                case "conf":
                case "nginx":
                    return CommandConf(rawParams);

                case "types":
                    return LisunPackageTypes.ListText();

                case "user":
                case "users":
                    return CommandUser(rawParams);

                case "ssh":
                case "sshd":
                    return CommandSsh(rawParams);

                case "superuser":
                    return CommandSuperUser(rawParams);

                case "php-frm":
                case "phpfrm":
                    return CommandPhpFrm(rawParams);

                case "system":
                case "sysport":
                    return CommandSystemPort(rawParams);

                case "systemctl":
                case "service":
                    return CommandSystemctl(rawParams);

                case "ps": return CommandPs();

                case "kill": return CommandKill(combinedText);

                case "sysinfo": return CommandSysInfo();

                case "calc": return CommandCalc(combinedText);

                case "grep": return CommandGrep(rawParams);

                case "wc": return CommandWc(combinedText);

                case "tail": return CommandTail(rawParams);

                case "sort": return CommandSort(rawParams);

                case "uniq": return CommandUniq(rawParams);

                case "diff": return CommandDiff(rawParams);

                case "hash":
                case "checksum":
                    return CommandHash(rawParams);

                case "base64": return CommandBase64(rawParams);

                case "zip": return CommandZip(rawParams);

                case "unzip": return CommandUnzip(rawParams);

                case "df": return CommandDf();

                case "free":
                case "mem":
                    return CommandFree();

                case "env": return CommandEnv(combinedText);

                case "which": return CommandWhich(combinedText);

                case "curl":
                case "wget":
                    return CommandCurl(rawParams);

                case "notify": return CommandNotify(combinedText);

                case "alias": return CommandAlias(rawParams);

                case "unalias": return CommandUnalias(combinedText);

                case "restart":
                case "reload":
                    LisunEngine.RequestSoftRestart();
                    return " [SYS] Запрошен мягкий перезапуск подсистем...";

                case "regedit": return CommandRegedit(namedArgs);

                default:
                    return " [ERROR] " + commandName + ": команда не найдена. Введите 'help'.";
            }
        }

        // ---------- реализация команд ----------

        /// <summary>
        /// su и sudo больше не включают режим суперпользователя из терминала:
        /// пароль в строке — плохая защита, его видно в истории и в журнале.
        /// Право superuser выдаётся приложением SuperUser, по одному пакету.
        /// Выключить режим из терминала по-прежнему можно: это не повышение прав.
        /// </summary>
        private static string CommandSu(List<string> rawParams, Dictionary<string, string> namedArgs, bool usedSudo)
        {
            if (IsSuperUser && !usedSudo)
            {
                IsSuperUser = false;
                return LisunLocale.T("su.turnedOff");
            }

            return LisunLocale.T("su.useApp");
        }

        /// <summary>
        /// Включает режим суперпользователя. Единственный разрешённый путь —
        /// приложение SuperUser: оно спрашивает подтверждение у пользователя.
        /// </summary>
        public static bool ElevateFromSuperUserApp(string packageName)
        {
            if (string.IsNullOrEmpty(packageName)) return false;
            if (!LisunPermissions.IsGranted(packageName, LisunPermissions.Superuser)) return false;

            IsSuperUser = true;
            LisunEngine.Log("[su] " + LisunLocale.T("su.granted", packageName).Trim());
            return true;
        }

        /// <summary>Снимает режим суперпользователя.</summary>
        /// <summary>
        /// superuser — открыть приложение выдачи прав.
        /// Прав из терминала больше нет: su сообщает об ошибке, а выдача идёт
        /// только через это окно, поэтому команда лишь показывает его.
        /// </summary>
        private static string CommandSuperUser(List<string> rawParams)
        {
            if (rawParams.Count > 0)
            {
                string action = rawParams[0].ToLowerInvariant();
                if (action == "help" || action == "?" || action == "usage")
                    return LisunLocale.T("suapp.usage");
            }

            string launched = TryLaunchRegisteredApp("su-app");
            if (launched != null) return IsRemote ? WindowNote("superuser") : LisunLocale.T("suapp.opened");

            foreach (KeyValuePair<string, DynamicApp> pair in FormEngine.ActiveApps)
            {
                if (pair.Key.IndexOf("superuser", StringComparison.OrdinalIgnoreCase) < 0) continue;

                pair.Value.Show();
                return IsRemote ? WindowNote("superuser") : LisunLocale.T("suapp.opened");
            }

            return LisunLocale.T("suapp.missing");
        }

        public static void DropElevation()
        {
            if (!IsSuperUser) return;

            IsSuperUser = false;
            LisunEngine.Log("[su] " + LisunLocale.T("su.turnedOff").Trim());
        }

        private static string CommandCd(string target)
        {
            if (string.IsNullOrEmpty(target) || target == "~" || target == "/" || target == "\\")
            {
                currentVirtualDir = LisunEngine.RootPath;
                return " " + CustomFormUtils.ToVirtualPath(currentVirtualDir);
            }

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] cd: выход за пределы корня LisunOS запрещён.";

            if (!Directory.Exists(resolved))
                return " [ERROR] cd: каталог не найден — " + target;

            currentVirtualDir = resolved;
            return " " + CustomFormUtils.ToVirtualPath(currentVirtualDir);
        }

        private static string CommandLs()
        {
            List<string> dirs;
            List<string> files = CustomFormUtils.GetDirectoryContent(currentVirtualDir, out dirs);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" " + CustomFormUtils.ToVirtualPath(currentVirtualDir));
            sb.AppendLine();

            foreach (string d in dirs) sb.AppendLine("   <DIR>    " + d);

            foreach (string f in files)
            {
                long size = 0;
                try { size = new FileInfo(Path.Combine(currentVirtualDir, f)).Length; }
                catch { }
                sb.AppendLine("   " + CustomFormUtils.FormatSize(size).PadLeft(8) + "  " + f);
            }

            if (dirs.Count == 0 && files.Count == 0) sb.AppendLine("   (пусто)");
            else sb.AppendLine(Environment.NewLine + "   Каталогов: " + dirs.Count + ", файлов: " + files.Count);

            return sb.ToString().TrimEnd();
        }

        private static string CommandTree()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" " + CustomFormUtils.ToVirtualPath(currentVirtualDir));
            AppendTree(currentVirtualDir, "   ", 0, sb);
            return sb.ToString().TrimEnd();
        }

        private static void AppendTree(string path, string prefix, int depth, StringBuilder sb)
        {
            if (depth > 4) return;

            string[] dirs;
            string[] files;
            try
            {
                dirs = Directory.GetDirectories(path);
                files = Directory.GetFiles(path);
            }
            catch { return; }

            for (int i = 0; i < dirs.Length; i++)
            {
                bool last = (i == dirs.Length - 1) && files.Length == 0;
                sb.AppendLine(prefix + (last ? "└── " : "├── ") + Path.GetFileName(dirs[i]) + "\\");
                AppendTree(dirs[i], prefix + (last ? "    " : "│   "), depth + 1, sb);
            }

            for (int i = 0; i < files.Length; i++)
            {
                bool last = i == files.Length - 1;
                sb.AppendLine(prefix + (last ? "└── " : "├── ") + Path.GetFileName(files[i]));
            }
        }

        private static string CommandCat(string target, int maxLines)
        {
            if (string.IsNullOrEmpty(target)) return " [ERROR] Укажите имя файла.";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            string text = CustomFormUtils.ReadFileText(resolved);
            if (maxLines == int.MaxValue) return text;

            string[] lines = text.Split('\n');
            if (lines.Length <= maxLines) return text;

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < maxLines; i++) sb.AppendLine(lines[i].TrimEnd('\r'));
            sb.AppendLine("   ... ещё строк: " + (lines.Length - maxLines));
            return sb.ToString();
        }

        private static string CommandStat(string target)
        {
            if (string.IsNullOrEmpty(target)) return " [ERROR] Укажите объект.";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            if (Directory.Exists(resolved))
            {
                DirectoryInfo di = new DirectoryInfo(resolved);
                return " Каталог : " + di.Name + Environment.NewLine +
                       " Путь    : " + CustomFormUtils.ToVirtualPath(di.FullName) + Environment.NewLine +
                       " Создан  : " + di.CreationTime.ToString("dd.MM.yyyy HH:mm") + Environment.NewLine +
                       " Изменён : " + di.LastWriteTime.ToString("dd.MM.yyyy HH:mm");
            }

            if (File.Exists(resolved))
            {
                FileInfo fi = new FileInfo(resolved);
                return " Файл    : " + fi.Name + Environment.NewLine +
                       " Путь    : " + CustomFormUtils.ToVirtualPath(fi.FullName) + Environment.NewLine +
                       " Размер  : " + CustomFormUtils.FormatSize(fi.Length) + Environment.NewLine +
                       " Изменён : " + fi.LastWriteTime.ToString("dd.MM.yyyy HH:mm");
            }

            return " [ERROR] Объект не найден: " + target;
        }

        private static string CommandDu()
        {
            long total = 0;
            int count = 0;
            try
            {
                foreach (string file in Directory.GetFiles(currentVirtualDir, "*", SearchOption.AllDirectories))
                {
                    try { total += new FileInfo(file).Length; count++; }
                    catch { }
                }
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }

            return " Файлов: " + count + ", суммарный объём: " + CustomFormUtils.FormatSize(total);
        }

        private static string CommandFind(string mask)
        {
            if (string.IsNullOrEmpty(mask)) return " [ERROR] Укажите маску поиска, например: find *.service";

            try
            {
                string[] hits = Directory.GetFiles(currentVirtualDir, mask, SearchOption.AllDirectories);
                if (hits.Length == 0) return " Совпадений не найдено.";

                StringBuilder sb = new StringBuilder();
                foreach (string hit in hits) sb.AppendLine("   " + CustomFormUtils.ToVirtualPath(hit));
                sb.AppendLine(Environment.NewLine + "   Найдено: " + hits.Length);
                return sb.ToString().TrimEnd();
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        private static string CommandTouch(string target)
        {
            if (string.IsNullOrEmpty(target)) return " [ERROR] Укажите имя файла.";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            if (File.Exists(resolved))
            {
                try { File.SetLastWriteTime(resolved, DateTime.Now); } catch { }
                return " [OK] Время изменения обновлено: " + target;
            }

            return CustomFormUtils.WriteFileText(resolved, string.Empty)
                ? " [OK] Файл создан: " + target
                : " [ERROR] Не удалось создать файл.";
        }

        private static string CommandWrite(List<string> rawParams, bool append)
        {
            if (rawParams.Count < 2) return " [ERROR] Формат: " + (append ? "append" : "write") + " <файл> <текст>";

            string name = rawParams[0];
            string text = string.Join(" ", rawParams.GetRange(1, rawParams.Count - 1).ToArray());

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, name, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            bool ok = append
                ? CustomFormUtils.AppendFileText(resolved, text + Environment.NewLine)
                : CustomFormUtils.WriteFileText(resolved, text);

            return ok ? " [OK] Записано в " + name : " [ERROR] Запись не удалась.";
        }

        private static string CommandMkdir(string target)
        {
            if (string.IsNullOrEmpty(target)) return " [ERROR] Укажите имя каталога.";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            return CustomFormUtils.CreateFolder(resolved)
                ? " [OK] Каталог создан: " + target
                : " [ERROR] Каталог уже существует или недоступен.";
        }

        private static string CommandRemove(string target, bool directory)
        {
            if (string.IsNullOrEmpty(target)) return " [ERROR] Укажите объект.";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, target, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            if (string.Equals(resolved.TrimEnd(Path.DirectorySeparatorChar),
                              LisunEngine.RootPath.TrimEnd(Path.DirectorySeparatorChar),
                              StringComparison.OrdinalIgnoreCase))
                return " [ERROR] Удаление корня системы заблокировано.";

            if (directory)
            {
                return CustomFormUtils.DeleteFolder(resolved)
                    ? " [OK] Каталог удалён: " + target
                    : " [ERROR] Каталог не найден.";
            }

            if (Directory.Exists(resolved))
            {
                if (!IsSuperUser) return " [ERROR] Это каталог. Используйте rmdir или sudo rm.";
                return CustomFormUtils.DeleteFolder(resolved)
                    ? " [OK] Каталог удалён: " + target
                    : " [ERROR] Удаление не удалось.";
            }

            return CustomFormUtils.DeleteFile(resolved)
                ? " [OK] Файл удалён: " + target
                : " [ERROR] Файл не найден.";
        }

        private static string CommandCopy(List<string> rawParams)
        {
            if (rawParams.Count < 2) return " [ERROR] Формат: cp <источник> <назначение>";

            string source, destination;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out source) ||
                !CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[1], out destination))
                return " [ERROR] Доступ за пределы корня запрещён.";

            try
            {
                if (!File.Exists(source)) return " [ERROR] Источник не найден.";
                if (Directory.Exists(destination)) destination = Path.Combine(destination, Path.GetFileName(source));

                File.Copy(source, destination, true);
                return " [OK] Скопировано.";
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        private static string CommandMove(List<string> rawParams)
        {
            if (rawParams.Count < 2) return " [ERROR] Формат: mv <источник> <назначение>";

            string source, destination;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out source) ||
                !CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[1], out destination))
                return " [ERROR] Доступ за пределы корня запрещён.";

            try
            {
                if (Directory.Exists(destination)) destination = Path.Combine(destination, Path.GetFileName(source));

                if (File.Exists(source))
                {
                    if (File.Exists(destination)) File.Delete(destination);
                    File.Move(source, destination);
                    return " [OK] Перемещено.";
                }
                if (Directory.Exists(source))
                {
                    Directory.Move(source, destination);
                    return " [OK] Каталог перемещён.";
                }
                return " [ERROR] Источник не найден.";
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        private static string CommandApps()
        {
            if (FormEngine.ActiveApps.Count == 0) return " Активных приложений нет.";

            StringBuilder sb = new StringBuilder(" Загруженные приложения:" + Environment.NewLine);
            foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
            {
                DynamicApp app = kvp.Value;
                sb.AppendLine("   • " + kvp.Key +
                              "  namespace: " + (string.IsNullOrEmpty(app.Namespace) ? "—" : app.Namespace) +
                              "  форма: " + (app.Form == null ? "не собрана" : "готова"));
            }
            return sb.ToString().TrimEnd();
        }

        private static string CommandServices()
        {
            if (!Directory.Exists(LisunEngine.ServicesPath)) return " Каталог сервисов отсутствует.";

            StringBuilder sb = new StringBuilder(" Установленные сервисы:" + Environment.NewLine);
            int count = 0;
            foreach (string dir in Directory.GetDirectories(LisunEngine.ServicesPath))
            {
                string[] scripts = Directory.GetFiles(dir, "*.service");
                sb.AppendLine("   • " + Path.GetFileName(dir) + "  (сценариев: " + scripts.Length + ")");
                count++;
            }
            if (count == 0) sb.AppendLine("   (пусто)");
            return sb.ToString().TrimEnd();
        }

        private static string CommandInstall(string package)
        {
            if (string.IsNullOrEmpty(package)) return " [ERROR] Формат: install <путь к .lnsh>";

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, package, out resolved))
                resolved = package;

            if (!File.Exists(resolved))
            {
                if (LisunRepository.Find(package) != null)
                {
                    string message;
                    LisunRepository.Install(package, IsSuperUser, out message);
                    return message;
                }

                return " [ERROR] Пакет не найден: " + package;
            }

            // Права передаются в установщик: через sudo / su можно ставить оболочки (type = hall).
            return LisunOSInstallerShell.InstallPackage(resolved, IsSuperUser)
                ? " [OK] Пакет установлен."
                : " [ERROR] Установка прервана — подробности в журнале ядра.";
        }

        private static string CommandRegedit(Dictionary<string, string> namedArgs)
        {
            if (namedArgs.ContainsKey("config")) return DumpRegistry("CONFIG", LisunEngine.RegistryConfig);
            if (namedArgs.ContainsKey("data")) return DumpRegistry("DATA", LisunEngine.RegistryData);

            if (namedArgs.ContainsKey("commands"))
            {
                if (!File.Exists(LisunEngine.RegCommandsFilePath)) return " Файл COMMANDS пуст.";

                StringBuilder sb = new StringBuilder(" [REGEDIT // COMMANDS]" + Environment.NewLine);
                foreach (string line in File.ReadAllLines(LisunEngine.RegCommandsFilePath)) sb.AppendLine("   • " + line);
                return sb.ToString().TrimEnd();
            }

            if (namedArgs.ContainsKey("set") && namedArgs.ContainsKey("val"))
            {
                string key = namedArgs["set"].Trim();
                string val = namedArgs["val"].Trim();
                string lowered = key.ToLower();

                bool protectedKey = lowered == "hallapp" || lowered == "hall" || lowered == "lisunhallkey";
                if (protectedKey && !IsSuperUser)
                    return " [ERROR] Ключ защищён. Требуется sudo или su.";

                if (lowered == "hallapp" || lowered == "lisunhallkey") LisunEngine.RegistryConfig[lowered] = val;
                else LisunEngine.RegistryData[lowered] = val;

                LisunEngine.SaveRegistry();
                return " [OK] Запись сохранена: " + lowered + " = " + val;
            }

            return " Формат: regedit -config | -data | -commands | -set:<ключ> -val:<значение>";
        }

        private static string DumpRegistry(string title, Dictionary<string, string> source)
        {
            StringBuilder sb = new StringBuilder(" [REGEDIT // " + title + "]" + Environment.NewLine);
            foreach (KeyValuePair<string, string> kvp in source) sb.AppendLine("   " + kvp.Key.PadRight(18) + " = " + kvp.Value);
            return sb.ToString().TrimEnd();
        }

        private static string GetConfig(string key, string fallback)
        {
            string value;
            return LisunEngine.RegistryConfig.TryGetValue(key, out value) ? value : fallback;
        }

        /// <summary>lang | lang list | lang &lt;код&gt; | lang export &lt;код&gt; | lang reload</summary>
        private static string CommandLang(string argument)
        {
            if (string.IsNullOrEmpty(argument)) return LisunLocale.ListText();

            string[] parts = argument.Trim().Split(new[] { ' ' }, 2);
            string action = parts[0].ToLowerInvariant();
            string value = parts.Length > 1 ? parts[1].Trim() : string.Empty;

            switch (action)
            {
                case "list":
                case "ls":
                    return LisunLocale.ListText();

                case "reload":
                    return LisunLocale.T("lang.reloaded", LisunLocale.LoadPacks());

                case "export":
                case "template":
                {
                    if (value.Length == 0) return LisunLocale.T("lang.usage");

                    string path;
                    if (!LisunLocale.ExportTemplate(value, out path))
                        return LisunLocale.T("lang.exportFailed");

                    return LisunLocale.T("lang.exported",
                        CustomFormUtils.ToVirtualPath(path), value.Trim().ToLowerInvariant());
                }
            }

            if (!LisunLocale.SetLanguage(argument.Trim()))
                return LisunLocale.T("lang.unknown", argument.Trim());

            return LisunLocale.T("msg.langChanged", LisunLocale.DisplayName);
        }

        private static string CommandLayout(string argument)
        {
            if (string.IsNullOrEmpty(argument))
                return LisunLocale.T("msg.layoutUsage", LisunLocale.LayoutTag, LisunLocale.InstalledLayouts());

            string target = argument.Trim().ToLowerInvariant();

            if (target == "next" || target == "switch" || target == "toggle")
            {
                return LisunLocale.CycleLayout()
                    ? LisunLocale.T("msg.layoutChanged", LisunLocale.LayoutTag)
                    : LisunLocale.T("msg.layoutFailed");
            }

            return LisunLocale.SetLayout(target)
                ? LisunLocale.T("msg.layoutChanged", LisunLocale.LayoutTag)
                : LisunLocale.T("msg.layoutMissing", target.ToUpperInvariant());
        }

        private static string CommandApt(List<string> args)
        {
            if (args.Count == 0) return LisunLocale.T("apt.usage");

            string action = args[0].ToLowerInvariant();
            string target = args.Count > 1
                ? string.Join(" ", args.GetRange(1, args.Count - 1).ToArray()).Trim()
                : string.Empty;

            switch (action)
            {
                case "list": return AptList();
                case "catalog":
                case "available":
                case "search":
                    return LisunRepository.Describe();
                case "info": return AptInfo(target);
                case "install": return AptInstall(target);
                case "update":
                case "upgrade":
                    return AptUpdate(target);
                case "remove":
                case "uninstall":
                    return AptRemove(target);
                case "protect": return AptProtect(target, true);
                case "unprotect": return AptProtect(target, false);
                default: return LisunLocale.T("apt.usage");
            }
        }

        /// <summary>php-frm, php, php-fpm — всё это один системный модуль PHP.</summary>
        private static bool IsPhpModuleName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            name = name.Trim().ToLowerInvariant();

            return name == "php-frm" || name == "php" || name == "php-fpm" ||
                   name == "php-cgi" || name == "phpfrm";
        }

        private static string AptList()
        {
            List<string> directories = LisunOSInstallerShell.InstalledPackageDirectories();
            if (directories.Count == 0) return LisunLocale.T("apt.listEmpty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("apt.listTitle") + Environment.NewLine);

            sb.AppendLine("   • " + LisunPhpModule.PackageName.PadRight(16) + " —          [" +
                          (LisunPhpModule.IsInstalled ? LisunLocale.T("php.on") : LisunLocale.T("php.off")) + "]");

            foreach (string directory in directories)
            {
                LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);

                string state = LisunCrypto.IsPackageProtected(directory)
                    ? LisunLocale.T("apt.state")
                    : LisunLocale.T("apt.stateOpen");

                int granted = LisunPermissions.GrantedFor(manifest.Name).Length;

                sb.AppendLine("   • " + manifest.Name.PadRight(16) +
                              " v" + manifest.Version.PadRight(9) +
                              " [" + state + "]  " +
                              LisunLocale.T("apt.rights") + ": " + granted + "/" + manifest.Permissions.Count);
                sb.AppendLine("       " + manifest.DisplayName +
                              (string.IsNullOrEmpty(manifest.Description) ? "" : "  —  " + manifest.Description));
            }
            return sb.ToString().TrimEnd();
        }

        private static string AptInfo(string name)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("apt.usage");

            if (IsPhpModuleName(name)) return LisunPhpModule.Status();

            string directory = LisunOSInstallerShell.FindInstalledPackage(name);
            if (directory == null) return LisunLocale.T("apt.notFound", name);

            LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(manifest.Summary());
            sb.AppendLine("   protected    : " + LisunCrypto.IsPackageProtected(directory));

            string[] granted = LisunPermissions.GrantedFor(manifest.Name);
            sb.AppendLine("   granted      : " + (granted.Length == 0 ? "—" : string.Join(", ", granted)));
            return sb.ToString().TrimEnd();
        }

        private static string AptInstall(string target)
        {
            if (string.IsNullOrEmpty(target)) return LisunLocale.T("apt.installUsage");

            // По сети ставим только из каталога и по ссылке: путь вроде
            // C:\... вывел бы сеанс за пределы виртуальной системы.
            if (IsRemote && PointsOutsideRoot(target)) return LisunLocale.T("ssh.outsideRoot");

            // Системный модуль PHP: apt install php-frm [путь к php-cgi.exe]
            string[] phpArgs = target.Split(new[] { ' ' }, 2);
            if (IsPhpModuleName(phpArgs[0]))
            {
                string explicitPath = phpArgs.Length > 1 ? phpArgs[1].Trim().Trim('"') : null;

                // Источник PHP указывают путём на диске — по сети это закрыто.
                if (IsRemote && PointsOutsideRoot(explicitPath)) return LisunLocale.T("ssh.outsideRoot");

                string message;
                LisunPhpModule.Install(explicitPath, out message);
                return message;
            }

            // Имя без пути и без расширения — это пакет из каталога на сайте:
            // apt install webserverv2 скачивает .lnsh по ссылке из catalog.json.
            // Сайт идёт первым: там лежит свежая сборка, а встроенная копия
            // остаётся резервом на случай, когда сети нет.
            if (!LooksLikePackageFile(target))
            {
                string fromCatalog = AptInstallFromCatalog(target);
                if (fromCatalog != null) return fromCatalog;

                if (LisunRepository.Find(target) != null)
                {
                    string message;
                    LisunRepository.Install(target, IsSuperUser, out message);
                    return LisunLocale.T("apt.fromBuiltIn", target) + Environment.NewLine + message;
                }
            }
            else if (LisunRepository.Find(target) != null)
            {
                string message;
                LisunRepository.Install(target, IsSuperUser, out message);
                return message;
            }

            return CommandInstall(target);
        }

        /// <summary>
        /// Похоже ли на путь к готовому архиву .lnsh, а не на имя пакета.
        /// </summary>
        private static bool LooksLikePackageFile(string target)
        {
            if (string.IsNullOrEmpty(target)) return false;

            string value = target.Trim().Trim('"');
            if (value.IndexOf('/') >= 0 || value.IndexOf('\\') >= 0) return true;
            if (value.EndsWith(".lnsh", StringComparison.OrdinalIgnoreCase)) return true;
            if (value.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) return true;

            return false;
        }

        /// <summary>
        /// Ищет пакет по имени или команде в каталоге с сайта и ставит его.
        /// Возвращает null, если такого имени в каталоге нет —
        /// тогда apt попробует считать аргумент путём к файлу.
        /// </summary>
        private static string AptInstallFromCatalog(string name)
        {
            name = (name ?? string.Empty).Trim();
            if (name.Length == 0) return null;

            // Каталог читается один раз за сеанс; если в нём ещё ничего нет
            // или нужного имени не видно — обновляем его с сайта.
            LisunStore.StoreItem item = LisunStore.FindRemote(name);
            if (item == null)
            {
                string refreshMessage;
                if (!LisunStore.Refresh(ShellName, out refreshMessage))
                {
                    // Сети нет или право network не выдано: пусть решает встроенный каталог.
                    LisunEngine.Log("[apt] " + (refreshMessage ?? string.Empty).Trim());
                    return null;
                }

                item = LisunStore.FindRemote(name);
            }

            if (item == null) return null;

            if (item.Installed) return LisunLocale.T("apt.alreadyInstalled", item.Name);

            string message;
            LisunStore.Install(item, IsSuperUser, out message);
            return LisunLocale.T("apt.fromSite", item.Name, item.Version.Length > 0 ? item.Version : "—") +
                   Environment.NewLine + message;
        }

        private static string AptUpdate(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                string message;
                return LisunOSInstallerShell.UpdatePackage(name, IsSuperUser, out message)
                    ? LisunLocale.T("apt.updated", name, message)
                    : LisunLocale.T("apt.updateFailed", name, message);
            }

            List<string> directories = LisunOSInstallerShell.InstalledPackageDirectories();
            if (directories.Count == 0) return LisunLocale.T("apt.listEmpty");

            StringBuilder sb = new StringBuilder();
            foreach (string directory in directories)
            {
                string packageName = LisunOSInstallerShell.ReadManifest(directory).Name;

                string message;
                sb.AppendLine(LisunOSInstallerShell.UpdatePackage(packageName, IsSuperUser, out message)
                    ? LisunLocale.T("apt.updated", packageName, message)
                    : LisunLocale.T("apt.updateFailed", packageName, message));
            }
            return sb.ToString().TrimEnd();
        }

        private static string AptRemove(string name)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("apt.usage");
            if (!IsSuperUser) return LisunLocale.T("apt.needSudo");

            if (IsPhpModuleName(name))
            {
                string message;
                LisunPhpModule.Uninstall(out message);
                return message;
            }

            return LisunOSInstallerShell.UninstallPackage(name)
                ? LisunLocale.T("apt.removed", name)
                : LisunLocale.T("apt.notFound", name);
        }

        private static string AptProtect(string name, bool protect)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("apt.usage");
            if (!protect && !IsSuperUser) return LisunLocale.T("apt.needSudo");

            string directory = LisunOSInstallerShell.FindInstalledPackage(name);
            if (directory == null) return LisunLocale.T("apt.notFound", name);

            int count = protect
                ? LisunCrypto.ProtectPackage(directory)
                : LisunCrypto.UnprotectPackage(directory);

            return protect
                ? LisunLocale.T("apt.protected", name, count)
                : LisunLocale.T("apt.unprotected", name, count);
        }

        // =====================================================================
        //  Разрешения приложений
        // =====================================================================

        private static string CommandPerm(List<string> args)
        {
            if (args.Count == 0) return LisunLocale.T("perm.usage");

            string action = args[0].ToLowerInvariant();

            switch (action)
            {
                case "all":
                case "help":
                    return LisunPermissions.DescribeAll();

                case "list":
                    return LisunPermissions.ListAllGrants();

                case "app":
                case "show":
                    if (args.Count < 2) return LisunLocale.T("perm.usage");
                    return LisunPermissions.ListFor(ResolvePackageName(args[1]));

                case "grant":
                case "revoke":
                    {
                        if (args.Count < 3) return LisunLocale.T("perm.usage");
                        if (!IsSuperUser) return LisunLocale.T("perm.needSudo");

                        string application = ResolvePackageName(args[1]);
                        string permission = args[2].Trim().ToLowerInvariant();

                        if (!LisunPermissions.IsKnown(permission)) return LisunLocale.T("perm.badName", permission);

                        if (action == "grant")
                        {
                            LisunPermissions.Grant(application, permission);
                            return LisunLocale.T("perm.granted", application, permission);
                        }

                        LisunPermissions.Revoke(application, permission);
                        return LisunLocale.T("perm.revoked", application, permission);
                    }

                case "reset":
                    {
                        if (args.Count < 2) return LisunLocale.T("perm.usage");
                        if (!IsSuperUser) return LisunLocale.T("perm.needSudo");

                        string application = ResolvePackageName(args[1]);
                        LisunPermissions.Reset(application);
                        return LisunLocale.T("perm.resetDone", application);
                    }

                default:
                    return LisunLocale.T("perm.usage");
            }
        }

        /// <summary>Приводит имя пакета к каноническому name из манифеста.</summary>
        private static string ResolvePackageName(string name)
        {
            string directory = LisunOSInstallerShell.FindInstalledPackage(name);
            if (directory == null) return name.Trim();

            return LisunOSInstallerShell.ReadManifest(directory).Name;
        }

        // =====================================================================
        //  Брандмауэр ufw
        // =====================================================================

        private static string CommandUfw(List<string> args)
        {
            if (args.Count == 0) return LisunFirewall.Status();

            string action = args[0].ToLowerInvariant();

            switch (action)
            {
                case "status":
                case "show":
                    return LisunFirewall.Status();

                case "enable":
                case "on":
                    if (!IsSuperUser) return LisunLocale.T("ufw.needSudo");
                    LisunFirewall.Enable();
                    return LisunLocale.T("ufw.enabled");

                case "disable":
                case "off":
                    if (!IsSuperUser) return LisunLocale.T("ufw.needSudo");
                    LisunFirewall.Disable();
                    return LisunLocale.T("ufw.disabled");

                case "default":
                    {
                        if (args.Count < 2) return LisunLocale.T("ufw.usage");
                        if (!IsSuperUser) return LisunLocale.T("ufw.needSudo");

                        bool allow = IsAllowWord(args[1]);
                        LisunFirewall.SetDefault(allow);
                        return LisunLocale.T("ufw.defaultSet",
                            allow ? LisunLocale.T("ufw.allowed") : LisunLocale.T("ufw.denied"));
                    }

                case "reset":
                    if (!IsSuperUser) return LisunLocale.T("ufw.needSudo");
                    LisunFirewall.Reset();
                    return LisunLocale.T("ufw.resetDone");

                case "port":
                case "allow":
                case "deny":
                    return CommandUfwPort(action, args);

                default:
                    {
                        // Короткая форма: ufw 8080 enable
                        int shortPort;
                        if (int.TryParse(action, out shortPort))
                        {
                            List<string> shifted = new List<string>();
                            shifted.Add("port");
                            shifted.AddRange(args);
                            return CommandUfwPort("port", shifted);
                        }

                        return LisunLocale.T("ufw.usage");
                    }
            }
        }

        private static string CommandUfwPort(string action, List<string> args)
        {
            if (args.Count < 2) return LisunLocale.T("ufw.usage");

            int port;
            if (!int.TryParse(args[1].Trim(), out port) || port < 1 || port > 65535)
                return LisunLocale.T("ufw.badPort", args[1]);

            if (!IsSuperUser) return LisunLocale.T("ufw.needSudo");

            // ufw allow 8080 | ufw deny 8080 | ufw port 8080 enable|disable|remove
            if (action == "allow") { LisunFirewall.SetPort(port, true); return LisunLocale.T("ufw.portAllowed", port); }
            if (action == "deny") { LisunFirewall.SetPort(port, false); return LisunLocale.T("ufw.portDenied", port); }

            if (args.Count < 3) return LisunLocale.T("ufw.portState", port, LisunFirewall.Describe(port));

            string state = args[2].Trim().ToLowerInvariant();

            if (state == "remove" || state == "delete" || state == "clear")
            {
                return LisunFirewall.RemovePort(port)
                    ? LisunLocale.T("ufw.portRemoved", port)
                    : LisunLocale.T("ufw.noPortRule", port);
            }

            bool allow = IsAllowWord(state);
            LisunFirewall.SetPort(port, allow);

            return allow ? LisunLocale.T("ufw.portAllowed", port) : LisunLocale.T("ufw.portDenied", port);
        }

        private static bool IsAllowWord(string value)
        {
            if (string.IsNullOrEmpty(value)) return false;
            value = value.Trim().ToLowerInvariant();

            return value == "enable" || value == "allow" || value == "on" ||
                   value == "open" || value == "true" || value == "yes";
        }

        // =====================================================================
        //  Диспетчер служб systemctl
        // =====================================================================

        private static string CommandSystemctl(List<string> args)
        {
            if (args.Count == 0) return LisunServiceManager.List();

            string action = args[0].ToLowerInvariant();
            string name = args.Count > 1
                ? string.Join(" ", args.GetRange(1, args.Count - 1).ToArray()).Trim()
                : string.Empty;

            switch (action)
            {
                case "list":
                case "list-units":
                    return LisunServiceManager.List();

                case "status":
                    return name.Length == 0 ? LisunServiceManager.List() : LisunServiceManager.Status(name);

                case "start":
                    if (name.Length == 0) return LisunLocale.T("systemctl.usage");
                    return LisunServiceManager.Start(name)
                        ? LisunLocale.T("systemctl.started", name)
                        : LisunLocale.T("systemctl.notFound", name);

                case "stop":
                    if (name.Length == 0) return LisunLocale.T("systemctl.usage");
                    return LisunServiceManager.Stop(name)
                        ? LisunLocale.T("systemctl.stopped", name)
                        : LisunLocale.T("systemctl.notRunning", name);

                case "restart":
                case "reload":
                    if (name.Length == 0) return LisunLocale.T("systemctl.usage");
                    return LisunServiceManager.Restart(name)
                        ? LisunLocale.T("systemctl.restarted", name)
                        : LisunLocale.T("systemctl.notFound", name);

                case "enable":
                case "disable":
                    {
                        if (name.Length == 0) return LisunLocale.T("systemctl.usage");
                        if (!IsSuperUser) return LisunLocale.T("systemctl.needSudo");

                        bool enable = action == "enable";
                        if (!LisunServiceManager.SetEnabled(name, enable))
                            return LisunLocale.T("systemctl.notFound", name);

                        return enable
                            ? LisunLocale.T("systemctl.enabledNow", name)
                            : LisunLocale.T("systemctl.disabledNow", name);
                    }

                default:
                    return LisunLocale.T("systemctl.usage");
            }
        }

        // =====================================================================
        //  Процессы и сведения о системе
        // =====================================================================

        private static string CommandPs()
        {
            if (FormEngine.ActiveApps.Count == 0) return LisunLocale.T("ps.empty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("ps.title") + Environment.NewLine);
            int pid = 1;

            foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
            {
                DynamicApp app = kvp.Value;
                string state = app.Form == null
                    ? LisunLocale.T("ps.noForm")
                    : (app.Form.Visible ? LisunLocale.T("ps.running") : LisunLocale.T("ps.idle"));

                sb.AppendLine("   " + pid.ToString().PadLeft(3) + "  " + kvp.Key.PadRight(16) +
                              (app.PackageName ?? "—").PadRight(16) + state);
                pid++;
            }
            return sb.ToString().TrimEnd();
        }

        private static string CommandKill(string name)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("kill.usage");

            foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
            {
                if (!kvp.Key.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase)) continue;

                FormEngine.CloseApplication(kvp.Key);
                return LisunLocale.T("kill.done", kvp.Key);
            }

            return LisunLocale.T("kill.notFound", name);
        }

        private static string CommandSysInfo()
        {
            TimeSpan up = LisunEngine.UptimeValue;
            long memory = GC.GetTotalMemory(false);

            StringBuilder sb = new StringBuilder(LisunLocale.T("sysinfo.title") + Environment.NewLine);
            sb.AppendLine("   LisunOS      : " + LisunEngine.Version + " \"" + LisunEngine.Codename + "\"");
            sb.AppendLine("   kernel       : " + GetConfig("kernel_type", "Core"));
            sb.AppendLine("   hall         : " + GetConfig("hallapp", "—"));
            sb.AppendLine("   user         : " + (IsSuperUser ? "root" : LisunEngine.UserName));
            sb.AppendLine("   language     : " + LisunLocale.ManifestTag);
            sb.AppendLine("   layout       : " + LisunLocale.LayoutTag + "  (" + LisunLocale.InstalledLayouts() + ")");
            sb.AppendLine("   uptime       : " + (int)up.TotalHours + "h " + up.Minutes + "m " + up.Seconds + "s");
            sb.AppendLine("   memory       : " + CustomFormUtils.FormatSize(memory));
            sb.AppendLine("   apps         : " + FormEngine.ActiveApps.Count);
            sb.AppendLine("   packages     : " + LisunOSInstallerShell.InstalledPackageDirectories().Count);
            sb.AppendLine("   commands     : " + LisunEngine.RegisteredCommands.Count);
            sb.AppendLine("   root         : " + CustomFormUtils.ToVirtualPath(LisunEngine.RootPath));
            sb.AppendLine("   host         : " + Environment.OSVersion.VersionString);
            sb.AppendLine("   clr          : " + Environment.Version);
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Вспомогательные утилиты
        // =====================================================================

        /// <summary>Калькулятор: + - * / % ^ и скобки.</summary>
        /// <summary>
        /// Разбор выражения для других частей системы — например,
        /// для окна Калькулятора, чтобы оно считало ровно как команда calc.
        /// </summary>
        public static bool TryEvaluate(string expression, out double value)
        {
            value = 0;
            if (string.IsNullOrEmpty(expression)) return false;

            try
            {
                int position = 0;
                double parsed = ParseExpression(expression, ref position);

                SkipSpaces(expression, ref position);
                if (position < expression.Length) return false;

                if (double.IsNaN(parsed) || double.IsInfinity(parsed)) return false;

                value = parsed;
                return true;
            }
            catch { return false; }
        }

        private static string CommandCalc(string expression)
        {
            if (string.IsNullOrEmpty(expression)) return LisunLocale.T("calc.usage");

            try
            {
                int position = 0;
                double value = ParseExpression(expression, ref position);

                SkipSpaces(expression, ref position);
                if (position < expression.Length) return LisunLocale.T("calc.bad", expression);

                return " " + expression.Trim() + " = " +
                       value.ToString("0.##########", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch
            {
                return LisunLocale.T("calc.bad", expression);
            }
        }

        private static double ParseExpression(string s, ref int i)
        {
            double value = ParseTerm(s, ref i);

            while (true)
            {
                SkipSpaces(s, ref i);
                if (i >= s.Length) break;

                char op = s[i];
                if (op != '+' && op != '-') break;

                i++;
                double right = ParseTerm(s, ref i);
                value = op == '+' ? value + right : value - right;
            }
            return value;
        }

        private static double ParseTerm(string s, ref int i)
        {
            double value = ParsePower(s, ref i);

            while (true)
            {
                SkipSpaces(s, ref i);
                if (i >= s.Length) break;

                char op = s[i];
                if (op != '*' && op != '/' && op != '%') break;

                i++;
                double right = ParsePower(s, ref i);

                if (op == '*') value *= right;
                else if (op == '/') value /= right;
                else value %= right;
            }
            return value;
        }

        private static double ParsePower(string s, ref int i)
        {
            double value = ParseFactor(s, ref i);

            SkipSpaces(s, ref i);
            if (i < s.Length && s[i] == '^')
            {
                i++;
                double exponent = ParsePower(s, ref i);
                value = Math.Pow(value, exponent);
            }
            return value;
        }

        private static double ParseFactor(string s, ref int i)
        {
            SkipSpaces(s, ref i);
            if (i >= s.Length) throw new FormatException();

            if (s[i] == '-') { i++; return -ParseFactor(s, ref i); }
            if (s[i] == '+') { i++; return ParseFactor(s, ref i); }

            if (s[i] == '(')
            {
                i++;
                double inner = ParseExpression(s, ref i);
                SkipSpaces(s, ref i);
                if (i < s.Length && s[i] == ')') i++;
                return inner;
            }

            int start = i;
            while (i < s.Length && (char.IsDigit(s[i]) || s[i] == '.' || s[i] == ',')) i++;
            if (start == i) throw new FormatException();

            return double.Parse(s.Substring(start, i - start).Replace(',', '.'),
                System.Globalization.CultureInfo.InvariantCulture);
        }

        private static void SkipSpaces(string s, ref int i)
        {
            while (i < s.Length && char.IsWhiteSpace(s[i])) i++;
        }

        /// <summary>Поиск строки в файле: grep &lt;текст&gt; &lt;файл&gt;</summary>
        private static string CommandGrep(List<string> args)
        {
            if (args.Count < 2) return LisunLocale.T("grep.usage");

            string needle = args[0];
            string fileName = string.Join(" ", args.GetRange(1, args.Count - 1).ToArray());

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, fileName, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            if (!File.Exists(resolved)) return " [ERROR] " + fileName;

            string[] lines = LisunCrypto.ReadAllLines(resolved);
            StringBuilder sb = new StringBuilder();
            int hits = 0;

            for (int i = 0; i < lines.Length; i++)
            {
                if (lines[i].IndexOf(needle, StringComparison.OrdinalIgnoreCase) < 0) continue;

                sb.AppendLine("   " + (i + 1).ToString().PadLeft(4) + ": " + lines[i].Trim());
                hits++;
            }

            if (hits == 0) return LisunLocale.T("grep.none", needle);
            return sb.ToString().TrimEnd() + Environment.NewLine + Environment.NewLine +
                   LisunLocale.T("grep.found", hits);
        }

        private static string CommandWc(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) return LisunLocale.T("wc.usage");

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, fileName, out resolved))
                return " [ERROR] Доступ за пределы корня запрещён.";

            if (!File.Exists(resolved)) return " [ERROR] " + fileName;

            string text = LisunCrypto.ReadAllText(resolved);
            string[] lines = text.Replace("\r\n", "\n").Split('\n');
            string[] words = text.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);

            return LisunLocale.T("wc.result", lines.Length, words.Length, text.Length);
        }

        private static string CommandNotify(string text)
        {
            if (string.IsNullOrEmpty(text)) return LisunLocale.T("notify.usage");

            System.Windows.Forms.MessageBox.Show(text, "LisunOS",
                System.Windows.Forms.MessageBoxButtons.OK,
                System.Windows.Forms.MessageBoxIcon.Information);

            return LisunLocale.T("notify.done");
        }

        // =====================================================================
        //  Псевдонимы команд
        // =====================================================================

        private const string AliasPrefix = "alias_";

        private static string CommandAlias(List<string> args)
        {
            if (args.Count == 0)
            {
                StringBuilder sb = new StringBuilder();
                int count = 0;

                foreach (KeyValuePair<string, string> kvp in LisunEngine.RegistryData)
                {
                    if (!kvp.Key.StartsWith(AliasPrefix, StringComparison.OrdinalIgnoreCase)) continue;

                    sb.AppendLine("   " + kvp.Key.Substring(AliasPrefix.Length).PadRight(12) + " = " + kvp.Value);
                    count++;
                }

                if (count == 0) return LisunLocale.T("alias.empty");
                return LisunLocale.T("alias.title") + Environment.NewLine + sb.ToString().TrimEnd();
            }

            if (args.Count < 2) return LisunLocale.T("alias.usage");

            string name = args[0].Trim().ToLowerInvariant();
            string target = string.Join(" ", args.GetRange(1, args.Count - 1).ToArray()).Trim();

            if (name == "alias" || name == "unalias") return LisunLocale.T("alias.reserved");

            LisunEngine.RegistryData[AliasPrefix + name] = target;
            LisunEngine.SaveRegistry();
            return LisunLocale.T("alias.set", name, target);
        }

        private static string CommandUnalias(string name)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("alias.usage");

            string key = AliasPrefix + name.Trim().ToLowerInvariant();
            if (!LisunEngine.RegistryData.Remove(key)) return LisunLocale.T("alias.notFound", name);

            LisunEngine.SaveRegistry();
            return LisunLocale.T("alias.removed", name);
        }

        /// <summary>Разворачивает псевдоним в начале строки.</summary>
        private static string ExpandAlias(string input)
        {
            string[] tokens = input.Split(new[] { ' ' }, 2);
            string key = AliasPrefix + tokens[0].Trim().ToLowerInvariant();

            string target;
            if (!LisunEngine.RegistryData.TryGetValue(key, out target) || string.IsNullOrEmpty(target)) return input;

            return tokens.Length > 1 ? target + " " + tokens[1] : target;
        }

        // =====================================================================
        //  Автоподсказка команд
        // =====================================================================

        private static readonly Dictionary<string, string[]> Hints =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { "help",      new[] { "список всех команд",                 "list every command" } },
            { "ver",       new[] { "версия ядра LisunOS",                "LisunOS kernel version" } },
            { "banner",    new[] { "логотип системы",                    "system banner" } },
            { "whoami",    new[] { "текущий пользователь",               "current user" } },
            { "hostname",  new[] { "имя машины",                         "machine name" } },
            { "uptime",    new[] { "время работы системы",               "system uptime" } },
            { "date",      new[] { "текущие дата и время",               "current date and time" } },
            { "echo",      new[] { "вывести текст",                      "print text" } },
            { "clear",     new[] { "очистить консоль",                   "clear the console" } },
            { "exit",      new[] { "завершить работу",                   "shut down" } },
            { "history",   new[] { "история команд",                     "command history" } },
            { "su",        new[] { "выключить режим суперпользователя",  "turn superuser mode off" } },
            { "superuser", new[] { "приложение выдачи права superuser",  "the superuser granting application" } },
            { "sudo",      new[] { "выполнить команду с правами root",   "run a command as root" } },
            { "restart",   new[] { "перезапуск подсистем",               "restart the subsystems" } },
            { "lang",      new[] { "язык интерфейса (ru / en)",          "interface language (ru / en)" } },
            { "layout",    new[] { "раскладка клавиатуры",               "keyboard layout" } },
            { "pwd",       new[] { "текущий каталог",                    "current directory" } },
            { "cd",        new[] { "перейти в каталог",                  "change directory" } },
            { "ls",        new[] { "содержимое каталога",                "list the directory" } },
            { "dir",       new[] { "содержимое каталога",                "list the directory" } },
            { "tree",      new[] { "дерево каталогов",                   "directory tree" } },
            { "cat",       new[] { "показать файл целиком",              "show the whole file" } },
            { "head",      new[] { "первые строки файла",                "first lines of a file" } },
            { "stat",      new[] { "сведения об объекте",                "item details" } },
            { "du",        new[] { "суммарный размер каталога",          "total directory size" } },
            { "find",      new[] { "поиск файлов по маске",              "find files by mask" } },
            { "touch",     new[] { "создать пустой файл",                "create an empty file" } },
            { "write",     new[] { "записать текст в файл",              "write text to a file" } },
            { "append",    new[] { "дописать текст в файл",              "append text to a file" } },
            { "mkdir",     new[] { "создать каталог",                    "create a directory" } },
            { "rm",        new[] { "удалить файл",                       "delete a file" } },
            { "rmdir",     new[] { "удалить каталог",                    "delete a directory" } },
            { "cp",        new[] { "копировать файл",                    "copy a file" } },
            { "mv",        new[] { "переместить или переименовать",      "move or rename" } },
            { "apps",      new[] { "загруженные приложения",             "loaded applications" } },
            { "services",  new[] { "установленные сервисы",              "installed services" } },
            { "install",   new[] { "установить пакет .lnsh",             "install an .lnsh package" } },
            { "apt",       new[] { "менеджер пакетов LisunOS",           "LisunOS package manager" } },
            { "regedit",   new[] { "реестр системы",                     "system registry" } },
            { "webview",   new[] { "встроенный браузер",                 "built-in browser" } },
            { "perm",      new[] { "разрешения приложений",              "application permissions" } },
            { "ps",        new[] { "активные процессы",                  "active processes" } },
            { "kill",      new[] { "завершить приложение",               "terminate an application" } },
            { "sysinfo",   new[] { "подробные сведения о системе",       "detailed system information" } },
            { "calc",      new[] { "калькулятор выражений",              "expression calculator" } },
            { "grep",      new[] { "поиск текста в файле",               "search text inside a file" } },
            { "wc",        new[] { "подсчёт строк, слов и символов",     "count lines, words, characters" } },
            { "notify",    new[] { "показать уведомление",               "show a notification" } },
            { "alias",     new[] { "создать псевдоним команды",          "create a command alias" } },
            { "unalias",   new[] { "удалить псевдоним",                  "remove an alias" } },
            { "ufw",       new[] { "брандмауэр и порты",                 "firewall and ports" } },
            { "systemctl", new[] { "управление службами",                "service management" } }
        };

        public static string DescribeCommand(string command)
        {
            string[] variants;
            if (command != null && Hints.TryGetValue(command, out variants))
            {
                int index = LisunLocale.Language == LisunLanguage.English ? 1 : 0;
                if (index < variants.Length) return variants[index];
                return variants[0];
            }
            return string.Empty;
        }

        /// <summary>Команды, подходящие под начало строки: встроенные плюс запущенные приложения.</summary>
        public static List<string> SuggestCommands(string prefix)
        {
            List<string> result = new List<string>();
            if (prefix == null) prefix = string.Empty;
            prefix = prefix.Trim();

            foreach (string command in KnownCommands)
            {
                if (prefix.Length == 0 || command.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    if (!result.Contains(command)) result.Add(command);
                }
            }

            foreach (KeyValuePair<string, List<string>> registered in LisunEngine.RegisteredCommands)
            {
                if (prefix.Length == 0 || registered.Key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                {
                    if (!result.Contains(registered.Key)) result.Add(registered.Key);
                }
            }

            result.Sort(StringComparer.OrdinalIgnoreCase);
            return result;
        }

        private static string BuildBanner()
        {
            return
                "  _    _               ___  ___" + Environment.NewLine +
                " | |  (_)___ _  _ _ _ / _ \\/ __|" + Environment.NewLine +
                " | |__| (_-< || | ' \\ (_) \\__ \\" + Environment.NewLine +
                " |____|_/__/\\_,_|_||_\\___/|___/  " + LisunEngine.Version;
        }

        private static string BuildHelp()
        {
            return LisunLocale.Language == LisunLanguage.English ? BuildHelpEnglish() : BuildHelpRussian();
        }

        private static string BuildHelpEnglish()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" LisunOS " + LisunEngine.Version + " commands");
            sb.AppendLine();
            sb.AppendLine("  SYSTEM");
            sb.AppendLine("    help, ver, banner, whoami, hostname, uptime, date, clear, exit");
            sb.AppendLine("    superuser            — grant the superuser right to a package (the only way)");
            sb.AppendLine("    su                   — turn superuser mode off (it is never turned on here)");
            sb.AppendLine("    sudo <command>       — run as root, once the mode is on");
            sb.AppendLine("    restart              — soft restart of the subsystems");
            sb.AppendLine("    history              — command history");
            sb.AppendLine();
            sb.AppendLine("  LANGUAGE AND KEYBOARD");
            sb.AppendLine("    lang [ru|en]         — system interface language");
            sb.AppendLine("    layout [ru|en|next]  — keyboard layout (Ctrl+Space)");
            sb.AppendLine();
            sb.AppendLine("  FILES");
            sb.AppendLine("    pwd, ls | dir, tree, cd <path>");
            sb.AppendLine("    cat <file>, head <file>, stat <item>, du, find <mask>");
            sb.AppendLine("    touch, mkdir, rm, rmdir, cp <src> <dst>, mv <src> <dst>");
            sb.AppendLine("    write <file> <text>, append <file> <text>");
            sb.AppendLine();
            sb.AppendLine("  APPLICATIONS");
            sb.AppendLine("    apps, services, install <package.lnsh>");
            sb.AppendLine("    apt list | info <name> | install <file> | update [name]");
            sb.AppendLine("    apt remove <name> | protect <name> | unprotect <name>   (needs sudo)");
            sb.AppendLine("    tail <file> [n] | sort <file> [-r|-n] | uniq <file> [-c] | diff <a> <b>");
            sb.AppendLine("    hash <file> [algo] | base64 encode|decode <text|file>");
            sb.AppendLine("    zip <archive> <path> | unzip <archive> [folder]");
            sb.AppendLine("    df | free | env [filter] | which <command> | curl <url> [file]");
            sb.AppendLine("    wifi list | connect <net> [pass] | disconnect | forget <net> | status | form");
            sb.AppendLine("                                   — Wi-Fi: scan, connect, sign-in page");
            sb.AppendLine("    php-frm status | download | update | remove | use builtin|own|system | auto on|off");
            sb.AppendLine("                                   — PHP module: downloads the build by itself");
            sb.AppendLine("    daemon list | status <name> | start <name> | stop <name> | run <name>");
            sb.AppendLine("                                   — background services, no window");
            sb.AppendLine("    system start | stop | status | open");
            sb.AppendLine("                                   — system port 8989, live setup feed (needs 'hall')");
            sb.AppendLine("    apt install php-frm            — PHP bundled inside LisunOS");
            sb.AppendLine("    apt install php-frm <zip|folder|php-cgi.exe>  — from your own source");
            sb.AppendLine("    ps, kill <application>");
            sb.AppendLine();
            sb.AppendLine("  PERMISSIONS");
            sb.AppendLine("    perm all                — every permission with a description");
            sb.AppendLine("    perm list               — what has been granted");
            sb.AppendLine("    perm app <name>         — one application's rights");
            sb.AppendLine("    perm grant <name> <right>  | revoke | reset   (needs sudo)");
            sb.AppendLine();
            sb.AppendLine("  UTILITIES");
            sb.AppendLine("    sysinfo, calc <expression>, grep <text> <file>, wc <file>");
            sb.AppendLine("    notify <text>, alias <name> <command>, unalias <name>");
            sb.AppendLine("    explorer             — graphical file manager (if the service is installed)");
            sb.AppendLine("    webview <url>        — built-in browser");
            sb.AppendLine();
            sb.AppendLine("  REGISTRY");
            sb.AppendLine("    regedit -config | -data | -commands");
            sb.AppendLine("    regedit -set:<key> -val:<value>");
            sb.AppendLine();
            sb.AppendLine("  Tips: Tab completes commands, Up/Down walks history, Esc returns to the terminal.");
            return sb.ToString().TrimEnd();
        }

        private static string BuildHelpRussian()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(" Команды LisunOS " + LisunEngine.Version);
            sb.AppendLine();
            sb.AppendLine("  СИСТЕМА");
            sb.AppendLine("    help, ver, banner, whoami, hostname, uptime, date, clear, exit");
            sb.AppendLine("    su [пароль]          — режим суперпользователя (root / admin)");
            sb.AppendLine("    sudo <команда>       — разовое повышение прав");
            sb.AppendLine("    restart              — мягкий перезапуск подсистем");
            sb.AppendLine("    history              — история введённых команд");
            sb.AppendLine();
            sb.AppendLine("  ЯЗЫК И КЛАВИАТУРА");
            sb.AppendLine("    lang [ru|en]         — язык интерфейса системы");
            sb.AppendLine("    layout [ru|en|next]  — раскладка клавиатуры (Ctrl+Space)");
            sb.AppendLine();
            sb.AppendLine("  ФАЙЛЫ");
            sb.AppendLine("    pwd, ls | dir, tree, cd <путь>");
            sb.AppendLine("    cat <файл>, head <файл>, stat <объект>, du, find <маска>");
            sb.AppendLine("    touch, mkdir, rm, rmdir, cp <из> <в>, mv <из> <в>");
            sb.AppendLine("    write <файл> <текст>, append <файл> <текст>");
            sb.AppendLine();
            sb.AppendLine("  ПРИЛОЖЕНИЯ");
            sb.AppendLine("    apps, services, install <пакет.lnsh>");
            sb.AppendLine("    apt list | info <имя> | install <файл> | update [имя]");
            sb.AppendLine("    apt remove <имя> | protect <имя> | unprotect <имя>   (нужен sudo)");
            sb.AppendLine("    tail <файл> [n] | sort <файл> [-r|-n] | uniq <файл> [-c] | diff <а> <б>");
            sb.AppendLine("    hash <файл> [алгоритм] | base64 encode|decode <текст|файл>");
            sb.AppendLine("    zip <архив> <путь> | unzip <архив> [папка]");
            sb.AppendLine("    df | free | env [фильтр] | which <команда> | curl <адрес> [файл]");
            sb.AppendLine("    wifi list | connect <сеть> [пароль] | disconnect | forget <сеть> | status | form");
            sb.AppendLine("                                   — Wi-Fi: поиск сетей, подключение, страница входа");
            sb.AppendLine("    php-frm status | download | update | remove | use builtin|own|system | auto on|off");
            sb.AppendLine("                                   — модуль PHP: сборка скачивается сама");
            sb.AppendLine("    daemon list | status <имя> | start <имя> | stop <имя> | run <имя>");
            sb.AppendLine("                                   — фоновые службы, работают без окна");
            sb.AppendLine("    system start | stop | status | open");
            sb.AppendLine("                                   — системный порт 8989, прямой эфир (нужно право 'hall')");
            sb.AppendLine("    apt install php-frm            — свой PHP внутри LisunOS");
            sb.AppendLine("    apt install php-frm <zip|папка|php-cgi.exe>  — из своего источника");
            sb.AppendLine("    ps, kill <приложение>");
            sb.AppendLine();
            sb.AppendLine("  РАЗРЕШЕНИЯ");
            sb.AppendLine("    perm all                — все права системы с описанием");
            sb.AppendLine("    perm list               — кому что выдано");
            sb.AppendLine("    perm app <имя>          — права одного приложения");
            sb.AppendLine("    perm grant <имя> <право>   | revoke | reset   (нужен sudo)");
            sb.AppendLine();
            sb.AppendLine("  УТИЛИТЫ");
            sb.AppendLine("    sysinfo, calc <выражение>, grep <текст> <файл>, wc <файл>");
            sb.AppendLine("    notify <текст>, alias <имя> <команда>, unalias <имя>");
            sb.AppendLine("    explorer             — графический проводник (если сервис установлен)");
            sb.AppendLine("    webview <адрес>      — встроенный браузер");
            sb.AppendLine();
            sb.AppendLine("  РЕЕСТР");
            sb.AppendLine("    regedit -config | -data | -commands");
            sb.AppendLine("    regedit -set:<ключ> -val:<значение>");
            sb.AppendLine();
            sb.AppendLine("  Подсказка: Tab — автодополнение, ↑↓ — история команд, Esc — возврат в терминал.");
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Wi-Fi
        // =====================================================================

        /// <summary>wifi list | connect | disconnect | forget | status | portal | form</summary>
        private static string CommandWifi(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "list";

            switch (action)
            {
                case "list":
                case "scan":
                    return LisunWifi.ListText();

                case "status":
                    return LisunWifi.StatusText();

                case "form":
                case "ui":
                case "open":
                    return OpenWifiForm();

                case "connect":
                {
                    if (rawParams.Count < 2) return LisunLocale.T("wifi.usage");

                    string ssid = rawParams[1];
                    string password = rawParams.Count > 2
                        ? string.Join(" ", rawParams.GetRange(2, rawParams.Count - 2).ToArray())
                        : string.Empty;

                    string message;
                    LisunWifi.Connect(ssid, password, out message);
                    return message;
                }

                case "disconnect":
                {
                    string message;
                    LisunWifi.Disconnect(out message);
                    return message;
                }

                case "forget":
                {
                    if (rawParams.Count < 2) return LisunLocale.T("wifi.usage");

                    string message;
                    LisunWifi.Forget(rawParams[1], out message);
                    return message;
                }

                case "portal":
                {
                    string url = LisunWifi.PortalUrl;

                    if (string.IsNullOrEmpty(url))
                    {
                        string portal;
                        LisunWifi.CheckConnectivity(out portal);
                        url = portal;
                    }

                    if (string.IsNullOrEmpty(url)) return LisunLocale.T("wifi.stateOnline");

                    LisunWifi.OpenPortal(url);
                    return LisunLocale.T("wifi.openingPortal", url);
                }

                default:
                    return LisunLocale.T("wifi.usage");
            }
        }

        private static string OpenWifiForm()
        {
            try
            {
                LisunWifiForm form = new LisunWifiForm(LisunWifi.PackageName);
                form.Show();
                return IsRemote ? WindowNote("wifi form") : " [OK] " + LisunLocale.T("wifi.title");
            }
            catch (Exception ex)
            {
                return " [ERROR] " + ex.Message;
            }
        }

        // =====================================================================
        //  php-frm
        // =====================================================================

        /// <summary>php-frm status | download | update | remove | use | auto | mirrors</summary>
        private static string CommandPhpFrm(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "status";

            switch (action)
            {
                case "status":
                case "info":
                    return LisunPhpModule.Status();

                case "mirrors":
                {
                    StringBuilder sb = new StringBuilder(LisunLocale.T("php.mirrorsTitle") + Environment.NewLine);

                    string[] mirrors = LisunPhpModule.Mirrors;
                    for (int index = 0; index < mirrors.Length; index++)
                        sb.AppendLine("   " + (index + 1) + ". " + mirrors[index]);

                    return sb.ToString().TrimEnd();
                }

                case "download":
                case "update":
                {
                    if (LisunPhpModule.Downloading)
                        return LisunLocale.T("php.busy", LisunPhpModule.DownloadStatus);

                    if (!LisunPermissions.Demand(LisunPhpModule.PackageName, LisunPermissions.Network))
                        return LisunLocale.T("wifi.needNetwork");

                    LisunPhpModule.BeginAutoDownload();

                    return LisunLocale.T("php.autoQueued") + Environment.NewLine +
                           LisunLocale.T("php.autoWatch", LisunSystemServer.SetupUrl);
                }

                case "remove":
                case "delete":
                {
                    if (!LisunPermissions.Demand(LisunPhpModule.PackageName, LisunPermissions.ManageFiles))
                        return LisunLocale.T("php.ownMissing");

                    string message;
                    LisunPhpModule.RemoveOwnPhp(out message);
                    return message;
                }

                case "auto":
                {
                    string value = rawParams.Count > 1 ? rawParams[1].ToLowerInvariant() : string.Empty;

                    if (value == "on" || value == "true" || value == "1")
                    {
                        LisunEngine.RegistryData["php_autodownload"] = "true";
                        LisunEngine.SaveRegistry();
                        return LisunLocale.T("php.autoOn");
                    }

                    if (value == "off" || value == "false" || value == "0")
                    {
                        LisunEngine.RegistryData["php_autodownload"] = "false";
                        LisunEngine.SaveRegistry();
                        return LisunLocale.T("php.autoOff");
                    }

                    return LisunLocale.T("php.usage");
                }

                case "use":
                {
                    string source = rawParams.Count > 1 ? rawParams[1].ToLowerInvariant() : string.Empty;

                    if (source == "builtin" || source == "own-engine" || source == "engine")
                    {
                        string root = LisunPhpModule.WwwRoot();

                        LisunPhpModule.EnableInConfig(root, null);
                        LisunEngine.RegistryData["php_path"] = string.Empty;
                        LisunEngine.SaveRegistry();
                        return LisunLocale.T("php.useBuiltIn");
                    }

                    string executable = source == "own" ? LisunPhpModule.FindOwnPhp()
                                      : source == "system" ? LisunPhpModule.SearchInPath("php-cgi.exe")
                                      : null;

                    if (executable == null) return LisunLocale.T("php.useFailed", source);

                    return LisunPhpModule.Attach(executable)
                        ? LisunLocale.T("php.attached", executable)
                        : LisunLocale.T("php.configFailed");
                }

                default:
                    return LisunLocale.T("php.usage");
            }
        }

        // =====================================================================
        //  Системный порт 8989
        // =====================================================================

        /// <summary>system start | stop | status | open</summary>
        private static string CommandSystemPort(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "status";

            switch (action)
            {
                case "start":
                case "enable":
                {
                    string message;
                    LisunSystemServer.Start(out message);
                    return message;
                }

                case "stop":
                case "disable":
                {
                    if (!LisunSystemServer.Running) return LisunLocale.T("sys.notRunning");

                    LisunSystemServer.Stop();
                    return LisunLocale.T("sys.stopped", LisunSystemServer.Port);
                }

                case "open":
                {
                    if (!LisunSystemServer.Running)
                    {
                        string message;
                        if (!LisunSystemServer.Start(out message)) return message;
                    }

                    LisunEngine.OpenInShellBrowser(LisunSystemServer.SetupUrl);
                    return LisunLocale.T("sys.opened", LisunSystemServer.SetupUrl);
                }

                case "status":
                case "info":
                {
                    StringBuilder sb = new StringBuilder(LisunLocale.T("sys.statusTitle") + Environment.NewLine);

                    sb.AppendLine("   " + LisunLocale.T("sys.fieldState") + ": " +
                                  LisunLocale.T(LisunSystemServer.Running ? "sys.open" : "sys.closed"));
                    sb.AppendLine("   " + LisunLocale.T("sys.fieldPort") + ": " + LisunSystemServer.Port);
                    sb.AppendLine("   " + LisunLocale.T("sys.fieldApp") + ": " + LisunSystemServer.HallApplication);
                    sb.AppendLine("   " + LisunLocale.T("sys.fieldHall") + ": " +
                                  LisunLocale.T(LisunSystemServer.HallGranted ? "sys.granted" : "sys.denied"));
                    sb.AppendLine("   " + LisunLocale.T("sys.fieldRequests") + ": " + LisunSystemServer.RequestCount);
                    sb.AppendLine("   " + LisunLocale.T("sys.fieldPage") + ": " + LisunSystemServer.SetupUrl);
                    sb.AppendLine("   " + LisunLocale.T("php.fieldAuto") + ": " +
                                  LisunLocale.T(LisunPhpModule.AutoDownloadEnabled ? "php.on" : "php.off"));
                    sb.AppendLine("   " + LisunLocale.T("php.fieldProgress") + ": " +
                                  (LisunPhpModule.DownloadStatus.Length == 0 ? "—" : LisunPhpModule.DownloadStatus));

                    return sb.ToString().TrimEnd();
                }

                default:
                    return LisunLocale.T("sys.usage");
            }
        }


        /// <summary>Имя приложения оболочки — от него спрашиваются права на команды.</summary>
        private static string ShellName
        {
            get
            {
                string value;
                if (LisunEngine.RegistryConfig.TryGetValue("hallapp", out value) && value.Length > 0)
                    return value;

                return "LisunOS.lshall";
            }
        }

        // =====================================================================
        //  Работа с текстом: tail, sort, uniq, diff
        // =====================================================================

        /// <summary>tail &lt;файл&gt; [строк] — последние строки файла.</summary>
        private static string CommandTail(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.tailUsage");

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out resolved))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(resolved)) return LisunLocale.T("tool.noFile", rawParams[0]);

            int count = 10;
            if (rawParams.Count > 1) int.TryParse(rawParams[1], out count);
            if (count < 1) count = 10;

            string[] lines = CustomFormUtils.ReadFileText(resolved).Replace("\r\n", "\n").Split('\n');
            int from = Math.Max(0, lines.Length - count);

            StringBuilder sb = new StringBuilder();
            for (int index = from; index < lines.Length; index++) sb.AppendLine(lines[index]);

            return sb.ToString().TrimEnd();
        }

        /// <summary>sort &lt;файл&gt; [-r] [-n] — отсортированные строки.</summary>
        private static string CommandSort(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.sortUsage");

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out resolved))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(resolved)) return LisunLocale.T("tool.noFile", rawParams[0]);

            bool reverse = rawParams.Contains("-r");
            bool numeric = rawParams.Contains("-n");

            List<string> lines = new List<string>(
                CustomFormUtils.ReadFileText(resolved).Replace("\r\n", "\n").Split('\n'));

            lines.RemoveAll(line => line.Length == 0);

            if (numeric)
            {
                lines.Sort((left, right) =>
                {
                    double a, b;
                    double.TryParse(left.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out a);
                    double.TryParse(right.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out b);
                    return a.CompareTo(b);
                });
            }
            else lines.Sort(StringComparer.CurrentCulture);

            if (reverse) lines.Reverse();

            return string.Join(Environment.NewLine, lines.ToArray());
        }

        /// <summary>uniq &lt;файл&gt; [-c] — строки без повторов, с подсчётом по -c.</summary>
        private static string CommandUniq(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.uniqUsage");

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out resolved))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(resolved)) return LisunLocale.T("tool.noFile", rawParams[0]);

            bool counting = rawParams.Contains("-c");

            List<string> order = new List<string>();
            Dictionary<string, int> counts = new Dictionary<string, int>(StringComparer.Ordinal);

            foreach (string line in CustomFormUtils.ReadFileText(resolved).Replace("\r\n", "\n").Split('\n'))
            {
                if (!counts.ContainsKey(line))
                {
                    counts[line] = 1;
                    order.Add(line);
                }
                else counts[line]++;
            }

            StringBuilder sb = new StringBuilder();
            foreach (string line in order)
                sb.AppendLine(counting ? counts[line].ToString().PadLeft(6) + "  " + line : line);

            return sb.ToString().TrimEnd();
        }

        /// <summary>diff &lt;файл1&gt; &lt;файл2&gt; — построчное сравнение.</summary>
        private static string CommandDiff(List<string> rawParams)
        {
            if (rawParams.Count < 2) return LisunLocale.T("tool.diffUsage");

            string leftPath, rightPath;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out leftPath) ||
                !CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[1], out rightPath))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(leftPath)) return LisunLocale.T("tool.noFile", rawParams[0]);
            if (!File.Exists(rightPath)) return LisunLocale.T("tool.noFile", rawParams[1]);

            string[] left = CustomFormUtils.ReadFileText(leftPath).Replace("\r\n", "\n").Split('\n');
            string[] right = CustomFormUtils.ReadFileText(rightPath).Replace("\r\n", "\n").Split('\n');

            StringBuilder sb = new StringBuilder();
            int differences = 0;
            int total = Math.Max(left.Length, right.Length);

            for (int index = 0; index < total; index++)
            {
                string a = index < left.Length ? left[index] : null;
                string b = index < right.Length ? right[index] : null;

                if (a == b) continue;

                differences++;
                if (differences > 200)
                {
                    sb.AppendLine("   " + LisunLocale.T("tool.diffMore"));
                    break;
                }

                if (a != null) sb.AppendLine((index + 1).ToString().PadLeft(5) + " - " + a);
                if (b != null) sb.AppendLine((index + 1).ToString().PadLeft(5) + " + " + b);
            }

            return differences == 0
                ? LisunLocale.T("tool.diffSame")
                : LisunLocale.T("tool.diffCount", differences) + Environment.NewLine + sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Данные: hash, base64
        // =====================================================================

        /// <summary>hash &lt;файл&gt; [md5|sha1|sha256] — контрольная сумма.</summary>
        private static string CommandHash(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.hashUsage");

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out resolved))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(resolved)) return LisunLocale.T("tool.noFile", rawParams[0]);

            string algorithm = rawParams.Count > 1 ? rawParams[1].ToLowerInvariant() : "sha256";

            try
            {
                using (HashAlgorithm hash = CreateHash(algorithm))
                {
                    if (hash == null) return LisunLocale.T("tool.hashUnknown", algorithm);

                    using (FileStream input = File.OpenRead(resolved))
                    {
                        byte[] result = hash.ComputeHash(input);

                        StringBuilder sb = new StringBuilder();
                        foreach (byte value in result) sb.Append(value.ToString("x2"));

                        return "   " + algorithm + "  " + sb + Environment.NewLine +
                               "   " + CustomFormUtils.FormatSize(new FileInfo(resolved).Length) +
                               "  " + Path.GetFileName(resolved);
                    }
                }
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        private static HashAlgorithm CreateHash(string algorithm)
        {
            switch (algorithm)
            {
                case "md5": return MD5.Create();
                case "sha1": return SHA1.Create();
                case "sha256": return SHA256.Create();
                case "sha384": return SHA384.Create();
                case "sha512": return SHA512.Create();
                default: return null;
            }
        }

        /// <summary>base64 encode|decode &lt;текст или файл&gt;</summary>
        private static string CommandBase64(List<string> rawParams)
        {
            if (rawParams.Count < 2) return LisunLocale.T("tool.base64Usage");

            string mode = rawParams[0].ToLowerInvariant();
            string value = string.Join(" ", rawParams.GetRange(1, rawParams.Count - 1).ToArray());

            try
            {
                string resolved;
                bool isFile = CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, value, out resolved) &&
                              File.Exists(resolved);

                if (mode == "encode" || mode == "e")
                {
                    byte[] data = isFile ? File.ReadAllBytes(resolved) : Encoding.UTF8.GetBytes(value);
                    return Convert.ToBase64String(data);
                }

                if (mode == "decode" || mode == "d")
                {
                    string source = isFile ? CustomFormUtils.ReadFileText(resolved).Trim() : value;
                    return Encoding.UTF8.GetString(Convert.FromBase64String(source));
                }

                return LisunLocale.T("tool.base64Usage");
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        // =====================================================================
        //  Архивы: zip, unzip
        // =====================================================================

        /// <summary>zip &lt;архив.zip&gt; &lt;файл или папка&gt; — упаковать.</summary>
        private static string CommandZip(List<string> rawParams)
        {
            if (rawParams.Count < 2) return LisunLocale.T("tool.zipUsage");

            if (!LisunPermissions.Demand(ShellName, LisunPermissions.WriteFiles))
                return LisunLocale.T("tool.needWrite");

            string archive, source;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out archive) ||
                !CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[1], out source))
                return LisunLocale.T("tool.outsideRoot");

            try
            {
                if (File.Exists(archive)) File.Delete(archive);

                if (Directory.Exists(source))
                {
                    ZipFile.CreateFromDirectory(source, archive, CompressionLevel.Optimal, false);
                }
                else if (File.Exists(source))
                {
                    using (ZipArchive zip = ZipFile.Open(archive, ZipArchiveMode.Create))
                        zip.CreateEntryFromFile(source, Path.GetFileName(source), CompressionLevel.Optimal);
                }
                else return LisunLocale.T("tool.noFile", rawParams[1]);

                return LisunLocale.T("tool.zipDone",
                    CustomFormUtils.ToVirtualPath(archive),
                    CustomFormUtils.FormatSize(new FileInfo(archive).Length));
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        /// <summary>unzip &lt;архив.zip&gt; [папка] — распаковать.</summary>
        private static string CommandUnzip(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.unzipUsage");

            if (!LisunPermissions.Demand(ShellName, LisunPermissions.WriteFiles))
                return LisunLocale.T("tool.needWrite");

            string archive;
            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[0], out archive))
                return LisunLocale.T("tool.outsideRoot");

            if (!File.Exists(archive)) return LisunLocale.T("tool.noFile", rawParams[0]);

            string target;
            string wanted = rawParams.Count > 1
                ? rawParams[1]
                : Path.GetFileNameWithoutExtension(archive);

            if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, wanted, out target))
                return LisunLocale.T("tool.outsideRoot");

            try
            {
                if (!Directory.Exists(target)) Directory.CreateDirectory(target);

                int count = 0;
                using (ZipArchive zip = ZipFile.OpenRead(archive))
                {
                    foreach (ZipArchiveEntry entry in zip.Entries)
                    {
                        if (entry.Length == 0 && entry.FullName.EndsWith("/")) continue;

                        string destination = Path.GetFullPath(Path.Combine(target, entry.FullName));

                        // Защита от путей вида ../../: распаковка только внутрь папки.
                        if (!destination.StartsWith(Path.GetFullPath(target), StringComparison.OrdinalIgnoreCase))
                            continue;

                        string directory = Path.GetDirectoryName(destination);
                        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                            Directory.CreateDirectory(directory);

                        entry.ExtractToFile(destination, true);
                        count++;
                    }
                }

                return LisunLocale.T("tool.unzipDone", count, CustomFormUtils.ToVirtualPath(target));
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        // =====================================================================
        //  Система: df, free, env, which, curl
        // =====================================================================

        /// <summary>df — место на диске под виртуальной системой.</summary>
        private static string CommandDf()
        {
            try
            {
                DriveInfo drive = new DriveInfo(Path.GetPathRoot(LisunEngine.RootPath));

                long used = drive.TotalSize - drive.TotalFreeSpace;
                int percent = drive.TotalSize > 0 ? (int)(used * 100 / drive.TotalSize) : 0;

                int filled = percent / 5;
                string bar = new string('█', filled) + new string('░', 20 - filled);

                StringBuilder sb = new StringBuilder(LisunLocale.T("tool.dfTitle") + Environment.NewLine);
                sb.AppendLine("   " + LisunLocale.T("tool.dfDrive") + ": " + drive.Name +
                              "  (" + drive.DriveFormat + ")");
                sb.AppendLine("   " + bar + "  " + percent + "%");
                sb.AppendLine("   " + LisunLocale.T("tool.dfUsed") + ": " + CustomFormUtils.FormatSize(used));
                sb.AppendLine("   " + LisunLocale.T("tool.dfFree") + ": " + CustomFormUtils.FormatSize(drive.TotalFreeSpace));
                sb.AppendLine("   " + LisunLocale.T("tool.dfTotal") + ": " + CustomFormUtils.FormatSize(drive.TotalSize));
                sb.AppendLine("   " + LisunLocale.T("tool.dfSystem") + ": " +
                              CustomFormUtils.FormatSize(DirectorySize(LisunEngine.RootPath)));

                return sb.ToString().TrimEnd();
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        private static long DirectorySize(string path)
        {
            long total = 0;
            try
            {
                foreach (string file in Directory.GetFiles(path, "*", SearchOption.AllDirectories))
                {
                    try { total += new FileInfo(file).Length; }
                    catch { }
                }
            }
            catch { }
            return total;
        }

        /// <summary>free — память процесса и системы.</summary>
        private static string CommandFree()
        {
            try
            {
                Process self = Process.GetCurrentProcess();

                StringBuilder sb = new StringBuilder(LisunLocale.T("tool.freeTitle") + Environment.NewLine);
                sb.AppendLine("   " + LisunLocale.T("tool.freeWorking") + ": " +
                              CustomFormUtils.FormatSize(self.WorkingSet64));
                sb.AppendLine("   " + LisunLocale.T("tool.freePrivate") + ": " +
                              CustomFormUtils.FormatSize(self.PrivateMemorySize64));
                sb.AppendLine("   " + LisunLocale.T("tool.freeManaged") + ": " +
                              CustomFormUtils.FormatSize(GC.GetTotalMemory(false)));
                sb.AppendLine("   " + LisunLocale.T("tool.freeThreads") + ": " + self.Threads.Count);
                sb.AppendLine("   " + LisunLocale.T("tool.freeHandles") + ": " + self.HandleCount);

                return sb.ToString().TrimEnd();
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }

        /// <summary>env — переменные среды LisunOS: CONFIG и DATA вместе.</summary>
        private static string CommandEnv(string filter)
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("tool.envTitle") + Environment.NewLine);

            filter = (filter ?? string.Empty).Trim();

            sb.AppendLine("   [CONFIG]");
            foreach (KeyValuePair<string, string> item in LisunEngine.RegistryConfig)
            {
                if (filter.Length > 0 && item.Key.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) continue;
                sb.AppendLine("     " + item.Key.PadRight(22) + " = " + Mask(item.Key, item.Value));
            }

            sb.AppendLine("   [DATA]");
            foreach (KeyValuePair<string, string> item in LisunEngine.RegistryData)
            {
                if (filter.Length > 0 && item.Key.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) continue;
                sb.AppendLine("     " + item.Key.PadRight(22) + " = " + Mask(item.Key, item.Value));
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>Ключи и пароли в выводе заменяются точками.</summary>
        private static string Mask(string key, string value)
        {
            string lowered = key.ToLowerInvariant();

            bool secret = lowered.Contains("key") || lowered.Contains("pass") ||
                          lowered.Contains("token") || lowered.Contains("secret");

            if (!secret || string.IsNullOrEmpty(value)) return value;

            return value.Length <= 4 ? "••••" : value.Substring(0, 4) + new string('•', 8);
        }

        /// <summary>which &lt;команда&gt; — откуда берётся команда.</summary>
        private static string CommandWhich(string name)
        {
            if (string.IsNullOrEmpty(name)) return LisunLocale.T("tool.whichUsage");

            name = name.Trim().ToLowerInvariant();

            foreach (string command in KnownCommands)
                if (command == name) return LisunLocale.T("tool.whichBuiltIn", name);

            List<string> applications;
            if (LisunEngine.RegisteredCommands.TryGetValue(name, out applications) && applications.Count > 0)
                return LisunLocale.T("tool.whichApp", name, string.Join(", ", applications.ToArray()));

            string alias;
            if (LisunEngine.RegistryData.TryGetValue(AliasPrefix + name, out alias))
                return LisunLocale.T("tool.whichAlias", name, alias);

            return LisunLocale.T("tool.whichNone", name);
        }

        /// <summary>curl &lt;адрес&gt; [файл] — скачать страницу или файл.</summary>
        private static string CommandCurl(List<string> rawParams)
        {
            if (rawParams.Count == 0) return LisunLocale.T("tool.curlUsage");

            if (!LisunPermissions.Demand(ShellName, LisunPermissions.Network))
                return LisunLocale.T("tool.needNetwork");

            string url = rawParams[0];
            if (url.IndexOf("://", StringComparison.Ordinal) < 0) url = "https://" + url;

            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.UserAgent = "LisunOS/" + LisunEngine.Version;
                request.Timeout = 20000;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream input = response.GetResponseStream())
                using (MemoryStream buffer = new MemoryStream())
                {
                    byte[] chunk = new byte[16384];
                    int read;
                    while (input != null && (read = input.Read(chunk, 0, chunk.Length)) > 0)
                        buffer.Write(chunk, 0, read);

                    byte[] data = buffer.ToArray();

                    if (rawParams.Count > 1)
                    {
                        if (!LisunPermissions.Demand(ShellName, LisunPermissions.WriteFiles))
                            return LisunLocale.T("tool.needWrite");

                        string target;
                        if (!CustomFormUtils.TryResolveInsideRoot(currentVirtualDir, rawParams[1], out target))
                            return LisunLocale.T("tool.outsideRoot");

                        File.WriteAllBytes(target, data);

                        return LisunLocale.T("tool.curlSaved",
                            CustomFormUtils.ToVirtualPath(target),
                            CustomFormUtils.FormatSize(data.Length),
                            (int)response.StatusCode);
                    }

                    string text = Encoding.UTF8.GetString(data);
                    if (text.Length > 8000) text = text.Substring(0, 8000) + Environment.NewLine +
                                                    "   " + LisunLocale.T("tool.curlTrimmed");

                    return LisunLocale.T("tool.curlHead", (int)response.StatusCode,
                               response.ContentType ?? "—", CustomFormUtils.FormatSize(data.Length)) +
                           Environment.NewLine + Environment.NewLine + text;
                }
            }
            catch (WebException ex)
            {
                HttpWebResponse response = ex.Response as HttpWebResponse;
                return response != null
                    ? LisunLocale.T("tool.curlFailed", (int)response.StatusCode + " " + response.StatusDescription)
                    : LisunLocale.T("tool.curlFailed", ex.Message);
            }
            catch (Exception ex) { return " [ERROR] " + ex.Message; }
        }


        /// <summary>store | store refresh | store install &lt;имя&gt; | store open</summary>
        private static string CommandStore(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "list";

            switch (action)
            {
                case "list":
                case "ls":
                    return LisunStore.ListText();

                case "refresh":
                case "update":
                {
                    string message;
                    LisunStore.Refresh(LisunStore.PackageName, out message);
                    return message;
                }

                case "install":
                {
                    if (rawParams.Count < 2) return LisunLocale.T("store.usage");

                    foreach (LisunStore.StoreItem item in LisunStore.Items())
                    {
                        if (!item.Name.Equals(rawParams[1], StringComparison.OrdinalIgnoreCase)) continue;

                        string message;
                        LisunStore.Install(item, IsSuperUser, out message);
                        return message;
                    }

                    return LisunLocale.T("store.notFound", rawParams[1]);
                }

                case "open":
                case "form":
                    return Execute("store");

                default:
                    return LisunLocale.T("store.usage");
            }
        }


        /// <summary>daemon | list | status | start | stop | restart | run | enable | disable</summary>
        private static string CommandDaemon(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "list";
            string name = rawParams.Count > 1
                ? string.Join(" ", rawParams.GetRange(1, rawParams.Count - 1).ToArray()).Trim()
                : string.Empty;

            switch (action)
            {
                case "list":
                case "ls":
                    return LisunDaemons.ListText();

                case "status":
                case "info":
                    return name.Length == 0 ? LisunDaemons.ListText() : LisunDaemons.StatusText(name);

                case "start":
                    if (name.Length == 0) return LisunLocale.T("daemon.usage");
                    return LisunDaemons.Start(name)
                        ? LisunLocale.T("daemon.started", name)
                        : LisunLocale.T("daemon.notFound", name);

                case "stop":
                    if (name.Length == 0) return LisunLocale.T("daemon.usage");
                    return LisunDaemons.Stop(name)
                        ? LisunLocale.T("daemon.stopped", name)
                        : LisunLocale.T("daemon.notRunning", name);

                case "restart":
                    if (name.Length == 0) return LisunLocale.T("daemon.usage");
                    return LisunDaemons.Restart(name)
                        ? LisunLocale.T("daemon.restarted", name)
                        : LisunLocale.T("daemon.notFound", name);

                case "run":
                case "now":
                    if (name.Length == 0) return LisunLocale.T("daemon.usage");
                    return LisunDaemons.RunNow(name);

                case "enable":
                case "disable":
                {
                    if (name.Length == 0) return LisunLocale.T("daemon.usage");

                    bool enable = action == "enable";
                    if (!LisunDaemons.SetEnabled(name, enable))
                        return LisunLocale.T("daemon.notFound", name);

                    return LisunLocale.T(enable ? "daemon.enabledNow" : "daemon.disabledNow", name);
                }

                case "stop-all":
                    LisunDaemons.StopAll();
                    return LisunLocale.T("daemon.allStopped");

                default:
                    return LisunLocale.T("daemon.usage");
            }
        }


        /// <summary>conf test | show | reload | edit | sample — настройки сервера.</summary>
        private static string CommandConf(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "test";
            string root = LisunPhpModule.WwwRoot();

            switch (action)
            {
                case "test":
                case "check":
                case "-t":
                {
                    LisunServerConfig config = LisunServerConfig.Load(root);
                    return config.Describe();
                }

                case "show":
                case "cat":
                {
                    string path = Path.Combine(root, LisunServerConfig.FileName);
                    if (!File.Exists(path)) return LisunLocale.T("conf.missing");

                    return LisunCrypto.ReadAllText(path);
                }

                case "reload":
                {
                    LisunServerConfig.Load(root);
                    return LisunLocale.T("conf.reloaded");
                }

                case "sample":
                case "example":
                {
                    string folder = Path.Combine(root, "conf.d");
                    if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

                    string path = Path.Combine(folder, "example.conf.txt");
                    CustomFormUtils.WriteFileText(path, LisunServerConfig.SampleIncludeContent());

                    return LisunLocale.T("conf.sampleWritten", CustomFormUtils.ToVirtualPath(path));
                }

                case "path":
                case "where":
                    return LisunLocale.T("conf.path",
                        CustomFormUtils.ToVirtualPath(Path.Combine(root, LisunServerConfig.FileName)),
                        CustomFormUtils.ToVirtualPath(Path.Combine(root, "conf.d")));

                default:
                    return LisunLocale.T("conf.usage");
            }
        }

        /// <summary>user list | create &lt;имя&gt; &lt;пароль&gt; | edit | remove | enable | disable</summary>
        private static string CommandUser(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "list";
            string name = rawParams.Count > 1 ? rawParams[1].Trim() : string.Empty;
            string password = rawParams.Count > 2
                ? string.Join(" ", rawParams.GetRange(2, rawParams.Count - 2).ToArray()).Trim()
                : string.Empty;

            switch (action)
            {
                case "list":
                case "ls":
                    return LisunUsers.ListText();

                case "create":
                case "add":
                {
                    if (name.Length == 0 || password.Length == 0) return LisunLocale.T("user.usage");
                    if (!LisunPermissions.Demand(ShellName, LisunPermissions.ManageUsers))
                        return LisunLocale.T("user.needRight");

                    string message;
                    LisunUsers.Create(name, password, out message);
                    return message;
                }

                case "edit":
                case "passwd":
                {
                    if (name.Length == 0 || password.Length == 0) return LisunLocale.T("user.usage");
                    if (!LisunPermissions.Demand(ShellName, LisunPermissions.ManageUsers))
                        return LisunLocale.T("user.needRight");

                    string message;
                    LisunUsers.Edit(name, password, out message);
                    return message;
                }

                case "remove":
                case "delete":
                {
                    if (name.Length == 0) return LisunLocale.T("user.usage");
                    if (!LisunPermissions.Demand(ShellName, LisunPermissions.ManageUsers))
                        return LisunLocale.T("user.needRight");

                    string message;
                    LisunUsers.Remove(name, out message);
                    return message;
                }

                case "enable":
                case "disable":
                {
                    if (name.Length == 0) return LisunLocale.T("user.usage");
                    if (!LisunPermissions.Demand(ShellName, LisunPermissions.ManageUsers))
                        return LisunLocale.T("user.needRight");

                    string message;
                    LisunUsers.SetEnabled(name, action == "enable", out message);
                    return message;
                }

                case "current":
                case "whoami":
                {
                    // user current           — кто сейчас
                    // user current set <имя> — сменить
                    if (name.Length == 0) return LisunLocale.T("user.currentIs", LisunUsers.Current);

                    if (!name.Equals("set", StringComparison.OrdinalIgnoreCase))
                        return LisunLocale.T("user.currentUsage");

                    if (password.Length == 0) return LisunLocale.T("user.currentUsage");

                    // Сменить пользователя может только root: иначе ограничение
                    // снималось бы одной командой и не значило бы ничего.
                    if (!LisunUsers.IsRoot(ActiveUser)) return LisunLocale.T("user.onlyRoot");

                    string message;
                    LisunUsers.SetCurrent(password, out message);
                    return message;
                }

                case "areas":
                case "limits-help":
                    return LisunUsers.AreasText();

                case "limit":
                case "limits":
                {
                    if (name.Length == 0) return LisunLocale.T("user.limitUsage");

                    string[] tail = password.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    string what = tail.Length > 0 ? tail[0].ToLowerInvariant() : string.Empty;
                    string area = tail.Length > 1 ? tail[1] : string.Empty;

                    if (what.Length == 0) return LisunUsers.LimitsText(name);

                    if (!LisunUsers.IsRoot(ActiveUser)) return LisunLocale.T("user.onlyRoot");

                    if (!LisunPermissions.Demand(ShellName, LisunPermissions.ManageUsers))
                        return LisunLocale.T("user.needRight");

                    string message;

                    if (what == "add" || what == "set" || what == "deny")
                    {
                        LisunUsers.AddLimit(name, area, out message);
                        return message;
                    }

                    if (what == "remove" || what == "allow" || what == "clear" || what == "all")
                    {
                        LisunUsers.RemoveLimit(name, what == "clear" || what == "all" ? null : area, out message);
                        return message;
                    }

                    return LisunLocale.T("user.limitUsage");
                }

                default:
                    return LisunLocale.T("user.usage");
            }
        }

        /// <summary>ssh | start [порт] | stop | status | log — удалённый вход.</summary>
        private static string CommandSsh(List<string> rawParams)
        {
            string action = rawParams.Count > 0 ? rawParams[0].ToLowerInvariant() : "status";

            switch (action)
            {
                case "status":
                case "info":
                case "address":
                case "ip":
                    return SshHost.StatusText();

                case "start":
                case "enable":
                {
                    int wanted = SshHost.DefaultPort;
                    if (rawParams.Count > 1) int.TryParse(rawParams[1], out wanted);

                    string message;
                    SshHost.Start(wanted, out message);
                    return message;
                }

                case "stop":
                case "disable":
                    if (!SshHost.Running) return LisunLocale.T("ssh.notRunning");

                    SshHost.Stop();
                    return LisunLocale.T("ssh.stopped");

                case "who":
                case "sessions":
                case "users":
                    return SshHost.WhoText();

                case "help":
                case "about":
                    return LisunLocale.T("ssh.helpTitle") + Environment.NewLine +
                           LisunLocale.T("ssh.helpBody");

                case "log":
                {
                    string[] lines = SshHost.Log;
                    if (lines.Length == 0) return LisunLocale.T("ssh.logEmpty");

                    StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.logTitle") + Environment.NewLine);
                    foreach (string line in lines) sb.AppendLine("   " + line);

                    return sb.ToString().TrimEnd();
                }

                default:
                    return LisunLocale.T("ssh.usage");
            }
        }

    }
}
