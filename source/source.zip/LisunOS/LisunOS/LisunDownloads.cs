﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>Чем закончилась загрузка.</summary>
    public enum LisunDownloadState
    {
        Queued = 0,
        Running = 1,
        Done = 2,
        Failed = 3,
        Canceled = 4
    }

    /// <summary>
    /// Одна загрузка: откуда, куда, сколько уже получено и с какой скоростью.
    /// Объект живёт и после окончания — он же попадает в историю.
    /// </summary>
    public sealed class LisunDownload
    {
        public string Name = string.Empty;
        public string Url = string.Empty;
        public string Target = string.Empty;
        public string ExpectedHash = string.Empty;
        public string ActualHash = string.Empty;
        public string Error = string.Empty;

        /// <summary>Сколько всего байт обещал сервер. 0 — размер неизвестен.</summary>
        public long Total;

        /// <summary>Сколько байт уже на диске.</summary>
        public long Received;

        /// <summary>Сколько было до начала: докачка не должна портить скорость.</summary>
        public long Resumed;

        public DateTime Started = DateTime.MinValue;
        public DateTime Finished = DateTime.MinValue;

        public LisunDownloadState State = LisunDownloadState.Queued;

        /// <summary>Просили отменить — поток загрузки проверяет это между блоками.</summary>
        internal volatile bool CancelRequested;

        public bool Active
        {
            get { return State == LisunDownloadState.Queued || State == LisunDownloadState.Running; }
        }

        public int Percent
        {
            get
            {
                if (Total <= 0) return 0;

                long value = Received * 100 / Total;
                if (value > 100) value = 100;
                if (value < 0) value = 0;
                return (int)value;
            }
        }

        public TimeSpan Elapsed
        {
            get
            {
                if (Started == DateTime.MinValue) return TimeSpan.Zero;

                DateTime end = Finished == DateTime.MinValue ? DateTime.Now : Finished;
                TimeSpan span = end - Started;
                return span < TimeSpan.Zero ? TimeSpan.Zero : span;
            }
        }

        /// <summary>Байт в секунду. 0 — делить ещё нечего.</summary>
        public double Speed
        {
            get
            {
                double seconds = Elapsed.TotalSeconds;
                if (seconds < 0.3) return 0;

                long own = Received - Resumed;
                if (own <= 0) return 0;

                return own / seconds;
            }
        }

        /// <summary>Сколько осталось ждать. Zero — посчитать нельзя.</summary>
        public TimeSpan Remaining
        {
            get
            {
                double speed = Speed;
                if (speed <= 1 || Total <= 0 || Received >= Total) return TimeSpan.Zero;

                double seconds = (Total - Received) / speed;
                if (seconds > 86400) return TimeSpan.Zero;

                return TimeSpan.FromSeconds(seconds);
            }
        }

        public override string ToString()
        {
            return Name + " " + Percent + "% " + CustomFormUtils.FormatSize(Received);
        }
    }

    /// <summary>
    /// Единственное место в системе, которое качает файлы из сети.
    ///
    /// Раньше каждый модуль качал сам: php-модуль — интерпретатор, магазин —
    /// пакеты, установщик — архивы по ссылке. Прогресс был виден только внутри
    /// php-модуля, отменить загрузку было нельзя, а проверить, то ли пришло,
    /// было нечем. Теперь все они зовут Fetch, а здесь собрано то, что нужно
    /// любой загрузке:
    ///
    ///   • прогресс, скорость и остаток времени — их видно и в терминале,
    ///     и в окне Wi-Fi, и в магазине;
    ///   • докачка: оборванный файл продолжается с того же байта (Range),
    ///     а не качается заново;
    ///   • зеркала: список ссылок перебирается до первой рабочей;
    ///   • проверка sha256 — если в каталоге указан отпечаток;
    ///   • отмена;
    ///   • история: что, откуда, когда и сколько — в /os/root/downloads.
    /// </summary>
    public static class LisunDownloads
    {
        /// <summary>Сколько записей истории держим на диске.</summary>
        public const int HistoryLimit = 60;

        private const int BufferSize = 81920;
        private const int Attempts = 3;

        private static readonly object gate = new object();
        private static readonly List<LisunDownload> items = new List<LisunDownload>();

        /// <summary>Сработало начало, каждый шаг прогресса и конец загрузки.</summary>
        public static event Action<LisunDownload> Changed;

        public static readonly string HistoryPath =
            Path.Combine(LisunEngine.RootPath, "root", "downloads");

        /// <summary>Общий счётчик: сколько байт система скачала за этот запуск.</summary>
        public static long TotalBytes { get; private set; }

        // =====================================================================
        //  Список загрузок
        // =====================================================================

        /// <summary>Снимок списка: сначала идущие, затем недавние.</summary>
        public static List<LisunDownload> Items()
        {
            lock (gate) return new List<LisunDownload>(items);
        }

        public static List<LisunDownload> ActiveItems()
        {
            List<LisunDownload> result = new List<LisunDownload>();

            lock (gate)
            {
                foreach (LisunDownload item in items)
                    if (item.Active) result.Add(item);
            }

            return result;
        }

        public static bool Busy
        {
            get { return ActiveItems().Count > 0; }
        }

        public static LisunDownload Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;

            lock (gate)
            {
                for (int index = items.Count - 1; index >= 0; index--)
                    if (string.Equals(items[index].Name, name, StringComparison.OrdinalIgnoreCase))
                        return items[index];
            }

            return null;
        }

        /// <summary>Отменяет одну загрузку по имени.</summary>
        public static bool Cancel(string name)
        {
            LisunDownload item = Find(name);
            if (item == null || !item.Active) return false;

            item.CancelRequested = true;
            return true;
        }

        /// <summary>Отменяет всё, что идёт прямо сейчас.</summary>
        public static int CancelAll()
        {
            int count = 0;

            foreach (LisunDownload item in ActiveItems())
            {
                item.CancelRequested = true;
                count++;
            }

            return count;
        }

        /// <summary>Убирает из списка всё, что уже закончилось.</summary>
        public static int Forget()
        {
            int removed = 0;

            lock (gate)
            {
                for (int index = items.Count - 1; index >= 0; index--)
                {
                    if (items[index].Active) continue;

                    items.RemoveAt(index);
                    removed++;
                }
            }

            return removed;
        }

        // =====================================================================
        //  Загрузка
        // =====================================================================

        /// <summary>Качает по одной ссылке. Возвращает запись о загрузке.</summary>
        public static LisunDownload Fetch(string name, string url, string target,
                                          string expectedHash, out string message)
        {
            return Fetch(name, new string[] { url }, target, expectedHash, out message);
        }

        /// <summary>
        /// Качает файл, перебирая зеркала до первого рабочего. Выполняется в
        /// текущем потоке: вызывающий сам решает, фон это или нет.
        /// </summary>
        public static LisunDownload Fetch(string name, string[] urls, string target,
                                          string expectedHash, out string message)
        {
            LisunDownload item = new LisunDownload();
            item.Name = string.IsNullOrEmpty(name) ? SafeName(target) : name;
            item.Target = target ?? string.Empty;
            item.ExpectedHash = Normalize(expectedHash);
            item.Url = urls != null && urls.Length > 0 ? urls[0] : string.Empty;

            lock (gate)
            {
                items.Add(item);

                while (items.Count > HistoryLimit)
                {
                    bool removed = false;

                    for (int index = 0; index < items.Count; index++)
                    {
                        if (items[index].Active) continue;

                        items.RemoveAt(index);
                        removed = true;
                        break;
                    }

                    if (!removed) break;
                }
            }

            if (urls == null || urls.Length == 0)
            {
                Finish(item, LisunDownloadState.Failed, LisunLocale.T("dl.noUrl"));
                message = LisunLocale.T("dl.failed", item.Name, item.Error);
                return item;
            }

            if (string.IsNullOrEmpty(item.Target))
            {
                Finish(item, LisunDownloadState.Failed, LisunLocale.T("dl.noTarget"));
                message = LisunLocale.T("dl.failed", item.Name, item.Error);
                return item;
            }

            Prepare(item.Target);

            item.State = LisunDownloadState.Running;
            item.Started = DateTime.Now;
            Raise(item);

            LisunEngine.Log("[download] " + LisunLocale.T("dl.started", item.Name, item.Url).Trim());

            string lastError = string.Empty;

            for (int mirror = 0; mirror < urls.Length; mirror++)
            {
                string url = urls[mirror];
                if (string.IsNullOrEmpty(url)) continue;

                item.Url = url;

                if (urls.Length > 1)
                    LisunEngine.Log("[download] " + LisunLocale.T("dl.mirror",
                        mirror + 1, urls.Length, url).Trim());

                for (int attempt = 1; attempt <= Attempts; attempt++)
                {
                    if (item.CancelRequested)
                    {
                        Finish(item, LisunDownloadState.Canceled, string.Empty);
                        message = LisunLocale.T("dl.canceled", item.Name);
                        return item;
                    }

                    try
                    {
                        Transfer(item, url);

                        if (item.CancelRequested)
                        {
                            Finish(item, LisunDownloadState.Canceled, string.Empty);
                            message = LisunLocale.T("dl.canceled", item.Name);
                            return item;
                        }

                        if (item.ExpectedHash.Length > 0)
                        {
                            item.ActualHash = Sha256File(item.Target);

                            if (!string.Equals(item.ActualHash, item.ExpectedHash,
                                               StringComparison.OrdinalIgnoreCase))
                            {
                                lastError = LisunLocale.T("dl.hashMismatch",
                                    Short(item.ExpectedHash), Short(item.ActualHash));

                                try { File.Delete(item.Target); }
                                catch { }

                                item.Received = 0;
                                continue;
                            }
                        }

                        lock (gate) TotalBytes += item.Received - item.Resumed;

                        Finish(item, LisunDownloadState.Done, string.Empty);

                        message = LisunLocale.T("dl.done", item.Name,
                            CustomFormUtils.FormatSize(item.Received),
                            Rate(item.Speed));
                        return item;
                    }
                    catch (WebException ex)
                    {
                        lastError = Describe(ex);

                        // 416 — на сервере файл иначе, чем наш обрывок: качаем заново.
                        HttpWebResponse failed = ex.Response as HttpWebResponse;
                        if (failed != null && (int)failed.StatusCode == 416)
                        {
                            try { File.Delete(item.Target); }
                            catch { }

                            item.Received = 0;
                            item.Resumed = 0;
                        }
                    }
                    catch (Exception ex)
                    {
                        lastError = ex.Message;
                    }

                    if (attempt < Attempts)
                    {
                        LisunEngine.Log("[download] " + LisunLocale.T("dl.retry",
                            attempt, Attempts, lastError).Trim());
                        Thread.Sleep(700 * attempt);
                    }
                }
            }

            Finish(item, LisunDownloadState.Failed, lastError);
            message = LisunLocale.T("dl.failed", item.Name, lastError);
            return item;
        }

        /// <summary>То же, но в отдельном потоке: окну не нужно ждать.</summary>
        public static LisunDownload Begin(string name, string[] urls, string target,
                                          string expectedHash, Action<LisunDownload> done)
        {
            LisunDownload created = null;
            ManualResetEvent ready = new ManualResetEvent(false);

            Thread worker = new Thread(delegate ()
            {
                string message;
                LisunDownload item = null;

                try
                {
                    item = Fetch(name, urls, target, expectedHash, out message);
                }
                finally
                {
                    created = item;
                    ready.Set();
                }

                if (done != null)
                {
                    try { done(item); }
                    catch (Exception ex) { LisunEngine.Log("[download] [ОШИБКА] " + ex.Message); }
                }
            });

            worker.IsBackground = true;
            worker.Name = "LisunDownload:" + (name ?? "file");
            worker.Start();

            // Ждём только появления записи, а не всей загрузки.
            ready.WaitOne(1500);
            return created ?? Find(name);
        }

        /// <summary>Короткий запрос за текстом: каталог, releases.json, проверка сети.</summary>
        public static string FetchText(string url, int timeoutMs, out string message)
        {
            message = string.Empty;

            try
            {
                Secure();

                HttpWebRequest request = Request(url);
                request.Timeout = timeoutMs > 0 ? timeoutMs : 15000;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream input = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(input, Encoding.UTF8))
                    return reader.ReadToEnd();
            }
            catch (WebException ex)
            {
                message = Describe(ex);
                return null;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return null;
            }
        }

        // =====================================================================
        //  Сама передача
        // =====================================================================

        /// <summary>
        /// Пишет файл по блокам: иначе не видно прогресса. Если файл уже начат,
        /// просит у сервера остаток через Range — докачка вместо нового круга.
        /// </summary>
        private static void Transfer(LisunDownload item, string url)
        {
            Secure();

            long already = 0;

            try
            {
                FileInfo info = new FileInfo(item.Target);
                if (info.Exists && info.Length > 0) already = info.Length;
            }
            catch { already = 0; }

            HttpWebRequest request = Request(url);
            request.Timeout = 30000;
            request.ReadWriteTimeout = 180000;

            if (already > 0)
            {
                try { request.AddRange(already); }
                catch { already = 0; }
            }

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            {
                bool partial = (int)response.StatusCode == 206;
                if (!partial) already = 0;

                item.Resumed = already;
                item.Received = already;
                item.Total = response.ContentLength > 0 ? response.ContentLength + already : 0;
                item.Started = DateTime.Now;

                if (already > 0)
                    LisunEngine.Log("[download] " + LisunLocale.T("dl.resumed",
                        item.Name, CustomFormUtils.FormatSize(already)).Trim());

                Raise(item);

                FileMode mode = already > 0 ? FileMode.Append : FileMode.Create;

                using (Stream input = response.GetResponseStream())
                using (FileStream output = new FileStream(item.Target, mode, FileAccess.Write))
                {
                    if (input == null) return;

                    byte[] buffer = new byte[BufferSize];
                    int reported = -10;
                    int read;

                    while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (item.CancelRequested)
                        {
                            output.Flush();
                            return;
                        }

                        output.Write(buffer, 0, read);
                        item.Received += read;

                        Raise(item);

                        // В журнал — каждые 10 %, иначе терминал зальёт строками.
                        int percent = item.Percent;
                        if (item.Total > 0 && percent >= reported + 10)
                        {
                            reported = percent - percent % 10;

                            LisunEngine.Log("[download] " + LisunLocale.T("dl.progress",
                                item.Name, percent,
                                CustomFormUtils.FormatSize(item.Received) + " / " +
                                CustomFormUtils.FormatSize(item.Total),
                                Rate(item.Speed)).Trim());
                        }
                    }

                    output.Flush();
                }
            }

            if (item.Total > 0 && item.Received < item.Total)
                throw new IOException(LisunLocale.T("dl.short",
                    CustomFormUtils.FormatSize(item.Received),
                    CustomFormUtils.FormatSize(item.Total)));
        }

        private static HttpWebRequest Request(string url)
        {
            if (string.IsNullOrEmpty(url)) throw new ArgumentException("url");

            if (url.IndexOf("://", StringComparison.Ordinal) < 0) url = "https://" + url;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.UserAgent = "LisunOS/" + LisunEngine.Version;
            request.AllowAutoRedirect = true;
            request.MaximumAutomaticRedirections = 10;
            request.KeepAlive = false;
            request.Headers["Accept-Encoding"] = "identity";

            return request;
        }

        /// <summary>TLS 1.2 и 1.3: без них github и php.net просто рвут соединение.</summary>
        private static void Secure()
        {
            try { ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12; }
            catch { }

            try { ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; }
            catch { }

            try { ServicePointManager.SecurityProtocol |= (SecurityProtocolType)12288; }
            catch { }

            ServicePointManager.DefaultConnectionLimit = 8;
        }

        private static void Prepare(string target)
        {
            try
            {
                string directory = Path.GetDirectoryName(target);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);
            }
            catch { }
        }

        private static void Finish(LisunDownload item, LisunDownloadState state, string error)
        {
            item.State = state;
            item.Error = error ?? string.Empty;
            item.Finished = DateTime.Now;

            if (state == LisunDownloadState.Canceled || state == LisunDownloadState.Failed)
            {
                // Обрывок оставляем только при отмене: его можно докачать.
                if (state == LisunDownloadState.Failed)
                {
                    try
                    {
                        if (item.ExpectedHash.Length > 0 && File.Exists(item.Target))
                            File.Delete(item.Target);
                    }
                    catch { }
                }
            }

            Raise(item);
            Record(item);

            string note = state == LisunDownloadState.Done
                ? LisunLocale.T("dl.done", item.Name, CustomFormUtils.FormatSize(item.Received), Rate(item.Speed))
                : state == LisunDownloadState.Canceled
                    ? LisunLocale.T("dl.canceled", item.Name)
                    : LisunLocale.T("dl.failed", item.Name, item.Error);

            LisunEngine.Log("[download] " + note.Trim());
        }

        private static void Raise(LisunDownload item)
        {
            Action<LisunDownload> handler = Changed;
            if (handler == null) return;

            try { handler(item); }
            catch { }
        }

        // =====================================================================
        //  История
        // =====================================================================

        /// <summary>Дописывает строку в /os/root/downloads и обрезает файл.</summary>
        private static void Record(LisunDownload item)
        {
            try
            {
                string line = string.Join("|", new string[]
                {
                    item.Finished.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                    item.Name,
                    StateText(item.State),
                    item.Received.ToString(CultureInfo.InvariantCulture),
                    item.Url
                });

                List<string> lines = new List<string>();

                if (File.Exists(HistoryPath))
                    lines.AddRange(File.ReadAllLines(HistoryPath, Encoding.UTF8));

                lines.Add(line);

                while (lines.Count > HistoryLimit) lines.RemoveAt(0);

                Prepare(HistoryPath);
                File.WriteAllLines(HistoryPath, lines.ToArray(), Encoding.UTF8);
            }
            catch { }
        }

        /// <summary>История с диска — она переживает перезапуск.</summary>
        public static List<string> HistoryLines()
        {
            List<string> result = new List<string>();

            try
            {
                if (File.Exists(HistoryPath))
                    result.AddRange(File.ReadAllLines(HistoryPath, Encoding.UTF8));
            }
            catch { }

            return result;
        }

        public static bool ClearHistory()
        {
            try
            {
                if (File.Exists(HistoryPath)) File.Delete(HistoryPath);
                return true;
            }
            catch { return false; }
        }

        // =====================================================================
        //  Текст для терминала и окон
        // =====================================================================

        /// <summary>Полоска прогресса: [#####-----] 50 %.</summary>
        public static string Bar(LisunDownload item, int width)
        {
            if (item == null) return string.Empty;
            if (width < 4) width = 10;

            if (item.Total <= 0)
                return "[" + new string('?', width) + "] " + CustomFormUtils.FormatSize(item.Received);

            int filled = item.Percent * width / 100;
            if (filled > width) filled = width;
            if (filled < 0) filled = 0;

            return "[" + new string('#', filled) + new string('-', width - filled) + "] " +
                   item.Percent.ToString(CultureInfo.InvariantCulture) + " %";
        }

        /// <summary>Скорость человеческими словами: 1,4 МБ/с.</summary>
        public static string Rate(double bytesPerSecond)
        {
            if (bytesPerSecond <= 1) return "—";

            return CustomFormUtils.FormatSize((long)bytesPerSecond) + LisunLocale.T("dl.perSecond");
        }

        public static string StateText(LisunDownloadState state)
        {
            switch (state)
            {
                case LisunDownloadState.Queued: return LisunLocale.T("dl.stateQueued");
                case LisunDownloadState.Running: return LisunLocale.T("dl.stateRunning");
                case LisunDownloadState.Done: return LisunLocale.T("dl.stateDone");
                case LisunDownloadState.Canceled: return LisunLocale.T("dl.stateCanceled");
                default: return LisunLocale.T("dl.stateFailed");
            }
        }

        /// <summary>Одна строка о загрузке — для окна Wi-Fi и магазина.</summary>
        public static string Line(LisunDownload item)
        {
            if (item == null) return string.Empty;

            if (item.Active)
            {
                string tail = item.Remaining > TimeSpan.Zero
                    ? "  " + LisunLocale.T("dl.left", Minutes(item.Remaining))
                    : string.Empty;

                return item.Name + "  " + Bar(item, 14) + "  " + Rate(item.Speed) + tail;
            }

            if (item.State == LisunDownloadState.Done)
                return item.Name + "  " + LisunLocale.T("dl.stateDone") + "  " +
                       CustomFormUtils.FormatSize(item.Received);

            return item.Name + "  " + StateText(item.State) +
                   (item.Error.Length > 0 ? "  " + item.Error : string.Empty);
        }

        /// <summary>Что качается прямо сейчас.</summary>
        public static string ActiveText()
        {
            List<LisunDownload> active = ActiveItems();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("dl.activeHeader"));

            if (active.Count == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("dl.noActive"));
                return sb.ToString();
            }

            foreach (LisunDownload item in active)
            {
                sb.AppendLine("   " + Line(item));
                sb.AppendLine("      " + LisunLocale.T("dl.into",
                    CustomFormUtils.ToVirtualPath(item.Target)));
            }

            return sb.ToString();
        }

        /// <summary>История: последние загрузки с диска.</summary>
        public static string HistoryText(int limit)
        {
            List<string> lines = HistoryLines();

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("dl.historyHeader", LisunEngine.Version));

            if (lines.Count == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("dl.historyEmpty"));
                return sb.ToString();
            }

            int start = limit > 0 && lines.Count > limit ? lines.Count - limit : 0;

            for (int index = start; index < lines.Count; index++)
            {
                string[] parts = lines[index].Split('|');
                if (parts.Length < 5) continue;

                long size;
                if (!long.TryParse(parts[3], NumberStyles.Integer, CultureInfo.InvariantCulture, out size))
                    size = 0;

                sb.AppendLine("   " + parts[0] + "  " + Pad(parts[1], 18) + "  " +
                              Pad(parts[2], 10) + "  " + Pad(CustomFormUtils.FormatSize(size), 10));
                sb.AppendLine("      " + parts[4]);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("dl.totalSession",
                CustomFormUtils.FormatSize(TotalBytes)));

            return sb.ToString();
        }

        // =====================================================================
        //  Мелочи
        // =====================================================================

        /// <summary>sha256 файла в нижнем регистре — им проверяется компонент.</summary>
        public static string Sha256File(string path)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                using (SHA256 algorithm = SHA256.Create())
                {
                    byte[] hash = algorithm.ComputeHash(stream);

                    StringBuilder sb = new StringBuilder(hash.Length * 2);
                    for (int index = 0; index < hash.Length; index++)
                        sb.Append(hash[index].ToString("x2", CultureInfo.InvariantCulture));

                    return sb.ToString();
                }
            }
            catch { return string.Empty; }
        }

        /// <summary>Подпись PK: вместо архива могла прийти страница с ошибкой.</summary>
        public static bool LooksLikeZip(string path)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                {
                    if (stream.Length < 4) return false;

                    return stream.ReadByte() == 0x50 && stream.ReadByte() == 0x4B;
                }
            }
            catch { return false; }
        }

        private static string Normalize(string hash)
        {
            if (string.IsNullOrEmpty(hash)) return string.Empty;

            return hash.Trim().Replace(" ", string.Empty).Replace(":", string.Empty).ToLowerInvariant();
        }

        private static string Short(string hash)
        {
            if (string.IsNullOrEmpty(hash)) return "—";

            return hash.Length <= 12 ? hash : hash.Substring(0, 12);
        }

        private static string SafeName(string target)
        {
            try { return Path.GetFileName(target ?? string.Empty); }
            catch { return "file"; }
        }

        private static string Minutes(TimeSpan span)
        {
            if (span.TotalHours >= 1)
                return ((int)span.TotalHours) + " ч " + span.Minutes + " мин";

            if (span.TotalMinutes >= 1)
                return ((int)span.TotalMinutes) + " мин " + span.Seconds + " с";

            return span.Seconds + " с";
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value : value.PadRight(width);
        }

        /// <summary>Понятная причина вместо «The remote server returned an error».</summary>
        public static string Describe(WebException ex)
        {
            HttpWebResponse response = ex.Response as HttpWebResponse;

            if (response != null)
                return (int)response.StatusCode + " " + response.StatusDescription;

            switch (ex.Status)
            {
                case WebExceptionStatus.NameResolutionFailure:
                    return LisunLocale.T("dl.noDns");

                case WebExceptionStatus.ConnectFailure:
                    return LisunLocale.T("dl.noConnect");

                case WebExceptionStatus.Timeout:
                    return LisunLocale.T("dl.timeout");

                case WebExceptionStatus.TrustFailure:
                case WebExceptionStatus.SecureChannelFailure:
                    return LisunLocale.T("dl.tls");

                default:
                    return ex.Message;
            }
        }
    }
}
