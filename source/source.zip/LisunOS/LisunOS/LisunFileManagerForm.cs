﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Управление файлами внутри одного каталога (например, корня сайта www).
    /// Создание, переименование, удаление и правка файлов и папок —
    /// всё с проверкой разрешений приложения и без выхода за пределы корня.
    /// </summary>
    public class LisunFileManagerForm : Form
    {
        private readonly string rootPath;
        private readonly string packageName;
        private string currentPath;

        private Panel pnlBar;
        private Button btnUp;
        private Button btnRefresh;
        private Button btnNewFile;
        private Button btnNewFolder;
        private Button btnRename;
        private Button btnDelete;
        private Button btnEdit;
        private Label lblPath;
        private ListView lstItems;
        private Label lblStatus;

        public LisunFileManagerForm(string rootPath, string packageName, string title)
        {
            this.rootPath = rootPath;
            this.packageName = packageName;

            if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
            currentPath = rootPath;

            BuildInterface(title);
            LoadDirectory(currentPath);
        }

        // =====================================================================
        //  Интерфейс
        // =====================================================================

        private void BuildInterface(string title)
        {
            Text = string.IsNullOrEmpty(title) ? LisunLocale.T("fm.title") : title;
            ClientSize = new Size(880, 560);
            MinimumSize = new Size(680, 420);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            ForeColor = Theme.Text;
            Font = Theme.Ui(9.5f);
            KeyPreview = true;
            DoubleBuffered = true;

            pnlBar = new Panel();
            pnlBar.Dock = DockStyle.Top;
            pnlBar.Height = 58;
            pnlBar.BackColor = Theme.Surface;
            pnlBar.Padding = new Padding(12, 12, 12, 12);

            btnUp = MakeButton("↑", 44, LisunLocale.T("fm.up"));
            btnUp.Click += (s, e) => GoUp();

            btnRefresh = MakeButton("⟳", 44, LisunLocale.T("fm.refresh"));
            btnRefresh.Click += (s, e) => LoadDirectory(currentPath);

            btnNewFile = MakeButton(LisunLocale.T("fm.newFile"), 120, null);
            btnNewFile.Click += (s, e) => CreateFile();

            btnNewFolder = MakeButton(LisunLocale.T("fm.newFolder"), 120, null);
            btnNewFolder.Click += (s, e) => CreateFolder();

            btnEdit = MakeButton(LisunLocale.T("fm.edit"), 110, null);
            btnEdit.Click += (s, e) => EditSelected();

            btnRename = MakeButton(LisunLocale.T("fm.rename"), 130, null);
            btnRename.Click += (s, e) => RenameSelected();

            btnDelete = MakeButton(LisunLocale.T("fm.delete"), 110, null);
            Theme.StyleButton(btnDelete, Color.FromArgb(82, 30, 30), Theme.Danger);
            btnDelete.Click += (s, e) => DeleteSelected();

            // Кнопки добавляются справа налево, поэтому порядок обратный.
            pnlBar.Controls.Add(btnDelete);
            pnlBar.Controls.Add(btnRename);
            pnlBar.Controls.Add(btnEdit);
            pnlBar.Controls.Add(btnNewFolder);
            pnlBar.Controls.Add(btnNewFile);
            pnlBar.Controls.Add(btnRefresh);
            pnlBar.Controls.Add(btnUp);

            lblPath = new Label();
            lblPath.Dock = DockStyle.Top;
            lblPath.Height = 32;
            lblPath.BackColor = Theme.SurfaceAlt;
            lblPath.ForeColor = Theme.Cyan;
            lblPath.Font = Theme.Mono(9.5f);
            lblPath.TextAlign = ContentAlignment.MiddleLeft;
            lblPath.Padding = new Padding(16, 0, 0, 0);

            lstItems = new ListView();
            lstItems.Dock = DockStyle.Fill;
            lstItems.View = View.Details;
            lstItems.FullRowSelect = true;
            lstItems.MultiSelect = false;
            lstItems.HideSelection = false;
            lstItems.BorderStyle = BorderStyle.None;
            lstItems.BackColor = Theme.Surface;
            lstItems.ForeColor = Theme.Text;
            lstItems.Font = Theme.Ui(9.5f);
            lstItems.Columns.Add(LisunLocale.T("explorer.colName"), 330);
            lstItems.Columns.Add(LisunLocale.T("explorer.colType"), 130);
            lstItems.Columns.Add(LisunLocale.T("explorer.colSize"), 100, HorizontalAlignment.Right);
            lstItems.Columns.Add(LisunLocale.T("explorer.colDate"), 150);
            lstItems.MouseDoubleClick += (s, e) => OpenSelected();
            lstItems.SelectedIndexChanged += (s, e) => UpdateButtons();

            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add(LisunLocale.T("fm.openItem"), null, (s, e) => OpenSelected());
            menu.Items.Add(LisunLocale.T("fm.edit"), null, (s, e) => EditSelected());
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(LisunLocale.T("fm.newFile"), null, (s, e) => CreateFile());
            menu.Items.Add(LisunLocale.T("fm.newFolder"), null, (s, e) => CreateFolder());
            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(LisunLocale.T("fm.rename"), null, (s, e) => RenameSelected());
            menu.Items.Add(LisunLocale.T("fm.delete"), null, (s, e) => DeleteSelected());
            Theme.HarmonizeStrip(menu);
            lstItems.ContextMenuStrip = menu;

            lblStatus = new Label();
            lblStatus.Dock = DockStyle.Bottom;
            lblStatus.Height = 30;
            lblStatus.BackColor = Theme.Surface;
            lblStatus.ForeColor = Theme.TextDim;
            lblStatus.Font = Theme.Mono(9f);
            lblStatus.TextAlign = ContentAlignment.MiddleLeft;
            lblStatus.Padding = new Padding(16, 0, 0, 0);

            Controls.Add(lstItems);
            Controls.Add(lblStatus);
            Controls.Add(lblPath);
            Controls.Add(pnlBar);

            KeyDown += FileManager_KeyDown;
        }

        private Button MakeButton(string text, int width, string tooltip)
        {
            Button button = new Button();
            button.Text = text;
            button.Dock = DockStyle.Left;
            button.Width = width;
            button.Margin = new Padding(0, 0, 8, 0);
            Theme.StyleButton(button, Theme.SurfaceAlt, Theme.Text);

            if (!string.IsNullOrEmpty(tooltip))
            {
                ToolTip hint = new ToolTip();
                hint.SetToolTip(button, tooltip);
            }
            return button;
        }

        private void FileManager_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5) { LoadDirectory(currentPath); e.Handled = true; }
            else if (e.KeyCode == Keys.F2) { RenameSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.Delete) { DeleteSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.Back) { GoUp(); e.Handled = true; }
            else if (e.KeyCode == Keys.Enter) { OpenSelected(); e.Handled = true; }
        }

        // =====================================================================
        //  Навигация и список
        // =====================================================================

        private bool IsRoot(string path)
        {
            return string.Equals(path.TrimEnd(Path.DirectorySeparatorChar),
                                 rootPath.TrimEnd(Path.DirectorySeparatorChar),
                                 StringComparison.OrdinalIgnoreCase);
        }

        private void GoUp()
        {
            if (IsRoot(currentPath)) return;

            DirectoryInfo parent = Directory.GetParent(currentPath);
            if (parent == null) return;

            // За пределы корня сервера не выходим.
            if (!parent.FullName.StartsWith(rootPath.TrimEnd(Path.DirectorySeparatorChar),
                    StringComparison.OrdinalIgnoreCase)) return;

            LoadDirectory(parent.FullName);
        }

        private void LoadDirectory(string path)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles))
            {
                lblStatus.Text = LisunLocale.T("perm.denied", packageName, LisunPermissions.ReadFiles).Trim();
                return;
            }

            if (!Directory.Exists(path)) return;
            currentPath = path;

            lblPath.Text = DisplayPath(path);
            btnUp.Enabled = !IsRoot(path);

            lstItems.BeginUpdate();
            try
            {
                lstItems.Items.Clear();

                List<string> folders;
                List<string> files = CustomFormUtils.GetDirectoryContent(path, out folders);

                foreach (string folder in folders)
                {
                    string full = Path.Combine(path, folder);
                    ListViewItem item = new ListViewItem(folder);
                    item.Tag = full;
                    item.SubItems.Add(LisunLocale.T("explorer.folder"));
                    item.SubItems.Add("");
                    item.SubItems.Add(SafeTime(full, true));
                    item.ForeColor = Theme.Warning;
                    lstItems.Items.Add(item);
                }

                foreach (string file in files)
                {
                    string full = Path.Combine(path, file);
                    long size = 0;
                    try { size = new FileInfo(full).Length; }
                    catch { }

                    string extension = Path.GetExtension(file);
                    ListViewItem item = new ListViewItem(file);
                    item.Tag = full;
                    item.SubItems.Add(string.IsNullOrEmpty(extension)
                        ? LisunLocale.T("explorer.file")
                        : LisunLocale.T("explorer.fileExt", extension.TrimStart('.').ToUpper()));
                    item.SubItems.Add(CustomFormUtils.FormatSize(size));
                    item.SubItems.Add(SafeTime(full, false));
                    item.ForeColor = Theme.Text;
                    lstItems.Items.Add(item);
                }

                lblStatus.Text = LisunLocale.T("fm.status", folders.Count, files.Count);
            }
            finally
            {
                lstItems.EndUpdate();
            }

            UpdateButtons();
        }

        private void UpdateButtons()
        {
            bool selected = lstItems.SelectedItems.Count > 0;
            bool isFile = selected && File.Exists(SelectedPath());

            btnRename.Enabled = selected;
            btnDelete.Enabled = selected;
            btnEdit.Enabled = isFile;
        }

        private string DisplayPath(string path)
        {
            string root = rootPath.TrimEnd(Path.DirectorySeparatorChar);
            if (!path.StartsWith(root, StringComparison.OrdinalIgnoreCase)) return CustomFormUtils.ToVirtualPath(path);

            string tail = path.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar);
            return tail.Length == 0 ? "www:\\" : "www:\\" + tail;
        }

        private static string SafeTime(string path, bool directory)
        {
            try
            {
                DateTime time = directory ? Directory.GetLastWriteTime(path) : File.GetLastWriteTime(path);
                return time.ToString("dd.MM.yyyy HH:mm");
            }
            catch { return ""; }
        }

        private string SelectedPath()
        {
            if (lstItems.SelectedItems.Count == 0) return null;

            object tag = lstItems.SelectedItems[0].Tag;
            return tag == null ? null : tag.ToString();
        }

        /// <summary>Разрешает путь только внутри корня сервера.</summary>
        private bool InsideRoot(string path)
        {
            try
            {
                string full = Path.GetFullPath(path);
                string root = Path.GetFullPath(rootPath).TrimEnd(Path.DirectorySeparatorChar);
                return full.StartsWith(root, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        // =====================================================================
        //  Действия
        // =====================================================================

        private void OpenSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (Directory.Exists(target)) { LoadDirectory(target); return; }
            if (File.Exists(target)) EditSelected();
        }

        private void CreateFile()
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("fm.newFile"),
                LisunLocale.T("fm.namePrompt"), "index.html", this);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (!InsideRoot(target)) { Warn(LisunLocale.T("fm.outside")); return; }

            if (File.Exists(target) || Directory.Exists(target)) { Warn(LisunLocale.T("explorer.exists")); return; }

            // Для html-файла сразу кладём минимальный каркас страницы.
            string content = name.EndsWith(".html", StringComparison.OrdinalIgnoreCase) ||
                             name.EndsWith(".htm", StringComparison.OrdinalIgnoreCase)
                ? "<!doctype html>" + Environment.NewLine +
                  "<html lang=\"ru\"><head><meta charset=\"utf-8\">" + Environment.NewLine +
                  "<title>" + Path.GetFileNameWithoutExtension(name) + "</title></head>" + Environment.NewLine +
                  "<body>" + Environment.NewLine + Environment.NewLine + "</body></html>"
                : string.Empty;

            if (!CustomFormUtils.WriteFileText(target, content)) { Warn(LisunLocale.T("fm.createFailed")); return; }

            LoadDirectory(currentPath);
            SelectByName(name);
        }

        private void CreateFolder()
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("fm.newFolder"),
                LisunLocale.T("fm.namePrompt"), "assets", this);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (!InsideRoot(target)) { Warn(LisunLocale.T("fm.outside")); return; }

            if (Directory.Exists(target) || File.Exists(target)) { Warn(LisunLocale.T("explorer.exists")); return; }

            if (!CustomFormUtils.CreateFolder(target)) { Warn(LisunLocale.T("fm.createFailed")); return; }

            LoadDirectory(currentPath);
            SelectByName(name);
        }

        private void RenameSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

            string oldName = Path.GetFileName(target);
            string newName = CustomFormUtils.Prompt(LisunLocale.T("fm.rename"),
                LisunLocale.T("explorer.newName"), oldName, this);
            if (string.IsNullOrEmpty(newName) || newName == oldName) return;

            string destination = Path.Combine(currentPath, newName);
            if (!InsideRoot(destination)) { Warn(LisunLocale.T("fm.outside")); return; }

            try
            {
                if (Directory.Exists(target)) Directory.Move(target, destination);
                else File.Move(target, destination);
            }
            catch (Exception ex)
            {
                Warn(LisunLocale.T("explorer.renameErr", ex.Message));
                return;
            }

            LoadDirectory(currentPath);
            SelectByName(newName);
        }

        private void DeleteSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageFiles)) return;
            if (!InsideRoot(target)) { Warn(LisunLocale.T("fm.outside")); return; }

            // Файл с защищёнными блоками удалить нельзя.
            if (File.Exists(target) && LisunApiEndpoint.FileBlocksDeletion(target))
            {
                Warn(LisunLocale.T("api.fileProtected", Path.GetFileName(target)));
                return;
            }

            bool isDirectory = Directory.Exists(target);
            string question = isDirectory
                ? LisunLocale.T("fm.confirmFolder", Path.GetFileName(target))
                : LisunLocale.T("explorer.confirm", Path.GetFileName(target));

            if (MessageBox.Show(question, Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
                return;

            bool removed = isDirectory
                ? CustomFormUtils.DeleteFolder(target)
                : CustomFormUtils.DeleteFile(target);

            if (!removed) Warn(LisunLocale.T("fm.deleteFailed"));

            LoadDirectory(currentPath);
        }

        private void SelectByName(string name)
        {
            foreach (ListViewItem item in lstItems.Items)
            {
                if (!item.Text.Equals(name, StringComparison.OrdinalIgnoreCase)) continue;

                item.Selected = true;
                item.EnsureVisible();
                lstItems.Focus();
                return;
            }
        }

        // =====================================================================
        //  Правка файла
        // =====================================================================

        private void EditSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target) || !File.Exists(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;

            long size = 0;
            try { size = new FileInfo(target).Length; }
            catch { }

            if (size > 2 * 1024 * 1024)
            {
                Warn(LisunLocale.T("fm.tooBig", CustomFormUtils.FormatSize(size)));
                return;
            }

            using (Form editor = new Form())
            {
                editor.Text = LisunLocale.T("fm.editing", Path.GetFileName(target));
                editor.ClientSize = new Size(860, 620);
                editor.StartPosition = FormStartPosition.CenterParent;
                editor.BackColor = Theme.Background;
                editor.ForeColor = Theme.Text;
                editor.Font = Theme.Ui(9.5f);
                editor.MinimumSize = new Size(560, 400);

                TextBox box = new TextBox();
                box.Multiline = true;
                box.AcceptsTab = true;
                box.WordWrap = false;
                box.ScrollBars = ScrollBars.Both;
                box.Dock = DockStyle.Fill;
                box.BackColor = Theme.Surface;
                box.ForeColor = Theme.Text;
                box.BorderStyle = BorderStyle.None;
                box.Font = Theme.Mono(10.5f);
                string originalText = LisunCrypto.ReadAllText(target);
                box.Text = originalText;

                Panel pad = new Panel();
                pad.Dock = DockStyle.Fill;
                pad.Padding = new Padding(14);
                pad.BackColor = Theme.Background;
                pad.Controls.Add(box);

                Panel bar = new Panel();
                bar.Dock = DockStyle.Bottom;
                bar.Height = 58;
                bar.BackColor = Theme.Surface;
                bar.Padding = new Padding(14, 12, 14, 12);

                Label info = new Label();
                info.Dock = DockStyle.Left;
                info.Width = 420;
                info.ForeColor = Theme.TextDim;
                info.Font = Theme.Mono(9f);
                info.TextAlign = ContentAlignment.MiddleLeft;
                string protection = LisunApiEndpoint.DescribeProtection(originalText);

                info.Text = protection.Length > 0 ? protection : DisplayPath(target);
                if (protection.Length > 0) info.ForeColor = Theme.Warning;

                Button cancel = new Button();
                cancel.Text = LisunLocale.T("dialog.cancel");
                cancel.Dock = DockStyle.Right;
                cancel.Width = 120;
                cancel.DialogResult = DialogResult.Cancel;
                Theme.StyleButton(cancel, Theme.SurfaceAlt, Theme.Text);

                Button save = new Button();
                save.Text = LisunLocale.T("fm.save");
                save.Dock = DockStyle.Right;
                save.Width = 130;
                save.DialogResult = DialogResult.OK;
                Theme.StyleButton(save, Theme.AccentDeep, Theme.Text);

                bar.Controls.Add(cancel);
                bar.Controls.Add(save);
                bar.Controls.Add(info);

                editor.Controls.Add(pad);
                editor.Controls.Add(bar);
                editor.AcceptButton = null;
                editor.CancelButton = cancel;

                if (editor.ShowDialog(this) != DialogResult.OK) return;

                if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

                // Защищённые блоки NOREMOVE обязаны остаться на месте.
                string finalText = box.Text;
                string blockError;

                if (!LisunApiEndpoint.ValidateEdit(originalText, finalText, out blockError))
                {
                    DialogResult answer = MessageBox.Show(
                        blockError + Environment.NewLine + Environment.NewLine + LisunLocale.T("api.restoreAsk"),
                        Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (answer != DialogResult.Yes) return;

                    finalText = LisunApiEndpoint.RestoreBlocks(originalText, finalText);
                }

                if (!CustomFormUtils.WriteFileText(target, finalText))
                {
                    Warn(LisunLocale.T("fm.saveFailed"));
                    return;
                }

                LisunEngine.Log("[FileManager] Сохранён " + CustomFormUtils.ToVirtualPath(target));
                LoadDirectory(currentPath);
                SelectByName(Path.GetFileName(target));
            }
        }

        private void Warn(string message)
        {
            MessageBox.Show(message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
