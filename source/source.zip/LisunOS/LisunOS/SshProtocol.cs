﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    // =====================================================================
    //  SSH-2 — настоящий протокол, чтобы работал обычный клиент ssh.
    //
    //  Раньше сервер говорил простым текстом поверх TCP: заходить
    //  приходилось PuTTY в режиме Raw. Теперь подключается именно ssh —
    //  с телефона и с другого ПК, — потому что здесь реализован обмен
    //  ключами и шифрование по RFC 4253.
    //
    //  Набор намеренно один, зато проверенный целиком:
    //      обмен ключами  diffie-hellman-group14-sha256
    //      ключ хоста     rsa-sha2-256 (ключ 2048 бит, свой у каждой машины)
    //      шифр           aes128-ctr
    //      контроль       hmac-sha2-256
    //      сжатия нет
    //
    //  Библиотек не требуется: всё собрано из того, что есть в .NET.
    // =====================================================================

    /// <summary>Сборка значений в том виде, в каком их ждёт протокол.</summary>
    internal sealed class SshWriter
    {
        private readonly MemoryStream stream = new MemoryStream();

        public SshWriter Byte(byte value)
        {
            stream.WriteByte(value);
            return this;
        }

        public SshWriter Bytes(byte[] value)
        {
            if (value != null && value.Length > 0) stream.Write(value, 0, value.Length);
            return this;
        }

        public SshWriter UInt32(uint value)
        {
            stream.WriteByte((byte)(value >> 24));
            stream.WriteByte((byte)(value >> 16));
            stream.WriteByte((byte)(value >> 8));
            stream.WriteByte((byte)value);
            return this;
        }

        public SshWriter Boolean(bool value)
        {
            stream.WriteByte(value ? (byte)1 : (byte)0);
            return this;
        }

        /// <summary>Строка протокола: длина четырьмя байтами, затем данные.</summary>
        public SshWriter String(byte[] value)
        {
            if (value == null) value = new byte[0];

            UInt32((uint)value.Length);
            return Bytes(value);
        }

        public SshWriter String(string value)
        {
            return String(Encoding.UTF8.GetBytes(value ?? string.Empty));
        }

        public SshWriter NameList(params string[] names)
        {
            return String(string.Join(",", names ?? new string[0]));
        }

        /// <summary>
        /// Целое со знаком. Старший бит задаёт знак, поэтому положительное
        /// число, у которого он установлен, дополняется нулевым байтом.
        /// </summary>
        public SshWriter MpInt(BigInteger value)
        {
            if (value.IsZero) return UInt32(0);

            byte[] raw = SshMath.ToUnsigned(value);
            if ((raw[0] & 0x80) != 0)
            {
                byte[] padded = new byte[raw.Length + 1];
                Buffer.BlockCopy(raw, 0, padded, 1, raw.Length);
                raw = padded;
            }

            return String(raw);
        }

        public byte[] ToArray()
        {
            return stream.ToArray();
        }
    }

    /// <summary>Разбор значений обратно.</summary>
    internal sealed class SshReader
    {
        private readonly byte[] data;
        private int position;

        public SshReader(byte[] data, int offset)
        {
            this.data = data ?? new byte[0];
            position = offset;
        }

        public bool Done
        {
            get { return position >= data.Length; }
        }

        public byte Byte()
        {
            if (position >= data.Length) throw new EndOfStreamException("пакет кончился");
            return data[position++];
        }

        public uint UInt32()
        {
            if (position + 4 > data.Length) throw new EndOfStreamException("пакет кончился");

            uint value = (uint)((data[position] << 24) | (data[position + 1] << 16) |
                                (data[position + 2] << 8) | data[position + 3]);
            position += 4;
            return value;
        }

        public bool Boolean()
        {
            return Byte() != 0;
        }

        public byte[] String()
        {
            int size = (int)UInt32();
            if (size < 0 || position + size > data.Length) throw new EndOfStreamException("строка за границей пакета");

            byte[] value = new byte[size];
            Buffer.BlockCopy(data, position, value, 0, size);
            position += size;

            return value;
        }

        public string Text()
        {
            return Encoding.UTF8.GetString(String());
        }

        public BigInteger MpInt()
        {
            return SshMath.FromUnsigned(String());
        }
    }

    /// <summary>
    /// Преобразования чисел. BigInteger в .NET хранит байты от младшего
    /// к старшему и со знаком, а протокол ждёт обратный порядок и без знака —
    /// поэтому переводы собраны в одном месте.
    /// </summary>
    internal static class SshMath
    {
        public static byte[] ToUnsigned(BigInteger value)
        {
            byte[] little = value.ToByteArray();

            int length = little.Length;
            while (length > 1 && little[length - 1] == 0) length--;

            byte[] big = new byte[length];
            for (int index = 0; index < length; index++) big[index] = little[length - 1 - index];

            return big;
        }

        public static BigInteger FromUnsigned(byte[] big)
        {
            if (big == null || big.Length == 0) return BigInteger.Zero;

            // Лишний нулевой байт в конце делает число заведомо положительным.
            byte[] little = new byte[big.Length + 1];
            for (int index = 0; index < big.Length; index++) little[index] = big[big.Length - 1 - index];

            return new BigInteger(little);
        }
    }

    /// <summary>Ключ хоста: один на машину, создаётся при первом запуске.</summary>
    internal static class SshHostKey
    {
        private static RSACryptoServiceProvider key;
        private static readonly object gate = new object();

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, ".ssh_host_key"); }
        }

        /// <summary>Отпечаток ключа — его и показывает клиент при первом входе.</summary>
        public static string Fingerprint()
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(Blob());
                return "SHA256:" + Convert.ToBase64String(hash).TrimEnd('=');
            }
        }

        /// <summary>
        /// Подпись SHA-256 умеет только провайдер PROV_RSA_AES (тип 24).
        /// Провайдер по умолчанию на этот алгоритм отвечает отказом, и
        /// рукопожатие рвалось бы на самой подписи.
        /// </summary>
        private static RSACryptoServiceProvider NewProvider()
        {
            CspParameters parameters = new CspParameters(24);

            RSACryptoServiceProvider provider = new RSACryptoServiceProvider(2048, parameters);
            provider.PersistKeyInCsp = false;

            return provider;
        }

        public static RSACryptoServiceProvider Key()
        {
            lock (gate)
            {
                if (key != null) return key;

                try
                {
                    if (File.Exists(StorePath))
                    {
                        RSACryptoServiceProvider loaded = NewProvider();
                        loaded.FromXmlString(File.ReadAllText(StorePath));

                        key = loaded;
                        return key;
                    }
                }
                catch (Exception ex)
                {
                    LisunEngine.Log("[ssh] [ОШИБКА] Ключ хоста: " + ex.Message);
                }

                // Ключа ещё нет — создаём и кладём рядом с реестром.
                RSACryptoServiceProvider fresh = NewProvider();

                try
                {
                    string folder = Path.GetDirectoryName(StorePath);
                    if (folder != null && !Directory.Exists(folder)) Directory.CreateDirectory(folder);

                    File.WriteAllText(StorePath, fresh.ToXmlString(true));
                }
                catch (Exception ex)
                {
                    LisunEngine.Log("[ssh] [ОШИБКА] Запись ключа хоста: " + ex.Message);
                }

                key = fresh;
                return key;
            }
        }

        /// <summary>Открытый ключ в виде, который уходит клиенту.</summary>
        public static byte[] Blob()
        {
            RSAParameters parameters = Key().ExportParameters(false);

            return new SshWriter()
                .String("ssh-rsa")
                .MpInt(SshMath.FromUnsigned(parameters.Exponent))
                .MpInt(SshMath.FromUnsigned(parameters.Modulus))
                .ToArray();
        }

        public static byte[] Sign(byte[] hash)
        {
            byte[] signature = Key().SignHash(hash, CryptoConfig.MapNameToOID("SHA256"));

            return new SshWriter()
                .String("rsa-sha2-256")
                .String(signature)
                .ToArray();
        }
    }

    /// <summary>
    /// Шифр aes128-ctr. В .NET готового CTR нет, но он собирается из ECB:
    /// шифруется счётчик, результат складывается с данными по xor.
    /// </summary>
    internal sealed class SshCtr : IDisposable
    {
        private readonly ICryptoTransform block;
        private readonly byte[] counter;
        private readonly byte[] pad = new byte[16];
        private readonly byte[] scratch = new byte[16];
        private int used = 16;

        public SshCtr(byte[] key, byte[] iv)
        {
            AesManaged aes = new AesManaged();
            aes.Mode = CipherMode.ECB;
            aes.Padding = PaddingMode.None;
            aes.KeySize = key.Length * 8;
            aes.Key = key;

            block = aes.CreateEncryptor();
            counter = (byte[])iv.Clone();
        }

        public byte[] Apply(byte[] data, int offset, int length)
        {
            byte[] result = new byte[length];

            for (int index = 0; index < length; index++)
            {
                if (used == 16)
                {
                    block.TransformBlock(counter, 0, 16, pad, 0);
                    Increment();
                    used = 0;
                }

                result[index] = (byte)(data[offset + index] ^ pad[used]);
                used++;
            }

            return result;
        }

        public byte[] Apply(byte[] data)
        {
            return Apply(data, 0, data.Length);
        }

        private void Increment()
        {
            for (int index = 15; index >= 0; index--)
            {
                counter[index]++;
                if (counter[index] != 0) break;
            }
        }

        public void Dispose()
        {
            try { block.Dispose(); }
            catch { }

            Array.Clear(pad, 0, pad.Length);
            Array.Clear(scratch, 0, scratch.Length);
        }
    }

    /// <summary>
    /// Вывод ключей сеанса по RFC 4253 §7.2.
    /// Чистая функция, вынесенная отдельно: её удобно сверять с эталоном.
    /// </summary>
    internal static class SshKeys
    {
        public static byte[] Derive(byte[] baseData, byte[] sessionId, byte letter, int size)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] value = sha.ComputeHash(new SshWriter()
                    .Bytes(baseData).Byte(letter).Bytes(sessionId).ToArray());

                while (value.Length < size)
                {
                    byte[] more = sha.ComputeHash(new SshWriter()
                        .Bytes(baseData).Bytes(value).ToArray());

                    byte[] joined = new byte[value.Length + more.Length];
                    Buffer.BlockCopy(value, 0, joined, 0, value.Length);
                    Buffer.BlockCopy(more, 0, joined, value.Length, more.Length);

                    value = joined;
                }

                byte[] result = new byte[size];
                Buffer.BlockCopy(value, 0, result, 0, size);

                return result;
            }
        }
    }

    /// <summary>
    /// Транспорт SSH-2: обмен версиями, согласование ключей, пакеты.
    /// Порядок байт в каждом поле здесь ровно тот, что задан в RFC 4253:
    /// ошибка в одном байте рвёт соединение без объяснения, поэтому
    /// сборка значений вынесена в SshWriter и не повторяется руками.
    /// </summary>
    internal sealed class SshTransport : IDisposable
    {
        public const byte MsgDisconnect = 1;
        public const byte MsgIgnore = 2;
        public const byte MsgUnimplemented = 3;
        public const byte MsgDebug = 4;
        public const byte MsgServiceRequest = 5;
        public const byte MsgServiceAccept = 6;
        public const byte MsgExtInfo = 7;
        public const byte MsgKexInit = 20;
        public const byte MsgNewKeys = 21;
        public const byte MsgKexDhInit = 30;
        public const byte MsgKexDhReply = 31;
        public const byte MsgUserauthRequest = 50;
        public const byte MsgUserauthFailure = 51;
        public const byte MsgUserauthSuccess = 52;
        public const byte MsgGlobalRequest = 80;
        public const byte MsgRequestFailure = 82;
        public const byte MsgChannelOpen = 90;
        public const byte MsgChannelOpenConfirmation = 91;
        public const byte MsgChannelOpenFailure = 92;
        public const byte MsgChannelWindowAdjust = 93;
        public const byte MsgChannelData = 94;
        public const byte MsgChannelEof = 96;
        public const byte MsgChannelClose = 97;
        public const byte MsgChannelRequest = 98;
        public const byte MsgChannelSuccess = 99;
        public const byte MsgChannelFailure = 100;

        /// <summary>Группа 14 из RFC 3526, 2048 бит.</summary>
        private const string Group14 =
            "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74" +
            "020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437" +
            "4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED" +
            "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05" +
            "98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB" +
            "9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B" +
            "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718" +
            "3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF";

        public static readonly string ServerVersion = "SSH-2.0-LisunOS_" + LisunEngine.Version;

        private readonly NetworkStream stream;
        private readonly RandomNumberGenerator random = RandomNumberGenerator.Create();

        private uint sequenceIn;
        private uint sequenceOut;

        private SshCtr encryptOut;
        private SshCtr decryptIn;
        private byte[] macKeyOut;
        private byte[] macKeyIn;

        private byte[] sessionId;

        public SshTransport(NetworkStream stream)
        {
            this.stream = stream;
        }

        // -----------------------------------------------------------------
        //  Пакеты
        // -----------------------------------------------------------------

        public void Send(byte[] payload)
        {
            int block = encryptOut != null ? 16 : 8;

            int size = 1 + payload.Length;
            int pad = block - ((size + 4) % block);
            if (pad < 4) pad += block;

            byte[] filler = new byte[pad];
            random.GetBytes(filler);

            byte[] packet = new SshWriter()
                .UInt32((uint)(size + pad))
                .Byte((byte)pad)
                .Bytes(payload)
                .Bytes(filler)
                .ToArray();

            if (encryptOut != null)
            {
                byte[] mac = Mac(macKeyOut, sequenceOut, packet);
                byte[] body = encryptOut.Apply(packet);

                stream.Write(body, 0, body.Length);
                stream.Write(mac, 0, mac.Length);
            }
            else stream.Write(packet, 0, packet.Length);

            stream.Flush();
            sequenceOut++;
        }

        public byte[] Receive()
        {
            byte[] packet;

            if (decryptIn != null)
            {
                // Длина лежит внутри шифра, поэтому сначала расшифровываем
                // первый блок и только потом знаем, сколько читать дальше.
                byte[] head = decryptIn.Apply(ReadExact(16));
                int total = (int)ReadUInt32(head, 0);

                if (total < 12 || total > 262144) throw new IOException("плохая длина пакета");

                packet = new byte[4 + total];
                Buffer.BlockCopy(head, 0, packet, 0, 16);

                int rest = 4 + total - 16;
                if (rest > 0)
                {
                    byte[] tail = decryptIn.Apply(ReadExact(rest));
                    Buffer.BlockCopy(tail, 0, packet, 16, rest);
                }

                byte[] mac = ReadExact(32);
                byte[] expect = Mac(macKeyIn, sequenceIn, packet);

                if (!SameBytes(mac, expect)) throw new IOException("не сошёлся hmac");
            }
            else
            {
                byte[] head = ReadExact(8);
                int total = (int)ReadUInt32(head, 0);

                if (total < 12 || total > 262144) throw new IOException("плохая длина пакета");

                packet = new byte[4 + total];
                Buffer.BlockCopy(head, 0, packet, 0, 8);

                int rest = 4 + total - 8;
                if (rest > 0) Buffer.BlockCopy(ReadExact(rest), 0, packet, 8, rest);
            }

            sequenceIn++;

            int pad = packet[4];
            int length = packet.Length - 5 - pad;
            if (length < 1) throw new IOException("пустой пакет");

            byte[] payload = new byte[length];
            Buffer.BlockCopy(packet, 5, payload, 0, length);

            return payload;
        }

        private byte[] ReadExact(int size)
        {
            byte[] buffer = new byte[size];
            int done = 0;

            while (done < size)
            {
                int read = stream.Read(buffer, done, size - done);
                if (read <= 0) throw new IOException("соединение закрыто");

                done += read;
            }

            return buffer;
        }

        private static uint ReadUInt32(byte[] data, int offset)
        {
            return (uint)((data[offset] << 24) | (data[offset + 1] << 16) |
                          (data[offset + 2] << 8) | data[offset + 3]);
        }

        private static byte[] Mac(byte[] key, uint sequence, byte[] packet)
        {
            byte[] data = new byte[4 + packet.Length];
            data[0] = (byte)(sequence >> 24);
            data[1] = (byte)(sequence >> 16);
            data[2] = (byte)(sequence >> 8);
            data[3] = (byte)sequence;

            Buffer.BlockCopy(packet, 0, data, 4, packet.Length);

            using (HMACSHA256 hmac = new HMACSHA256(key)) return hmac.ComputeHash(data);
        }

        private static bool SameBytes(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;

            int difference = 0;
            for (int index = 0; index < left.Length; index++) difference |= left[index] ^ right[index];

            return difference == 0;
        }

        // -----------------------------------------------------------------
        //  Рукопожатие
        // -----------------------------------------------------------------

        /// <summary>
        /// Обмен версиями. Первые байты клиента могли быть прочитаны раньше —
        /// сервер по ним и понял, что перед ним ssh, — поэтому они приходят
        /// сюда готовыми.
        /// </summary>
        public string ExchangeVersions(string alreadyRead)
        {
            byte[] mine = Encoding.ASCII.GetBytes(ServerVersion + "\r\n");
            stream.Write(mine, 0, mine.Length);
            stream.Flush();

            StringBuilder sb = new StringBuilder(alreadyRead ?? string.Empty);

            while (sb.ToString().IndexOf('\n') < 0)
            {
                int value = stream.ReadByte();
                if (value < 0) throw new IOException("нет строки версии");

                sb.Append((char)value);
                if (sb.Length > 512) throw new IOException("слишком длинная строка версии");
            }

            return sb.ToString().TrimEnd('\r', '\n');
        }

        private byte[] KexInitPayload()
        {
            byte[] cookie = new byte[16];
            random.GetBytes(cookie);

            return new SshWriter()
                .Byte(MsgKexInit)
                .Bytes(cookie)
                .NameList("diffie-hellman-group14-sha256")
                .NameList("rsa-sha2-256")
                .NameList("aes128-ctr")
                .NameList("aes128-ctr")
                .NameList("hmac-sha2-256")
                .NameList("hmac-sha2-256")
                .NameList("none")
                .NameList("none")
                .NameList()
                .NameList()
                .Boolean(false)
                .UInt32(0)
                .ToArray();
        }

        public void Handshake(string clientVersion)
        {
            byte[] serverKexInit = KexInitPayload();
            Send(serverKexInit);

            byte[] clientKexInit = Receive();
            while (clientKexInit[0] != MsgKexInit) clientKexInit = Receive();

            byte[] packet = Receive();
            if (packet[0] != MsgKexDhInit)
                throw new IOException("ждали KEXDH_INIT, пришло " + packet[0]);

            BigInteger prime = BigInteger.Parse("00" + Group14, System.Globalization.NumberStyles.HexNumber);
            BigInteger e = new SshReader(packet, 1).MpInt();

            if (e <= BigInteger.One || e >= prime - BigInteger.One)
                throw new IOException("клиент прислал недопустимое e");

            byte[] secret = new byte[32];
            random.GetBytes(secret);

            BigInteger y = SshMath.FromUnsigned(secret);
            BigInteger f = BigInteger.ModPow(2, y, prime);
            BigInteger shared = BigInteger.ModPow(e, y, prime);

            byte[] hostKey = SshHostKey.Blob();

            byte[] hashData = new SshWriter()
                .String(clientVersion)
                .String(ServerVersion)
                .String(clientKexInit)
                .String(serverKexInit)
                .String(hostKey)
                .MpInt(e)
                .MpInt(f)
                .MpInt(shared)
                .ToArray();

            byte[] exchangeHash;
            using (SHA256 sha = SHA256.Create()) exchangeHash = sha.ComputeHash(hashData);

            if (sessionId == null) sessionId = exchangeHash;

            Send(new SshWriter()
                .Byte(MsgKexDhReply)
                .String(hostKey)
                .MpInt(f)
                .String(SshHostKey.Sign(exchangeHash))
                .ToArray());

            Send(new byte[] { MsgNewKeys });

            byte[] answer = Receive();
            while (answer[0] != MsgNewKeys) answer = Receive();

            DeriveKeys(shared, exchangeHash);
        }

        /// <summary>Ключи сеанса выводятся из общего секрета и хеша обмена.</summary>
        private void DeriveKeys(BigInteger shared, byte[] exchangeHash)
        {
            byte[] baseData = new SshWriter().MpInt(shared).Bytes(exchangeHash).ToArray();

            byte[] ivIn = KeyOf(baseData, (byte)'A', 16);
            byte[] ivOut = KeyOf(baseData, (byte)'B', 16);
            byte[] keyIn = KeyOf(baseData, (byte)'C', 16);
            byte[] keyOut = KeyOf(baseData, (byte)'D', 16);

            macKeyIn = KeyOf(baseData, (byte)'E', 32);
            macKeyOut = KeyOf(baseData, (byte)'F', 32);

            decryptIn = new SshCtr(keyIn, ivIn);
            encryptOut = new SshCtr(keyOut, ivOut);
        }

        private byte[] KeyOf(byte[] baseData, byte letter, int size)
        {
            return SshKeys.Derive(baseData, sessionId, letter, size);
        }

        public void Dispose()
        {
            try { if (encryptOut != null) encryptOut.Dispose(); }
            catch { }

            try { if (decryptIn != null) decryptIn.Dispose(); }
            catch { }

            try { random.Dispose(); }
            catch { }
        }
    }

    /// <summary>
    /// Сеанс поверх транспорта: вход по паролю, канал, оболочка.
    /// Протокол знает только этот класс; что делать с командой, решает
    /// вызывающий — поэтому ядро системы тут ни при чём.
    /// </summary>
    internal sealed class SshSession
    {
        private readonly SshTransport transport;
        private readonly CommandExecutorEngine.RemoteSession session;

        private readonly Func<string, string, bool> checkUser;
        private readonly Func<CommandExecutorEngine.RemoteSession, string, string> execute;
        private readonly Action<string> log;

        private uint channel;
        private readonly List<byte> pending = new List<byte>();
        private readonly List<byte> line = new List<byte>();

        private string previous = string.Empty;

        public SshSession(SshTransport transport,
                          CommandExecutorEngine.RemoteSession session,
                          Func<string, string, bool> checkUser,
                          Func<CommandExecutorEngine.RemoteSession, string, string> execute,
                          Action<string> log)
        {
            this.transport = transport;
            this.session = session;
            this.checkUser = checkUser;
            this.execute = execute;
            this.log = log;
        }

        // -----------------------------------------------------------------
        //  Вход
        // -----------------------------------------------------------------

        public bool Authenticate()
        {
            int attempts = 0;

            while (true)
            {
                byte[] packet = transport.Receive();
                byte kind = packet[0];

                if (kind == SshTransport.MsgServiceRequest)
                {
                    byte[] name = new SshReader(packet, 1).String();

                    transport.Send(new SshWriter()
                        .Byte(SshTransport.MsgServiceAccept).String(name).ToArray());
                    continue;
                }

                if (kind == SshTransport.MsgUserauthRequest)
                {
                    SshReader reader = new SshReader(packet, 1);

                    string user = reader.Text();
                    reader.String();                       // имя службы
                    string method = reader.Text();

                    if (method == "password")
                    {
                        reader.Boolean();
                        string password = reader.Text();

                        if (checkUser(user, password))
                        {
                            session.User = user;

                            transport.Send(new byte[] { SshTransport.MsgUserauthSuccess });
                            return true;
                        }

                        attempts++;
                    }

                    // Пустой список методов означал бы «входа нет вовсе»,
                    // поэтому всегда предлагаем пароль ещё раз.
                    transport.Send(new SshWriter()
                        .Byte(SshTransport.MsgUserauthFailure)
                        .NameList("password")
                        .Boolean(false)
                        .ToArray());

                    if (attempts >= 5) return false;
                    continue;
                }

                if (kind == SshTransport.MsgDisconnect) return false;

                if (kind == SshTransport.MsgIgnore || kind == SshTransport.MsgDebug ||
                    kind == SshTransport.MsgExtInfo) continue;

                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgUnimplemented).UInt32(0).ToArray());
            }
        }

        // -----------------------------------------------------------------
        //  Канал
        // -----------------------------------------------------------------

        public void Serve()
        {
            while (true)
            {
                byte[] packet = transport.Receive();
                byte kind = packet[0];

                if (kind == SshTransport.MsgChannelOpen)
                {
                    SshReader reader = new SshReader(packet, 1);

                    string what = reader.Text();
                    uint peer = reader.UInt32();
                    reader.UInt32();
                    reader.UInt32();

                    if (what != "session")
                    {
                        transport.Send(new SshWriter()
                            .Byte(SshTransport.MsgChannelOpenFailure)
                            .UInt32(peer).UInt32(3)
                            .String("поддерживается только session").String("")
                            .ToArray());
                        continue;
                    }

                    channel = peer;

                    transport.Send(new SshWriter()
                        .Byte(SshTransport.MsgChannelOpenConfirmation)
                        .UInt32(peer).UInt32(0)
                        .UInt32(2 * 1024 * 1024).UInt32(32768)
                        .ToArray());
                    continue;
                }

                if (kind == SshTransport.MsgChannelRequest)
                {
                    SshReader reader = new SshReader(packet, 1);

                    reader.UInt32();
                    string request = reader.Text();
                    bool wantReply = reader.Boolean();

                    if (wantReply)
                    {
                        bool ok = request == "pty-req" || request == "shell" ||
                                  request == "env" || request == "window-change";

                        transport.Send(new SshWriter()
                            .Byte(ok ? SshTransport.MsgChannelSuccess : SshTransport.MsgChannelFailure)
                            .UInt32(channel)
                            .ToArray());
                    }

                    if (request == "shell" || request == "exec")
                    {
                        Shell();
                        return;
                    }

                    continue;
                }

                if (kind == SshTransport.MsgGlobalRequest)
                {
                    transport.Send(new byte[] { SshTransport.MsgRequestFailure });
                    continue;
                }

                if (kind == SshTransport.MsgChannelClose || kind == SshTransport.MsgChannelEof ||
                    kind == SshTransport.MsgDisconnect) return;
            }
        }

        private void Write(string text)
        {
            byte[] data = Encoding.UTF8.GetBytes((text ?? string.Empty).Replace("\r\n", "\n").Replace("\n", "\r\n"));

            int offset = 0;
            while (offset < data.Length)
            {
                int size = Math.Min(30000, data.Length - offset);

                byte[] chunk = new byte[size];
                Buffer.BlockCopy(data, offset, chunk, 0, size);
                offset += size;

                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgChannelData).UInt32(channel).String(chunk).ToArray());
            }
        }

        private void WriteRaw(byte[] data)
        {
            transport.Send(new SshWriter()
                .Byte(SshTransport.MsgChannelData).UInt32(channel).String(data).ToArray());
        }

        /// <summary>
        /// Достаёт из накопленных байт одну строку. Клиент может прислать
        /// несколько строк одним пакетом, поэтому остаток обязан сохраняться —
        /// иначе вторая команда из вставленного текста пропадала бы.
        /// </summary>
        private string TakeLine()
        {
            for (int index = 0; index < pending.Count; index++)
            {
                byte value = pending[index];

                if (value == 13 || value == 10)
                {
                    int skip = index + 1;

                    // CRLF — один разделитель, а не два.
                    if (value == 13 && skip < pending.Count && pending[skip] == 10) skip++;

                    string text = Encoding.UTF8.GetString(line.ToArray());

                    line.Clear();
                    pending.RemoveRange(0, skip);

                    Write("\r\n");
                    return text;
                }

                if (value == 8 || value == 127)
                {
                    if (line.Count > 0)
                    {
                        line.RemoveAt(line.Count - 1);
                        Write("\b \b");
                    }
                    continue;
                }

                if (value == 3)
                {
                    line.Clear();
                    pending.RemoveRange(0, index + 1);

                    Write("^C\r\n");
                    return string.Empty;
                }

                line.Add(value);
                WriteRaw(new[] { value });
            }

            pending.Clear();
            return null;
        }

        private string ReadLine()
        {
            while (true)
            {
                string text = TakeLine();
                if (text != null) return text;

                byte[] packet = transport.Receive();
                byte kind = packet[0];

                if (kind == SshTransport.MsgChannelData)
                {
                    SshReader reader = new SshReader(packet, 1);
                    reader.UInt32();

                    pending.AddRange(reader.String());
                    continue;
                }

                if (kind == SshTransport.MsgChannelClose || kind == SshTransport.MsgChannelEof ||
                    kind == SshTransport.MsgDisconnect) return null;
            }
        }

        // -----------------------------------------------------------------
        //  Оболочка
        // -----------------------------------------------------------------

        private void Shell()
        {
            Write("LisunOS " + LisunEngine.Version + " \"" + LisunEngine.Codename + "\"\r\n");
            Write(LisunLocale.T("ssh.welcome", session.User) + "\r\n");
            Write(LisunLocale.T("ssh.hint") + "\r\n\r\n");

            while (true)
            {
                Write("LisunOS " + session.User + ":" +
                      CommandExecutorEngine.RemotePrompt(session) + "> ");

                string input = ReadLine();
                if (input == null) break;

                input = input.Trim();
                if (input.Length == 0) continue;

                if (input.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                    input.Equals("logout", StringComparison.OrdinalIgnoreCase) ||
                    input.Equals("quit", StringComparison.OrdinalIgnoreCase))
                {
                    Write(LisunLocale.T("ssh.bye") + "\r\n");
                    break;
                }

                if (input.Equals("clear", StringComparison.OrdinalIgnoreCase) ||
                    input.Equals("cls", StringComparison.OrdinalIgnoreCase))
                {
                    Write("\u001b[2J\u001b[H");
                    continue;
                }

                if (input == "!!")
                {
                    if (previous.Length == 0)
                    {
                        Write(LisunLocale.T("ssh.noHistory") + "\r\n");
                        continue;
                    }

                    input = previous;
                    Write(input + "\r\n");
                }

                if (input == "?" || input.Equals("ssh help", StringComparison.OrdinalIgnoreCase))
                {
                    Write(LisunLocale.T("ssh.helpTitle") + "\r\n" +
                          LisunLocale.T("ssh.helpBody") + "\r\n");
                    continue;
                }

                previous = input;

                string answer = execute(session, input);
                Write((answer ?? string.Empty) + "\r\n");
            }

            Close();
        }

        /// <summary>
        /// Закрытие по правилам: код возврата, конец данных, закрытие канала.
        /// Если просто оборвать сокет, клиент напишет «Broken pipe».
        /// </summary>
        private void Close()
        {
            try
            {
                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgChannelRequest).UInt32(channel)
                    .String("exit-status").Boolean(false).UInt32(0)
                    .ToArray());

                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgChannelEof).UInt32(channel).ToArray());

                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgChannelClose).UInt32(channel).ToArray());

                for (int index = 0; index < 8; index++)
                {
                    byte[] packet = transport.Receive();
                    if (packet[0] == SshTransport.MsgChannelClose ||
                        packet[0] == SshTransport.MsgDisconnect) break;
                }

                transport.Send(new SshWriter()
                    .Byte(SshTransport.MsgDisconnect).UInt32(11)
                    .String("bye").String("")
                    .ToArray());
            }
            catch
            {
                // Клиент мог уйти первым — это не ошибка.
            }
        }
    }
}
