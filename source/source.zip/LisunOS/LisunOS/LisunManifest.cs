﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Манифест пакета LisunOS (meta.json).
    ///
    /// Поддерживаются два формата:
    ///   1) один объект:            { "name": "...", "description": "..." }
    ///   2) массив локализаций:     [ { "lang": "ruRU", ... }, { "lang": "enUS", ... } ]
    ///
    /// Во втором случае для каждого языка берутся свои name/description, а системные
    /// поля (type, version, author, permissions) объединяются по всем записям.
    /// </summary>
    public class LisunManifest
    {
        private sealed class Entry
        {
            public string Lang = string.Empty;
            public readonly Dictionary<string, string> Values =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            public readonly List<string> Permissions = new List<string>();
        }

        private readonly List<Entry> entries = new List<Entry>();

        public string FolderName { get; set; }

        /// <summary>Техническое имя пакета — одинаково во всех локализациях.</summary>
        public string Name { get; set; }

        public string Type { get; private set; }
        public string Version { get; private set; }
        public string Author { get; private set; }
        public string Url { get; private set; }
        public string HallKey { get; private set; }
        public string Source { get; set; }
        public string InstalledAt { get; set; }

        /// <summary>Объединённый список прав по всем локализациям.</summary>
        public readonly List<string> Permissions = new List<string>();

        public List<string> Languages
        {
            get
            {
                List<string> list = new List<string>();
                foreach (Entry entry in entries)
                {
                    if (entry.Lang.Length > 0 && !list.Contains(entry.Lang)) list.Add(entry.Lang);
                }
                return list;
            }
        }

        public bool IsEmpty { get { return entries.Count == 0; } }

        // =====================================================================
        //  Чтение
        // =====================================================================

        public static LisunManifest FromFile(string metaPath)
        {
            try
            {
                if (!File.Exists(metaPath)) return new LisunManifest();
                return FromJson(LisunCrypto.ReadAllText(metaPath));
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Manifest] [ОШИБКА] Чтение " + Path.GetFileName(metaPath) + ": " + ex.Message);
                return new LisunManifest();
            }
        }

        public static LisunManifest FromJson(string json)
        {
            LisunManifest manifest = new LisunManifest();

            LisunJson.Node root = LisunJson.Parse(json);
            if (root == null) return manifest;

            if (root.IsArray)
            {
                foreach (LisunJson.Node item in root.Array)
                {
                    if (item.IsObject) manifest.AddEntry(item);
                }
            }
            else if (root.IsObject)
            {
                manifest.AddEntry(root);
            }

            manifest.Consolidate();
            return manifest;
        }

        private void AddEntry(LisunJson.Node node)
        {
            Entry entry = new Entry();

            foreach (KeyValuePair<string, LisunJson.Node> kvp in node.Object)
            {
                if (kvp.Key.Equals("permissions", StringComparison.OrdinalIgnoreCase))
                {
                    foreach (string permission in kvp.Value.AsTextList())
                    {
                        if (!entry.Permissions.Contains(permission)) entry.Permissions.Add(permission);
                    }
                    continue;
                }

                entry.Values[kvp.Key] = kvp.Value.AsText();
            }

            string lang;
            if (entry.Values.TryGetValue("lang", out lang)) entry.Lang = (lang ?? string.Empty).Trim();

            entries.Add(entry);
        }

        private void Consolidate()
        {
            foreach (Entry entry in entries)
            {
                Name = Pick(Name, entry, "name");
                Type = Pick(Type, entry, "type");
                Version = Pick(Version, entry, "version");
                Author = Pick(Author, entry, "author");
                Url = Pick(Url, entry, "url");
                HallKey = Pick(HallKey, entry, "hall_key");
                Source = Pick(Source, entry, "source");
                InstalledAt = Pick(InstalledAt, entry, "installed");

                foreach (string permission in entry.Permissions)
                {
                    if (!Permissions.Contains(permission)) Permissions.Add(permission);
                }
            }

            Type = LisunPackageTypes.Normalize(Type);
            if (string.IsNullOrEmpty(Version)) Version = "1.0.0";
        }

        private static string Pick(string current, Entry entry, string key)
        {
            if (!string.IsNullOrEmpty(current)) return current;

            string value;
            if (entry.Values.TryGetValue(key, out value) && !string.IsNullOrEmpty(value)) return value.Trim();
            return current;
        }

        // =====================================================================
        //  Локализованные значения
        // =====================================================================

        /// <summary>
        /// Значение поля для текущего языка системы. Порядок поиска:
        /// точное совпадение (ruRU) → по двухбуквенному коду (ru) → запись без lang → первая запись.
        /// </summary>
        public string Localized(string key)
        {
            return Localized(key, LisunLocale.ManifestTag, LisunLocale.Code);
        }

        public string Localized(string key, string fullTag, string shortTag)
        {
            Entry exact = FindEntry(fullTag, true);
            string value = Read(exact, key);
            if (value != null) return value;

            Entry partial = FindEntry(shortTag, false);
            value = Read(partial, key);
            if (value != null) return value;

            Entry neutral = FindEntry(string.Empty, true);
            value = Read(neutral, key);
            if (value != null) return value;

            foreach (Entry entry in entries)
            {
                value = Read(entry, key);
                if (value != null) return value;
            }

            return string.Empty;
        }

        private static string Read(Entry entry, string key)
        {
            if (entry == null) return null;

            string value;
            if (entry.Values.TryGetValue(key, out value) && !string.IsNullOrEmpty(value)) return value;
            return null;
        }

        private Entry FindEntry(string tag, bool exact)
        {
            foreach (Entry entry in entries)
            {
                if (exact)
                {
                    if (string.Equals(entry.Lang, tag, StringComparison.OrdinalIgnoreCase)) return entry;
                }
                else if (tag.Length > 0 && entry.Lang.StartsWith(tag, StringComparison.OrdinalIgnoreCase))
                {
                    return entry;
                }
            }
            return null;
        }

        public string DisplayName
        {
            get
            {
                string localized = Localized("title");
                if (!string.IsNullOrEmpty(localized)) return localized;
                if (!string.IsNullOrEmpty(Name)) return Name;
                return FolderName ?? "package";
            }
        }

        public string Description
        {
            get { return Localized("description"); }
        }

        /// <summary>Любое поле манифеста, с учётом языка.</summary>
        public string Field(string key)
        {
            return Localized(key);
        }

        // =====================================================================
        //  Запись манифеста установки
        // =====================================================================

        public void WriteInstallManifest(string targetDirectory)
        {
            try
            {
                List<string> lines = new List<string>();
                lines.Add("name=" + (Name ?? string.Empty));
                lines.Add("type=" + Type);
                lines.Add("version=" + Version);
                if (!string.IsNullOrEmpty(Author)) lines.Add("author=" + Author);
                if (!string.IsNullOrEmpty(Url)) lines.Add("url=" + Url);
                if (!string.IsNullOrEmpty(Source)) lines.Add("source=" + Source);
                lines.Add("languages=" + string.Join(",", Languages.ToArray()));
                lines.Add("permissions=" + string.Join(",", Permissions.ToArray()));
                lines.Add("installed=" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));

                File.WriteAllLines(Path.Combine(targetDirectory, "install.manifest"), lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Manifest] [ОШИБКА] Запись install.manifest: " + ex.Message);
            }
        }

        public void MergeInstallManifest(string targetDirectory)
        {
            try
            {
                string path = Path.Combine(targetDirectory, "install.manifest");
                if (!File.Exists(path)) return;

                foreach (string raw in File.ReadAllLines(path))
                {
                    string[] parts = raw.Split(new[] { '=' }, 2);
                    if (parts.Length != 2) continue;

                    string key = parts[0].Trim().ToLowerInvariant();
                    string value = parts[1].Trim();

                    if (key == "source" && string.IsNullOrEmpty(Source)) Source = value;
                    else if (key == "installed") InstalledAt = value;
                    else if (key == "url" && string.IsNullOrEmpty(Url)) Url = value;
                }
            }
            catch { }
        }

        /// <summary>Сводка для команды apt info.</summary>
        public string Summary()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("   name         : " + (Name ?? "—"));
            sb.AppendLine("   title        : " + DisplayName);
            sb.AppendLine("   description  : " + (string.IsNullOrEmpty(Description) ? "—" : Description));
            sb.AppendLine("   type         : " + Type + "   " + LisunPackageTypes.Describe(Type));
            sb.AppendLine("   version      : " + Version);
            sb.AppendLine("   author       : " + (string.IsNullOrEmpty(Author) ? "—" : Author));

            List<string> languages = Languages;
            sb.AppendLine("   languages    : " + (languages.Count == 0 ? "—" : string.Join(", ", languages.ToArray())));

            sb.AppendLine("   permissions  : " + (Permissions.Count == 0 ? "—" : string.Join(", ", Permissions.ToArray())));
            if (!string.IsNullOrEmpty(Url)) sb.AppendLine("   url          : " + Url);
            if (!string.IsNullOrEmpty(Source)) sb.AppendLine("   source       : " + Source);
            if (!string.IsNullOrEmpty(InstalledAt)) sb.AppendLine("   installed    : " + InstalledAt);

            return sb.ToString().TrimEnd();
        }
    }
}
