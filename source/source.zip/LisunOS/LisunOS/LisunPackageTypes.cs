﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Типы пакетов LisunOS — поле type в meta.json.
    /// От типа зависит, что установщик делает после распаковки и какие
    /// права пакет может просить без отдельного разрешения зала.
    /// </summary>
    public static class LisunPackageTypes
    {
        public const string Service = "service";   // приложение с окном
        public const string App = "app";           // то же самое, короткое имя
        public const string Daemon = "daemon";     // только фоновые службы, без окна
        public const string Library = "library";   // файлы для других пакетов, ничего не запускает
        public const string Theme = "theme";       // оформление: цвета и шрифты
        public const string Locale = "locale";     // языковой пакет для /os/sys/locale
        public const string Module = "module";     // расширение сервера: конфигурация и www
        public const string Hall = "hall";         // оболочка системы, ставится только через sudo

        public static readonly string[] Known =
        {
            Service, App, Daemon, Library, Theme, Locale, Module, Hall
        };

        private static readonly Dictionary<string, string[]> Descriptions =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { Service, new[] { "Приложение с окном",                    "Application with a window" } },
            { App,     new[] { "Приложение с окном",                    "Application with a window" } },
            { Daemon,  new[] { "Только фоновые службы, без окна",       "Background services only, no window" } },
            { Library, new[] { "Файлы для других пакетов",              "Files for other packages" } },
            { Theme,   new[] { "Оформление: цвета и шрифты",            "Appearance: colors and fonts" } },
            { Locale,  new[] { "Языковой пакет интерфейса",             "Interface language pack" } },
            { Module,  new[] { "Расширение сервера: настройки и www",   "Server extension: configuration and www" } },
            { Hall,    new[] { "Оболочка системы, нужен sudo",          "System shell, requires sudo" } }
        };

        public static bool IsKnown(string type)
        {
            return !string.IsNullOrEmpty(type) && Descriptions.ContainsKey(type.Trim());
        }

        public static string Describe(string type)
        {
            string[] variants;
            if (type != null && Descriptions.TryGetValue(type.Trim(), out variants))
            {
                int index = LisunLocale.Language == LisunLanguage.English ? 1 : 0;
                return index < variants.Length ? variants[index] : variants[0];
            }

            return LisunLocale.T("type.unknown");
        }

        /// <summary>Нормализует написание: APP → app, пусто → service.</summary>
        public static string Normalize(string type)
        {
            if (string.IsNullOrEmpty(type)) return Service;

            string value = type.Trim().ToLowerInvariant();
            return IsKnown(value) ? value : Service;
        }

        /// <summary>Запускает ли тип окна приложений.</summary>
        public static bool HasWindow(string type)
        {
            string value = Normalize(type);
            return value == Service || value == App || value == Hall;
        }

        /// <summary>Нужен ли режим суперпользователя для установки.</summary>
        public static bool NeedsElevation(string type)
        {
            return Normalize(type) == Hall;
        }

        /// <summary>Куда пакет раскладывает файлы помимо своей папки.</summary>
        public static string TargetFolder(string type)
        {
            switch (Normalize(type))
            {
                case Locale: return LisunEngine.LocalePath;
                case Theme: return System.IO.Path.Combine(LisunEngine.RootPath, "sys", "themes");
                case Library: return System.IO.Path.Combine(LisunEngine.RootPath, "sys", "lib");
                default: return string.Empty;
            }
        }

        public static string ListText()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("type.title") + Environment.NewLine);

            foreach (string type in Known)
                sb.AppendLine("   • " + type.PadRight(10) + Describe(type));

            return sb.ToString().TrimEnd();
        }
    }
}
