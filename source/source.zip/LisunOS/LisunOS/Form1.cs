﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LisunOS
{
    public partial class Form1 : Form
    {
        private const int MaxConsoleLength = 200000;
        private const string TerminalKey = "terminal";

        private sealed class ShellTab
        {
            public string Key;
            public string Title;
            public string TitleKey;     // ключ локализации, если заголовок переводится
            public Button Button;
            public Control Content;
            public bool Closable;
        }

        private readonly List<ShellTab> tabs = new List<ShellTab>();
        private ShellTab activeTab;

        private readonly List<string> commandHistory = new List<string>();
        private int historyIndex = -1;

        private WebViewForm embeddedBrowser;
        private bool isBooting;

        private readonly ToolTip statusHints = new ToolTip();

        private readonly List<string> suggestionNames = new List<string>();

        private ContextMenuStrip shellMenu;
        private ContextMenuStrip layoutMenu;
        private ContextMenuStrip languageMenu;

        public Form1()
        {
            InitializeComponent();

            DoubleBuffered = true;
            LisunEngine.UiHost = this;

            ApplyRuntimeTheme();
            HookTitleBar();

            // Терминал — основная вкладка оболочки: всегда первая и не закрывается.
            RegisterTab(TerminalKey, null, "tab.terminal", pnlTerminal, false, true);
            SelectTab(tabs[0]);

            LisunEngine.ShellBrowserOpener = url => { OpenBrowser(url); return true; };
            LisunEngine.OnLogAdded += AppendKernelLog;
            LisunEngine.OnSoftRestartRequested += HandleSoftRestart;
            FormEngine.OnAppShowRequested += HandleAppShowRequested;
            LisunLocale.LanguageChanged += ApplyLanguage;

            // Подсказки берут названия из словаря, поэтому дерево
            // пересобирается вместе со сменой языка.
            LisunLocale.LanguageChanged += LisunCommandTree.Reset;
            LisunLocale.LayoutChanged += UpdateStatus;

            KeyDown += Form1_KeyDown;

            clockTimer.Start();
            ApplyLanguage();

            Shown += (s, e) => RunBootSequence();
        }

        // =====================================================================
        //  Оформление и заголовок окна
        // =====================================================================

        private void ApplyRuntimeTheme()
        {
            rtbConsole.Font = Theme.Mono(10.5f);
            txtInput.Font = Theme.Mono(10.5f);
            lblPrompt.Font = Theme.Mono(10.5f, FontStyle.Bold);
            lblTitle.Font = Theme.Ui(10f, FontStyle.Bold);
            lblStatusLeft.Font = Theme.Mono(9f);
            lblStatusRight.Font = Theme.Mono(9f);

            StyleCaptionButton(btnMenu, Theme.SurfaceHot);
            StyleCaptionButton(btnMinimize, Theme.SurfaceHot);
            StyleCaptionButton(btnMaximize, Theme.SurfaceHot);
            StyleCaptionButton(btnClose, Color.FromArgb(203, 56, 56));

            StyleStatusButton(btnLayout, Theme.Accent);
            StyleStatusButton(btnLanguage, Theme.TextDim);
        }

        private static void StyleCaptionButton(Button button, Color hover)
        {
            button.BackColor = Theme.Surface;
            button.UseVisualStyleBackColor = false;
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = hover;
            button.FlatAppearance.MouseDownBackColor = hover;
            button.Cursor = Cursors.Hand;
        }

        private static void StyleStatusButton(Button button, Color foreColor)
        {
            button.BackColor = Theme.Surface;
            button.ForeColor = foreColor;
            button.UseVisualStyleBackColor = false;
            button.FlatAppearance.BorderSize = 0;
            button.FlatAppearance.MouseOverBackColor = Theme.SurfaceHot;
            button.FlatAppearance.MouseDownBackColor = Theme.AccentDeep;
            button.Cursor = Cursors.Hand;
        }

        private void HookTitleBar()
        {
            pnlTitleBar.MouseDown += TitleBar_MouseDown;
            lblTitle.MouseDown += TitleBar_MouseDown;
            pnlTitleBar.MouseDoubleClick += TitleBar_MouseDoubleClick;
            lblTitle.MouseDoubleClick += TitleBar_MouseDoubleClick;

            // Рамка строки ввода подсвечивается, когда поле в фокусе.
            txtInput.Enter += (s, e) => pnlInputInner.Invalidate();
            txtInput.Leave += (s, e) => pnlInputInner.Invalidate();

            txtInput.TextChanged += (s, e) => UpdateSuggestions();
            pnlTerminal.Resize += (s, e) => { if (lstSuggest.Visible) PositionSuggestions(); };
        }

        [DllImport("user32.dll")]
        private static extern bool ReleaseCapture();

        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        private const int WM_NCLBUTTONDOWN = 0x00A1;
        private const int WM_NCHITTEST = 0x0084;
        private const int HTCLIENT = 1;
        private const int HTCAPTION = 2;
        private const int HTLEFT = 10, HTRIGHT = 11, HTTOP = 12, HTTOPLEFT = 13,
                          HTTOPRIGHT = 14, HTBOTTOM = 15, HTBOTTOMLEFT = 16, HTBOTTOMRIGHT = 17;
        private const int ResizeGrip = 6;

        private void TitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left) return;
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        }

        private void TitleBar_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            ToggleMaximize();
        }

        /// <summary>Окно без системной рамки, поэтому изменение размера обрабатываем вручную.</summary>
        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_NCHITTEST && WindowState == FormWindowState.Normal)
            {
                base.WndProc(ref m);
                if (m.Result.ToInt32() != HTCLIENT) return;

                long parameter = m.LParam.ToInt64();
                int screenX = unchecked((short)(parameter & 0xFFFF));
                int screenY = unchecked((short)((parameter >> 16) & 0xFFFF));
                Point point = PointToClient(new Point(screenX, screenY));

                bool left = point.X <= ResizeGrip;
                bool right = point.X >= ClientSize.Width - ResizeGrip;
                bool top = point.Y <= ResizeGrip;
                bool bottom = point.Y >= ClientSize.Height - ResizeGrip;

                if (top && left) m.Result = (IntPtr)HTTOPLEFT;
                else if (top && right) m.Result = (IntPtr)HTTOPRIGHT;
                else if (bottom && left) m.Result = (IntPtr)HTBOTTOMLEFT;
                else if (bottom && right) m.Result = (IntPtr)HTBOTTOMRIGHT;
                else if (left) m.Result = (IntPtr)HTLEFT;
                else if (right) m.Result = (IntPtr)HTRIGHT;
                else if (top) m.Result = (IntPtr)HTTOP;
                else if (bottom) m.Result = (IntPtr)HTBOTTOM;
                return;
            }

            base.WndProc(ref m);
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            ToggleMaximize();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ToggleMaximize()
        {
            if (WindowState == FormWindowState.Maximized)
            {
                WindowState = FormWindowState.Normal;
                btnMaximize.Text = "☐";
            }
            else
            {
                // Без этого безрамочное окно перекрывает панель задач.
                MaximizedBounds = Screen.FromControl(this).WorkingArea;
                WindowState = FormWindowState.Maximized;
                btnMaximize.Text = "❐";
            }
        }

        private void pnlInputInner_Resize(object sender, EventArgs e)
        {
            Theme.ApplyRoundedRegion(pnlInputInner, 10);
        }

        private void pnlInputInner_Paint(object sender, PaintEventArgs e)
        {
            Rectangle bounds = new Rectangle(0, 0, pnlInputInner.Width - 1, pnlInputInner.Height - 1);
            using (System.Drawing.Drawing2D.GraphicsPath path = Theme.RoundedRect(bounds, 10))
            using (Pen pen = new Pen(txtInput.Focused ? Theme.Accent : Theme.Border))
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.DrawPath(pen, path);
            }
        }

        // =====================================================================
        //  Язык системы и раскладка клавиатуры
        // =====================================================================

        private void ApplyLanguage()
        {
            lblTitle.Text = LisunLocale.T("shell.title", LisunEngine.Version);

            btnLanguage.Text = LisunLocale.DisplayName;
            toolTip_SetLanguageHints();

            foreach (ShellTab tab in tabs)
            {
                if (tab.TitleKey == null || tab.Button == null) continue;
                tab.Title = LisunLocale.T(tab.TitleKey);
                tab.Button.Text = tab.Title;
            }

            if (embeddedBrowser != null && !embeddedBrowser.IsDisposed) embeddedBrowser.ApplyLanguage();

            UpdateStatus();
        }

        private void toolTip_SetLanguageHints()
        {
            statusHints.SetToolTip(btnMenu, LisunLocale.T("menu.title"));
            statusHints.SetToolTip(btnLayout, LisunLocale.T("status.layoutHint"));
            statusHints.SetToolTip(btnLanguage, LisunLocale.T("status.langHint"));
        }

        // --- выпадающие меню ---

        private void btnMenu_Click(object sender, EventArgs e)
        {
            if (shellMenu == null) shellMenu = new ContextMenuStrip();
            shellMenu.Items.Clear();

            ToolStripMenuItem language = new ToolStripMenuItem(LisunLocale.T("menu.language"));
            FillLanguageItems(language.DropDownItems);
            shellMenu.Items.Add(language);

            ToolStripMenuItem layout = new ToolStripMenuItem(LisunLocale.T("menu.layout"));
            FillLayoutItems(layout.DropDownItems);
            shellMenu.Items.Add(layout);

            shellMenu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem terminal = new ToolStripMenuItem(LisunLocale.T("menu.terminal"));
            terminal.Click += (s, a) => SelectTab(FindTab(TerminalKey));
            shellMenu.Items.Add(terminal);

            ToolStripMenuItem browser = new ToolStripMenuItem(LisunLocale.T("menu.browser"));
            browser.Click += (s, a) => OpenBrowser("https://www.google.com");
            shellMenu.Items.Add(browser);

            ToolStripMenuItem restart = new ToolStripMenuItem(LisunLocale.T("menu.restart"));
            restart.Click += (s, a) => LisunEngine.RequestSoftRestart();
            shellMenu.Items.Add(restart);

            shellMenu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem exit = new ToolStripMenuItem(LisunLocale.T("menu.exit"));
            exit.Click += (s, a) => Close();
            shellMenu.Items.Add(exit);

            Theme.HarmonizeStrip(shellMenu);
            shellMenu.Show(btnMenu, new Point(0, btnMenu.Height));
        }

        private void btnLayout_Click(object sender, EventArgs e)
        {
            if (layoutMenu == null) layoutMenu = new ContextMenuStrip();
            FillLayoutItems(layoutMenu.Items);
            Theme.HarmonizeStrip(layoutMenu);

            // Статус-бар внизу окна, поэтому меню раскрывается вверх.
            layoutMenu.Show(btnLayout, new Point(0, -layoutMenu.PreferredSize.Height));
        }

        private void btnLanguage_Click(object sender, EventArgs e)
        {
            if (languageMenu == null) languageMenu = new ContextMenuStrip();
            FillLanguageItems(languageMenu.Items);
            Theme.HarmonizeStrip(languageMenu);

            languageMenu.Show(btnLanguage, new Point(0, -languageMenu.PreferredSize.Height));
        }

        /// <summary>
        /// Пункты меню языка: два встроенных плюс все пакеты из /os/sys/locale.
        /// Список строится заново при каждом открытии, поэтомуновый пакет
        /// появляется сразу после «lang reload».
        /// </summary>
        private void FillLanguageItems(ToolStripItemCollection items)
        {
            items.Clear();

            foreach (LisunLocale.LanguagePack pack in LisunLocale.Available())
            {
                string code = pack.Code;

                ToolStripMenuItem item = new ToolStripMenuItem(pack.Name);
                item.Checked = code.Equals(LisunLocale.Code, StringComparison.OrdinalIgnoreCase);
                item.Click += (s, a) =>
                {
                    if (LisunLocale.SetLanguage(code))
                        WriteLine(LisunLocale.T("msg.langChanged", LisunLocale.DisplayName), Theme.Cyan);
                };

                items.Add(item);
            }
        }

        private void FillLayoutItems(ToolStripItemCollection items)
        {
            items.Clear();

            string current = LisunLocale.LayoutTag;
            int count = 0;

            try
            {
                foreach (InputLanguage language in InputLanguage.InstalledInputLanguages)
                {
                    string code = language.Culture.TwoLetterISOLanguageName;
                    ToolStripMenuItem item = new ToolStripMenuItem(
                        code.ToUpperInvariant() + "   —   " + language.Culture.NativeName);
                    item.Checked = string.Equals(code, current, StringComparison.OrdinalIgnoreCase);

                    string captured = code;
                    item.Click += (s, e) =>
                    {
                        if (LisunLocale.SetLayout(captured))
                            WriteLine(LisunLocale.T("msg.layoutChanged", LisunLocale.LayoutTag), Theme.Accent);
                        else
                            WriteLine(LisunLocale.T("msg.layoutMissing", captured.ToUpperInvariant()), Theme.Danger);
                        WriteLine("", Theme.Text);
                    };

                    items.Add(item);
                    count++;
                }
            }
            catch { }

            if (count == 0)
            {
                ToolStripMenuItem empty = new ToolStripMenuItem(LisunLocale.T("menu.noLayouts"));
                empty.Enabled = false;
                items.Add(empty);
                return;
            }

            items.Add(new ToolStripSeparator());

            ToolStripMenuItem next = new ToolStripMenuItem(LisunLocale.T("menu.nextLayout"));
            next.Click += (s, e) => CycleKeyboardLayout();
            items.Add(next);
        }

        private void ToggleSystemLanguage()
        {
            LisunLocale.ToggleLanguage();
            WriteLine(LisunLocale.T("msg.langChanged", LisunLocale.DisplayName), Theme.Accent);
            WriteLine("", Theme.Text);
        }

        private void CycleKeyboardLayout()
        {
            if (LisunLocale.CycleLayout())
            {
                WriteLine(LisunLocale.T("msg.layoutChanged", LisunLocale.LayoutTag), Theme.Accent);
            }
            else
            {
                WriteLine(LisunLocale.T("msg.layoutFailed"), Theme.Danger);
            }
            WriteLine("", Theme.Text);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                if (lstSuggest.Visible)
                {
                    HideSuggestions();
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    return;
                }

                if (activeTab != null && activeTab.Key != TerminalKey)
                {
                    SelectTab(FindTab(TerminalKey));
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                }
                return;
            }

            if (e.Control && e.KeyCode == Keys.Space)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                CycleKeyboardLayout();
                return;
            }

            if (e.Control && e.Alt && e.KeyCode == Keys.L)
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
                ToggleSystemLanguage();
            }
        }

        // =====================================================================
        //  Вкладки оболочки
        // =====================================================================

        private ShellTab RegisterTab(string key, string title, string titleKey, Control content,
            bool closable, bool showButton)
        {
            ShellTab existing = FindTab(key);
            if (existing != null) return existing;

            ShellTab tab = new ShellTab();
            tab.Key = key;
            tab.TitleKey = titleKey;
            tab.Title = titleKey != null ? LisunLocale.T(titleKey) : title;
            tab.Content = content;
            tab.Closable = closable;

            if (showButton)
            {
                Button button = new Button();
                button.Text = tab.Title;
                button.AutoSize = false;
                button.Height = 26;
                button.Width = Math.Max(110, TextRenderer.MeasureText(tab.Title, Theme.Ui(9f)).Width + 34);
                button.Margin = new Padding(0, 0, 6, 0);
                button.FlatStyle = FlatStyle.Flat;
                button.Font = Theme.Ui(9f);
                button.TabStop = false;
                button.Cursor = Cursors.Hand;
                button.FlatAppearance.BorderSize = 1;

                // Повторный клик по активной вкладке возвращает в терминал.
                button.Click += (s, e) =>
                {
                    // Повторный клик по активной вкладке приложения возвращает в терминал.
                    if (activeTab == tab && tab.Key != TerminalKey) SelectTab(FindTab(TerminalKey));
                    else SelectTab(tab);
                };

                if (closable)
                {
                    ContextMenuStrip menu = new ContextMenuStrip();
                    ToolStripMenuItem close = new ToolStripMenuItem(LisunLocale.T("tab.close"));
                    close.Click += (s, e) => CloseTab(tab);
                    menu.Items.Add(close);
                    Theme.HarmonizeStrip(menu);
                    button.ContextMenuStrip = menu;
                }

                tab.Button = button;
                pnlTabs.Controls.Add(button);
            }

            if (content.Parent != pnlMain)
            {
                content.Dock = DockStyle.Fill;
                pnlMain.Controls.Add(content);
            }
            content.Visible = false;

            tabs.Add(tab);
            if (tab.Button != null) StyleTabButton(tab, false);

            UpdateTabStripVisibility();
            return tab;
        }

        private ShellTab FindTab(string key)
        {
            foreach (ShellTab tab in tabs)
            {
                if (string.Equals(tab.Key, key, StringComparison.OrdinalIgnoreCase)) return tab;
            }
            return null;
        }

        private void SelectTab(ShellTab tab)
        {
            if (tab == null) return;

            foreach (ShellTab item in tabs)
            {
                bool active = item == tab;
                item.Content.Visible = active;
                if (item.Button != null) StyleTabButton(item, active);
                if (active) item.Content.BringToFront();
            }

            activeTab = tab;
            if (tab.Key == TerminalKey && !isBooting) txtInput.Focus();
        }

        private static void StyleTabButton(ShellTab tab, bool active)
        {
            Button button = tab.Button;
            if (button == null) return;

            button.BackColor = active ? Theme.SurfaceAlt : Theme.Background;
            button.ForeColor = active ? Theme.Text : Theme.TextDim;
            button.UseVisualStyleBackColor = false;
            button.FlatAppearance.BorderColor = active ? Theme.Accent : Theme.Border;
            button.FlatAppearance.MouseOverBackColor = Theme.SurfaceHot;
        }

        /// <summary>Верхняя панель показывается только когда есть открытые приложения.</summary>
        private void UpdateTabStripVisibility()
        {
            int visible = 0;
            foreach (ShellTab tab in tabs)
            {
                if (tab.Button != null) visible++;
            }
            pnlTabs.Visible = visible > 0;
        }

        private void CloseTab(ShellTab tab)
        {
            if (tab == null || !tab.Closable) return;

            tabs.Remove(tab);

            if (tab.Button != null)
            {
                pnlTabs.Controls.Remove(tab.Button);
                tab.Button.Dispose();
            }

            if (tab.Content != null && tab.Content != pnlTerminal)
            {
                pnlMain.Controls.Remove(tab.Content);
                tab.Content.Dispose();
            }

            UpdateTabStripVisibility();

            if (activeTab == tab) SelectTab(FindTab(TerminalKey));
        }

        // =====================================================================
        //  Загрузка системы
        // =====================================================================

        private async void RunBootSequence()
        {
            isBooting = true;
            txtInput.ReadOnly = true;
            pnlInputOuter.Visible = false;

            try
            {
                WriteLine(LisunLocale.T("boot.engine"), Theme.Accent);
                WriteLine(LisunLocale.T("boot.prepare"), Theme.TextDim);
                await Task.Delay(250);

                LisunEngine.Initialize();

                // Язык системы и раскладка восстанавливаются из реестра (по умолчанию русские).
                LisunLocale.LoadFromRegistry();
                await Task.Delay(200);

                WriteLine("", Theme.Text);
                WriteLine(LisunLocale.T("boot.scan"), Theme.Cyan);

                // На загрузке права не запрашиваем — приложение спросит их при первом действии.
                LisunPermissions.SilentMode = true;
                try { LisunEngine.StartServicesAndBlock(); }
                finally { LisunPermissions.SilentMode = false; }
                await Task.Delay(200);

                StartNetworkSubsystem();

                WriteLine("", Theme.Text);
                WriteLine("  _    _               ___  ___", Theme.Accent);
                WriteLine(" | |  (_)___ _  _ _ _ / _ \\/ __|", Theme.Accent);
                WriteLine(" | |__| (_-< || | ' \\ (_) \\__ \\", Theme.Accent);
                WriteLine(" |____|_/__/\\_,_|_||_\\___/|___/", Theme.Accent);
                WriteLine("", Theme.Text);
                WriteLine(LisunLocale.T("boot.version", LisunEngine.Version, LisunEngine.Codename), Theme.Text);
                WriteLine(LisunLocale.T("boot.rights"), Theme.TextDim);
                WriteLine("", Theme.Text);
                WriteLine(LisunLocale.T("boot.hint"), Theme.TextDim);
                WriteLine(LisunLocale.T("boot.hintEsc"), Theme.TextDim);
                WriteLine("", Theme.Text);
            }
            catch (Exception ex)
            {
                WriteLine(LisunLocale.T("boot.fail", ex.Message), Theme.Danger);
            }
            finally
            {
                isBooting = false;
                pnlInputOuter.Visible = true;
                txtInput.ReadOnly = false;
                UpdateStatus();
                if (activeTab != null && activeTab.Key == TerminalKey) txtInput.Focus();
            }
        }

        private void HandleSoftRestart()
        {
            for (int i = tabs.Count - 1; i >= 0; i--)
            {
                if (tabs[i].Key.StartsWith("app:", StringComparison.OrdinalIgnoreCase)) CloseTab(tabs[i]);
            }

            WriteLine(LisunLocale.T("msg.servicesReload"), Theme.Accent);
            LisunEngine.StartServicesAndBlock();
            UpdateStatus();
        }

        private void HandleAppShowRequested(DynamicApp app)
        {
            if (app == null || app.Form == null || app.Form.IsDisposed) return;

            string key = "app:" + app.Name;
            ShellTab existing = FindTab(key);
            if (existing != null)
            {
                SelectTab(existing);
                return;
            }

            Panel host = new Panel();
            host.Dock = DockStyle.Fill;
            host.BackColor = Theme.Background;

            try
            {
                Form appForm = app.Form;
                appForm.TopLevel = false;
                appForm.FormBorderStyle = FormBorderStyle.None;
                appForm.Dock = DockStyle.Fill;
                host.Controls.Add(appForm);
                appForm.Show();
            }
            catch (Exception ex)
            {
                WriteLine(LisunLocale.T("msg.embedFailed", ex.Message), Theme.Danger);
                host.Dispose();
                return;
            }

            ShellTab tab = RegisterTab(key, app.Title, null, host, true, true);
            SelectTab(tab);
        }

        // =====================================================================
        //  Консоль
        // =====================================================================

        private void AppendKernelLog(string message)
        {
            if (rtbConsole == null || rtbConsole.IsDisposed) return;

            if (rtbConsole.InvokeRequired)
            {
                try { rtbConsole.BeginInvoke(new Action<string>(AppendKernelLog), message); }
                catch { }
                return;
            }

            WriteLine(message, ColorForLine(message));
        }

        private void WriteLine(string text, Color color)
        {
            Write((text ?? string.Empty) + Environment.NewLine, color);
        }

        private void Write(string text, Color color)
        {
            if (rtbConsole == null || rtbConsole.IsDisposed || string.IsNullOrEmpty(text)) return;

            if (rtbConsole.TextLength > MaxConsoleLength)
            {
                // SelectedText не применяется к ReadOnly-полю, поэтому флаг снимается на время.
                rtbConsole.ReadOnly = false;
                rtbConsole.Select(0, MaxConsoleLength / 2);
                rtbConsole.SelectedText = string.Empty;
                rtbConsole.ReadOnly = true;
            }

            rtbConsole.SelectionStart = rtbConsole.TextLength;
            rtbConsole.SelectionLength = 0;
            rtbConsole.SelectionColor = color;
            rtbConsole.AppendText(text);
            rtbConsole.SelectionColor = rtbConsole.ForeColor;
            rtbConsole.SelectionStart = rtbConsole.TextLength;
            rtbConsole.ScrollToCaret();
        }

        private static Color ColorForLine(string line)
        {
            if (string.IsNullOrEmpty(line)) return Theme.TextDim;
            string upper = line.ToUpperInvariant();

            if (upper.Contains("[ERROR]") || upper.Contains("ОШИБКА") || upper.Contains("[FATAL]")) return Theme.Danger;
            if (upper.Contains("[OK]")) return Theme.Success;
            if (upper.Contains("[KERNEL]") || upper.Contains("[BOOT]")) return Theme.Cyan;
            if (upper.Contains("[FORMENGINE]")) return Theme.Magenta;
            if (upper.Contains("[SYS]") || upper.Contains("[OS]")) return Theme.Accent;
            if (upper.Contains("[INSTALLER]") || upper.Contains("[LSI]")) return Theme.Warning;
            return Theme.TextDim;
        }

        private void UpdateStatus()
        {
            lblStatusLeft.Text = CustomFormUtils.ToVirtualPath(CommandExecutorEngine.CurrentDirectory);

            string user = CommandExecutorEngine.ActiveUser;
            lblStatusRight.Text = user + "   |   " + LisunLocale.T("status.apps") + ": " + FormEngine.ActiveApps.Count +
                                  "   |   " + DateTime.Now.ToString("HH:mm:ss");

            lblStatusRight.ForeColor = CommandExecutorEngine.IsSuperUser ? Theme.Warning : Theme.TextDim;
            // В приглашении видно, от чьего имени идут команды.
            lblPrompt.ForeColor = CommandExecutorEngine.IsSuperUser ? Theme.Warning : Theme.Accent;
            lblPrompt.Text = "LisunOS " + CommandExecutorEngine.ActiveUser + ":\\>";

            btnLayout.Text = LisunLocale.LayoutTag;
            btnLanguage.Text = LisunLocale.DisplayName;
        }

        private void clockTimer_Tick(object sender, EventArgs e)
        {
            UpdateStatus();
        }

        // =====================================================================
        //  Ввод команд
        // =====================================================================

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                e.Handled = true;

                HideSuggestions();

                string input = txtInput.Text.Trim();
                txtInput.Clear();
                if (input.Length == 0) return;

                ExecuteCommand(input);
                return;
            }

            if (e.KeyCode == Keys.Up)
            {
                e.SuppressKeyPress = true;
                if (lstSuggest.Visible) MoveSuggestion(-1);
                else NavigateHistory(-1);
                return;
            }

            if (e.KeyCode == Keys.Down)
            {
                e.SuppressKeyPress = true;
                if (lstSuggest.Visible) MoveSuggestion(1);
                else NavigateHistory(1);
                return;
            }

            if (e.KeyCode == Keys.Tab)
            {
                e.SuppressKeyPress = true;
                if (lstSuggest.Visible) ApplySuggestion();
                else CompleteCommand();
                return;
            }

            if (e.KeyCode == Keys.L && e.Control && !e.Alt)
            {
                e.SuppressKeyPress = true;
                rtbConsole.Clear();
            }
        }

        // =====================================================================
        //  Автоподсказка команд
        // =====================================================================

        private void UpdateSuggestions()
        {
            if (isBooting)
            {
                HideSuggestions();
                HideGhost();
                UpdateUsageLine(null);
                return;
            }

            string text = txtInput.Text;
            if (text.Length == 0)
            {
                HideSuggestions();
                HideGhost();
                UpdateUsageLine(null);
                return;
            }

            LisunCommandTree.Hint hint = LisunCommandTree.Suggest(text);

            // Сверка аргумента — серым сразу после набранного текста,
            // как подсказка команды в Minecraft: видно, что ждут ваш текст.
            ShowGhost(text, hint);

            if (!hint.HasItems)
            {
                HideSuggestions();
                return;
            }

            // Единственный вариант, совпавший целиком, показывать незачем.
            if (hint.Items.Count == 1 && hint.Prefix.Length > 0 &&
                hint.Items[0].Equals(hint.Prefix, StringComparison.OrdinalIgnoreCase))
            {
                HideSuggestions();
                return;
            }

            suggestionNames.Clear();
            lstSuggest.BeginUpdate();
            try
            {
                lstSuggest.Items.Clear();

                for (int index = 0; index < hint.Items.Count && index < 60; index++)
                {
                    string item = hint.Items[index];
                    string description = index < hint.Descriptions.Count ? hint.Descriptions[index] : string.Empty;

                    suggestionNames.Add(item);

                    lstSuggest.Items.Add(description.Length > 0
                        ? item.PadRight(Math.Max(14, item.Length + 2)) + "  " + description
                        : item);
                }
            }
            finally
            {
                lstSuggest.EndUpdate();
            }

            lstSuggest.SelectedIndex = 0;
            PositionSuggestions();
            lstSuggest.Visible = true;
            lstSuggest.BringToFront();
        }

        // =====================================================================
        //  Сверка аргумента: серый текст после курсора
        // =====================================================================

        private Label lblGhost;

        private void EnsureGhost()
        {
            if (lblGhost != null) return;

            lblGhost = new Label();
            lblGhost.AutoSize = true;
            lblGhost.BackColor = txtInput.BackColor;
            lblGhost.ForeColor = Theme.TextDim;
            lblGhost.Font = txtInput.Font;
            lblGhost.Visible = false;
            lblGhost.Enabled = false;

            // Щелчок по сверке должен попадать в поле ввода, а не в метку.
            lblGhost.Click += (s, e) => txtInput.Focus();

            txtInput.Parent.Controls.Add(lblGhost);
            lblGhost.BringToFront();
        }

        /// <summary>
        /// Показывает серую сверку: &lt;сеть&gt; или строку использования,
        /// когда система ждёт ваш текст, а не выбор из списка.
        /// </summary>
        private void ShowGhost(string text, LisunCommandTree.Hint hint)
        {
            EnsureGhost();

            // Строку использования обновляем первой: она может раздвинуть
            // панель, а сверку мы ставим по месту поля ввода — после этого.
            UpdateUsageLine(hint);

            // Сверка нужна там, где начинается новое слово: после пробела.
            bool atWordStart = text.EndsWith(" ") || text.Length == 0;

            string ghost = string.Empty;
            if (atWordStart && hint.HasPlaceholder) ghost = hint.Placeholder;
            else if (atWordStart && !hint.HasItems && hint.Usage.Length > 0) ghost = hint.Usage;

            if (ghost.Length == 0)
            {
                HideGhost();
                return;
            }

            lblGhost.Text = ghost;
            lblGhost.Font = txtInput.Font;
            lblGhost.BackColor = txtInput.BackColor;

            int offset = TextRenderer.MeasureText(text, txtInput.Font,
                new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding).Width;

            int left = txtInput.Left + txtInput.Padding.Left + offset + 2;
            int right = txtInput.Right - 8;

            if (left > right - 20)
            {
                HideGhost();
                return;
            }

            lblGhost.Location = new Point(left, txtInput.Top + (txtInput.Height - lblGhost.Height) / 2);
            lblGhost.Visible = true;
            lblGhost.BringToFront();
        }

        private void HideGhost()
        {
            if (lblGhost != null && lblGhost.Visible) lblGhost.Visible = false;
        }

        private Label lblUsage;

        /// <summary>
        /// Высота панели ввода без строки использования.
        /// Панель прижата к низу и высоту держит сама, поэтому строку
        /// нельзя просто показать: место она займёт у поля ввода.
        /// </summary>
        private int inputBaseHeight;

        private const int UsageLineHeight = 18;

        /// <summary>
        /// Строка использования над полем ввода: wifi connect &lt;сеть&gt; [пароль].
        /// Показывает всю грамматику команды, даже когда сверка не помещается.
        /// </summary>
        private void UpdateUsageLine(LisunCommandTree.Hint hint)
        {
            string usage = hint == null ? string.Empty : hint.Usage;

            // Прятать нечего, пока строки нет: панель и так нужной высоты.
            if (usage.Length == 0)
            {
                ShowUsageLine(false);
                return;
            }

            EnsureUsageLine();

            lblUsage.Text = usage;
            ShowUsageLine(true);
        }

        private void EnsureUsageLine()
        {
            if (lblUsage == null)
            {
                // Запоминаем исходную высоту до того, как в панели
                // появится что-то ещё.
                inputBaseHeight = pnlInputOuter.Height;

                lblUsage = new Label();
                lblUsage.AutoSize = false;
                lblUsage.Height = UsageLineHeight;
                lblUsage.Dock = DockStyle.Top;
                lblUsage.BackColor = pnlInputOuter.BackColor;
                lblUsage.ForeColor = Theme.TextDim;
                lblUsage.Font = Theme.Mono(8.75f);
                lblUsage.Padding = new Padding(4, 0, 0, 0);
                lblUsage.Visible = false;

                pnlInputOuter.Controls.Add(lblUsage);
                lblUsage.SendToBack();
            }
        }

        /// <summary>
        /// Показывает или прячет строку использования, раздвигая саму панель.
        /// Без этого строка отнимала высоту у поля ввода, и текст в нём
        /// обрезался по горизонтали.
        /// </summary>
        private void ShowUsageLine(bool visible)
        {
            if (lblUsage == null) return;
            if (lblUsage.Visible == visible) return;

            if (inputBaseHeight <= 0) inputBaseHeight = pnlInputOuter.Height;

            pnlInputOuter.SuspendLayout();
            try
            {
                lblUsage.Visible = visible;
                pnlInputOuter.Height = visible
                    ? inputBaseHeight + UsageLineHeight
                    : inputBaseHeight;
            }
            finally
            {
                pnlInputOuter.ResumeLayout(true);
            }

            // Список подсказок стоит над панелью — он едет вместе с ней.
            if (lstSuggest.Visible) PositionSuggestions();
        }

        private void PositionSuggestions()
        {
            int rows = Math.Min(lstSuggest.Items.Count, 7);
            int height = Math.Max(lstSuggest.ItemHeight + 4, rows * lstSuggest.ItemHeight + 4);
            int width = Math.Max(240, pnlInputOuter.Width - 32);
            int top = Math.Max(4, pnlInputOuter.Top - height - 6);

            lstSuggest.SetBounds(16, top, width, height);
        }

        private void HideSuggestions()
        {
            if (lstSuggest.Visible) lstSuggest.Visible = false;
        }

        private void MoveSuggestion(int direction)
        {
            if (lstSuggest.Items.Count == 0) return;

            int index = lstSuggest.SelectedIndex + direction;
            if (index < 0) index = lstSuggest.Items.Count - 1;
            if (index >= lstSuggest.Items.Count) index = 0;

            lstSuggest.SelectedIndex = index;
        }

        /// <summary>
        /// Подставляет выбранный вариант вместо последнего набранного слова,
        /// чтобы работали и субкоманды: «apt ins» → «apt install ».
        /// </summary>
        private void ApplySuggestion()
        {
            int index = lstSuggest.SelectedIndex;
            if (index < 0 || index >= suggestionNames.Count) return;

            HideSuggestions();

            string text = txtInput.Text;
            string chosen = suggestionNames[index];

            int cut = text.LastIndexOf(' ');
            string head = cut < 0 ? string.Empty : text.Substring(0, cut + 1);

            txtInput.Text = head + chosen + " ";
            txtInput.SelectionStart = txtInput.TextLength;
            txtInput.Focus();
        }

        private void lstSuggest_Click(object sender, EventArgs e)
        {
            ApplySuggestion();
        }

        private void NavigateHistory(int direction)
        {
            if (commandHistory.Count == 0) return;

            if (historyIndex == -1) historyIndex = commandHistory.Count;
            historyIndex += direction;

            if (historyIndex < 0) historyIndex = 0;
            if (historyIndex >= commandHistory.Count)
            {
                historyIndex = commandHistory.Count;
                txtInput.Clear();
                return;
            }

            txtInput.Text = commandHistory[historyIndex];
            txtInput.SelectionStart = txtInput.TextLength;
        }

        private void CompleteCommand()
        {
            string prefix = txtInput.Text.Trim();
            if (prefix.Length == 0 || prefix.Contains(" ")) return;

            List<string> candidates = new List<string>();
            foreach (string command in CommandExecutorEngine.KnownCommands)
            {
                if (command.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) candidates.Add(command);
            }
            foreach (KeyValuePair<string, List<string>> registered in LisunEngine.RegisteredCommands)
            {
                if (registered.Key.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) candidates.Add(registered.Key);
            }

            if (candidates.Count == 0) return;

            if (candidates.Count == 1)
            {
                txtInput.Text = candidates[0] + " ";
                txtInput.SelectionStart = txtInput.TextLength;
                return;
            }

            WriteLine("   " + string.Join("   ", candidates.ToArray()), Theme.TextDim);
        }

        private void ExecuteCommand(string input)
        {
            commandHistory.Add(input);
            historyIndex = -1;

            Write(lblPrompt.Text + " ", CommandExecutorEngine.IsSuperUser ? Theme.Warning : Theme.Accent);
            WriteLine(input, Theme.Text);

            string lowered = input.ToLowerInvariant();

            if (lowered == "exit" || lowered == "quit")
            {
                WriteLine(LisunLocale.T("msg.shutdown"), Theme.TextDim);
                Close();
                return;
            }

            if (lowered == "clear" || lowered == "cls")
            {
                rtbConsole.Clear();
                return;
            }

            if (lowered == "history")
            {
                for (int i = 0; i < commandHistory.Count; i++)
                    WriteLine("   " + (i + 1).ToString().PadLeft(3) + "  " + commandHistory[i], Theme.TextDim);
                WriteLine("", Theme.Text);
                return;
            }

            if (lowered == "webview" || lowered.StartsWith("webview "))
            {
                string[] parts = input.Split(new[] { ' ' }, 2);
                string target = parts.Length > 1 ? parts[1].Trim() : "https://www.google.com";
                OpenBrowser(target);
                return;
            }

            string result = CommandExecutorEngine.Execute(input);

            if (result == "clear")
            {
                rtbConsole.Clear();
                return;
            }

            if (!string.IsNullOrEmpty(result))
            {
                WriteLine(result, ColorForLine(result));
                WriteLine("", Theme.Text);
            }

            UpdateStatus();
        }

        // =====================================================================
        //  Встроенный браузер
        // =====================================================================

        private void OpenBrowser(string url)
        {
            ShellTab tab = FindTab("browser");

            if (tab == null || embeddedBrowser == null || embeddedBrowser.IsDisposed)
            {
                Panel host = new Panel();
                host.Dock = DockStyle.Fill;
                host.BackColor = Theme.Background;

                embeddedBrowser = new WebViewForm();
                embeddedBrowser.TopLevel = false;
                embeddedBrowser.FormBorderStyle = FormBorderStyle.None;
                embeddedBrowser.Dock = DockStyle.Fill;
                embeddedBrowser.OnBrowserCloseRequested += HideBrowser;

                host.Controls.Add(embeddedBrowser);
                embeddedBrowser.Show();

                tab = RegisterTab("browser", null, "tab.browser", host, true, true);
            }

            SelectTab(tab);
            embeddedBrowser.NavigateTo(url);
            WriteLine(LisunLocale.T("msg.browserOpen", url), Theme.Accent);
            WriteLine("", Theme.Text);
        }

        private void HideBrowser()
        {
            SelectTab(FindTab(TerminalKey));

            WriteLine(LisunLocale.T("msg.browserHidden"), Theme.Accent);
            WriteLine("", Theme.Text);
            txtInput.Focus();
        }

        // =====================================================================

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            // Статические события обязательно отвязываем, иначе форма остаётся жить
            // в памяти и падает при следующем логе ядра.
            LisunEngine.OnLogAdded -= AppendKernelLog;
            LisunEngine.OnSoftRestartRequested -= HandleSoftRestart;
            FormEngine.OnAppShowRequested -= HandleAppShowRequested;
            LisunLocale.LanguageChanged -= ApplyLanguage;
            LisunLocale.LayoutChanged -= UpdateStatus;
            LisunEngine.UiHost = null;
            LisunEngine.ShellBrowserOpener = null;

            if (shellMenu != null) shellMenu.Dispose();
            if (layoutMenu != null) layoutMenu.Dispose();
            if (languageMenu != null) languageMenu.Dispose();
            statusHints.Dispose();

            base.OnFormClosed(e);
        }

        /// <summary>
        /// Сеть при загрузке: слежение за интернетом, автозагрузка php-frm
        /// и системный порт 8989 — последний только если право hall уже выдано,
        /// чтобы загрузка системы не упиралась в вопрос пользователю.
        /// </summary>
        private void StartNetworkSubsystem()
        {
            try
            {
                LisunWifi.ConnectivityChanged += OnConnectivityChanged;
                LisunWifi.StartWatcher();

                WriteLine(LisunLocale.T("boot.network"), Theme.TextDim);

                if (LisunSystemServer.HallGranted)
                {
                    string message;
                    if (LisunSystemServer.Start(out message))
                        WriteLine("   " + LisunLocale.T("sys.fieldPage") + ": " +
                                  LisunSystemServer.SetupUrl, Theme.Cyan);
                    else
                        WriteLine("   " + message, Theme.Warning);
                }
                else
                {
                    WriteLine("   " + LisunLocale.T("boot.hallHint"), Theme.TextDim);
                }
            }
            catch (Exception ex)
            {
                WriteLine(LisunLocale.T("boot.fail", ex.Message), Theme.Danger);
            }
        }

        /// <summary>
        /// Интернет появился — сразу тянем php-frm, если своего PHP ещё нет.
        /// Прямой эфир загрузки идёт на localhost:8989/php-frm.html?action=setup.
        /// </summary>
        private void OnConnectivityChanged(bool online)
        {
            LisunEngine.RunOnUi(() =>
            {
                if (IsDisposed) return;

                WriteLine(LisunLocale.T(online ? "wifi.wentOnline" : "wifi.wentOffline"),
                          online ? Theme.Success : Theme.Warning);

                if (!online) return;
                if (LisunPhpModule.OwnPhpInstalled || LisunPhpModule.Downloading) return;
                if (!LisunPhpModule.AutoDownloadEnabled) return;

                if (LisunPhpModule.BeginAutoDownload())
                {
                    WriteLine(LisunLocale.T("php.autoQueued"), Theme.Cyan);
                    WriteLine(LisunLocale.T("php.autoWatch", LisunSystemServer.SetupUrl), Theme.TextDim);
                }
            });
        }

    }
}
