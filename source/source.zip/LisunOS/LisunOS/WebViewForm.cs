﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LisunOS
{
    public partial class WebViewForm : Form
    {
        /// <summary>Оболочка подписывается на это событие, чтобы свернуть браузер.</summary>
        public event Action OnBrowserCloseRequested;

        private const string HomePage = "https://www.google.com";

        private static readonly string[] EngineNames = { "Google", "Яндекс", "Bing", "DuckDuckGo" };
        private static readonly string[] EngineUrls =
        {
            "https://www.google.com/search?q=",
            "https://yandex.ru/search/?text=",
            "https://www.bing.com/search?q=",
            "https://duckduckgo.com/?q="
        };

        private int engineIndex;

        public WebViewForm()
        {
            InitializeComponent();
            ApplyTheme();
            ApplyLanguage();
        }

        private void ApplyTheme()
        {
            txtBrowserUrl.Font = Theme.Mono(10f);
            lblStatus.Font = Theme.Mono(9f);

            Theme.StyleButton(btnNavBack, Theme.SurfaceAlt, Theme.Text);
            Theme.StyleButton(btnNavForward, Theme.SurfaceAlt, Theme.Text);
            Theme.StyleButton(btnReload, Theme.SurfaceAlt, Theme.Text);
            Theme.StyleButton(btnHome, Theme.SurfaceAlt, Theme.Text);
            Theme.StyleButton(btnGo, Theme.AccentDeep, Theme.Text);
            Theme.StyleButton(btnEngine, Theme.SurfaceAlt, Theme.Accent);
            Theme.StyleButton(btnCloseBrowser, Color.FromArgb(92, 32, 32), Color.FromArgb(246, 198, 198));

            btnNavBack.Font = Theme.Ui(12f);
            btnNavForward.Font = Theme.Ui(12f);
            btnReload.Font = Theme.Ui(12f);
            btnHome.Font = Theme.Ui(12f);
        }

        /// <summary>Перевод интерфейса браузера; вызывается при смене языка системы.</summary>
        public void ApplyLanguage()
        {
            btnGo.Text = LisunLocale.T("browser.go");
            btnCloseBrowser.Text = LisunLocale.T("browser.hide");
            if (string.IsNullOrEmpty(lblStatus.Text) || lblStatus.Text.Length < 2)
                lblStatus.Text = LisunLocale.T("browser.ready");

            UpdateEngineCaption();
        }

        // =====================================================================
        //  Навигация
        // =====================================================================

        public void NavigateTo(string target)
        {
            if (string.IsNullOrWhiteSpace(target)) target = HomePage;
            target = target.Trim();

            string url = IsLikelyUrl(target) ? NormalizeUrl(target) : BuildSearchUrl(target);

            txtBrowserUrl.Text = url;
            SetStatus(LisunLocale.T("browser.loading", url));

            try { miniWebBrowser.Navigate(url); }
            catch (Exception ex) { SetStatus(LisunLocale.T("browser.navError", ex.Message)); }
        }

        private static bool IsLikelyUrl(string value)
        {
            if (value.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                value.StartsWith("https://", StringComparison.OrdinalIgnoreCase) ||
                value.StartsWith("file://", StringComparison.OrdinalIgnoreCase) ||
                value.StartsWith("about:", StringComparison.OrdinalIgnoreCase)) return true;

            if (value.IndexOf(' ') >= 0) return false;

            int dot = value.IndexOf('.');
            return dot > 0 && dot < value.Length - 1;
        }

        private static string NormalizeUrl(string value)
        {
            if (value.StartsWith("http", StringComparison.OrdinalIgnoreCase) ||
                value.StartsWith("file://", StringComparison.OrdinalIgnoreCase) ||
                value.StartsWith("about:", StringComparison.OrdinalIgnoreCase)) return value;

            return "https://" + value;
        }

        /// <summary>
        /// Раньше адрес собирался как "https://google.com" + запрос — получался мусор
        /// вроде https://google.comпогода. Теперь используется корректный путь поиска.
        /// </summary>
        private string BuildSearchUrl(string query)
        {
            return EngineUrls[engineIndex] + Uri.EscapeDataString(query);
        }

        private void UpdateEngineCaption()
        {
            btnEngine.Text = EngineNames[engineIndex] + "  ▾";
        }

        private void SetStatus(string text)
        {
            lblStatus.Text = text;
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        private void btnNavBack_Click(object sender, EventArgs e)
        {
            if (miniWebBrowser.CanGoBack) miniWebBrowser.GoBack();
        }

        private void btnNavForward_Click(object sender, EventArgs e)
        {
            if (miniWebBrowser.CanGoForward) miniWebBrowser.GoForward();
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            try { miniWebBrowser.Refresh(WebBrowserRefreshOption.Completely); }
            catch { }
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            NavigateTo(HomePage);
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            NavigateTo(txtBrowserUrl.Text);
        }

        private void btnEngine_Click(object sender, EventArgs e)
        {
            engineIndex = (engineIndex + 1) % EngineNames.Length;
            UpdateEngineCaption();
            SetStatus(LisunLocale.T("browser.engine", EngineNames[engineIndex]));
        }

        private void btnCloseBrowser_Click(object sender, EventArgs e)
        {
            Action handler = OnBrowserCloseRequested;
            if (handler != null) handler();
        }

        private void txtBrowserUrl_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Enter) return;

            e.SuppressKeyPress = true;
            e.Handled = true;
            NavigateTo(txtBrowserUrl.Text);
        }

        private void miniWebBrowser_Navigating(object sender, WebBrowserNavigatingEventArgs e)
        {
            SetStatus(LisunLocale.T("browser.connecting"));
        }

        private void miniWebBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            if (e.Url != null) txtBrowserUrl.Text = e.Url.ToString();
            SetStatus(LisunLocale.T("browser.receiving"));
        }

        private void miniWebBrowser_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            btnNavBack.Enabled = miniWebBrowser.CanGoBack;
            btnNavForward.Enabled = miniWebBrowser.CanGoForward;

            string title = miniWebBrowser.DocumentTitle;
            string done = LisunLocale.T("browser.done");
            SetStatus(string.IsNullOrEmpty(title) ? done : done + "  ·  " + title);
        }
    }
}
