﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика приложения «Доступ по сети» (пакет apps/sshapp).
    ///
    /// Окно отвечает на один вопрос: что вводить на телефоне или другом ПК,
    /// чтобы попасть в оболочку LisunOS. Поэтому адрес показан целиком,
    /// вместе с портом, рядом кнопка «Копировать», а ниже — пользователи,
    /// без которых сервер не запускается.
    /// </summary>
    public partial class SshLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label subtitle;
        private readonly Label addressHint;
        private readonly ListBox addresses;
        private readonly Label portCaption;
        private readonly TextBox port;
        private readonly Button start;
        private readonly Button stop;
        private readonly Button copy;
        private readonly Label serverState;

        private readonly Label usersCaption;
        private readonly ListView users;
        private readonly Label userCaption;
        private readonly TextBox userName;
        private readonly Label passCaption;
        private readonly TextBox userPass;
        private readonly Button userCreate;
        private readonly Button userPassword;
        private readonly Button userRemove;

        private readonly Label logCaption;
        private readonly TextBox log;
        private readonly Label status;

        private readonly Timer timer = new Timer();
        private readonly List<string> userRows = new List<string>();

        private int lastLogCount = -1;

        public SshLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblTitle");
            subtitle = context.Get<Label>("lblSubtitle");
            addressHint = context.Get<Label>("lblAddressHint");
            addresses = context.Get<ListBox>("lstAddresses");
            portCaption = context.Get<Label>("lblPortCaption");
            port = context.Get<TextBox>("txtPort");
            start = context.Get<Button>("btnStartSsh");
            stop = context.Get<Button>("btnStopSsh");
            copy = context.Get<Button>("btnCopyAddress");
            serverState = context.Get<Label>("lblServerState");

            usersCaption = context.Get<Label>("lblUsersCaption");
            users = context.Get<ListView>("lstSshUsers");
            userCaption = context.Get<Label>("lblUserCaption");
            userName = context.Get<TextBox>("txtUserName");
            passCaption = context.Get<Label>("lblPassCaption");
            userPass = context.Get<TextBox>("txtUserPass");
            userCreate = context.Get<Button>("btnUserCreate");
            userPassword = context.Get<Button>("btnUserPassword");
            userRemove = context.Get<Button>("btnUserRemove");

            logCaption = context.Get<Label>("lblLogCaption");
            log = context.Get<TextBox>("txtSshLog");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("sshapp.windowTitle");
                form.Disposed += (s, e) => { try { timer.Stop(); timer.Dispose(); } catch { } };
            }

            if (title != null)
            {
                title.Text = LisunLocale.T("sshapp.windowTitle");
                title.Font = Theme.Ui(14f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
            }
            if (subtitle != null)
            {
                subtitle.Text = LisunLocale.T("sshapp.subtitle");
                subtitle.Font = Theme.Ui(9f);
            }
            if (addressHint != null)
            {
                addressHint.Text = LisunLocale.T("sshapp.addressHint");
                addressHint.Font = Theme.Ui(9f);
                addressHint.ForeColor = Theme.TextDim;
            }
            if (usersCaption != null)
            {
                usersCaption.Text = LisunLocale.T("sshapp.usersCaption");
                usersCaption.Font = Theme.Ui(11f, FontStyle.Bold);
            }
            if (logCaption != null)
            {
                logCaption.Text = LisunLocale.T("sshapp.logCaption");
                logCaption.Font = Theme.Ui(11f, FontStyle.Bold);
            }

            if (portCaption != null) portCaption.Text = LisunLocale.T("sshapp.port");
            if (userCaption != null) userCaption.Text = LisunLocale.T("sshapp.user");
            if (passCaption != null) passCaption.Text = LisunLocale.T("sshapp.password");

            if (addresses != null)
            {
                addresses.Font = Theme.Mono(11f);
                addresses.ItemHeight = 22;
            }
            if (log != null) log.Font = Theme.Mono(9f);
            if (status != null) status.Font = Theme.Mono(8.75f);
            if (serverState != null) serverState.Font = Theme.Mono(9.5f);
            if (port != null) { port.Font = Theme.Mono(10f); port.Text = SshHost.Port.ToString(); }
            if (userName != null) userName.Font = Theme.Mono(10f);
            if (userPass != null) userPass.Font = Theme.Mono(10f);

            if (users != null)
            {
                users.Font = Theme.Mono(9.5f);
                users.Columns.Add(LisunLocale.T("sshapp.columnUser"), 130);
                users.Columns.Add(LisunLocale.T("sshapp.columnState"), 90);
                users.Columns.Add(LisunLocale.T("sshapp.columnLogins"), 70);
                users.Columns.Add(LisunLocale.T("sshapp.columnLast"), 100);
            }

            if (start != null)
            {
                start.Text = LisunLocale.T("sshapp.start");
                Theme.StyleButton(start, Theme.AccentDeep, Theme.Text);
            }
            if (stop != null)
            {
                stop.Text = LisunLocale.T("sshapp.stop");
                Theme.StyleButton(stop, Theme.SurfaceAlt, Theme.TextDim);
            }
            if (copy != null)
            {
                copy.Text = LisunLocale.T("sshapp.copy");
                Theme.StyleButton(copy, Theme.SurfaceAlt, Theme.Text);
            }
            if (userCreate != null)
            {
                userCreate.Text = LisunLocale.T("sshapp.userCreate");
                Theme.StyleButton(userCreate, Theme.AccentDeep, Theme.Text);
            }
            if (userPassword != null)
            {
                userPassword.Text = LisunLocale.T("sshapp.userPassword");
                Theme.StyleButton(userPassword, Theme.SurfaceAlt, Theme.Text);
            }
            if (userRemove != null)
            {
                userRemove.Text = LisunLocale.T("sshapp.userRemove");
                Theme.StyleButton(userRemove, Theme.SurfaceAlt, Theme.Danger);
            }

            FillAddresses();
            FillUsers();
            ShowServerState();

            timer.Interval = 1500;
            timer.Tick += (s, e) => Tick();
            timer.Start();

            SetStatus(LisunUsers.Count == 0
                ? LisunLocale.T("sshapp.firstUser")
                : LisunLocale.T("sshapp.ready"));
        }

        // =====================================================================
        //  Адреса
        // =====================================================================

        private void FillAddresses()
        {
            if (addresses == null) return;

            string selected = addresses.SelectedItem as string;

            addresses.BeginUpdate();
            addresses.Items.Clear();

            List<string> list;
            try { list = SshHost.Addresses(); }
            catch { list = new List<string>(); }

            int shown = SshHost.Running ? SshHost.Port : ReadPort();

            foreach (string address in list)
                addresses.Items.Add(address + ":" + shown);

            if (addresses.Items.Count == 0)
                addresses.Items.Add(LisunLocale.T("sshapp.noAddress"));

            addresses.EndUpdate();

            if (selected != null)
            {
                int index = addresses.Items.IndexOf(selected);
                if (index >= 0) addresses.SelectedIndex = index;
            }
            if (addresses.SelectedIndex < 0 && addresses.Items.Count > 0) addresses.SelectedIndex = 0;
        }

        private int ReadPort()
        {
            if (port == null) return SshHost.DefaultPort;

            int value;
            if (!int.TryParse((port.Text ?? string.Empty).Trim(), out value)) return SshHost.DefaultPort;
            if (value < 1 || value > 65535) return SshHost.DefaultPort;

            return value;
        }

        private void ShowServerState()
        {
            if (serverState != null)
            {
                serverState.Text = SshHost.Running
                    ? LisunLocale.T("sshapp.stateOn", SshHost.Port, SshHost.Sessions)
                    : LisunLocale.T("sshapp.stateOff");
                serverState.ForeColor = SshHost.Running ? Theme.Success : Theme.TextDim;
            }

            if (start != null) start.Enabled = !SshHost.Running;
            if (stop != null) stop.Enabled = SshHost.Running;
            if (port != null) port.Enabled = !SshHost.Running;
        }

        // =====================================================================
        //  Пользователи
        // =====================================================================

        private void FillUsers()
        {
            if (users == null) return;

            string selected = SelectedUser();

            users.BeginUpdate();
            users.Items.Clear();
            userRows.Clear();

            List<LisunUsers.Account> list;
            try { list = LisunUsers.All(); }
            catch { list = new List<LisunUsers.Account>(); }

            foreach (LisunUsers.Account account in list)
            {
                ListViewItem row = new ListViewItem(account.Name);
                row.SubItems.Add(account.Enabled
                    ? LisunLocale.T("sshapp.userOn")
                    : LisunLocale.T("sshapp.userOff"));
                row.SubItems.Add(account.Logins.ToString());
                row.SubItems.Add(account.LastLogin == DateTime.MinValue
                    ? "—"
                    : account.LastLogin.ToString("dd.MM HH:mm"));
                row.ForeColor = account.Enabled ? Theme.Text : Theme.TextDim;

                users.Items.Add(row);
                userRows.Add(account.Name);
            }

            users.EndUpdate();

            if (selected != null) SelectUser(selected);
        }

        private string SelectedUser()
        {
            if (users == null || users.SelectedIndices.Count == 0) return null;

            int index = users.SelectedIndices[0];
            if (index < 0 || index >= userRows.Count) return null;
            return userRows[index];
        }

        private void SelectUser(string name)
        {
            if (users == null || name == null) return;

            for (int index = 0; index < userRows.Count && index < users.Items.Count; index++)
            {
                if (userRows[index].Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    users.Items[index].Selected = true;
                    return;
                }
            }
        }

        // =====================================================================
        //  Журнал
        // =====================================================================

        private void ShowLog()
        {
            if (log == null) return;

            string[] lines;
            try { lines = SshHost.Log; }
            catch { lines = new string[0]; }

            // Перерисовываем только когда строк стало больше:
            // иначе каждые полторы секунды сбрасывалась бы прокрутка.
            if (lines.Length == lastLogCount) return;
            lastLogCount = lines.Length;

            StringBuilder sb = new StringBuilder();
            foreach (string line in lines) sb.AppendLine(line);

            if (lines.Length == 0) sb.AppendLine(LisunLocale.T("sshapp.logEmpty"));

            log.Text = sb.ToString();
            log.SelectionStart = log.TextLength;
            log.ScrollToCaret();
        }

        private void Tick()
        {
            if (form == null || form.IsDisposed) return;

            ShowServerState();
            ShowLog();
        }

        private void SetStatus(string text)
        {
            if (status != null) status.Text = text;
        }

        // =====================================================================
        //  Обработчики формы
        // =====================================================================

        public void btnStartSsh_Click(object sender, EventArgs e)
        {
            if (LisunUsers.Count == 0)
            {
                SetStatus(LisunLocale.T("sshapp.firstUser"));
                return;
            }

            string message;
            SshHost.Start(ReadPort(), out message);

            FillAddresses();
            ShowServerState();
            SetStatus(message.Trim());
        }

        public void btnStopSsh_Click(object sender, EventArgs e)
        {
            SshHost.Stop();

            FillAddresses();
            ShowServerState();
            SetStatus(LisunLocale.T("sshapp.stopped"));
        }

        public void btnCopyAddress_Click(object sender, EventArgs e)
        {
            if (addresses == null || addresses.SelectedItem == null)
            {
                SetStatus(LisunLocale.T("sshapp.pickAddress"));
                return;
            }

            string address = addresses.SelectedItem.ToString();
            if (address == LisunLocale.T("sshapp.noAddress"))
            {
                SetStatus(LisunLocale.T("sshapp.pickAddress"));
                return;
            }

            if (!LisunPermissions.Demand(packageName, LisunPermissions.Clipboard))
            {
                SetStatus(LisunLocale.T("sshapp.needClipboard"));
                return;
            }

            try
            {
                Clipboard.SetText(address);
                SetStatus(LisunLocale.T("sshapp.copied", address));
            }
            catch (Exception ex)
            {
                SetStatus(" [ERROR] " + ex.Message);
            }
        }

        public void lstSshUsers_SelectedIndexChanged(object sender, EventArgs e)
        {
            string name = SelectedUser();
            if (name != null && userName != null) userName.Text = name;
        }

        public void btnUserCreate_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageUsers))
            {
                SetStatus(LisunLocale.T("sshapp.needUsers"));
                return;
            }

            string name = userName == null ? string.Empty : (userName.Text ?? string.Empty).Trim();
            string password = userPass == null ? string.Empty : userPass.Text ?? string.Empty;

            string message;
            if (LisunUsers.Create(name, password, out message))
            {
                if (userPass != null) userPass.Text = string.Empty;
                FillUsers();
                SelectUser(name);
            }

            SetStatus(message.Trim());
        }

        public void btnUserPassword_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageUsers))
            {
                SetStatus(LisunLocale.T("sshapp.needUsers"));
                return;
            }

            string name = SelectedUser();
            if (name == null) name = userName == null ? string.Empty : (userName.Text ?? string.Empty).Trim();

            string password = userPass == null ? string.Empty : userPass.Text ?? string.Empty;

            string message;
            if (LisunUsers.Edit(name, password, out message))
            {
                if (userPass != null) userPass.Text = string.Empty;
                FillUsers();
                SelectUser(name);
            }

            SetStatus(message.Trim());
        }

        public void btnUserRemove_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageUsers))
            {
                SetStatus(LisunLocale.T("sshapp.needUsers"));
                return;
            }

            string name = SelectedUser();
            if (name == null)
            {
                SetStatus(LisunLocale.T("sshapp.pickUser"));
                return;
            }

            DialogResult answer = MessageBox.Show(
                LisunLocale.T("sshapp.removeBody", name),
                LisunLocale.T("sshapp.removeTitle"),
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (answer != DialogResult.Yes)
            {
                SetStatus(LisunLocale.T("sshapp.removeCancelled"));
                return;
            }

            string message;
            LisunUsers.Remove(name, out message);

            FillUsers();
            SetStatus(message.Trim());
        }
    }
}
