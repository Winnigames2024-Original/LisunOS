﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Окно Wi-Fi: список сетей вокруг, пароль и подключение.
    /// Открытая сеть подключается без пароля, сеть со страницей входа
    /// открывает браузер, а при появлении интернета сразу стартует php-frm.
    /// </summary>
    public class LisunWifiForm : Form
    {
        private readonly string packageName;

        private Panel pnlHeader;
        private Label lblTitle;
        private Label lblState;

        private ListView lstNetworks;

        private Panel pnlForm;
        private Label lblPasswordCaption;
        private TextBox txtPassword;
        private CheckBox chkShow;

        private Button btnScan;
        private Button btnConnect;
        private Button btnDisconnect;
        private Button btnForget;
        private Button btnPortal;
        private Button btnSetup;

        private Label lblStatus;
        private ProgressBar prgBusy;

        private List<WifiNetwork> networks = new List<WifiNetwork>();
        private bool busy;

        public LisunWifiForm(string packageName)
        {
            this.packageName = string.IsNullOrEmpty(packageName) ? LisunWifi.PackageName : packageName;

            BuildInterface();
            BeginScan();
        }

        // =====================================================================
        //  Интерфейс
        // =====================================================================

        private void BuildInterface()
        {
            Text = LisunLocale.T("wifi.title");
            ClientSize = new Size(760, 560);
            MinimumSize = new Size(620, 460);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            ForeColor = Theme.Text;
            Font = Theme.Ui(9.5f);
            DoubleBuffered = true;

            pnlHeader = new Panel();
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Height = 74;
            pnlHeader.BackColor = Theme.Surface;
            pnlHeader.Padding = new Padding(18, 12, 18, 12);
            Controls.Add(pnlHeader);

            lblTitle = new Label();
            lblTitle.Text = LisunLocale.T("wifi.title");
            lblTitle.Font = Theme.Ui(13f, FontStyle.Bold);
            lblTitle.ForeColor = Theme.Text;
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(18, 12);
            pnlHeader.Controls.Add(lblTitle);

            lblState = new Label();
            lblState.Text = LisunLocale.T("wifi.scanning");
            lblState.Font = Theme.Mono(9f);
            lblState.ForeColor = Theme.TextDim;
            lblState.AutoSize = true;
            lblState.Location = new Point(20, 42);
            pnlHeader.Controls.Add(lblState);

            Panel pnlBottom = new Panel();
            pnlBottom.Dock = DockStyle.Bottom;
            pnlBottom.Height = 150;
            pnlBottom.BackColor = Theme.Surface;
            pnlBottom.Padding = new Padding(18, 12, 18, 12);
            Controls.Add(pnlBottom);

            pnlForm = pnlBottom;

            lblPasswordCaption = new Label();
            lblPasswordCaption.Text = LisunLocale.T("wifi.password");
            lblPasswordCaption.ForeColor = Theme.TextDim;
            lblPasswordCaption.AutoSize = true;
            lblPasswordCaption.Location = new Point(18, 14);
            pnlForm.Controls.Add(lblPasswordCaption);

            txtPassword = new TextBox();
            txtPassword.Location = new Point(18, 34);
            txtPassword.Size = new Size(330, 26);
            txtPassword.BackColor = Theme.SurfaceAlt;
            txtPassword.ForeColor = Theme.Text;
            txtPassword.BorderStyle = BorderStyle.FixedSingle;
            txtPassword.Font = Theme.Mono(10.5f);
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.KeyDown += txtPassword_KeyDown;
            pnlForm.Controls.Add(txtPassword);

            chkShow = new CheckBox();
            chkShow.Text = LisunLocale.T("wifi.showPassword");
            chkShow.ForeColor = Theme.TextDim;
            chkShow.AutoSize = true;
            chkShow.Location = new Point(360, 38);
            chkShow.CheckedChanged += chkShow_CheckedChanged;
            pnlForm.Controls.Add(chkShow);

            btnConnect = MakeButton(LisunLocale.T("wifi.connect"), 18, 74, 150, Theme.AccentDeep);
            btnConnect.Click += btnConnect_Click;
            pnlForm.Controls.Add(btnConnect);

            btnDisconnect = MakeButton(LisunLocale.T("wifi.disconnect"), 176, 74, 130, Theme.SurfaceAlt);
            btnDisconnect.Click += btnDisconnect_Click;
            pnlForm.Controls.Add(btnDisconnect);

            btnForget = MakeButton(LisunLocale.T("wifi.forget"), 314, 74, 120, Theme.SurfaceAlt);
            btnForget.Click += btnForget_Click;
            pnlForm.Controls.Add(btnForget);

            btnPortal = MakeButton(LisunLocale.T("wifi.openPortalButton"), 442, 74, 170, Theme.SurfaceAlt);
            btnPortal.Click += btnPortal_Click;
            btnPortal.Enabled = false;
            pnlForm.Controls.Add(btnPortal);

            prgBusy = new ProgressBar();
            prgBusy.Location = new Point(18, 112);
            prgBusy.Size = new Size(594, 6);
            prgBusy.Style = ProgressBarStyle.Marquee;
            prgBusy.MarqueeAnimationSpeed = 0;
            prgBusy.Visible = false;
            pnlForm.Controls.Add(prgBusy);

            lblStatus = new Label();
            lblStatus.Text = string.Empty;
            lblStatus.ForeColor = Theme.TextDim;
            lblStatus.Font = Theme.Mono(8.75f);
            lblStatus.AutoEllipsis = true;
            lblStatus.Location = new Point(18, 122);
            lblStatus.Size = new Size(700, 20);
            pnlForm.Controls.Add(lblStatus);

            Panel pnlTools = new Panel();
            pnlTools.Dock = DockStyle.Top;
            pnlTools.Height = 46;
            pnlTools.BackColor = Theme.Background;
            pnlTools.Padding = new Padding(18, 8, 18, 8);
            Controls.Add(pnlTools);

            btnScan = MakeButton(LisunLocale.T("wifi.scan"), 18, 6, 150, Theme.SurfaceAlt);
            btnScan.Click += btnScan_Click;
            pnlTools.Controls.Add(btnScan);

            btnSetup = MakeButton(LisunLocale.T("wifi.openSetup"), 176, 6, 230, Theme.SurfaceAlt);
            btnSetup.Click += btnSetup_Click;
            pnlTools.Controls.Add(btnSetup);

            lstNetworks = new ListView();
            lstNetworks.Dock = DockStyle.Fill;
            lstNetworks.View = View.Details;
            lstNetworks.FullRowSelect = true;
            lstNetworks.MultiSelect = false;
            lstNetworks.HideSelection = false;
            lstNetworks.BackColor = Theme.Surface;
            lstNetworks.ForeColor = Theme.Text;
            lstNetworks.BorderStyle = BorderStyle.None;
            lstNetworks.Font = Theme.Mono(9.5f);
            lstNetworks.Columns.Add(LisunLocale.T("wifi.columnName"), 300);
            lstNetworks.Columns.Add(LisunLocale.T("wifi.columnSignal"), 140);
            lstNetworks.Columns.Add(LisunLocale.T("wifi.columnSecurity"), 180);
            lstNetworks.Columns.Add(LisunLocale.T("wifi.columnSaved"), 110);
            lstNetworks.SelectedIndexChanged += lstNetworks_SelectedIndexChanged;
            lstNetworks.DoubleClick += lstNetworks_DoubleClick;
            Controls.Add(lstNetworks);

            Theme.Harmonize(this);
        }

        private Button MakeButton(string text, int x, int y, int width, Color back)
        {
            Button button = new Button();
            button.Text = text;
            button.Location = new Point(x, y);
            button.Size = new Size(width, 32);

            Theme.StyleButton(button, back, Theme.Text);
            return button;
        }

        // =====================================================================
        //  Сканирование
        // =====================================================================

        private void BeginScan()
        {
            if (busy) return;

            // Сканирование — это обращение к сети, поэтому спрашиваем право.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.Network))
            {
                SetStatus(LisunLocale.T("wifi.needNetwork"), Theme.Danger);
                return;
            }

            SetBusy(true, LisunLocale.T("wifi.scanning"));

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                List<WifiNetwork> found;
                string current;
                bool adapter;

                try
                {
                    adapter = LisunWifi.AdapterPresent;
                    found = adapter ? LisunWifi.Scan() : new List<WifiNetwork>();
                    current = LisunWifi.CurrentSsid();
                }
                catch (Exception ex)
                {
                    adapter = false;
                    found = new List<WifiNetwork>();
                    current = string.Empty;

                    LisunEngine.RunOnUi(() => SetStatus(" [ERROR] " + ex.Message, Theme.Danger));
                }

                List<string> saved;
                try { saved = LisunWifi.SavedProfiles(); }
                catch { saved = new List<string>(); }

                LisunEngine.RunOnUi(() => FillList(found, saved, current, adapter));
            });
        }

        private void FillList(List<WifiNetwork> found, List<string> saved, string current, bool adapter)
        {
            if (IsDisposed) return;

            networks = found;

            lstNetworks.BeginUpdate();
            lstNetworks.Items.Clear();

            foreach (WifiNetwork network in found)
            {
                ListViewItem item = new ListViewItem(network.Ssid);

                item.SubItems.Add(network.SignalBar + "  " + network.Signal + "%");
                item.SubItems.Add(network.Open ? LisunLocale.T("wifi.openShort") : network.Authentication);
                item.SubItems.Add(saved.Contains(network.Ssid) ? LisunLocale.T("wifi.savedMark") : string.Empty);
                item.Tag = network;

                if (network.Connected)
                {
                    item.ForeColor = Theme.Success;
                    item.Font = Theme.Mono(9.5f, FontStyle.Bold);
                }
                else if (network.Open)
                {
                    item.ForeColor = Theme.Cyan;
                }

                lstNetworks.Items.Add(item);
            }

            lstNetworks.EndUpdate();

            SetBusy(false, null);

            if (!adapter)
            {
                lblState.Text = LisunLocale.T("wifi.noAdapter");
                SetStatus(LisunLocale.T("wifi.noAdapter"), Theme.Warning);
                return;
            }

            lblState.Text = current.Length > 0
                ? LisunLocale.T("wifi.headerConnected", current, found.Count)
                : LisunLocale.T("wifi.headerFree", found.Count);

            RefreshPortalButton();
            UpdatePasswordState();
        }

        private void RefreshPortalButton()
        {
            btnPortal.Enabled = !string.IsNullOrEmpty(LisunWifi.PortalUrl);
        }

        private WifiNetwork Selected
        {
            get
            {
                if (lstNetworks.SelectedItems.Count == 0) return null;

                return lstNetworks.SelectedItems[0].Tag as WifiNetwork;
            }
        }

        private void UpdatePasswordState()
        {
            WifiNetwork network = Selected;

            if (network == null)
            {
                txtPassword.Enabled = true;
                lblPasswordCaption.Text = LisunLocale.T("wifi.password");
                return;
            }

            // Открытой сети пароль не нужен — поле просто гаснет.
            txtPassword.Enabled = !network.Open;
            lblPasswordCaption.Text = network.Open
                ? LisunLocale.T("wifi.passwordNotNeeded")
                : network.Enterprise
                    ? LisunLocale.T("wifi.passwordEnterprise")
                    : LisunLocale.T("wifi.passwordFor", network.Ssid);
        }

        private void SetBusy(bool state, string status)
        {
            busy = state;

            btnScan.Enabled = !state;
            btnConnect.Enabled = !state;
            btnDisconnect.Enabled = !state;
            btnForget.Enabled = !state;

            prgBusy.Visible = state;
            prgBusy.MarqueeAnimationSpeed = state ? 30 : 0;

            if (status != null) SetStatus(status, Theme.TextDim);
        }

        private void SetStatus(string text, Color color)
        {
            if (IsDisposed || lblStatus == null) return;

            lblStatus.Text = text ?? string.Empty;
            lblStatus.ForeColor = color;
        }

        // =====================================================================
        //  Обработчики
        // =====================================================================

        private void btnScan_Click(object sender, EventArgs e)
        {
            BeginScan();
        }

        private void lstNetworks_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdatePasswordState();
        }

        private void lstNetworks_DoubleClick(object sender, EventArgs e)
        {
            btnConnect_Click(sender, e);
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) btnConnect_Click(sender, EventArgs.Empty);
        }

        private void chkShow_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkShow.Checked;
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            WifiNetwork network = Selected;
            if (network == null)
            {
                SetStatus(LisunLocale.T("wifi.selectFirst"), Theme.Warning);
                return;
            }

            string password = network.Open ? string.Empty : txtPassword.Text;

            SetBusy(true, LisunLocale.T("wifi.connecting", network.Ssid));

            string ssid = network.Ssid;

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                string message;
                bool success;

                try { success = LisunWifi.Connect(ssid, password, out message); }
                catch (Exception ex)
                {
                    success = false;
                    message = " [ERROR] " + ex.Message;
                }

                LisunEngine.RunOnUi(() =>
                {
                    SetBusy(false, null);
                    SetStatus(message, success ? Theme.Success : Theme.Danger);

                    txtPassword.Clear();
                    RefreshPortalButton();
                    BeginScan();
                });
            });
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            string message;
            bool success = LisunWifi.Disconnect(out message);

            SetStatus(message, success ? Theme.TextDim : Theme.Danger);
            BeginScan();
        }

        private void btnForget_Click(object sender, EventArgs e)
        {
            WifiNetwork network = Selected;
            if (network == null)
            {
                SetStatus(LisunLocale.T("wifi.selectFirst"), Theme.Warning);
                return;
            }

            string message;
            bool success = LisunWifi.Forget(network.Ssid, out message);

            SetStatus(message, success ? Theme.TextDim : Theme.Danger);
            BeginScan();
        }

        private void btnPortal_Click(object sender, EventArgs e)
        {
            LisunWifi.OpenPortal(LisunWifi.PortalUrl);
            SetStatus(LisunLocale.T("wifi.openingPortal", LisunWifi.PortalUrl), Theme.TextDim);
        }

        private void btnSetup_Click(object sender, EventArgs e)
        {
            string message;

            if (!LisunSystemServer.Running && !LisunSystemServer.Start(out message))
            {
                SetStatus(message, Theme.Danger);
                return;
            }

            if (!LisunEngine.OpenInShellBrowser(LisunSystemServer.SetupUrl))
            {
                try { System.Diagnostics.Process.Start(LisunSystemServer.SetupUrl); }
                catch (Exception ex) { SetStatus(" [ERROR] " + ex.Message, Theme.Danger); return; }
            }

            SetStatus(LisunLocale.T("wifi.setupOpened", LisunSystemServer.SetupUrl), Theme.TextDim);
        }
    }
}
