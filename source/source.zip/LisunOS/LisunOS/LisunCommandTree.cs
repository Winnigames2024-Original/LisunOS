﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Дерево команд LisunOS: команда → субкоманда → суб-субкоманда → аргумент.
    ///
    /// Из него строятся подсказки в терминале. Узел-аргумент показывается
    /// серой сверкой вида &lt;имя&gt; — как подсказка команды в Minecraft:
    /// видно, что система ждёт ваш текст, и какой именно.
    /// </summary>
    public static class LisunCommandTree
    {
        public sealed class Node
        {
            public string Name = string.Empty;
            public string Description = string.Empty;

            /// <summary>Узел ждёт свой текст, а не выбор из списка.</summary>
            public bool IsArgument;

            /// <summary>Аргумент можно не указывать.</summary>
            public bool Optional;

            /// <summary>Откуда брать готовые значения: сети, пакеты, языки.</summary>
            public Func<List<string>> Values;

            public readonly List<Node> Children = new List<Node>();

            public Node Add(Node child)
            {
                Children.Add(child);
                return this;
            }

            /// <summary>Как узел выглядит в подсказке.</summary>
            public string Label
            {
                get { return IsArgument ? "<" + Name + ">" : Name; }
            }
        }

        /// <summary>Что показать по текущей строке ввода.</summary>
        public sealed class Hint
        {
            /// <summary>Варианты выбора: пары «что вставить» и «пояснение».</summary>
            public readonly List<string> Items = new List<string>();
            public readonly List<string> Descriptions = new List<string>();

            /// <summary>Сверка аргумента — то, что подставляется серым: &lt;сеть&gt;.</summary>
            public string Placeholder = string.Empty;

            /// <summary>Строка использования: wifi connect &lt;сеть&gt; [пароль].</summary>
            public string Usage = string.Empty;

            /// <summary>Уже набранная часть последнего слова — её заменяет выбор.</summary>
            public string Prefix = string.Empty;

            public bool HasItems { get { return Items.Count > 0; } }
            public bool HasPlaceholder { get { return Placeholder.Length > 0; } }
        }

        // =====================================================================
        //  Построение дерева
        // =====================================================================

        private static Node root;

        private static Node Word(string name, string description)
        {
            Node node = new Node();
            node.Name = name;
            node.Description = description ?? string.Empty;
            return node;
        }

        private static Node Arg(string name, string description)
        {
            Node node = Word(name, description);
            node.IsArgument = true;
            return node;
        }

        private static Node Arg(string name, string description, Func<List<string>> values)
        {
            Node node = Arg(name, description);
            node.Values = values;
            return node;
        }

        private static Node Optional(string name, string description)
        {
            Node node = Arg(name, description);
            node.Optional = true;
            return node;
        }

        public static Node Root
        {
            get
            {
                if (root == null) root = Build();
                return root;
            }
        }

        /// <summary>Дерево строится заново, когда меняется язык интерфейса.</summary>
        public static void Reset()
        {
            root = null;
        }

        private static Node Build()
        {
            Node tree = Word(string.Empty, string.Empty);

            // ---------- пакеты ----------
            Node apt = Word("apt", T("tree.apt"));
            apt.Add(Word("list", T("tree.aptList")));
            apt.Add(Word("info", T("tree.aptInfo")).Add(Arg(T("arg.package"), "", InstalledNames)));
            apt.Add(Word("install", T("tree.aptInstall")).Add(Arg(T("arg.packageOrFile"), "", CatalogNames)));
            apt.Add(Word("update", T("tree.aptUpdate")).Add(Optional(T("arg.package"), "")));
            apt.Add(Word("remove", T("tree.aptRemove")).Add(Arg(T("arg.package"), "", InstalledNames)));
            apt.Add(Word("protect", T("tree.aptProtect")).Add(Arg(T("arg.package"), "", InstalledNames)));
            apt.Add(Word("unprotect", T("tree.aptUnprotect")).Add(Arg(T("arg.package"), "", InstalledNames)));
            tree.Add(apt);

            // ---------- каталог ----------
            Node store = Word("store", T("tree.store"));
            store.Add(Word("list", T("tree.storeList")));
            store.Add(Word("refresh", T("tree.storeRefresh")));
            Node storeInstall = Word("install", T("tree.storeInstall"));
            storeInstall.Add(Word("apps.all", T("tree.storeAll")));
            storeInstall.Add(Arg(T("arg.package"), "", CatalogNames));
            store.Add(storeInstall);
            store.Add(Word("open", T("tree.storeOpen")));
            tree.Add(store);

            // ---------- сеть ----------
            Node wifi = Word("wifi", T("tree.wifi"));
            wifi.Add(Word("list", T("tree.wifiList")));
            wifi.Add(Word("status", T("tree.wifiStatus")));
            wifi.Add(Word("form", T("tree.wifiForm")));
            wifi.Add(Word("portal", T("tree.wifiPortal")));
            wifi.Add(Word("disconnect", T("tree.wifiDisconnect")));
            wifi.Add(Word("connect", T("tree.wifiConnect"))
                .Add(Arg(T("arg.network"), "", NetworkNames).Add(Optional(T("arg.password"), ""))));
            wifi.Add(Word("forget", T("tree.wifiForget")).Add(Arg(T("arg.network"), "", SavedNetworks)));
            tree.Add(wifi);

            Node version = Word("ver", T("tree.verList"));
            version.Add(Word("list", T("tree.verList")));
            tree.Add(version);

            // ---------- сборка пакетов и мастер ----------
            Node pack = Word("pack", T("tree.pack"));
            pack.Add(Arg(T("arg.folder"), ""));
            tree.Add(pack);

            Node setup = Word("setup", T("tree.setup"));
            setup.Add(Word("reset", T("tree.setupReset")));
            setup.Add(Word("status", T("tree.setupStatus")));
            tree.Add(setup);

            // ---------- загрузки и компоненты ----------
            Node download = Word("download", T("tree.download"));
            download.Add(Word("list", T("tree.downloadList")));
            download.Add(Word("history", T("tree.downloadHistory")));
            download.Add(Word("cancel", T("tree.downloadCancel")));
            download.Add(Word("clear", T("tree.downloadClear")));
            download.Add(Arg(T("arg.url"), ""));
            tree.Add(download);

            Node lib = Word("lib", T("tree.lib"));
            lib.Add(Word("list", T("tree.libList")));
            lib.Add(Word("check", T("tree.libCheck")));
            lib.Add(Word("update", T("tree.libUpdate")));
            lib.Add(Word("info", T("tree.libInfo")).Add(Arg(T("arg.component"), "", ComponentNames)));
            lib.Add(Word("install", T("tree.libInstall")).Add(Arg(T("arg.component"), "", ComponentNames)));
            lib.Add(Word("remove", T("tree.libRemove")).Add(Arg(T("arg.component"), "", ComponentNames)));
            lib.Add(Word("path", T("tree.libPath")).Add(Arg(T("arg.component"), "", ComponentNames)));
            lib.Add(Word("auto", T("tree.libAuto")).Add(Arg("on|off", "")));
            tree.Add(lib);

            Node update = Word("update", T("tree.update"));
            update.Add(Word("status", T("tree.updateStatus")));
            update.Add(Word("check", T("tree.updateCheck")));
            update.Add(Word("download", T("tree.updateDownload")));
            update.Add(Word("install", T("tree.updateInstall")));
            tree.Add(update);


            // ---------- язык ----------
            Node lang = Word("lang", T("tree.lang"));
            lang.Add(Word("list", T("tree.langList")));
            lang.Add(Word("reload", T("tree.langReload")));
            lang.Add(Word("export", T("tree.langExport")).Add(Arg(T("arg.langCode"), "")));
            foreach (string code in LanguageCodes()) lang.Add(Word(code, T("tree.langSwitch")));
            tree.Add(lang);

            // ---------- права ----------
            Node perm = Word("perm", T("tree.perm"));
            perm.Add(Word("list", T("tree.permList")));
            perm.Add(Word("all", T("tree.permAll")));
            perm.Add(Word("app", T("tree.permApp")).Add(Arg(T("arg.application"), "", ApplicationNames)));
            perm.Add(Word("grant", T("tree.permGrant"))
                .Add(Arg(T("arg.application"), "", ApplicationNames).Add(Arg(T("arg.right"), "", RightNames))));
            perm.Add(Word("revoke", T("tree.permRevoke"))
                .Add(Arg(T("arg.application"), "", ApplicationNames).Add(Arg(T("arg.right"), "", RightNames))));
            perm.Add(Word("reset", T("tree.permReset")).Add(Arg(T("arg.application"), "", ApplicationNames)));
            tree.Add(perm);

            // ---------- службы ----------
            Node systemctl = Word("systemctl", T("tree.systemctl"));
            foreach (string action in new[] { "list", "status", "start", "stop", "restart", "enable", "disable" })
                systemctl.Add(Word(action, T("tree.systemctl." + action))
                    .Add(Optional(T("arg.service"), "")));
            tree.Add(systemctl);

            // ---------- фоновые службы ----------
            Node daemon = Word("daemon", T("tree.daemon"));
            daemon.Add(Word("list", T("tree.daemonList")));
            foreach (string action in new[] { "status", "start", "stop", "restart", "run", "enable", "disable" })
                daemon.Add(Word(action, T("tree.daemon." + action))
                    .Add(Arg(T("arg.daemon"), "", DaemonNames)));
            daemon.Add(Word("stop-all", T("tree.daemonStopAll")));
            tree.Add(daemon);

            // ---------- настройки сервера ----------
            Node conf = Word("conf", T("tree.conf"));
            conf.Add(Word("test", T("tree.confTest")));
            conf.Add(Word("show", T("tree.confShow")));
            conf.Add(Word("reload", T("tree.confReload")));
            conf.Add(Word("sample", T("tree.confSample")));
            conf.Add(Word("path", T("tree.confPath")));
            tree.Add(conf);

            // ---------- PHP ----------
            Node php = Word("php-frm", T("tree.php"));
            php.Add(Word("status", T("tree.phpStatus")));
            php.Add(Word("download", T("tree.phpDownload")));
            php.Add(Word("update", T("tree.phpUpdate")));
            php.Add(Word("remove", T("tree.phpRemove")));
            php.Add(Word("mirrors", T("tree.phpMirrors")));
            php.Add(Word("auto", T("tree.phpAuto"))
                .Add(Word("on", "")).Add(Word("off", "")));
            php.Add(Word("use", T("tree.phpUse"))
                .Add(Word("builtin", T("tree.phpUseBuiltIn")))
                .Add(Word("own", T("tree.phpUseOwn")))
                .Add(Word("system", T("tree.phpUseSystem"))));
            tree.Add(php);

            // ---------- системный порт ----------
            Node system = Word("system", T("tree.system"));
            system.Add(Word("start", T("tree.systemStart")));
            system.Add(Word("stop", T("tree.systemStop")));
            system.Add(Word("status", T("tree.systemStatus")));
            system.Add(Word("open", T("tree.systemOpen")));
            tree.Add(system);

            // ---------- брандмауэр ----------
            Node ufw = Word("ufw", T("tree.ufw"));
            ufw.Add(Word("enable", T("tree.ufwEnable")));
            ufw.Add(Word("disable", T("tree.ufwDisable")));
            ufw.Add(Word("status", T("tree.ufwStatus")));
            ufw.Add(Word("port", T("tree.ufwPort"))
                .Add(Arg(T("arg.port"), "")
                    .Add(Word("enable", T("tree.ufwOpen")))
                    .Add(Word("disable", T("tree.ufwClose")))));
            tree.Add(ufw);

            // ---------- файлы ----------
            tree.Add(Word("cd", T("tree.cd")).Add(Arg(T("arg.folder"), "", Folders)));
            tree.Add(Word("ls", T("tree.ls")).Add(Optional(T("arg.folder"), "")));
            tree.Add(Word("cat", T("tree.cat")).Add(Arg(T("arg.file"), "", Files)));
            tree.Add(Word("head", T("tree.head")).Add(Arg(T("arg.file"), "", Files)));
            tree.Add(Word("tail", T("tree.tail"))
                .Add(Arg(T("arg.file"), "", Files).Add(Optional(T("arg.lines"), ""))));
            tree.Add(Word("sort", T("tree.sort")).Add(Arg(T("arg.file"), "", Files)
                .Add(Word("-r", T("tree.sortReverse"))).Add(Word("-n", T("tree.sortNumeric")))));
            tree.Add(Word("uniq", T("tree.uniq")).Add(Arg(T("arg.file"), "", Files)
                .Add(Word("-c", T("tree.uniqCount")))));
            tree.Add(Word("diff", T("tree.diff"))
                .Add(Arg(T("arg.file"), "", Files).Add(Arg(T("arg.file"), "", Files))));
            tree.Add(Word("hash", T("tree.hash")).Add(Arg(T("arg.file"), "", Files)
                .Add(Word("md5", "")).Add(Word("sha1", "")).Add(Word("sha256", "")).Add(Word("sha512", ""))));
            tree.Add(Word("base64", T("tree.base64"))
                .Add(Word("encode", T("tree.base64Encode")).Add(Arg(T("arg.textOrFile"), "")))
                .Add(Word("decode", T("tree.base64Decode")).Add(Arg(T("arg.textOrFile"), ""))));
            tree.Add(Word("zip", T("tree.zip"))
                .Add(Arg(T("arg.archive"), "").Add(Arg(T("arg.path"), "", Entries))));
            tree.Add(Word("unzip", T("tree.unzip"))
                .Add(Arg(T("arg.archive"), "", Files).Add(Optional(T("arg.folder"), ""))));
            tree.Add(Word("rm", T("tree.rm")).Add(Arg(T("arg.file"), "", Entries)));
            tree.Add(Word("mkdir", T("tree.mkdir")).Add(Arg(T("arg.folder"), "")));
            tree.Add(Word("cp", T("tree.cp")).Add(Arg(T("arg.from"), "", Entries).Add(Arg(T("arg.to"), ""))));
            tree.Add(Word("mv", T("tree.mv")).Add(Arg(T("arg.from"), "", Entries).Add(Arg(T("arg.to"), ""))));
            tree.Add(Word("grep", T("tree.grep")).Add(Arg(T("arg.text"), "").Add(Arg(T("arg.file"), "", Files))));
            tree.Add(Word("curl", T("tree.curl")).Add(Arg(T("arg.url"), "").Add(Optional(T("arg.file"), ""))));
            tree.Add(Word("which", T("tree.which")).Add(Arg(T("arg.command"), "", CommandNames)));
            tree.Add(Word("env", T("tree.env")).Add(Optional(T("arg.filter"), "")));
            tree.Add(Word("calc", T("tree.calc")).Add(Arg(T("arg.expression"), "")));
            tree.Add(Word("echo", T("tree.echo")).Add(Arg(T("arg.text"), "")));
            tree.Add(Word("webview", T("tree.webview")).Add(Arg(T("arg.urlOrQuery"), "")));
            tree.Add(Word("layout", T("tree.layout")).Add(Optional(T("arg.layout"), "")));
            tree.Add(Word("kill", T("tree.kill")).Add(Arg(T("arg.application"), "", RunningApps)));
            tree.Add(Word("alias", T("tree.alias")).Add(Arg(T("arg.name"), "").Add(Arg(T("arg.command"), ""))));
            tree.Add(Word("unalias", T("tree.unalias")).Add(Arg(T("arg.name"), "")));

            // ---------- пользователи, ssh, типы пакетов ----------
            tree.Add(Word("user", T("tree.user"))
                .Add(Word("create", T("tree.userCreate"))
                    .Add(Arg(T("arg.user"), "").Add(Arg(T("arg.password"), ""))))
                .Add(Word("remove", T("tree.userRemove")).Add(Arg(T("arg.user"), "", UserNames)))
                .Add(Word("edit", T("tree.userEdit"))
                    .Add(Arg(T("arg.user"), "", UserNames).Add(Arg(T("arg.password"), ""))))
                .Add(Word("enable", "").Add(Arg(T("arg.user"), "", UserNames)))
                .Add(Word("disable", "").Add(Arg(T("arg.user"), "", UserNames)))
                .Add(Word("list", T("tree.userList")))
                .Add(Word("current", T("tree.userCurrent"))
                    .Add(Word("set", "").Add(Arg(T("arg.user"), "", UserNames))))
                .Add(Word("limit", T("tree.userLimit"))
                    .Add(Arg(T("arg.user"), "", UserNames)
                        .Add(Word("add", "").Add(Arg(T("arg.area"), "", AreaNames)))
                        .Add(Word("remove", "").Add(Arg(T("arg.area"), "", AreaNames)))
                        .Add(Word("clear", ""))))
                .Add(Word("areas", T("tree.userAreas")))
                .Add(Word("password", T("tree.userPassword"))));

            tree.Add(Word("ssh", T("tree.ssh"))
                .Add(Word("start", T("tree.sshStart")).Add(Optional(T("arg.port"), "")))
                .Add(Word("stop", T("tree.sshStop")))
                .Add(Word("status", T("tree.sshStatus")))
                .Add(Word("who", T("tree.sshWho")))
                .Add(Word("help", T("tree.sshHelp")))
                .Add(Word("log", "")));

            tree.Add(Word("types", T("tree.types")));
            tree.Add(Word("superuser", T("tree.superuser")));

            // ---------- без аргументов ----------
            foreach (string simple in new[]
            {
                "help", "ver", "whoami", "hostname", "uptime", "date", "clear", "banner",
                "pwd", "tree", "apps", "services", "ps", "sysinfo", "df", "free",
                "restart", "exit", "history", "su", "sudo", "regedit", "notify", "wc", "stat", "du", "find", "touch"
            })
                if (Find(tree, simple) == null) tree.Add(Word(simple, CommandExecutorEngine.DescribeCommand(simple)));

            return tree;
        }

        private static string T(string key)
        {
            string value = LisunLocale.T(key);
            return value == key ? string.Empty : value;
        }

        // =====================================================================
        //  Источники значений
        // =====================================================================

        private static List<string> AreaNames()
        {
            return new List<string>(LisunUsers.Tokens);
        }

        private static List<string> UserNames()
        {
            try { return LisunUsers.Names(); }
            catch { return new List<string>(); }
        }

        private static List<string> InstalledNames()
        {
            List<string> result = new List<string>();

            foreach (string directory in LisunOSInstallerShell.InstalledPackageDirectories())
            {
                LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);
                if (manifest != null && manifest.Name.Length > 0) result.Add(manifest.Name);
            }

            result.Add(LisunPhpModule.PackageName);
            return result;
        }

        private static List<string> CatalogNames()
        {
            List<string> result = new List<string>();
            foreach (LisunStore.StoreItem item in LisunStore.Items()) result.Add(item.Name);

            return result;
        }

        private static List<string> NetworkNames()
        {
            List<string> result = new List<string>();

            try
            {
                foreach (WifiNetwork network in LisunWifi.Scan())
                    result.Add(network.Ssid.IndexOf(' ') >= 0 ? "\"" + network.Ssid + "\"" : network.Ssid);
            }
            catch { }

            return result;
        }

        /// <summary>Имена компонентов для подсказки: php, docs, apps, system…</summary>
        private static List<string> ComponentNames()
        {
            List<string> result = new List<string>();

            try
            {
                foreach (LisunComponent component in LisunLibraries.Items())
                    result.Add(component.Name);
            }
            catch { }

            return result;
        }

        private static List<string> SavedNetworks()
        {
            try { return LisunWifi.SavedProfiles(); }
            catch { return new List<string>(); }
        }

        private static List<string> LanguageCodes()
        {
            List<string> result = new List<string>();

            try
            {
                foreach (LisunLocale.LanguagePack pack in LisunLocale.Available()) result.Add(pack.Code);
            }
            catch { }

            return result;
        }

        private static List<string> ApplicationNames()
        {
            List<string> result = InstalledNames();

            foreach (string granted in LisunPermissions.ApplicationsWithGrants())
                if (!result.Contains(granted)) result.Add(granted);

            return result;
        }

        private static List<string> RightNames()
        {
            return new List<string>(LisunPermissions.Known);
        }

        private static List<string> DaemonNames()
        {
            return LisunDaemons.Names();
        }

        private static List<string> RunningApps()
        {
            List<string> result = new List<string>();

            foreach (KeyValuePair<string, DynamicApp> item in FormEngine.ActiveApps) result.Add(item.Key);
            return result;
        }

        private static List<string> CommandNames()
        {
            return new List<string>(CommandExecutorEngine.KnownCommands);
        }

        private static List<string> Entries() { return Listing(true, true); }
        private static List<string> Files() { return Listing(true, false); }
        private static List<string> Folders() { return Listing(false, true); }

        private static List<string> Listing(bool files, bool folders)
        {
            List<string> result = new List<string>();

            try
            {
                string current = CommandExecutorEngine.CurrentDirectory;

                if (folders)
                    foreach (string directory in System.IO.Directory.GetDirectories(current))
                        result.Add(System.IO.Path.GetFileName(directory) + "/");

                if (files)
                    foreach (string file in System.IO.Directory.GetFiles(current))
                        result.Add(System.IO.Path.GetFileName(file));
            }
            catch { }

            if (result.Count > 60) result.RemoveRange(60, result.Count - 60);
            return result;
        }

        // =====================================================================
        //  Подсказка по строке ввода
        // =====================================================================

        private static Node Find(Node parent, string name)
        {
            foreach (Node child in parent.Children)
                if (!child.IsArgument && child.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return child;

            return null;
        }

        /// <summary>
        /// Разбирает набранную строку и говорит, что показать:
        /// список вариантов, сверку аргумента и строку использования.
        /// </summary>
        public static Hint Suggest(string input)
        {
            Hint hint = new Hint();
            if (input == null) input = string.Empty;

            bool trailingSpace = input.Length > 0 && input.EndsWith(" ");

            string[] words = input.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // Слово, которое сейчас набирается; при пробеле в конце — новое, пустое.
            string typing = trailingSpace || words.Length == 0 ? string.Empty : words[words.Length - 1];
            int consumed = trailingSpace ? words.Length : Math.Max(0, words.Length - 1);

            hint.Prefix = typing;

            // Идём по дереву настолько, насколько хватает введённых слов.
            Node node = Root;
            List<string> path = new List<string>();

            for (int index = 0; index < consumed; index++)
            {
                Node next = Find(node, words[index]);

                if (next == null)
                {
                    // Слово не из списка — значит это значение аргумента.
                    Node argument = FirstArgument(node);
                    if (argument == null)
                    {
                        hint.Usage = BuildUsage(path, node);
                        return hint;
                    }

                    node = argument;
                    path.Add(argument.Label);
                    continue;
                }

                node = next;
                path.Add(next.Name);
            }

            hint.Usage = BuildUsage(path, node);

            // Варианты: сначала субкоманды, затем значения аргумента.
            foreach (Node child in node.Children)
            {
                if (child.IsArgument)
                {
                    if (hint.Placeholder.Length == 0) hint.Placeholder = child.Label;

                    if (child.Values == null) continue;

                    List<string> values;
                    try { values = child.Values(); }
                    catch { continue; }

                    foreach (string value in values)
                    {
                        if (value.Length == 0) continue;
                        if (typing.Length > 0 &&
                            value.IndexOf(typing, StringComparison.OrdinalIgnoreCase) != 0) continue;

                        hint.Items.Add(value);
                        hint.Descriptions.Add(child.Description.Length > 0 ? child.Description : child.Label);
                    }

                    continue;
                }

                if (typing.Length > 0 &&
                    child.Name.IndexOf(typing, StringComparison.OrdinalIgnoreCase) != 0) continue;

                hint.Items.Add(child.Name);
                hint.Descriptions.Add(child.Description);
            }

            return hint;
        }

        private static Node FirstArgument(Node parent)
        {
            foreach (Node child in parent.Children)
                if (child.IsArgument) return child;

            return null;
        }

        /// <summary>Строка использования: wifi connect &lt;сеть&gt; [пароль].</summary>
        private static string BuildUsage(List<string> path, Node node)
        {
            StringBuilder sb = new StringBuilder();

            foreach (string piece in path)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(piece);
            }

            List<string> words = new List<string>();
            List<string> arguments = new List<string>();

            foreach (Node child in node.Children)
            {
                if (child.IsArgument) arguments.Add(child.Optional ? "[" + child.Name + "]" : child.Label);
                else words.Add(child.Name);
            }

            if (words.Count > 0)
            {
                if (sb.Length > 0) sb.Append(' ');

                if (words.Count <= 6) sb.Append(string.Join(" | ", words.ToArray()));
                else sb.Append(string.Join(" | ", words.GetRange(0, 6).ToArray())).Append(" | …");
            }

            foreach (string argument in arguments)
            {
                if (sb.Length > 0) sb.Append(' ');
                sb.Append(argument);
            }

            return sb.ToString();
        }
    }
}
