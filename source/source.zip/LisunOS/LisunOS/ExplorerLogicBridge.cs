﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика графического проводника LisunOS.
    /// Раньше этот класс отсутствовал, хотя FormEngine его создавал — проект не компилировался.
    /// Теперь он реально управляет формой, собранной из designer-файла сервиса.
    /// </summary>
    public class ExplorerLogicBridge
    {
        private readonly DynamicFormContext context;
        private readonly Form form;

        private readonly ListView filesView;
        private readonly TreeView dirTree;
        private readonly TextBox addressBar;
        private readonly Button backButton;
        private readonly Button upButton;

        private ToolStripMenuItem renameItem;
        private ToolStripMenuItem refreshItem;

        private readonly Stack<string> history = new Stack<string>();
        private readonly string rootPath;
        private readonly string packageName;
        private string currentPath;

        public ExplorerLogicBridge(DynamicFormContext context)
        {
            this.context = context;
            form = context.Form;

            filesView = context.Get<ListView>("lstFilesView");
            dirTree = context.Get<TreeView>("treeDirNodes");
            addressBar = context.Get<TextBox>("txtAddressBar");
            backButton = context.Get<Button>("btnBack");
            upButton = context.Get<Button>("btnUp");

            packageName = context.PackageName;
            rootPath = LisunEngine.RootPath;
            if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
            currentPath = rootPath;
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("explorer.title");
                form.KeyPreview = true;
                form.KeyDown += Form_KeyDown;

                // Проводник переводится на лету вместе с языком системы.
                LisunLocale.LanguageChanged += ApplyLanguage;
                form.Disposed += (s, e) => LisunLocale.LanguageChanged -= ApplyLanguage;
            }

            SetupFilesView();
            ExtendContextMenu();
            InitTree();
            LoadDirectory(currentPath);
        }

        // ---------- подготовка интерфейса ----------

        private void SetupFilesView()
        {
            if (filesView == null) return;

            filesView.View = View.Details;
            filesView.FullRowSelect = true;
            filesView.HideSelection = false;
            filesView.MultiSelect = false;
            filesView.BorderStyle = BorderStyle.None;
            filesView.Font = Theme.Ui(9.5f);
            filesView.BackColor = Theme.Surface;
            filesView.ForeColor = Theme.Text;

            if (filesView.Columns.Count == 0)
            {
                filesView.Columns.Add(LisunLocale.T("explorer.colName"), 260);
                filesView.Columns.Add(LisunLocale.T("explorer.colType"), 110);
                filesView.Columns.Add(LisunLocale.T("explorer.colSize"), 90, HorizontalAlignment.Right);
                filesView.Columns.Add(LisunLocale.T("explorer.colDate"), 140);
            }

            ImageList icons = new ImageList();
            icons.ImageSize = new Size(16, 16);
            icons.ColorDepth = ColorDepth.Depth32Bit;
            icons.Images.Add("folder", DrawFolderIcon());
            icons.Images.Add("file", DrawFileIcon());

            filesView.SmallImageList = icons;
            filesView.LargeImageList = icons;

            if (dirTree != null)
            {
                dirTree.ImageList = icons;
                dirTree.Font = Theme.Ui(9.5f);
                dirTree.BackColor = Theme.Surface;
                dirTree.ForeColor = Theme.Text;
                dirTree.BorderStyle = BorderStyle.None;
                dirTree.ShowLines = true;
                dirTree.LineColor = Theme.Border;
            }

            if (addressBar != null)
            {
                addressBar.ReadOnly = true;
                addressBar.BorderStyle = BorderStyle.FixedSingle;
                addressBar.BackColor = Theme.Background;
                addressBar.ForeColor = Theme.TextDim;
                addressBar.Font = Theme.Mono(9.5f);
            }
        }

        private void ExtendContextMenu()
        {
            if (filesView == null || filesView.ContextMenuStrip == null) return;

            ContextMenuStrip menu = filesView.ContextMenuStrip;

            menu.Items.Add(new ToolStripSeparator());

            renameItem = new ToolStripMenuItem(LisunLocale.T("explorer.rename"));
            renameItem.Click += (s, e) => RenameSelected();
            menu.Items.Add(renameItem);

            refreshItem = new ToolStripMenuItem(LisunLocale.T("explorer.refresh"));
            refreshItem.Click += (s, e) => LoadDirectory(currentPath);
            menu.Items.Add(refreshItem);

            Theme.HarmonizeStrip(menu);
        }

        private static Bitmap DrawFolderIcon()
        {
            Bitmap bitmap = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                using (SolidBrush tab = new SolidBrush(Color.FromArgb(214, 164, 68)))
                    g.FillRectangle(tab, 1, 3, 6, 3);

                using (LinearGradientBrush body = new LinearGradientBrush(
                    new Rectangle(1, 5, 14, 9),
                    Color.FromArgb(240, 193, 86), Color.FromArgb(206, 150, 46), 90f))
                    g.FillRectangle(body, 1, 5, 14, 9);
            }
            return bitmap;
        }

        private static Bitmap DrawFileIcon()
        {
            Bitmap bitmap = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                using (SolidBrush sheet = new SolidBrush(Color.FromArgb(222, 229, 238)))
                    g.FillRectangle(sheet, 3, 1, 10, 14);

                using (Pen edge = new Pen(Color.FromArgb(150, 160, 175)))
                    g.DrawRectangle(edge, 3, 1, 10, 14);

                using (Pen line = new Pen(Color.FromArgb(120, 132, 150)))
                {
                    g.DrawLine(line, 5, 5, 11, 5);
                    g.DrawLine(line, 5, 8, 11, 8);
                    g.DrawLine(line, 5, 11, 9, 11);
                }
            }
            return bitmap;
        }

        // ---------- навигация ----------

        private void InitTree()
        {
            if (dirTree == null) return;

            dirTree.Nodes.Clear();
            TreeNode root = new TreeNode("LisunOS (C:)");
            root.Tag = rootPath;
            root.ImageKey = "folder";
            root.SelectedImageKey = "folder";

            dirTree.Nodes.Add(root);
            FillTreeNode(root);
            root.Expand();
        }

        private void FillTreeNode(TreeNode parent)
        {
            if (parent == null || parent.Tag == null) return;

            try
            {
                parent.Nodes.Clear();
                foreach (string dir in Directory.GetDirectories(parent.Tag.ToString()))
                {
                    TreeNode node = new TreeNode(Path.GetFileName(dir));
                    node.Tag = dir;
                    node.ImageKey = "folder";
                    node.SelectedImageKey = "folder";

                    try
                    {
                        if (Directory.GetDirectories(dir).Length > 0) node.Nodes.Add(new TreeNode("..."));
                    }
                    catch { }

                    parent.Nodes.Add(node);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Explorer] [ОШИБКА] Чтение дерева: " + ex.Message);
            }
        }

        private void LoadDirectory(string path)
        {
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;

            // Просмотр содержимого требует права read_files.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles))
            {
                if (filesView != null) filesView.Items.Clear();
                if (addressBar != null) addressBar.Text = LisunLocale.T("perm.denied", packageName, LisunPermissions.ReadFiles).Trim();
                return;
            }

            currentPath = path;

            if (addressBar != null) addressBar.Text = CustomFormUtils.ToVirtualPath(path);
            if (backButton != null) backButton.Enabled = history.Count > 0;
            if (upButton != null) upButton.Enabled = !IsRoot(path);
            if (filesView == null) return;

            filesView.BeginUpdate();
            try
            {
                filesView.Items.Clear();

                List<string> folders;
                List<string> files = CustomFormUtils.GetDirectoryContent(path, out folders);

                foreach (string folder in folders)
                {
                    string full = Path.Combine(path, folder);
                    ListViewItem item = new ListViewItem(folder, "folder");
                    item.Tag = full;
                    item.SubItems.Add(LisunLocale.T("explorer.folder"));
                    item.SubItems.Add("");
                    item.SubItems.Add(SafeWriteTime(full, true));
                    item.ForeColor = Theme.Text;
                    filesView.Items.Add(item);
                }

                foreach (string file in files)
                {
                    string full = Path.Combine(path, file);
                    long size = 0;
                    try { size = new FileInfo(full).Length; }
                    catch { }

                    string extension = Path.GetExtension(file);
                    ListViewItem item = new ListViewItem(file, "file");
                    item.Tag = full;
                    item.SubItems.Add(string.IsNullOrEmpty(extension)
                        ? LisunLocale.T("explorer.file")
                        : LisunLocale.T("explorer.fileExt", extension.TrimStart('.').ToUpper()));
                    item.SubItems.Add(CustomFormUtils.FormatSize(size));
                    item.SubItems.Add(SafeWriteTime(full, false));
                    item.ForeColor = Theme.TextDim;
                    filesView.Items.Add(item);
                }
            }
            finally
            {
                filesView.EndUpdate();
            }
        }

        private static string SafeWriteTime(string path, bool directory)
        {
            try
            {
                DateTime time = directory ? Directory.GetLastWriteTime(path) : File.GetLastWriteTime(path);
                return time.ToString("dd.MM.yyyy HH:mm");
            }
            catch { return ""; }
        }

        private bool IsRoot(string path)
        {
            return string.Equals(
                path.TrimEnd(Path.DirectorySeparatorChar),
                rootPath.TrimEnd(Path.DirectorySeparatorChar),
                StringComparison.OrdinalIgnoreCase);
        }

        private void NavigateTo(string path)
        {
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;
            if (string.Equals(path, currentPath, StringComparison.OrdinalIgnoreCase)) return;

            history.Push(currentPath);
            LoadDirectory(path);
        }

        // ---------- обработчики из designer-файла ----------

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (history.Count == 0) return;
            LoadDirectory(history.Pop());
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (IsRoot(currentPath)) return;

            DirectoryInfo parent = Directory.GetParent(currentPath);
            if (parent != null) NavigateTo(parent.FullName);
        }

        private void lstFilesView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OpenSelected();
        }

        private void treeDirNodes_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (e.Node != null && e.Node.Tag != null) FillTreeNode(e.Node);
        }

        private void treeDirNodes_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node != null && e.Node.Tag != null) NavigateTo(e.Node.Tag.ToString());
        }

        private void ctxCreateFile_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("explorer.titleFile"),
                LisunLocale.T("explorer.newFile"), "NewFile.txt", form);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (File.Exists(target))
            {
                MessageBox.Show(LisunLocale.T("explorer.exists"), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            CustomFormUtils.WriteFileText(target, "");
            LoadDirectory(currentPath);
        }

        private void ctxCreateFolder_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("explorer.titleDir"),
                LisunLocale.T("explorer.newFolder"), "NewFolder", form);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (Directory.Exists(target))
            {
                MessageBox.Show(LisunLocale.T("explorer.exists"), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            CustomFormUtils.CreateFolder(target);
            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }

        private void ctxDelete_Click(object sender, EventArgs e)
        {
            DeleteSelected();
        }

        // ---------- действия ----------

        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5) { LoadDirectory(currentPath); e.Handled = true; }
            else if (e.KeyCode == Keys.Back) { btnUp_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.KeyCode == Keys.Delete) { DeleteSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.F2) { RenameSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.Enter && filesView != null && filesView.Focused) { OpenSelected(); e.Handled = true; }
        }

        private string SelectedPath()
        {
            if (filesView == null || filesView.SelectedItems.Count == 0) return null;
            object tag = filesView.SelectedItems[0].Tag;
            return tag == null ? null : tag.ToString();
        }

        private void OpenSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (Directory.Exists(target))
            {
                NavigateTo(target);
                return;
            }
            if (File.Exists(target))
            {
                if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;
                ShowFileViewer(target);
            }
        }

        private void DeleteSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageFiles)) return;

            // Удаление запрещают только блоки NOREMOVE; CANTEDIT не мешает.
            if (File.Exists(target) && LisunApiEndpoint.FileBlocksDeletion(target))
            {
                MessageBox.Show(LisunLocale.T("api.fileProtected", Path.GetFileName(target)),
                    LisunLocale.T("explorer.title"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult confirm = MessageBox.Show(
                LisunLocale.T("explorer.confirm", Path.GetFileName(target)),
                LisunLocale.T("explorer.title"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            if (Directory.Exists(target)) CustomFormUtils.DeleteFolder(target);
            else CustomFormUtils.DeleteFile(target);

            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }

        private void RenameSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

            string oldName = Path.GetFileName(target);
            string newName = CustomFormUtils.Prompt(LisunLocale.T("explorer.rename"),
                LisunLocale.T("explorer.newName"), oldName, form);
            if (string.IsNullOrEmpty(newName) || newName == oldName) return;

            string destination = Path.Combine(currentPath, newName);
            try
            {
                if (Directory.Exists(target)) Directory.Move(target, destination);
                else File.Move(target, destination);
            }
            catch (Exception ex)
            {
                MessageBox.Show(LisunLocale.T("explorer.renameErr", ex.Message), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }

        /// <summary>Перевод интерфейса проводника при смене языка системы.</summary>
        private void ApplyLanguage()
        {
            if (form == null || form.IsDisposed) return;

            form.Text = LisunLocale.T("explorer.title");

            if (filesView != null && filesView.Columns.Count >= 4)
            {
                filesView.Columns[0].Text = LisunLocale.T("explorer.colName");
                filesView.Columns[1].Text = LisunLocale.T("explorer.colType");
                filesView.Columns[2].Text = LisunLocale.T("explorer.colSize");
                filesView.Columns[3].Text = LisunLocale.T("explorer.colDate");
            }

            if (renameItem != null) renameItem.Text = LisunLocale.T("explorer.rename");
            if (refreshItem != null) refreshItem.Text = LisunLocale.T("explorer.refresh");

            LoadDirectory(currentPath);
        }

        private void RefreshTreeBranch()
        {
            if (dirTree == null || dirTree.Nodes.Count == 0) return;
            FillTreeNode(dirTree.Nodes[0]);
            dirTree.Nodes[0].Expand();
        }

        /// <summary>
        /// Редактор файла: править можно любой файл, но текст внутри блоков
        /// ~~~CANTEDIT~ ... ~CANTEDIT~~~ и ~~~NOREMOVE~ ... ~NOREMOVE~~~ остаётся как есть.
        /// </summary>
        private void ShowFileViewer(string path)
        {
            string original = LisunCrypto.ReadAllText(path);

            using (Form editor = new Form())
            {
                editor.Text = LisunLocale.T("fm.editing", Path.GetFileName(path));
                editor.ClientSize = new Size(860, 640);
                editor.MinimumSize = new Size(560, 420);
                editor.StartPosition = FormStartPosition.CenterParent;
                editor.BackColor = Theme.Background;
                editor.ForeColor = Theme.Text;
                editor.Font = Theme.Ui(9.5f);

                TextBox box = new TextBox();
                box.Multiline = true;
                box.AcceptsTab = true;
                box.WordWrap = false;
                box.ScrollBars = ScrollBars.Both;
                box.Dock = DockStyle.Fill;
                box.BackColor = Theme.Surface;
                box.ForeColor = Theme.Text;
                box.BorderStyle = BorderStyle.None;
                box.Font = Theme.Mono(10.5f);
                box.Text = original;

                Panel padding = new Panel();
                padding.Dock = DockStyle.Fill;
                padding.Padding = new Padding(14);
                padding.BackColor = Theme.Background;
                padding.Controls.Add(box);

                Panel bar = new Panel();
                bar.Dock = DockStyle.Bottom;
                bar.Height = 58;
                bar.BackColor = Theme.Surface;
                bar.Padding = new Padding(14, 12, 14, 12);

                string protection = LisunApiEndpoint.DescribeProtection(original);

                Label info = new Label();
                info.Dock = DockStyle.Left;
                info.Width = 470;
                info.Font = Theme.Mono(9f);
                info.TextAlign = ContentAlignment.MiddleLeft;
                info.ForeColor = protection.Length > 0 ? Theme.Warning : Theme.TextDim;
                info.Text = protection.Length > 0
                    ? protection
                    : CustomFormUtils.ToVirtualPath(path);

                Button cancel = new Button();
                cancel.Text = LisunLocale.T("dialog.cancel");
                cancel.Dock = DockStyle.Right;
                cancel.Width = 120;
                cancel.DialogResult = DialogResult.Cancel;
                Theme.StyleButton(cancel, Theme.SurfaceAlt, Theme.Text);

                Button save = new Button();
                save.Text = LisunLocale.T("fm.save");
                save.Dock = DockStyle.Right;
                save.Width = 130;
                save.DialogResult = DialogResult.OK;
                Theme.StyleButton(save, Theme.AccentDeep, Theme.Text);

                bar.Controls.Add(cancel);
                bar.Controls.Add(save);
                bar.Controls.Add(info);

                editor.Controls.Add(padding);
                editor.Controls.Add(bar);
                editor.CancelButton = cancel;

                DialogResult outcome = form != null ? editor.ShowDialog(form) : editor.ShowDialog();
                if (outcome != DialogResult.OK) return;

                if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

                string text = box.Text;
                string error;

                if (!LisunApiEndpoint.ValidateEdit(original, text, out error))
                {
                    DialogResult answer = MessageBox.Show(
                        error + Environment.NewLine + Environment.NewLine + LisunLocale.T("api.restoreAsk"),
                        LisunLocale.T("explorer.title"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (answer != DialogResult.Yes) return;
                    text = LisunApiEndpoint.RestoreBlocks(original, text);
                }

                if (!CustomFormUtils.WriteFileText(path, text))
                {
                    MessageBox.Show(LisunLocale.T("fm.saveFailed"), LisunLocale.T("explorer.title"),
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                LisunEngine.Log("[Explorer] Сохранён " + CustomFormUtils.ToVirtualPath(path));
                LoadDirectory(currentPath);
            }
        }
    }
}
