﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика графического проводника LisunOS.
    /// Раньше этот класс отсутствовал, хотя FormEngine его создавал — проект не компилировался.
    /// Теперь он реально управляет формой, собранной из designer-файла сервиса.
    /// </summary>
    public class ExplorerLogicBridge
    {
        private readonly DynamicFormContext context;
        private readonly Form form;

        private readonly ListView filesView;
        private readonly TreeView dirTree;
        private readonly TextBox addressBar;
        private readonly Button backButton;
        private readonly Button forwardButton;
        private readonly Button upButton;
        private readonly Button homeButton;
        private readonly Button refreshButton;
        private readonly TextBox filterBox;
        private readonly Label statusLabel;

        private ToolStripMenuItem renameItem;
        private ToolStripMenuItem refreshItem;
        private ToolTip hints;

        // Пункты меню из designer-файла: нужны, чтобы переводить их
        // при смене языка и гасить «Вставить», когда буфер пуст.
        private readonly ToolStripMenuItem openItem;
        private readonly ToolStripMenuItem createFolderItem;
        private readonly ToolStripMenuItem createFileItem;
        private readonly ToolStripMenuItem copyItem;
        private readonly ToolStripMenuItem cutItem;
        private readonly ToolStripMenuItem pasteItem;
        private readonly ToolStripMenuItem zipItem;
        private readonly ToolStripMenuItem unzipItem;
        private readonly ToolStripMenuItem propertiesItem;
        private readonly ToolStripMenuItem deleteItem;

        private readonly Stack<string> history = new Stack<string>();
        private readonly Stack<string> forwardHistory = new Stack<string>();

        /// <summary>Что лежит в буфере проводника и что с этим делать при вставке.</summary>
        private readonly List<string> clipboard = new List<string>();
        private bool clipboardCut;

        /// <summary>Сортировка списка: по какому столбцу и в какую сторону.</summary>
        private int sortColumn;
        private bool sortAscending = true;

        private readonly string rootPath;
        private readonly string packageName;
        private string currentPath;

        public ExplorerLogicBridge(DynamicFormContext context)
        {
            this.context = context;
            form = context.Form;

            filesView = context.Get<ListView>("lstFilesView");
            dirTree = context.Get<TreeView>("treeDirNodes");
            addressBar = context.Get<TextBox>("txtAddressBar");
            backButton = context.Get<Button>("btnBack");
            forwardButton = context.Get<Button>("btnForward");
            upButton = context.Get<Button>("btnUp");
            homeButton = context.Get<Button>("btnHome");
            refreshButton = context.Get<Button>("btnRefresh");
            filterBox = context.Get<TextBox>("txtFilter");
            statusLabel = context.Get<Label>("lblExplorerStatus");

            openItem = context.Get<ToolStripMenuItem>("ctxOpen");
            createFolderItem = context.Get<ToolStripMenuItem>("ctxCreateFolder");
            createFileItem = context.Get<ToolStripMenuItem>("ctxCreateFile");
            copyItem = context.Get<ToolStripMenuItem>("ctxCopy");
            cutItem = context.Get<ToolStripMenuItem>("ctxCut");
            pasteItem = context.Get<ToolStripMenuItem>("ctxPaste");
            zipItem = context.Get<ToolStripMenuItem>("ctxZip");
            unzipItem = context.Get<ToolStripMenuItem>("ctxUnzip");
            propertiesItem = context.Get<ToolStripMenuItem>("ctxProperties");
            deleteItem = context.Get<ToolStripMenuItem>("ctxDelete");

            packageName = context.PackageName;
            rootPath = LisunEngine.RootPath;
            if (!Directory.Exists(rootPath)) Directory.CreateDirectory(rootPath);
            currentPath = rootPath;
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("explorer.title");
                form.KeyPreview = true;
                form.KeyDown += Form_KeyDown;

                // Проводник переводится на лету вместе с языком системы.
                LisunLocale.LanguageChanged += ApplyLanguage;
                form.Disposed += (s, e) => LisunLocale.LanguageChanged -= ApplyLanguage;
            }

            SetupFilesView();
            ExtendContextMenu();
            ApplyHints();
            InitTree();
            LoadDirectory(currentPath);
        }

        // ---------- подготовка интерфейса ----------

        private void SetupFilesView()
        {
            if (filesView == null) return;

            filesView.View = View.Details;
            filesView.FullRowSelect = true;
            filesView.HideSelection = false;
            // Операции над несколькими объектами разом: удалить, скопировать, упаковать.
            filesView.MultiSelect = true;
            filesView.BorderStyle = BorderStyle.None;
            filesView.Font = Theme.Ui(9.5f);
            filesView.BackColor = Theme.Surface;
            filesView.ForeColor = Theme.Text;

            if (filesView.Columns.Count == 0)
            {
                filesView.Columns.Add(LisunLocale.T("explorer.colName"), 260);
                filesView.Columns.Add(LisunLocale.T("explorer.colType"), 110);
                filesView.Columns.Add(LisunLocale.T("explorer.colSize"), 90, HorizontalAlignment.Right);
                filesView.Columns.Add(LisunLocale.T("explorer.colDate"), 140);
            }

            ImageList icons = new ImageList();
            icons.ImageSize = new Size(16, 16);
            icons.ColorDepth = ColorDepth.Depth32Bit;
            icons.Images.Add("folder", DrawFolderIcon());
            icons.Images.Add("file", DrawFileIcon());

            filesView.SmallImageList = icons;
            filesView.LargeImageList = icons;

            if (dirTree != null)
            {
                dirTree.ImageList = icons;
                dirTree.Font = Theme.Ui(9.5f);
                dirTree.BackColor = Theme.Surface;
                dirTree.ForeColor = Theme.Text;
                dirTree.BorderStyle = BorderStyle.None;
                dirTree.ShowLines = true;
                dirTree.LineColor = Theme.Border;
            }

            // Адресную строку можно править руками: ввёл путь, нажал Enter — перешёл.
            if (addressBar != null)
            {
                addressBar.ReadOnly = false;
                addressBar.BorderStyle = BorderStyle.FixedSingle;
                addressBar.BackColor = Theme.Background;
                addressBar.ForeColor = Theme.Text;
                addressBar.Font = Theme.Mono(9.5f);
            }

            if (filterBox != null)
            {
                filterBox.BorderStyle = BorderStyle.FixedSingle;
                filterBox.BackColor = Theme.Background;
                filterBox.ForeColor = Theme.Text;
                filterBox.Font = Theme.Mono(9.5f);
            }

            if (statusLabel != null)
            {
                statusLabel.Font = Theme.Mono(8.75f);
                statusLabel.BackColor = Theme.Surface;
                statusLabel.ForeColor = Theme.TextDim;
                statusLabel.Padding = new Padding(8, 0, 8, 0);
            }

            if (backButton != null) Theme.StyleButton(backButton, Theme.SurfaceAlt, Theme.Text);
            if (forwardButton != null) Theme.StyleButton(forwardButton, Theme.SurfaceAlt, Theme.Text);
            if (upButton != null) Theme.StyleButton(upButton, Theme.SurfaceAlt, Theme.Text);
            if (homeButton != null) Theme.StyleButton(homeButton, Theme.SurfaceAlt, Theme.Text);
            if (refreshButton != null) Theme.StyleButton(refreshButton, Theme.SurfaceAlt, Theme.Text);
        }

        /// <summary>Подсказки к кнопкам навигации — иначе стрелки ни о чём не говорят.</summary>
        private void ApplyHints()
        {
            if (hints == null)
            {
                hints = new ToolTip();
                hints.InitialDelay = 400;

                if (form != null) form.Disposed += (s, e) => { try { hints.Dispose(); } catch { } };
            }

            if (backButton != null) hints.SetToolTip(backButton, LisunLocale.T("explorer.hintBack"));
            if (forwardButton != null) hints.SetToolTip(forwardButton, LisunLocale.T("explorer.hintForward"));
            if (upButton != null) hints.SetToolTip(upButton, LisunLocale.T("explorer.hintUp"));
            if (homeButton != null) hints.SetToolTip(homeButton, LisunLocale.T("explorer.hintHome"));
            if (refreshButton != null) hints.SetToolTip(refreshButton, LisunLocale.T("explorer.hintRefresh"));
            if (filterBox != null) hints.SetToolTip(filterBox, LisunLocale.T("explorer.hintFilter"));
            if (addressBar != null) hints.SetToolTip(addressBar, LisunLocale.T("explorer.hintAddress"));
        }

        private void ExtendContextMenu()
        {
            if (filesView == null || filesView.ContextMenuStrip == null) return;

            ContextMenuStrip menu = filesView.ContextMenuStrip;

            NameMenuItems();

            if (pasteItem != null) pasteItem.Enabled = false;

            // Что доступно, зависит от выделенного: меню решает это при открытии.
            menu.Opening += (s, e) => UpdateMenuState();

            menu.Items.Add(new ToolStripSeparator());

            renameItem = new ToolStripMenuItem(LisunLocale.T("explorer.rename"));
            renameItem.Click += (s, e) => RenameSelected();
            menu.Items.Add(renameItem);

            refreshItem = new ToolStripMenuItem(LisunLocale.T("explorer.refresh"));
            refreshItem.Click += (s, e) => LoadDirectory(currentPath);
            menu.Items.Add(refreshItem);

            Theme.HarmonizeStrip(menu);
        }

        /// <summary>Подписи пунктов меню берём из словаря, а не из designer-файла.</summary>
        private void NameMenuItems()
        {
            if (openItem != null) openItem.Text = LisunLocale.T("explorer.ctxOpen");
            if (createFolderItem != null) createFolderItem.Text = LisunLocale.T("explorer.ctxCreateFolder");
            if (createFileItem != null) createFileItem.Text = LisunLocale.T("explorer.ctxCreateFile");
            if (copyItem != null) copyItem.Text = LisunLocale.T("explorer.ctxCopy");
            if (cutItem != null) cutItem.Text = LisunLocale.T("explorer.ctxCut");
            if (pasteItem != null) pasteItem.Text = LisunLocale.T("explorer.ctxPaste");
            if (zipItem != null) zipItem.Text = LisunLocale.T("explorer.ctxZip");
            if (unzipItem != null) unzipItem.Text = LisunLocale.T("explorer.ctxUnzip");
            if (propertiesItem != null) propertiesItem.Text = LisunLocale.T("explorer.ctxProperties");
            if (deleteItem != null) deleteItem.Text = LisunLocale.T("explorer.ctxDelete");
        }

        private void UpdateMenuState()
        {
            int selected = filesView == null ? 0 : filesView.SelectedItems.Count;
            string single = selected == 1 ? SelectedPath() : null;

            bool isFile = single != null && File.Exists(single);
            bool isArchive = isFile &&
                (single.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) ||
                 single.EndsWith(".lnsh", StringComparison.OrdinalIgnoreCase));

            if (openItem != null) openItem.Enabled = selected == 1;
            if (copyItem != null) copyItem.Enabled = selected > 0;
            if (cutItem != null) cutItem.Enabled = selected > 0;
            if (pasteItem != null) pasteItem.Enabled = clipboard.Count > 0;
            if (zipItem != null) zipItem.Enabled = selected > 0;
            if (unzipItem != null) unzipItem.Enabled = isArchive;
            if (propertiesItem != null) propertiesItem.Enabled = selected == 1;
            if (deleteItem != null) deleteItem.Enabled = selected > 0;
            if (renameItem != null) renameItem.Enabled = selected == 1;
        }

        private static Bitmap DrawFolderIcon()
        {
            Bitmap bitmap = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                using (SolidBrush tab = new SolidBrush(Color.FromArgb(214, 164, 68)))
                    g.FillRectangle(tab, 1, 3, 6, 3);

                using (LinearGradientBrush body = new LinearGradientBrush(
                    new Rectangle(1, 5, 14, 9),
                    Color.FromArgb(240, 193, 86), Color.FromArgb(206, 150, 46), 90f))
                    g.FillRectangle(body, 1, 5, 14, 9);
            }
            return bitmap;
        }

        private static Bitmap DrawFileIcon()
        {
            Bitmap bitmap = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);

                using (SolidBrush sheet = new SolidBrush(Color.FromArgb(222, 229, 238)))
                    g.FillRectangle(sheet, 3, 1, 10, 14);

                using (Pen edge = new Pen(Color.FromArgb(150, 160, 175)))
                    g.DrawRectangle(edge, 3, 1, 10, 14);

                using (Pen line = new Pen(Color.FromArgb(120, 132, 150)))
                {
                    g.DrawLine(line, 5, 5, 11, 5);
                    g.DrawLine(line, 5, 8, 11, 8);
                    g.DrawLine(line, 5, 11, 9, 11);
                }
            }
            return bitmap;
        }

        // ---------- навигация ----------

        private void InitTree()
        {
            if (dirTree == null) return;

            dirTree.Nodes.Clear();
            TreeNode root = new TreeNode("LisunOS (C:)");
            root.Tag = rootPath;
            root.ImageKey = "folder";
            root.SelectedImageKey = "folder";

            dirTree.Nodes.Add(root);
            FillTreeNode(root);
            root.Expand();
        }

        private void FillTreeNode(TreeNode parent)
        {
            if (parent == null || parent.Tag == null) return;

            try
            {
                parent.Nodes.Clear();
                foreach (string dir in Directory.GetDirectories(parent.Tag.ToString()))
                {
                    TreeNode node = new TreeNode(Path.GetFileName(dir));
                    node.Tag = dir;
                    node.ImageKey = "folder";
                    node.SelectedImageKey = "folder";

                    try
                    {
                        if (Directory.GetDirectories(dir).Length > 0) node.Nodes.Add(new TreeNode("..."));
                    }
                    catch { }

                    parent.Nodes.Add(node);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Explorer] [ОШИБКА] Чтение дерева: " + ex.Message);
            }
        }

        private void LoadDirectory(string path)
        {
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;

            // Просмотр содержимого требует права read_files.
            if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles))
            {
                if (filesView != null) filesView.Items.Clear();
                if (addressBar != null) addressBar.Text = LisunLocale.T("perm.denied", packageName, LisunPermissions.ReadFiles).Trim();
                return;
            }

            currentPath = path;

            if (addressBar != null) addressBar.Text = CustomFormUtils.ToVirtualPath(path);
            if (backButton != null) backButton.Enabled = history.Count > 0;
            if (forwardButton != null) forwardButton.Enabled = forwardHistory.Count > 0;
            if (upButton != null) upButton.Enabled = !IsRoot(path);
            if (homeButton != null) homeButton.Enabled = !IsRoot(path);
            if (filesView == null) return;

            string needle = filterBox == null ? string.Empty : (filterBox.Text ?? string.Empty).Trim();

            int folderCount = 0;
            int fileCount = 0;
            int hidden = 0;
            long totalSize = 0;

            filesView.BeginUpdate();
            try
            {
                filesView.Items.Clear();

                List<string> folders;
                List<string> files = CustomFormUtils.GetDirectoryContent(path, out folders);

                foreach (string folder in folders)
                {
                    if (!Matches(folder, needle)) { hidden++; continue; }

                    string full = Path.Combine(path, folder);
                    ListViewItem item = new ListViewItem(folder, "folder");
                    item.Tag = full;
                    item.SubItems.Add(LisunLocale.T("explorer.folder"));
                    item.SubItems.Add("");
                    item.SubItems.Add(SafeWriteTime(full, true));
                    item.ForeColor = Theme.Text;
                    filesView.Items.Add(item);
                    folderCount++;
                }

                foreach (string file in files)
                {
                    if (!Matches(file, needle)) { hidden++; continue; }

                    string full = Path.Combine(path, file);
                    long size = 0;
                    try { size = new FileInfo(full).Length; }
                    catch { }

                    totalSize += size;

                    string extension = Path.GetExtension(file);
                    ListViewItem item = new ListViewItem(file, "file");
                    item.Tag = full;
                    item.SubItems.Add(string.IsNullOrEmpty(extension)
                        ? LisunLocale.T("explorer.file")
                        : LisunLocale.T("explorer.fileExt", extension.TrimStart('.').ToUpper()));
                    item.SubItems.Add(CustomFormUtils.FormatSize(size));
                    item.SubItems.Add(SafeWriteTime(full, false));

                    // Защищённый пакет видно сразу, не открывая файл.
                    item.ForeColor = LisunCrypto.IsEncryptedFile(full) ? Theme.Magenta : Theme.TextDim;
                    filesView.Items.Add(item);
                    fileCount++;
                }

                ApplySort();
            }
            finally
            {
                filesView.EndUpdate();
            }

            ShowStatus(folderCount, fileCount, hidden, totalSize);
        }

        /// <summary>Фильтр по имени: пустая строка пропускает всё.</summary>
        private static bool Matches(string name, string needle)
        {
            if (string.IsNullOrEmpty(needle)) return true;
            return name.IndexOf(needle, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private void ShowStatus(int folders, int files, int hidden, long totalSize)
        {
            if (statusLabel == null) return;

            StringBuilder sb = new StringBuilder();
            sb.Append(LisunLocale.T("explorer.statusCounts", folders, files, CustomFormUtils.FormatSize(totalSize)));

            if (hidden > 0) sb.Append("   ").Append(LisunLocale.T("explorer.statusHidden", hidden));

            if (clipboard.Count > 0)
                sb.Append("   ").Append(LisunLocale.T(clipboardCut ? "explorer.statusCut" : "explorer.statusCopied",
                    clipboard.Count));

            statusLabel.Text = sb.ToString();
        }

        /// <summary>
        /// Сортировка: папки всегда идут выше файлов, а внутри каждой группы
        /// действует выбранный столбец. Размер и дату сравниваем по значению,
        /// а не по строке, иначе 9 КБ окажется больше 10 МБ.
        /// </summary>
        private void ApplySort()
        {
            if (filesView == null || filesView.Items.Count < 2) return;

            List<ListViewItem> items = new List<ListViewItem>();
            foreach (ListViewItem item in filesView.Items) items.Add(item);

            int column = sortColumn;
            bool ascending = sortAscending;

            items.Sort(delegate (ListViewItem left, ListViewItem right)
            {
                bool leftFolder = left.ImageKey == "folder";
                bool rightFolder = right.ImageKey == "folder";
                if (leftFolder != rightFolder) return leftFolder ? -1 : 1;

                int result;
                switch (column)
                {
                    case 2:
                        result = SizeOf(left).CompareTo(SizeOf(right));
                        break;

                    case 3:
                        result = TimeOf(left).CompareTo(TimeOf(right));
                        break;

                    case 1:
                        result = string.Compare(left.SubItems[1].Text, right.SubItems[1].Text,
                            StringComparison.OrdinalIgnoreCase);
                        break;

                    default:
                        result = string.Compare(left.Text, right.Text, StringComparison.OrdinalIgnoreCase);
                        break;
                }

                if (result == 0)
                    result = string.Compare(left.Text, right.Text, StringComparison.OrdinalIgnoreCase);

                return ascending ? result : -result;
            });

            filesView.Items.Clear();
            filesView.Items.AddRange(items.ToArray());
        }

        private static long SizeOf(ListViewItem item)
        {
            object tag = item.Tag;
            if (tag == null) return -1;

            try
            {
                string path = tag.ToString();
                return File.Exists(path) ? new FileInfo(path).Length : -1;
            }
            catch { return -1; }
        }

        private static DateTime TimeOf(ListViewItem item)
        {
            object tag = item.Tag;
            if (tag == null) return DateTime.MinValue;

            try
            {
                string path = tag.ToString();
                if (Directory.Exists(path)) return Directory.GetLastWriteTime(path);
                if (File.Exists(path)) return File.GetLastWriteTime(path);
            }
            catch { }

            return DateTime.MinValue;
        }

        private static string SafeWriteTime(string path, bool directory)
        {
            try
            {
                DateTime time = directory ? Directory.GetLastWriteTime(path) : File.GetLastWriteTime(path);
                return time.ToString("dd.MM.yyyy HH:mm");
            }
            catch { return ""; }
        }

        private bool IsRoot(string path)
        {
            return string.Equals(
                path.TrimEnd(Path.DirectorySeparatorChar),
                rootPath.TrimEnd(Path.DirectorySeparatorChar),
                StringComparison.OrdinalIgnoreCase);
        }

        private void NavigateTo(string path)
        {
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;
            if (string.Equals(path, currentPath, StringComparison.OrdinalIgnoreCase)) return;

            history.Push(currentPath);

            // Новый переход обрывает ветку «вперёд», как в любом браузере.
            forwardHistory.Clear();

            LoadDirectory(path);
        }

        // ---------- обработчики из designer-файла ----------

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (history.Count == 0) return;

            forwardHistory.Push(currentPath);
            LoadDirectory(history.Pop());
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (IsRoot(currentPath)) return;

            DirectoryInfo parent = Directory.GetParent(currentPath);
            if (parent != null) NavigateTo(parent.FullName);
        }

        private void lstFilesView_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            OpenSelected();
        }

        private void treeDirNodes_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            if (e.Node != null && e.Node.Tag != null) FillTreeNode(e.Node);
        }

        private void treeDirNodes_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node != null && e.Node.Tag != null) NavigateTo(e.Node.Tag.ToString());
        }

        private void ctxCreateFile_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("explorer.titleFile"),
                LisunLocale.T("explorer.newFile"), "NewFile.txt", form);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (File.Exists(target))
            {
                MessageBox.Show(LisunLocale.T("explorer.exists"), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            CustomFormUtils.WriteFileText(target, "");
            LoadDirectory(currentPath);
        }

        private void ctxCreateFolder_Click(object sender, EventArgs e)
        {
            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string name = CustomFormUtils.Prompt(LisunLocale.T("explorer.titleDir"),
                LisunLocale.T("explorer.newFolder"), "NewFolder", form);
            if (string.IsNullOrEmpty(name)) return;

            string target = Path.Combine(currentPath, name);
            if (Directory.Exists(target))
            {
                MessageBox.Show(LisunLocale.T("explorer.exists"), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            CustomFormUtils.CreateFolder(target);
            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }

        private void ctxDelete_Click(object sender, EventArgs e)
        {
            DeleteSelected();
        }

        // ---------- действия ----------

        private void Form_KeyDown(object sender, KeyEventArgs e)
        {
            // В адресной строке и в фильтре клавиши принадлежат полю, а не проводнику.
            if (addressBar != null && addressBar.Focused) return;
            if (filterBox != null && filterBox.Focused) return;

            if (e.Control && e.KeyCode == Keys.C) { RememberForPaste(false); e.Handled = true; }
            else if (e.Control && e.KeyCode == Keys.X) { RememberForPaste(true); e.Handled = true; }
            else if (e.Control && e.KeyCode == Keys.V) { ctxPaste_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.Control && e.KeyCode == Keys.A && filesView != null)
            {
                foreach (ListViewItem item in filesView.Items) item.Selected = true;
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.L && addressBar != null)
            {
                addressBar.Focus();
                addressBar.SelectAll();
                e.Handled = true;
            }
            else if (e.Control && e.KeyCode == Keys.F && filterBox != null)
            {
                filterBox.Focus();
                filterBox.SelectAll();
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.F5) { btnRefresh_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.Alt && e.KeyCode == Keys.Left) { btnBack_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.Alt && e.KeyCode == Keys.Right) { btnForward_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.KeyCode == Keys.Back) { btnUp_Click(sender, EventArgs.Empty); e.Handled = true; }
            else if (e.KeyCode == Keys.Delete) { DeleteSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.F2) { RenameSelected(); e.Handled = true; }
            else if (e.KeyCode == Keys.Enter && filesView != null && filesView.Focused) { OpenSelected(); e.Handled = true; }
        }

        private string SelectedPath()
        {
            if (filesView == null || filesView.SelectedItems.Count == 0) return null;
            object tag = filesView.SelectedItems[0].Tag;
            return tag == null ? null : tag.ToString();
        }

        private void OpenSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (Directory.Exists(target))
            {
                NavigateTo(target);
                return;
            }
            if (File.Exists(target))
            {
                if (!LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) return;
                ShowFileViewer(target);
            }
        }

        private void DeleteSelected()
        {
            List<string> targets = SelectedPaths();
            if (targets.Count == 0) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.ManageFiles)) return;

            // Удаление запрещают только блоки NOREMOVE; CANTEDIT не мешает.
            List<string> protectedFiles = new List<string>();
            foreach (string target in targets)
                if (File.Exists(target) && LisunApiEndpoint.FileBlocksDeletion(target))
                    protectedFiles.Add(Path.GetFileName(target));

            if (protectedFiles.Count > 0)
            {
                MessageBox.Show(LisunLocale.T("api.fileProtected", string.Join(", ", protectedFiles.ToArray())),
                    LisunLocale.T("explorer.title"), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string question = targets.Count == 1
                ? LisunLocale.T("explorer.confirm", Path.GetFileName(
                      targets[0].TrimEnd(Path.DirectorySeparatorChar)))
                : LisunLocale.T("explorer.confirmMany", targets.Count);

            DialogResult confirm = MessageBox.Show(question,
                LisunLocale.T("explorer.title"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm != DialogResult.Yes) return;

            int done = 0;
            foreach (string target in targets)
            {
                bool removed = Directory.Exists(target)
                    ? CustomFormUtils.DeleteFolder(target)
                    : CustomFormUtils.DeleteFile(target);

                if (removed) done++;
            }

            // Удалённое могло лежать в буфере — иначе «Вставить» сломается.
            foreach (string target in targets) clipboard.Remove(target);
            if (clipboard.Count == 0 && pasteItem != null) pasteItem.Enabled = false;

            RefreshTreeBranch();
            LoadDirectory(currentPath);

            if (statusLabel != null && done != targets.Count)
                statusLabel.Text = LisunLocale.T("explorer.deletePartial", done, targets.Count);
        }

        private void RenameSelected()
        {
            string target = SelectedPath();
            if (string.IsNullOrEmpty(target)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

            string oldName = Path.GetFileName(target);
            string newName = CustomFormUtils.Prompt(LisunLocale.T("explorer.rename"),
                LisunLocale.T("explorer.newName"), oldName, form);
            if (string.IsNullOrEmpty(newName) || newName == oldName) return;

            string destination = Path.Combine(currentPath, newName);
            try
            {
                if (Directory.Exists(target)) Directory.Move(target, destination);
                else File.Move(target, destination);
            }
            catch (Exception ex)
            {
                MessageBox.Show(LisunLocale.T("explorer.renameErr", ex.Message), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }


        // =====================================================================
        //  Навигация: вперёд, домой, обновить, адресная строка, фильтр
        // =====================================================================

        private void btnForward_Click(object sender, EventArgs e)
        {
            if (forwardHistory.Count == 0) return;

            string target = forwardHistory.Pop();
            history.Push(currentPath);
            LoadDirectory(target);
        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            NavigateTo(rootPath);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshTreeBranch();
            LoadDirectory(currentPath);
        }

        /// <summary>Enter в адресной строке — переход, Escape — вернуть текущий путь.</summary>
        private void txtAddressBar_KeyDown(object sender, KeyEventArgs e)
        {
            if (addressBar == null) return;

            if (e.KeyCode == Keys.Escape)
            {
                addressBar.Text = CustomFormUtils.ToVirtualPath(currentPath);
                e.Handled = true;
                return;
            }

            if (e.KeyCode != Keys.Enter) return;

            e.Handled = true;
            e.SuppressKeyPress = true;

            string typed = (addressBar.Text ?? string.Empty).Trim();
            if (typed.Length == 0) return;

            string resolved;
            if (!CustomFormUtils.TryResolveInsideRoot(currentPath, typed, out resolved))
            {
                MessageBox.Show(LisunLocale.T("tool.outsideRoot").Trim(), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                addressBar.Text = CustomFormUtils.ToVirtualPath(currentPath);
                return;
            }

            if (Directory.Exists(resolved))
            {
                NavigateTo(resolved);
                return;
            }

            if (File.Exists(resolved))
            {
                // Введён файл: открываем его, а список оставляем на его папке.
                string folder = Path.GetDirectoryName(resolved);
                if (folder != null && !string.Equals(folder, currentPath, StringComparison.OrdinalIgnoreCase))
                    NavigateTo(folder);

                if (LisunPermissions.Demand(packageName, LisunPermissions.ReadFiles)) ShowFileViewer(resolved);
                return;
            }

            MessageBox.Show(LisunLocale.T("explorer.noSuchPath", typed), LisunLocale.T("explorer.title"),
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            addressBar.Text = CustomFormUtils.ToVirtualPath(currentPath);
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            LoadDirectory(currentPath);
        }

        private void lstFilesView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (statusLabel == null || filesView == null) return;
            if (filesView.SelectedItems.Count == 0) { LoadDirectoryStatus(); return; }

            if (filesView.SelectedItems.Count == 1)
            {
                string path = SelectedPath();
                if (path == null) return;

                long size = 0;
                try { if (File.Exists(path)) size = new FileInfo(path).Length; }
                catch { }

                statusLabel.Text = LisunLocale.T("explorer.statusOne",
                    CustomFormUtils.ToVirtualPath(path), CustomFormUtils.FormatSize(size));
                return;
            }

            long total = 0;
            foreach (string path in SelectedPaths())
            {
                try { if (File.Exists(path)) total += new FileInfo(path).Length; }
                catch { }
            }

            statusLabel.Text = LisunLocale.T("explorer.statusMany",
                filesView.SelectedItems.Count, CustomFormUtils.FormatSize(total));
        }

        /// <summary>Вернуть в строку состояния сводку по папке — после снятия выделения.</summary>
        private void LoadDirectoryStatus()
        {
            if (filesView == null) return;

            int folders = 0;
            int files = 0;
            long size = 0;

            foreach (ListViewItem item in filesView.Items)
            {
                if (item.ImageKey == "folder") { folders++; continue; }

                files++;
                size += Math.Max(0, SizeOf(item));
            }

            ShowStatus(folders, files, 0, size);
        }

        private void lstFilesView_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == sortColumn) sortAscending = !sortAscending;
            else { sortColumn = e.Column; sortAscending = true; }

            if (filesView != null)
            {
                filesView.BeginUpdate();
                try { ApplySort(); }
                finally { filesView.EndUpdate(); }
            }
        }

        // =====================================================================
        //  Буфер обмена проводника, упаковка, свойства
        // =====================================================================

        private List<string> SelectedPaths()
        {
            List<string> result = new List<string>();
            if (filesView == null) return result;

            foreach (ListViewItem item in filesView.SelectedItems)
            {
                if (item.Tag == null) continue;
                result.Add(item.Tag.ToString());
            }

            return result;
        }

        private void ctxOpen_Click(object sender, EventArgs e)
        {
            OpenSelected();
        }

        private void ctxCopy_Click(object sender, EventArgs e)
        {
            RememberForPaste(false);
        }

        private void ctxCut_Click(object sender, EventArgs e)
        {
            RememberForPaste(true);
        }

        private void RememberForPaste(bool cut)
        {
            List<string> selected = SelectedPaths();
            if (selected.Count == 0) return;

            clipboard.Clear();
            clipboard.AddRange(selected);
            clipboardCut = cut;

            if (pasteItem != null) pasteItem.Enabled = true;

            LoadDirectory(currentPath);
        }

        private void ctxPaste_Click(object sender, EventArgs e)
        {
            if (clipboard.Count == 0) return;

            if (!LisunPermissions.Demand(packageName,
                clipboardCut ? LisunPermissions.EditFiles : LisunPermissions.WriteFiles)) return;

            int done = 0;
            List<string> failed = new List<string>();

            foreach (string source in clipboard)
            {
                string name = Path.GetFileName(source.TrimEnd(Path.DirectorySeparatorChar));
                string target = Path.Combine(currentPath, name);

                // Вставка в ту же папку создала бы «копию копии» поверх исходника.
                if (string.Equals(source, target, StringComparison.OrdinalIgnoreCase))
                    target = Path.Combine(currentPath, UniqueName(currentPath, name));

                try
                {
                    if (Directory.Exists(source))
                    {
                        if (IsInside(source, target)) { failed.Add(name); continue; }

                        if (clipboardCut) Directory.Move(source, target);
                        else CopyFolder(source, target);
                    }
                    else if (File.Exists(source))
                    {
                        if (clipboardCut) File.Move(source, target);
                        else File.Copy(source, target, false);
                    }
                    else continue;

                    done++;
                }
                catch (Exception ex)
                {
                    LisunEngine.Log("[Explorer] [ОШИБКА] " + name + ": " + ex.Message);
                    failed.Add(name);
                }
            }

            if (clipboardCut)
            {
                clipboard.Clear();
                clipboardCut = false;
                if (pasteItem != null) pasteItem.Enabled = false;
            }

            RefreshTreeBranch();
            LoadDirectory(currentPath);

            if (failed.Count > 0)
                MessageBox.Show(LisunLocale.T("explorer.pasteFailed", string.Join(", ", failed.ToArray())),
                    LisunLocale.T("explorer.title"), MessageBoxButtons.OK, MessageBoxIcon.Warning);

            if (statusLabel != null) statusLabel.Text = LisunLocale.T("explorer.pasteDone", done);
        }

        /// <summary>Нельзя копировать папку внутрь себя же — получится бесконечная вложенность.</summary>
        private static bool IsInside(string folder, string candidate)
        {
            string from = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            string to = Path.GetFullPath(candidate).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

            return to.StartsWith(from, StringComparison.OrdinalIgnoreCase);
        }

        private static string UniqueName(string folder, string name)
        {
            string stem = Path.GetFileNameWithoutExtension(name);
            string extension = Path.GetExtension(name);

            for (int index = 2; index < 1000; index++)
            {
                string candidate = stem + " (" + index + ")" + extension;
                string full = Path.Combine(folder, candidate);

                if (!File.Exists(full) && !Directory.Exists(full)) return candidate;
            }

            return stem + "-" + DateTime.Now.ToString("HHmmss") + extension;
        }

        private static void CopyFolder(string source, string target)
        {
            Directory.CreateDirectory(target);

            foreach (string file in Directory.GetFiles(source))
                File.Copy(file, Path.Combine(target, Path.GetFileName(file)), true);

            foreach (string folder in Directory.GetDirectories(source))
                CopyFolder(folder, Path.Combine(target, Path.GetFileName(folder)));
        }

        private void ctxZip_Click(object sender, EventArgs e)
        {
            List<string> selected = SelectedPaths();
            if (selected.Count == 0) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string suggested = selected.Count == 1
                ? Path.GetFileNameWithoutExtension(selected[0].TrimEnd(Path.DirectorySeparatorChar)) + ".zip"
                : Path.GetFileName(currentPath.TrimEnd(Path.DirectorySeparatorChar)) + ".zip";

            string name = CustomFormUtils.Prompt(LisunLocale.T("explorer.zipTitle"),
                LisunLocale.T("explorer.zipLabel"), suggested, form);
            if (string.IsNullOrEmpty(name)) return;

            if (!name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase)) name += ".zip";

            string archive = Path.Combine(currentPath, name);

            try
            {
                if (File.Exists(archive)) File.Delete(archive);

                using (ZipArchive zip = ZipFile.Open(archive, ZipArchiveMode.Create))
                {
                    foreach (string path in selected)
                    {
                        if (Directory.Exists(path)) AddFolderToZip(zip, path, Path.GetFileName(
                            path.TrimEnd(Path.DirectorySeparatorChar)));
                        else if (File.Exists(path))
                            zip.CreateEntryFromFile(path, Path.GetFileName(path), CompressionLevel.Optimal);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(LisunLocale.T("explorer.zipFailed", ex.Message), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadDirectory(currentPath);

            if (statusLabel != null)
            {
                long size = 0;
                try { size = new FileInfo(archive).Length; }
                catch { }

                statusLabel.Text = LisunLocale.T("explorer.zipDone", name, CustomFormUtils.FormatSize(size));
            }
        }

        private static void AddFolderToZip(ZipArchive zip, string folder, string prefix)
        {
            foreach (string file in Directory.GetFiles(folder))
                zip.CreateEntryFromFile(file, prefix + "/" + Path.GetFileName(file), CompressionLevel.Optimal);

            foreach (string child in Directory.GetDirectories(folder))
                AddFolderToZip(zip, child, prefix + "/" + Path.GetFileName(child));
        }

        private void ctxUnzip_Click(object sender, EventArgs e)
        {
            string archive = SelectedPath();
            if (string.IsNullOrEmpty(archive) || !File.Exists(archive)) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles)) return;

            string folder = Path.Combine(currentPath,
                Path.GetFileNameWithoutExtension(archive));

            try
            {
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

                int count = 0;
                using (ZipArchive zip = ZipFile.OpenRead(archive))
                {
                    foreach (ZipArchiveEntry entry in zip.Entries)
                    {
                        // Имя внутри архива может уводить наружу («../..»): такие записи пропускаем.
                        string destination = Path.GetFullPath(Path.Combine(folder, entry.FullName));
                        if (!IsInside(folder, destination)) continue;

                        if (entry.FullName.EndsWith("/") || entry.FullName.EndsWith("\\"))
                        {
                            Directory.CreateDirectory(destination);
                            continue;
                        }

                        string parent = Path.GetDirectoryName(destination);
                        if (parent != null && !Directory.Exists(parent)) Directory.CreateDirectory(parent);

                        entry.ExtractToFile(destination, true);
                        count++;
                    }
                }

                RefreshTreeBranch();
                LoadDirectory(currentPath);

                if (statusLabel != null)
                    statusLabel.Text = LisunLocale.T("explorer.unzipDone",
                        Path.GetFileName(folder), count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(LisunLocale.T("explorer.unzipFailed", ex.Message), LisunLocale.T("explorer.title"),
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ctxProperties_Click(object sender, EventArgs e)
        {
            string path = SelectedPath();
            if (string.IsNullOrEmpty(path)) return;

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("explorer.propName", Path.GetFileName(
                path.TrimEnd(Path.DirectorySeparatorChar))));
            sb.AppendLine(LisunLocale.T("explorer.propPath", CustomFormUtils.ToVirtualPath(path)));

            try
            {
                if (Directory.Exists(path))
                {
                    int files;
                    int folders;
                    long size = MeasureFolder(path, out files, out folders);

                    sb.AppendLine(LisunLocale.T("explorer.propKindFolder"));
                    sb.AppendLine(LisunLocale.T("explorer.propContent", folders, files));
                    sb.AppendLine(LisunLocale.T("explorer.propSize", CustomFormUtils.FormatSize(size)));
                    sb.AppendLine(LisunLocale.T("explorer.propChanged", Directory.GetLastWriteTime(path)));
                }
                else if (File.Exists(path))
                {
                    FileInfo info = new FileInfo(path);

                    sb.AppendLine(LisunLocale.T("explorer.propKindFile",
                        Path.GetExtension(path).TrimStart('.').ToUpper()));
                    sb.AppendLine(LisunLocale.T("explorer.propSize", CustomFormUtils.FormatSize(info.Length)));
                    sb.AppendLine(LisunLocale.T("explorer.propChanged", info.LastWriteTime));
                    sb.AppendLine(LisunLocale.T("explorer.propReadOnly",
                        info.IsReadOnly ? LisunLocale.T("explorer.yes") : LisunLocale.T("explorer.no")));
                    sb.AppendLine(LisunLocale.T("explorer.propEncrypted",
                        LisunCrypto.IsEncryptedFile(path) ? LisunLocale.T("explorer.yes") : LisunLocale.T("explorer.no")));
                    sb.AppendLine(LisunLocale.T("explorer.propNoRemove",
                        LisunApiEndpoint.FileBlocksDeletion(path)
                            ? LisunLocale.T("explorer.yes")
                            : LisunLocale.T("explorer.no")));
                }
            }
            catch (Exception ex)
            {
                sb.AppendLine(" [ERROR] " + ex.Message);
            }

            MessageBox.Show(sb.ToString(), LisunLocale.T("explorer.propTitle"),
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>Суммарный размер папки — считаем рекурсивно, но не падаем на отказе доступа.</summary>
        private static long MeasureFolder(string folder, out int files, out int folders)
        {
            long size = 0;
            files = 0;
            folders = 0;

            try
            {
                foreach (string file in Directory.GetFiles(folder))
                {
                    files++;
                    try { size += new FileInfo(file).Length; }
                    catch { }
                }

                foreach (string child in Directory.GetDirectories(folder))
                {
                    folders++;

                    int childFiles;
                    int childFolders;
                    size += MeasureFolder(child, out childFiles, out childFolders);

                    files += childFiles;
                    folders += childFolders;
                }
            }
            catch { }

            return size;
        }

        /// <summary>Перевод интерфейса проводника при смене языка системы.</summary>
        private void ApplyLanguage()
        {
            if (form == null || form.IsDisposed) return;

            form.Text = LisunLocale.T("explorer.title");

            if (filesView != null && filesView.Columns.Count >= 4)
            {
                filesView.Columns[0].Text = LisunLocale.T("explorer.colName");
                filesView.Columns[1].Text = LisunLocale.T("explorer.colType");
                filesView.Columns[2].Text = LisunLocale.T("explorer.colSize");
                filesView.Columns[3].Text = LisunLocale.T("explorer.colDate");
            }

            if (renameItem != null) renameItem.Text = LisunLocale.T("explorer.rename");
            if (refreshItem != null) refreshItem.Text = LisunLocale.T("explorer.refresh");

            NameMenuItems();
            ApplyHints();

            LoadDirectory(currentPath);
        }

        private void RefreshTreeBranch()
        {
            if (dirTree == null || dirTree.Nodes.Count == 0) return;
            FillTreeNode(dirTree.Nodes[0]);
            dirTree.Nodes[0].Expand();
        }

        /// <summary>
        /// Редактор файла: править можно любой файл, но текст внутри блоков
        /// ~~~CANTEDIT~ ... ~CANTEDIT~~~ и ~~~NOREMOVE~ ... ~NOREMOVE~~~ остаётся как есть.
        /// </summary>
        private void ShowFileViewer(string path)
        {
            string original = LisunCrypto.ReadAllText(path);

            using (Form editor = new Form())
            {
                editor.Text = LisunLocale.T("fm.editing", Path.GetFileName(path));
                editor.ClientSize = new Size(860, 640);
                editor.MinimumSize = new Size(560, 420);
                editor.StartPosition = FormStartPosition.CenterParent;
                editor.BackColor = Theme.Background;
                editor.ForeColor = Theme.Text;
                editor.Font = Theme.Ui(9.5f);

                TextBox box = new TextBox();
                box.Multiline = true;
                box.AcceptsTab = true;
                box.WordWrap = false;
                box.ScrollBars = ScrollBars.Both;
                box.Dock = DockStyle.Fill;
                box.BackColor = Theme.Surface;
                box.ForeColor = Theme.Text;
                box.BorderStyle = BorderStyle.None;
                box.Font = Theme.Mono(10.5f);
                box.Text = original;

                Panel padding = new Panel();
                padding.Dock = DockStyle.Fill;
                padding.Padding = new Padding(14);
                padding.BackColor = Theme.Background;
                padding.Controls.Add(box);

                Panel bar = new Panel();
                bar.Dock = DockStyle.Bottom;
                bar.Height = 58;
                bar.BackColor = Theme.Surface;
                bar.Padding = new Padding(14, 12, 14, 12);

                string protection = LisunApiEndpoint.DescribeProtection(original);

                Label info = new Label();
                info.Dock = DockStyle.Left;
                info.Width = 470;
                info.Font = Theme.Mono(9f);
                info.TextAlign = ContentAlignment.MiddleLeft;
                info.ForeColor = protection.Length > 0 ? Theme.Warning : Theme.TextDim;
                info.Text = protection.Length > 0
                    ? protection
                    : CustomFormUtils.ToVirtualPath(path);

                Button cancel = new Button();
                cancel.Text = LisunLocale.T("dialog.cancel");
                cancel.Dock = DockStyle.Right;
                cancel.Width = 120;
                cancel.DialogResult = DialogResult.Cancel;
                Theme.StyleButton(cancel, Theme.SurfaceAlt, Theme.Text);

                Button save = new Button();
                save.Text = LisunLocale.T("fm.save");
                save.Dock = DockStyle.Right;
                save.Width = 130;
                save.DialogResult = DialogResult.OK;
                Theme.StyleButton(save, Theme.AccentDeep, Theme.Text);

                bar.Controls.Add(cancel);
                bar.Controls.Add(save);
                bar.Controls.Add(info);

                editor.Controls.Add(padding);
                editor.Controls.Add(bar);
                editor.CancelButton = cancel;

                DialogResult outcome = form != null ? editor.ShowDialog(form) : editor.ShowDialog();
                if (outcome != DialogResult.OK) return;

                if (!LisunPermissions.Demand(packageName, LisunPermissions.EditFiles)) return;

                string text = box.Text;
                string error;

                if (!LisunApiEndpoint.ValidateEdit(original, text, out error))
                {
                    DialogResult answer = MessageBox.Show(
                        error + Environment.NewLine + Environment.NewLine + LisunLocale.T("api.restoreAsk"),
                        LisunLocale.T("explorer.title"), MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (answer != DialogResult.Yes) return;
                    text = LisunApiEndpoint.RestoreBlocks(original, text);
                }

                if (!CustomFormUtils.WriteFileText(path, text))
                {
                    MessageBox.Show(LisunLocale.T("fm.saveFailed"), LisunLocale.T("explorer.title"),
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                LisunEngine.Log("[Explorer] Сохранён " + CustomFormUtils.ToVirtualPath(path));
                LoadDirectory(currentPath);
            }
        }
    }
}
