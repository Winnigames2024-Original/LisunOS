﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика приложения «Журнал» (пакет apps/logsapp).
    ///
    /// Записи ядра лежат в LisunEngine.SystemLog одной строкой на событие,
    /// а источник события записан в квадратных скобках: [store], [ssh], [apt].
    /// Отсюда и фильтр: список источников собирается из самих записей,
    /// поэтому новый модуль появляется в нём сам, без правок приложения.
    /// </summary>
    public partial class LogsLogicBridge
    {
        private const string AnySource = "*";

        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label count;
        private readonly Label findCaption;
        private readonly TextBox find;
        private readonly Label sourceCaption;
        private readonly ComboBox source;
        private readonly CheckBox onlyErrors;
        private readonly CheckBox follow;
        private readonly ListBox lines;
        private readonly Button refresh;
        private readonly Button save;
        private readonly Button copy;
        private readonly Label status;

        private readonly Timer timer = new Timer();

        private int lastTotal = -1;
        private bool filling;

        public LogsLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblTitle");
            count = context.Get<Label>("lblCount");
            findCaption = context.Get<Label>("lblFindCaption");
            find = context.Get<TextBox>("txtLogFind");
            sourceCaption = context.Get<Label>("lblSourceCaption");
            source = context.Get<ComboBox>("cmbLogSource");
            onlyErrors = context.Get<CheckBox>("chkOnlyErrors");
            follow = context.Get<CheckBox>("chkFollow");
            lines = context.Get<ListBox>("lstLogLines");
            refresh = context.Get<Button>("btnLogRefresh");
            save = context.Get<Button>("btnLogSave");
            copy = context.Get<Button>("btnLogCopy");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("logs.windowTitle");
                form.Disposed += (s, e) => { try { timer.Stop(); timer.Dispose(); } catch { } };
            }

            if (title != null)
            {
                title.Text = LisunLocale.T("logs.windowTitle");
                title.Font = Theme.Ui(14f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
            }
            if (count != null) count.Font = Theme.Mono(9f);
            if (status != null) status.Font = Theme.Mono(8.75f);

            if (findCaption != null) findCaption.Text = LisunLocale.T("logs.find");
            if (sourceCaption != null) sourceCaption.Text = LisunLocale.T("logs.source");
            if (onlyErrors != null)
            {
                onlyErrors.Text = LisunLocale.T("logs.onlyErrors");
                onlyErrors.ForeColor = Theme.TextDim;
                onlyErrors.Font = Theme.Ui(8.75f);
            }
            if (follow != null)
            {
                follow.Text = LisunLocale.T("logs.follow");
                follow.ForeColor = Theme.TextDim;
                follow.Font = Theme.Ui(8.75f);
            }

            if (find != null) find.Font = Theme.Mono(9.5f);
            if (source != null) source.Font = Theme.Mono(9.5f);
            if (lines != null)
            {
                lines.Font = Theme.Mono(9.25f);
                lines.ItemHeight = 18;
            }

            if (refresh != null)
            {
                refresh.Text = LisunLocale.T("logs.refresh");
                Theme.StyleButton(refresh, Theme.SurfaceAlt, Theme.Text);
            }
            if (save != null)
            {
                save.Text = LisunLocale.T("logs.save");
                Theme.StyleButton(save, Theme.AccentDeep, Theme.Text);
            }
            if (copy != null)
            {
                copy.Text = LisunLocale.T("logs.copy");
                Theme.StyleButton(copy, Theme.SurfaceAlt, Theme.Text);
            }

            FillSources();
            Fill(true);

            timer.Interval = 1200;
            timer.Tick += (s, e) => Tick();
            timer.Start();

            SetStatus(LisunLocale.T("logs.ready"));
        }

        // =====================================================================
        //  Данные
        // =====================================================================

        private List<string> Journal()
        {
            if (!LisunPermissions.IsGranted(packageName, LisunPermissions.ReadLog) &&
                !LisunPermissions.Demand(packageName, LisunPermissions.ReadLog))
                return new List<string>();

            try { return new List<string>(LisunEngine.SystemLog); }
            catch { return new List<string>(); }
        }

        /// <summary>Метка источника записи: «[store] …» -&gt; «store».</summary>
        private static string SourceOf(string line)
        {
            if (string.IsNullOrEmpty(line)) return string.Empty;

            // Первым идёт время в своих скобках — его пропускаем.
            int from = line.IndexOf(']');
            if (from < 0) return string.Empty;

            int open = line.IndexOf('[', from);
            if (open < 0) return string.Empty;

            int close = line.IndexOf(']', open);
            if (close <= open + 1) return string.Empty;

            return line.Substring(open + 1, close - open - 1).Trim();
        }

        private void FillSources()
        {
            if (source == null) return;

            string selected = source.SelectedItem as string;

            List<string> found = new List<string>();
            foreach (string line in Journal())
            {
                string name = SourceOf(line);
                if (name.Length == 0) continue;

                bool known = false;
                foreach (string existing in found)
                    if (existing.Equals(name, StringComparison.OrdinalIgnoreCase)) { known = true; break; }

                if (!known) found.Add(name);
            }

            found.Sort(StringComparer.OrdinalIgnoreCase);

            filling = true;
            source.Items.Clear();
            source.Items.Add(AnySource);
            foreach (string name in found) source.Items.Add(name);

            int index = selected == null ? 0 : source.Items.IndexOf(selected);
            source.SelectedIndex = index < 0 ? 0 : index;
            filling = false;
        }

        private bool Passes(string line)
        {
            if (onlyErrors != null && onlyErrors.Checked &&
                line.IndexOf("ОШИБКА", StringComparison.OrdinalIgnoreCase) < 0 &&
                line.IndexOf("ERROR", StringComparison.OrdinalIgnoreCase) < 0)
                return false;

            if (source != null && source.SelectedIndex > 0)
            {
                string wanted = source.SelectedItem as string;
                if (wanted != null && !SourceOf(line).Equals(wanted, StringComparison.OrdinalIgnoreCase))
                    return false;
            }

            if (find != null)
            {
                string needle = (find.Text ?? string.Empty).Trim();
                if (needle.Length > 0 && line.IndexOf(needle, StringComparison.OrdinalIgnoreCase) < 0)
                    return false;
            }

            return true;
        }

        private void Fill(bool toEnd)
        {
            if (lines == null) return;

            List<string> journal = Journal();
            lastTotal = journal.Count;

            int keptIndex = lines.SelectedIndex;

            lines.BeginUpdate();
            lines.Items.Clear();

            int shown = 0;
            foreach (string line in journal)
            {
                if (!Passes(line)) continue;

                lines.Items.Add(line);
                shown++;
            }

            lines.EndUpdate();

            if (count != null)
                count.Text = LisunLocale.T("logs.count", shown, journal.Count);

            if (toEnd && lines.Items.Count > 0) lines.TopIndex = Math.Max(0, lines.Items.Count - 1);
            else if (keptIndex >= 0 && keptIndex < lines.Items.Count) lines.SelectedIndex = keptIndex;
        }

        private void Tick()
        {
            if (form == null || form.IsDisposed) return;
            if (follow == null || !follow.Checked) return;

            int total;
            try { total = LisunEngine.SystemLog.Count; }
            catch { return; }

            if (total == lastTotal) return;

            Fill(true);
        }

        private void SetStatus(string text)
        {
            if (status != null) status.Text = text;
        }

        // =====================================================================
        //  Обработчики формы
        // =====================================================================

        public void txtLogFind_TextChanged(object sender, EventArgs e)
        {
            if (filling) return;
            Fill(false);
        }

        public void cmbLogSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (filling) return;
            Fill(false);
        }

        public void chkOnlyErrors_CheckedChanged(object sender, EventArgs e)
        {
            if (filling) return;
            Fill(false);
        }

        public void chkFollow_CheckedChanged(object sender, EventArgs e)
        {
            if (follow != null && follow.Checked) Fill(true);
        }

        public void btnLogRefresh_Click(object sender, EventArgs e)
        {
            FillSources();
            Fill(true);
            SetStatus(LisunLocale.T("logs.refreshed"));
        }

        public void btnLogSave_Click(object sender, EventArgs e)
        {
            if (lines == null || lines.Items.Count == 0)
            {
                SetStatus(LisunLocale.T("logs.nothingToSave"));
                return;
            }

            if (!LisunPermissions.Demand(packageName, LisunPermissions.WriteFiles))
            {
                SetStatus(LisunLocale.T("logs.needWrite"));
                return;
            }

            try
            {
                string folder = Path.Combine(LisunEngine.RootPath, "home", "logs");
                if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);

                string file = Path.Combine(folder,
                    "journal-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".log");

                StringBuilder sb = new StringBuilder();
                foreach (object item in lines.Items) sb.AppendLine(item.ToString());

                File.WriteAllText(file, sb.ToString(), new UTF8Encoding(true));

                SetStatus(LisunLocale.T("logs.saved",
                    CustomFormUtils.ToVirtualPath(file), lines.Items.Count));
            }
            catch (Exception ex)
            {
                SetStatus(" [ERROR] " + ex.Message);
            }
        }

        public void btnLogCopy_Click(object sender, EventArgs e)
        {
            if (lines == null || lines.SelectedItem == null)
            {
                SetStatus(LisunLocale.T("logs.pickLine"));
                return;
            }

            if (!LisunPermissions.Demand(packageName, LisunPermissions.Clipboard))
            {
                SetStatus(LisunLocale.T("logs.needClipboard"));
                return;
            }

            try
            {
                Clipboard.SetText(lines.SelectedItem.ToString());
                SetStatus(LisunLocale.T("logs.copied"));
            }
            catch (Exception ex)
            {
                SetStatus(" [ERROR] " + ex.Message);
            }
        }
    }
}
