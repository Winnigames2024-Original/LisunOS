﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Обновление самой системы: releases.json на сайте — список выпусков,
    /// в каждом есть LisunOS.exe. Отсюда берётся «есть ли версия новее»,
    /// качается новый exe и, по отдельной команде, подменяется текущий.
    ///
    /// Подменить файл, который прямо сейчас запущен, Windows не даёт, поэтому
    /// установка пишет рядом короткий .cmd: он ждёт выхода процесса, переносит
    /// старый exe в .old, кладёт новый и запускает его. Ничего не удаляется
    /// безвозвратно — прежний exe остаётся рядом.
    /// </summary>
    public static class LisunUpdates
    {
        public const string PackageName = "update";

        public const string ReleasesUrl =
            "https://winnigames2024-original.github.io/LisunOS/releases.json";

        /// <summary>Куда качаем: /os/root/updates.</summary>
        public static readonly string UpdatesPath =
            Path.Combine(LisunEngine.RootPath, "root", "updates");

        public static string LatestVersion { get; private set; }
        public static string LatestTag { get; private set; }
        public static string LatestName { get; private set; }
        public static string LatestDate { get; private set; }
        public static string ExeUrl { get; private set; }
        public static long ExeSize { get; private set; }
        public static string ZipUrl { get; private set; }
        public static DateTime CheckedAt { get; private set; }
        public static string LastError { get; private set; }

        /// <summary>Файл, скачанный последней командой update download.</summary>
        public static string DownloadedFile { get; private set; }

        public static readonly List<string> LatestHighlights = new List<string>();

        static LisunUpdates()
        {
            LatestVersion = string.Empty;
            LatestTag = string.Empty;
            LatestName = string.Empty;
            LatestDate = string.Empty;
            ExeUrl = string.Empty;
            ZipUrl = string.Empty;
            LastError = string.Empty;
            DownloadedFile = string.Empty;
            CheckedAt = DateTime.MinValue;
        }

        /// <summary>Адрес списка выпусков: CONFIG releases_url, иначе сайт проекта.</summary>
        public static string Address
        {
            get
            {
                string value;
                if (LisunEngine.RegistryConfig != null &&
                    LisunEngine.RegistryConfig.TryGetValue("releases_url", out value) &&
                    !string.IsNullOrEmpty(value))
                    return value.Trim();

                return ReleasesUrl;
            }
        }

        /// <summary>На сайте версия новее установленной.</summary>
        public static bool Available
        {
            get
            {
                return LatestVersion.Length > 0 &&
                       Compare(LatestVersion, LisunEngine.Version) > 0;
            }
        }

        // =====================================================================
        //  Проверка
        // =====================================================================

        /// <summary>Читает releases.json и запоминает самый свежий выпуск.</summary>
        public static bool Check(out string message)
        {
            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("upd.needNetwork");
                return false;
            }

            string error;
            string body = LisunDownloads.FetchText(Address, 15000, out error);

            if (body == null)
            {
                LastError = error;
                message = LisunLocale.T("upd.checkFailed", error);
                return false;
            }

            if (!ParseReleases(body))
            {
                LastError = LisunLocale.T("upd.badJson");
                message = LisunLocale.T("upd.checkFailed", LastError);
                return false;
            }

            CheckedAt = DateTime.Now;
            LastError = string.Empty;

            message = Available
                ? LisunLocale.T("upd.available", LatestVersion, LisunEngine.Version,
                    ExeSize > 0 ? CustomFormUtils.FormatSize(ExeSize) : "—")
                : LisunLocale.T("upd.current", LisunEngine.Version);

            LisunEngine.Log("[update] " + message.Trim());
            return true;
        }

        private static bool ParseReleases(string body)
        {
            LisunJson.Node root = LisunJson.Parse(body);
            if (root == null) return false;

            LisunJson.Node list = root.IsArray ? root : root.Child("releases");
            if (list == null || !list.IsArray || list.Array.Count == 0) return false;

            LisunJson.Node best = null;
            string bestVersion = string.Empty;

            foreach (LisunJson.Node node in list.Array)
            {
                if (!node.IsObject) continue;

                string version = Text(node, "version");
                if (version.Length == 0) version = Text(node, "tag").TrimStart('v', 'V');
                if (version.Length == 0) continue;

                LisunJson.Node pre = node.Child("prerelease");
                if (pre != null && pre.Boolean) continue;

                if (bestVersion.Length == 0 || Compare(version, bestVersion) > 0)
                {
                    bestVersion = version;
                    best = node;
                }
            }

            if (best == null) return false;

            LatestVersion = bestVersion;
            LatestTag = Text(best, "tag");
            LatestName = Text(best, "name");
            LatestDate = Text(best, "date");

            ExeUrl = string.Empty;
            ZipUrl = string.Empty;
            ExeSize = 0;

            LisunJson.Node assets = best.Child("assets");
            if (assets != null && assets.IsArray)
            {
                foreach (LisunJson.Node asset in assets.Array)
                {
                    if (!asset.IsObject) continue;

                    string name = Text(asset, "name");
                    string url = Text(asset, "url");
                    if (url.Length == 0) continue;

                    LisunJson.Node size = asset.Child("size");

                    if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase))
                    {
                        ExeUrl = url;
                        if (size != null) ExeSize = (long)size.Number;
                    }
                    else if (name.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                    {
                        ZipUrl = url;
                    }
                }
            }

            LatestHighlights.Clear();

            LisunJson.Node highlights = best.Child(
                LisunLocale.Language == LisunLanguage.English ? "highlights_en" : "highlights_ru");

            if (highlights != null && highlights.IsArray)
                LatestHighlights.AddRange(highlights.AsTextList());

            return true;
        }

        private static string Text(LisunJson.Node node, string key)
        {
            LisunJson.Node child = node.Child(key);
            return child == null ? string.Empty : child.AsText().Trim();
        }

        /// <summary>Сравнивает 1.8.0 и 1.7.3 по числам, а не по алфавиту.</summary>
        public static int Compare(string left, string right)
        {
            string[] a = (left ?? string.Empty).Split('.');
            string[] b = (right ?? string.Empty).Split('.');

            int count = Math.Max(a.Length, b.Length);

            for (int index = 0; index < count; index++)
            {
                int first = index < a.Length ? Number(a[index]) : 0;
                int second = index < b.Length ? Number(b[index]) : 0;

                if (first != second) return first > second ? 1 : -1;
            }

            return 0;
        }

        private static int Number(string value)
        {
            StringBuilder digits = new StringBuilder();

            foreach (char symbol in value ?? string.Empty)
            {
                if (symbol >= '0' && symbol <= '9') digits.Append(symbol);
                else break;
            }

            int result;
            if (int.TryParse(digits.ToString(), NumberStyles.Integer,
                             CultureInfo.InvariantCulture, out result))
                return result;

            return 0;
        }

        // =====================================================================
        //  Загрузка нового exe
        // =====================================================================

        /// <summary>Качает LisunOS.exe нового выпуска в /os/root/updates.</summary>
        public static bool Download(out string message)
        {
            if (LatestVersion.Length == 0)
            {
                string note;
                if (!Check(out note))
                {
                    message = note;
                    return false;
                }
            }

            if (!Available)
            {
                message = LisunLocale.T("upd.current", LisunEngine.Version);
                return false;
            }

            if (ExeUrl.Length == 0)
            {
                message = LisunLocale.T("upd.noAsset", LatestVersion);
                return false;
            }

            try
            {
                if (!Directory.Exists(UpdatesPath)) Directory.CreateDirectory(UpdatesPath);
            }
            catch { }

            string target = Path.Combine(UpdatesPath, "LisunOS-" + LatestVersion + ".exe");

            try { if (File.Exists(target)) File.Delete(target); }
            catch { }

            string report;
            LisunDownload download = LisunDownloads.Fetch("LisunOS-" + LatestVersion,
                new string[] { ExeUrl }, target, string.Empty, out report);

            if (download.State != LisunDownloadState.Done)
            {
                message = report;
                return false;
            }

            if (!LooksLikeExe(target))
            {
                try { File.Delete(target); }
                catch { }

                message = LisunLocale.T("upd.notExe");
                return false;
            }

            if (ExeSize > 0 && Math.Abs(download.Received - ExeSize) > 4096)
            {
                try { File.Delete(target); }
                catch { }

                message = LisunLocale.T("upd.wrongSize",
                    CustomFormUtils.FormatSize(download.Received),
                    CustomFormUtils.FormatSize(ExeSize));
                return false;
            }

            DownloadedFile = target;

            message = LisunLocale.T("upd.downloaded", LatestVersion,
                CustomFormUtils.ToVirtualPath(target),
                CustomFormUtils.FormatSize(download.Received));

            LisunEngine.Log("[update] " + message.Trim());
            return true;
        }

        /// <summary>Подпись MZ: вместо exe могла прийти страница с ошибкой.</summary>
        private static bool LooksLikeExe(string path)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                {
                    if (stream.Length < 1024) return false;

                    return stream.ReadByte() == 0x4D && stream.ReadByte() == 0x5A;
                }
            }
            catch { return false; }
        }

        // =====================================================================
        //  Подмена exe
        // =====================================================================

        /// <summary>
        /// Ставит скачанный выпуск: пишет .cmd рядом с exe и выходит.
        /// Скрипт ждёт закрытия процесса, переносит старый файл в .old
        /// и запускает новый.
        /// </summary>
        public static bool Install(out string message)
        {
            if (DownloadedFile.Length == 0 || !File.Exists(DownloadedFile))
            {
                string note;
                if (!Download(out note))
                {
                    message = note;
                    return false;
                }
            }

            string current;

            try { current = Application.ExecutablePath; }
            catch (Exception ex)
            {
                message = LisunLocale.T("upd.noSelf", ex.Message);
                return false;
            }

            if (string.IsNullOrEmpty(current) || !File.Exists(current))
            {
                message = LisunLocale.T("upd.noSelf", current ?? "—");
                return false;
            }

            string script = Path.Combine(LisunEngine.TempPath, "lisunos-update.cmd");
            int pid = Process.GetCurrentProcess().Id;

            StringBuilder cmd = new StringBuilder();
            cmd.AppendLine("@echo off");
            cmd.AppendLine("chcp 65001 >nul");
            cmd.AppendLine("echo LisunOS " + LatestVersion);
            // Ждём, пока закроется наш процесс: подменить запущенный exe нельзя.
            cmd.AppendLine(":wait");
            cmd.AppendLine("tasklist /fi \"PID eq " + pid + "\" | find \"" + pid + "\" >nul");
            cmd.AppendLine("if not errorlevel 1 (");
            cmd.AppendLine("  timeout /t 1 /nobreak >nul");
            cmd.AppendLine("  goto wait");
            cmd.AppendLine(")");
            cmd.AppendLine("if exist \"" + current + ".old\" del /q \"" + current + ".old\"");
            cmd.AppendLine("move /y \"" + current + "\" \"" + current + ".old\" >nul");
            cmd.AppendLine("copy /y \"" + DownloadedFile + "\" \"" + current + "\" >nul");
            cmd.AppendLine("if errorlevel 1 (");
            cmd.AppendLine("  move /y \"" + current + ".old\" \"" + current + "\" >nul");
            cmd.AppendLine(")");
            cmd.AppendLine("start \"\" \"" + current + "\"");
            cmd.AppendLine("del /q \"%~f0\"");

            try
            {
                if (!Directory.Exists(LisunEngine.TempPath))
                    Directory.CreateDirectory(LisunEngine.TempPath);

                File.WriteAllText(script, cmd.ToString(), Encoding.GetEncoding(866));
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("upd.scriptFailed", ex.Message);
                return false;
            }

            try
            {
                ProcessStartInfo info = new ProcessStartInfo("cmd.exe", "/c \"" + script + "\"");
                info.CreateNoWindow = true;
                info.UseShellExecute = false;
                info.WorkingDirectory = Path.GetDirectoryName(current);

                Process.Start(info);
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("upd.startFailed", ex.Message);
                return false;
            }

            message = LisunLocale.T("upd.installing", LatestVersion,
                CustomFormUtils.ToVirtualPath(Path.GetFileName(current) + ".old"));

            LisunEngine.Log("[update] " + message.Trim());
            return true;
        }

        // =====================================================================
        //  Текст
        // =====================================================================

        public static string StatusText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("upd.header"));
            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("upd.fieldInstalled") + LisunEngine.Version +
                          " \"" + LisunEngine.Codename + "\"");

            if (LatestVersion.Length == 0)
            {
                sb.AppendLine("   " + LisunLocale.T("upd.fieldLatest") + LisunLocale.T("upd.notChecked"));
                sb.AppendLine();
                sb.AppendLine("   " + LisunLocale.T("upd.hint"));
                return sb.ToString();
            }

            sb.AppendLine("   " + LisunLocale.T("upd.fieldLatest") + LatestVersion +
                          (LatestDate.Length > 0 ? "  (" + LatestDate + ")" : string.Empty));

            if (ExeSize > 0)
                sb.AppendLine("   " + LisunLocale.T("upd.fieldSize") +
                              CustomFormUtils.FormatSize(ExeSize));

            sb.AppendLine("   " + LisunLocale.T("upd.fieldState") +
                (Available ? LisunLocale.T("upd.stateNewer") : LisunLocale.T("upd.stateSame")));

            if (CheckedAt != DateTime.MinValue)
                sb.AppendLine("   " + LisunLocale.T("upd.fieldChecked") +
                              CheckedAt.ToString("HH:mm:ss"));

            if (DownloadedFile.Length > 0 && File.Exists(DownloadedFile))
                sb.AppendLine("   " + LisunLocale.T("upd.fieldFile") +
                              CustomFormUtils.ToVirtualPath(DownloadedFile));

            if (LatestHighlights.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("   " + LisunLocale.T("upd.whatsNew"));

                foreach (string line in LatestHighlights)
                    sb.AppendLine("      • " + line);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("upd.hint"));

            return sb.ToString();
        }
    }
}
