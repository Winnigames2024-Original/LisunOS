﻿namespace LisunOS
{
    partial class WebViewForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlNav;
        private System.Windows.Forms.Panel pnlUrl;
        private System.Windows.Forms.TextBox txtBrowserUrl;
        private System.Windows.Forms.Button btnNavBack;
        private System.Windows.Forms.Button btnNavForward;
        private System.Windows.Forms.Button btnReload;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnGo;
        private System.Windows.Forms.Button btnEngine;
        private System.Windows.Forms.Button btnCloseBrowser;
        private System.Windows.Forms.WebBrowser miniWebBrowser;
        private System.Windows.Forms.Label lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlNav = new System.Windows.Forms.Panel();
            this.pnlUrl = new System.Windows.Forms.Panel();
            this.txtBrowserUrl = new System.Windows.Forms.TextBox();
            this.btnNavBack = new System.Windows.Forms.Button();
            this.btnNavForward = new System.Windows.Forms.Button();
            this.btnReload = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.btnGo = new System.Windows.Forms.Button();
            this.btnEngine = new System.Windows.Forms.Button();
            this.btnCloseBrowser = new System.Windows.Forms.Button();
            this.miniWebBrowser = new System.Windows.Forms.WebBrowser();
            this.lblStatus = new System.Windows.Forms.Label();

            this.pnlNav.SuspendLayout();
            this.pnlUrl.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBrowserUrl
            // 
            this.txtBrowserUrl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(36)))), ((int)(((byte)(46)))));
            this.txtBrowserUrl.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtBrowserUrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtBrowserUrl.Font = new System.Drawing.Font("Consolas", 10F);
            this.txtBrowserUrl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(214)))), ((int)(((byte)(224)))));
            this.txtBrowserUrl.Multiline = true;
            this.txtBrowserUrl.WordWrap = false;
            this.txtBrowserUrl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBrowserUrl_KeyDown);
            // 
            // pnlUrl
            // 
            this.pnlUrl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(36)))), ((int)(((byte)(46)))));
            this.pnlUrl.Controls.Add(this.txtBrowserUrl);
            this.pnlUrl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUrl.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.pnlUrl.Padding = new System.Windows.Forms.Padding(12, 7, 12, 7);
            // 
            // btnNavBack
            // 
            this.btnNavBack.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnNavBack.Size = new System.Drawing.Size(40, 32);
            this.btnNavBack.Text = "←";
            this.btnNavBack.Click += new System.EventHandler(this.btnNavBack_Click);
            // 
            // btnNavForward
            // 
            this.btnNavForward.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnNavForward.Size = new System.Drawing.Size(40, 32);
            this.btnNavForward.Text = "→";
            this.btnNavForward.Click += new System.EventHandler(this.btnNavForward_Click);
            // 
            // btnReload
            // 
            this.btnReload.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnReload.Size = new System.Drawing.Size(40, 32);
            this.btnReload.Text = "⟳";
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // btnHome
            // 
            this.btnHome.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnHome.Size = new System.Drawing.Size(40, 32);
            this.btnHome.Text = "⌂";
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // btnGo
            // 
            this.btnGo.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnGo.Size = new System.Drawing.Size(86, 32);
            this.btnGo.Text = "Перейти";
            this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
            // 
            // btnEngine
            // 
            this.btnEngine.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnEngine.Size = new System.Drawing.Size(104, 32);
            this.btnEngine.Text = "Google";
            this.btnEngine.Click += new System.EventHandler(this.btnEngine_Click);
            // 
            // btnCloseBrowser
            // 
            this.btnCloseBrowser.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCloseBrowser.Size = new System.Drawing.Size(118, 32);
            this.btnCloseBrowser.Text = "✕  Свернуть";
            this.btnCloseBrowser.Click += new System.EventHandler(this.btnCloseBrowser_Click);
            // 
            // pnlNav
            // 
            this.pnlNav.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.pnlNav.Controls.Add(this.pnlUrl);
            this.pnlNav.Controls.Add(this.btnHome);
            this.pnlNav.Controls.Add(this.btnReload);
            this.pnlNav.Controls.Add(this.btnNavForward);
            this.pnlNav.Controls.Add(this.btnNavBack);
            this.pnlNav.Controls.Add(this.btnGo);
            this.pnlNav.Controls.Add(this.btnEngine);
            this.pnlNav.Controls.Add(this.btnCloseBrowser);
            this.pnlNav.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNav.Padding = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.pnlNav.Size = new System.Drawing.Size(900, 48);
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.lblStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblStatus.Font = new System.Drawing.Font("Consolas", 9F);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.lblStatus.Padding = new System.Windows.Forms.Padding(14, 0, 14, 0);
            this.lblStatus.Size = new System.Drawing.Size(900, 26);
            this.lblStatus.Text = "Готов";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // miniWebBrowser
            // 
            this.miniWebBrowser.AllowWebBrowserDrop = false;
            this.miniWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.miniWebBrowser.IsWebBrowserContextMenuEnabled = true;
            this.miniWebBrowser.ScriptErrorsSuppressed = true;
            this.miniWebBrowser.Navigating += new System.Windows.Forms.WebBrowserNavigatingEventHandler(this.miniWebBrowser_Navigating);
            this.miniWebBrowser.Navigated += new System.Windows.Forms.WebBrowserNavigatedEventHandler(this.miniWebBrowser_Navigated);
            this.miniWebBrowser.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.miniWebBrowser_DocumentCompleted);
            // 
            // WebViewForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(900, 560);
            this.Controls.Add(this.miniWebBrowser);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pnlNav);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WebViewForm";
            this.Text = "LisunOS WebView";

            this.pnlNav.ResumeLayout(false);
            this.pnlUrl.ResumeLayout(false);
            this.pnlUrl.PerformLayout();
            this.ResumeLayout(false);
        }
    }
}
