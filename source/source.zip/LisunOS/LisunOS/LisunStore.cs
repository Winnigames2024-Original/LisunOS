﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Каталог приложений LisunOS: встроенные пакеты плюс список из сети.
    /// Сетевой каталог — обычный catalog.json; адрес можно заменить ключом
    /// store_url, чтобы держать свой каталог.
    /// </summary>
    public static class LisunStore
    {
        public const string PackageName = "store";

        public sealed class StoreItem
        {
            public string Name = string.Empty;
            public string Title = string.Empty;
            public string Description = string.Empty;
            public string Version = string.Empty;
            public string Author = string.Empty;
            public string Command = string.Empty;
            public string Url = string.Empty;
            public bool BuiltIn;

            public readonly List<string> Permissions = new List<string>();

            /// <summary>Установлен ли пакет прямо сейчас.</summary>
            public bool Installed
            {
                get { return LisunOSInstallerShell.FindInstalledPackage(Name) != null; }
            }

            /// <summary>Версия, установленная в системе, либо пустая строка.</summary>
            public string InstalledVersion
            {
                get
                {
                    string directory = LisunOSInstallerShell.FindInstalledPackage(Name);
                    if (directory == null) return string.Empty;

                    LisunManifest manifest = LisunOSInstallerShell.ReadManifest(directory);
                    return manifest == null ? string.Empty : manifest.Version;
                }
            }
        }

        /// <summary>Адрес каталога; переопределяется ключом store_url.</summary>
        public static string CatalogUrl
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData.TryGetValue("store_url", out value) && value.Length > 10)
                    return value;

                return "https://raw.githubusercontent.com/Winnigames2024-Original/LisunOS/main/apps/catalog.json";
            }
        }

        private static readonly List<StoreItem> remote = new List<StoreItem>();
        private static DateTime fetchedAt = DateTime.MinValue;
        private static string lastError = string.Empty;

        public static string LastError
        {
            get { return lastError; }
        }

        public static DateTime FetchedAt
        {
            get { return fetchedAt; }
        }

        /// <summary>Встроенные пакеты плюс всё, что удалось прочитать из сети.</summary>
        public static List<StoreItem> Items()
        {
            List<StoreItem> result = new List<StoreItem>();

            foreach (LisunRepository.RepoPackage package in LisunRepository.Catalog())
            {
                StoreItem item = new StoreItem();
                item.Name = package.Name;
                item.Version = package.Version;
                item.Command = package.Command;
                item.BuiltIn = true;

                bool english = LisunLocale.Language == LisunLanguage.English;
                item.Title = english ? package.TitleEn : package.TitleRu;
                item.Description = english ? package.DescriptionEn : package.DescriptionRu;

                item.Permissions.AddRange(package.Permissions);
                result.Add(item);
            }

            foreach (StoreItem item in remote)
            {
                bool known = false;
                foreach (StoreItem existing in result)
                    if (existing.Name.Equals(item.Name, StringComparison.OrdinalIgnoreCase)) known = true;

                if (!known) result.Add(item);
            }

            result.Sort((left, right) => string.Compare(left.Name, right.Name, StringComparison.OrdinalIgnoreCase));
            return result;
        }

        /// <summary>
        /// Пакеты, прочитанные из catalog.json на сайте, как они есть —
        /// без склейки со встроенным каталогом. Нужно apt, чтобы предпочесть
        /// свежую версию с сайта встроенной копии того же имени.
        /// </summary>
        public static List<StoreItem> Remote()
        {
            return new List<StoreItem>(remote);
        }

        /// <summary>Ищет пакет с сайта по имени или по команде.</summary>
        public static StoreItem FindRemote(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            name = name.Trim();

            foreach (StoreItem item in remote)
                if (item.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return item;

            foreach (StoreItem item in remote)
                if (item.Command.Length > 0 && item.Command.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return item;

            // «superuser» и «SuperUserApp» — одно и то же приложение.
            foreach (StoreItem item in remote)
                if (SameName(item.Name, name) || SameName(item.Command, name) ||
                    SameName(item.Title, name)) return item;

            return null;
        }

        /// <summary>
        /// Сравнение имён по-человечески: регистр не важен, суффикс «app»
        /// и знаки не важны. superuser = SuperUserApp = super-user.
        /// </summary>
        public static bool SameName(string left, string right)
        {
            return Normalize(left).Length > 0 && Normalize(left) == Normalize(right);
        }

        public static string Normalize(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;

            StringBuilder sb = new StringBuilder();

            foreach (char symbol in value.Trim().ToLowerInvariant())
                if (char.IsLetterOrDigit(symbol)) sb.Append(symbol);

            string text = sb.ToString();

            if (text.Length > 3 && text.EndsWith("app", StringComparison.Ordinal))
                text = text.Substring(0, text.Length - 3);

            return text;
        }

        /// <summary>Читает catalog.json. Требуется право network.</summary>
        public static bool Refresh(string requester, out string message)
        {
            if (!LisunPermissions.Demand(requester ?? PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("store.needNetwork");
                return false;
            }

            try
            {
                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(CatalogUrl);
                request.UserAgent = "LisunOS/" + LisunEngine.Version;
                request.Timeout = 15000;

                string body;
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                    body = reader.ReadToEnd();

                int count = Parse(body);

                fetchedAt = DateTime.Now;
                lastError = string.Empty;

                message = LisunLocale.T("store.refreshed", count);
                LisunEngine.Log("[store] " + message.Trim());
                return true;
            }
            catch (Exception ex)
            {
                lastError = ex.Message;
                message = LisunLocale.T("store.refreshFailed", ex.Message);
                return false;
            }
        }

        private static int Parse(string body)
        {
            remote.Clear();

            LisunJson.Node root = LisunJson.Parse(body);
            if (root == null) return 0;

            LisunJson.Node list = root.IsArray ? root : root.Child("packages");
            if (list == null || !list.IsArray) return 0;

            foreach (LisunJson.Node node in list.Array)
            {
                if (!node.IsObject) continue;

                StoreItem item = new StoreItem();
                item.Name = Text(node, "name");
                if (item.Name.Length == 0) continue;

                bool english = LisunLocale.Language == LisunLanguage.English;

                item.Version = Text(node, "version");
                item.Author = Text(node, "author");
                item.Command = Text(node, "command");
                item.Url = Text(node, "url");
                item.Title = Text(node, english ? "title_en" : "title_ru");
                item.Description = Text(node, english ? "description_en" : "description_ru");

                if (item.Title.Length == 0) item.Title = Text(node, "title");
                if (item.Description.Length == 0) item.Description = Text(node, "description");

                LisunJson.Node rights = node.Child("permissions");
                if (rights != null) item.Permissions.AddRange(rights.AsTextList());

                remote.Add(item);
            }

            return remote.Count;
        }

        private static string Text(LisunJson.Node node, string key)
        {
            LisunJson.Node child = node.Child(key);
            return child == null ? string.Empty : child.AsText().Trim();
        }

        /// <summary>Устанавливает пакет: встроенный — из каталога, сетевой — по ссылке.</summary>
        public static bool Install(StoreItem item, bool elevated, out string message)
        {
            if (item == null)
            {
                message = LisunLocale.T("store.pickFirst");
                return false;
            }

            if (item.BuiltIn) return LisunRepository.Install(item.Name, elevated, out message);

            if (item.Url.Length == 0)
            {
                message = LisunLocale.T("store.noUrl", item.Name);
                return false;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("store.needNetwork");
                return false;
            }

            return DownloadAndInstall(item, elevated, out message);
        }

        /// <summary>
        /// Ссылка ведёт на официальный сайт проекта. Такому пакету права
        /// выдаются при установке сами: выбор уже сделан в каталоге.
        /// </summary>
        public static bool IsOfficial(string url)
        {
            if (string.IsNullOrEmpty(url)) return false;

            string value = url.ToLowerInvariant();

            return value.Contains("winnigames2024-original.github.io/lisunos") ||
                   value.Contains("github.com/winnigames2024-original/lisunos") ||
                   value.Contains("raw.githubusercontent.com/winnigames2024-original/lisunos");
        }

        /// <summary>Качает .lnsh во временную папку и отдаёт установщику.</summary>
        private static bool DownloadAndInstall(StoreItem item, bool elevated, out string message)
        {
            string archive = Path.Combine(LisunEngine.TempPath, item.Name + ".lnsh");

            try
            {
                if (!Directory.Exists(LisunEngine.TempPath)) Directory.CreateDirectory(LisunEngine.TempPath);

                ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(item.Url);
                request.UserAgent = "LisunOS/" + LisunEngine.Version;
                request.Timeout = 30000;
                request.ReadWriteTimeout = 60000;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream input = response.GetResponseStream())
                using (FileStream output = new FileStream(archive, FileMode.Create, FileAccess.Write))
                {
                    byte[] chunk = new byte[16384];
                    int read;
                    while (input != null && (read = input.Read(chunk, 0, chunk.Length)) > 0)
                        output.Write(chunk, 0, read);
                }

                // Пакет — это ZIP: проверяем подпись, иначе пришла страница с ошибкой.
                bool looksRight;
                using (FileStream check = File.OpenRead(archive))
                    looksRight = check.Length > 100 && check.ReadByte() == 0x50 && check.ReadByte() == 0x4B;

                if (!looksRight)
                {
                    message = LisunLocale.T("store.notPackage", item.Name);
                    return false;
                }

                LisunEngine.Log("[store] " + LisunLocale.T("store.downloaded", item.Name,
                    CustomFormUtils.FormatSize(new FileInfo(archive).Length)).Trim());

                bool official = IsOfficial(item.Url);
                bool previous = LisunPermissions.TrustedSource;

                if (official) LisunPermissions.TrustedSource = true;

                bool installed;
                try { installed = LisunOSInstallerShell.InstallPackage(archive, elevated); }
                finally { LisunPermissions.TrustedSource = previous; }

                message = installed
                    ? LisunLocale.T("store.installDone", item.Name)
                    : LisunLocale.T("store.installFailed", item.Name);

                return installed;
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("store.installFailed", item.Name + ": " + ex.Message);
                return false;
            }
            finally
            {
                try { if (File.Exists(archive)) File.Delete(archive); }
                catch { }
            }
        }

        /// <summary>
        /// «store install apps.all» — поставить всё, что есть в каталоге.
        /// Установленное пропускается, неудачи не останавливают остальных:
        /// в конце видно, что встало, что уже было и что не получилось.
        /// </summary>
        public static string InstallAll(bool elevated)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("store.allHeader"));
            sb.AppendLine();

            string note;
            if (remote.Count == 0)
            {
                Refresh(PackageName, out note);
                sb.AppendLine("   " + note.Trim());
                sb.AppendLine();
            }

            List<StoreItem> list = Items();

            int installed = 0;
            int skipped = 0;
            int failed = 0;

            foreach (StoreItem item in list)
            {
                if (item.Installed)
                {
                    skipped++;
                    sb.AppendLine("   [ -- ] " + Column(item.Name) + LisunLocale.T("store.allSkip"));
                    continue;
                }

                string message;
                bool done = Install(item, elevated, out message);

                if (done) installed++;
                else failed++;

                sb.AppendLine("   " + (done ? "[ OK ] " : "[FAIL] ") + Column(item.Name) + message.Trim());
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("store.allDone", installed, skipped, failed));

            LisunEngine.Log("[store] " + LisunLocale.T("store.allDone", installed, skipped, failed).Trim());
            return sb.ToString();
        }

        private static string Column(string value)
        {
            if (value == null) value = string.Empty;

            return value.Length >= 18 ? value + " " : value.PadRight(18);
        }

        /// <summary>Таблица каталога для команды «store».</summary>
        public static string ListText()
        {
            List<StoreItem> items = Items();

            StringBuilder sb = new StringBuilder(LisunLocale.T("store.title", items.Count) + Environment.NewLine);

            foreach (StoreItem item in items)
            {
                string state = item.Installed
                    ? LisunLocale.T("store.installed", item.InstalledVersion)
                    : item.BuiltIn ? LisunLocale.T("store.builtIn") : LisunLocale.T("store.available");

                sb.AppendLine("   • " + item.Name.PadRight(16) + " v" + item.Version.PadRight(9) + " " + state);

                if (item.Description.Length > 0) sb.AppendLine("       " + item.Description);
            }

            if (lastError.Length > 0) sb.AppendLine("   " + LisunLocale.T("store.refreshFailed", lastError));

            return sb.ToString().TrimEnd();
        }
    }
}
