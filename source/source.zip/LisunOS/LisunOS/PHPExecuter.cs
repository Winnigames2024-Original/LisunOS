﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace LisunOS.Php
{
    /// <summary>
    /// Окружение запуска: корень сайта, текущий файл, суперглобальные массивы,
    /// заголовки ответа и сессия. Один экземпляр на один HTTP-запрос.
    /// </summary>
    public class PhpContext
    {
        public string DocumentRoot = "";
        public string CurrentFile = "";
        public string ScriptFile = "";

        public readonly List<string> Headers = new List<string>();
        public readonly Dictionary<string, string> Cookies =
            new Dictionary<string, string>(StringComparer.Ordinal);

        public int StatusCode = 200;
        public string SessionId = "";
        public bool SessionStarted;

        public string ResolveInclude(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;

            try
            {
                List<string> candidates = new List<string>();

                if (Path.IsPathRooted(path)) candidates.Add(path);
                else
                {
                    string directory = string.IsNullOrEmpty(CurrentFile)
                        ? DocumentRoot
                        : Path.GetDirectoryName(CurrentFile);

                    candidates.Add(Path.Combine(directory ?? DocumentRoot, path));
                    candidates.Add(Path.Combine(DocumentRoot, path));
                }

                foreach (string candidate in candidates)
                {
                    string full = Path.GetFullPath(candidate);
                    if (!IsInsideRoot(full)) continue;
                    if (File.Exists(full)) return full;
                }
            }
            catch { }

            return null;
        }

        public bool IsInsideRoot(string path)
        {
            try
            {
                string root = Path.GetFullPath(DocumentRoot).TrimEnd(Path.DirectorySeparatorChar);
                return Path.GetFullPath(path).StartsWith(root, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public string ReadFile(string path)
        {
            return LisunCrypto.ReadAllText(path);
        }

        /// <summary>Путь внутри корня сайта или null, если выходит за его пределы.</summary>
        public string SafePath(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;

            try
            {
                string full = Path.IsPathRooted(path)
                    ? Path.GetFullPath(path)
                    : Path.GetFullPath(Path.Combine(
                        string.IsNullOrEmpty(CurrentFile) ? DocumentRoot : Path.GetDirectoryName(CurrentFile),
                        path));

                return IsInsideRoot(full) ? full : null;
            }
            catch { return null; }
        }
    }

    /// <summary>Результат исполнения PHP-страницы.</summary>
    public class PhpResult
    {
        public string Body = "";
        public string ContentType = "text/html; charset=utf-8";
        public int StatusCode = 200;
        public readonly List<string> Headers = new List<string>();
        public string Error;

        public bool Ok { get { return Error == null; } }
    }

    /// <summary>
    /// Запуск PHP-страниц встроенным интерпретатором LisunOS.
    /// Внешний php-cgi.exe не требуется.
    /// </summary>
    public static class PhpExecuter
    {
        public const string EngineName = "LisunOS PHP Engine";
        public const string EngineVersion = "1.0";

        private static readonly string SessionDirectory =
            Path.Combine(LisunEngine.TempPath, "php-sessions");

        /// <summary>
        /// Исполняет файл страницы.
        /// query — строка запроса, post — тело формы, cookies — заголовок Cookie.
        /// </summary>
        public static PhpResult Execute(string scriptPath, string documentRoot, string method,
            string query, string postBody, string cookieHeader, string requestUri)
        {
            PhpResult result = new PhpResult();

            if (!File.Exists(scriptPath))
            {
                result.Error = "файл не найден: " + scriptPath;
                return result;
            }

            Interp interp = new Interp();

            PhpContext context = new PhpContext();
            context.DocumentRoot = documentRoot;
            context.ScriptFile = scriptPath;
            context.CurrentFile = scriptPath;
            interp.Context = context;

            PhpArray get = ParseQuery(query);
            PhpArray post = ParseQuery(postBody);
            PhpArray cookies = ParseCookies(cookieHeader);

            PhpArray request = new PhpArray();
            MergeInto(request, get);
            MergeInto(request, post);
            MergeInto(request, cookies);

            interp.Globals.Set("_GET", get);
            interp.Globals.Set("_POST", post);
            interp.Globals.Set("_COOKIE", cookies);
            interp.Globals.Set("_REQUEST", request);
            interp.Globals.Set("_FILES", new PhpArray());
            interp.Globals.Set("_ENV", new PhpArray());
            interp.Globals.Set("_SESSION", new PhpArray());
            interp.Globals.Set("_SERVER", BuildServer(context, method, query, requestUri, postBody, cookieHeader));

            string sessionId;
            if (cookies.Has("PHPSESSID")) sessionId = PhpOps.ToStr(cookies.Get("PHPSESSID"));
            else sessionId = Guid.NewGuid().ToString("N");

            context.SessionId = sessionId;

            try
            {
                string source = LisunCrypto.ReadAllText(scriptPath);
                interp.Run(source);

                result.Body = interp.Out.ToString();
                result.StatusCode = context.StatusCode;

                foreach (string header in context.Headers)
                {
                    result.Headers.Add(header);

                    if (header.StartsWith("Content-Type:", StringComparison.OrdinalIgnoreCase))
                        result.ContentType = header.Substring(13).Trim();
                }

                if (context.SessionStarted) SaveSession(context.SessionId, interp.Globals.Get("_SESSION") as PhpArray);
            }
            catch (PhpErrorException ex)
            {
                result.Body = interp.Out.ToString();
                result.Error = "строка " + ex.Line + ": " + ex.Message;
            }
            catch (Exception ex)
            {
                result.Body = interp.Out.ToString();
                result.Error = ex.Message;
            }
            finally
            {
                // Файлы, открытые через fopen, не должны переживать запрос.
                PhpLibrary.CloseStreams();
            }

            return result;
        }

        private static void MergeInto(PhpArray target, PhpArray source)
        {
            foreach (object key in source.Keys) target.Set(key, source.Get(key));
        }

        private static PhpArray BuildServer(PhpContext context, string method, string query,
            string requestUri, string postBody, string cookieHeader)
        {
            PhpArray server = new PhpArray();

            server.Set("REQUEST_METHOD", string.IsNullOrEmpty(method) ? "GET" : method.ToUpperInvariant());
            server.Set("QUERY_STRING", query ?? "");
            server.Set("REQUEST_URI", requestUri ?? "/");
            server.Set("SCRIPT_FILENAME", context.ScriptFile);
            server.Set("SCRIPT_NAME", "/" + Path.GetFileName(context.ScriptFile));
            server.Set("PHP_SELF", "/" + Path.GetFileName(context.ScriptFile));
            server.Set("DOCUMENT_ROOT", context.DocumentRoot);
            server.Set("SERVER_SOFTWARE", EngineName + "/" + EngineVersion);
            server.Set("SERVER_PROTOCOL", "HTTP/1.1");
            server.Set("GATEWAY_INTERFACE", "LisunOS/1.0");
            server.Set("REMOTE_ADDR", "127.0.0.1");
            server.Set("HTTP_COOKIE", cookieHeader ?? "");
            server.Set("CONTENT_LENGTH", (postBody ?? "").Length);
            server.Set("REQUEST_TIME", DateTimeOffset.Now.ToUnixTimeSeconds());

            return server;
        }

        // ---------- разбор запроса ----------

        public static PhpArray ParseQuery(string text)
        {
            PhpArray array = new PhpArray();
            if (string.IsNullOrEmpty(text)) return array;

            foreach (string pair in text.Split('&'))
            {
                if (pair.Length == 0) continue;

                int equals = pair.IndexOf('=');
                string key = equals < 0 ? pair : pair.Substring(0, equals);
                string value = equals < 0 ? "" : pair.Substring(equals + 1);

                key = Decode(key);
                value = Decode(value);

                // name[] и name[key]
                int bracket = key.IndexOf('[');
                if (bracket > 0 && key.EndsWith("]"))
                {
                    string name = key.Substring(0, bracket);
                    string inner = key.Substring(bracket + 1, key.Length - bracket - 2);

                    PhpArray nested = array.Get(name) as PhpArray;
                    if (nested == null) { nested = new PhpArray(); array.Set(name, nested); }

                    if (inner.Length == 0) nested.Append(value);
                    else nested.Set(inner, value);
                    continue;
                }

                array.Set(key, value);
            }

            return array;
        }

        private static string Decode(string text)
        {
            try { return Uri.UnescapeDataString(text.Replace("+", " ")); }
            catch { return text; }
        }

        public static PhpArray ParseCookies(string header)
        {
            PhpArray array = new PhpArray();
            if (string.IsNullOrEmpty(header)) return array;

            foreach (string pair in header.Split(';'))
            {
                string trimmed = pair.Trim();
                if (trimmed.Length == 0) continue;

                int equals = trimmed.IndexOf('=');
                if (equals <= 0) continue;

                array.Set(Decode(trimmed.Substring(0, equals).Trim()), Decode(trimmed.Substring(equals + 1)));
            }

            return array;
        }

        // ---------- сессии ----------

        public static PhpArray LoadSession(string sessionId)
        {
            PhpArray session = new PhpArray();

            try
            {
                string path = SessionPath(sessionId);
                if (!File.Exists(path)) return session;

                foreach (string line in File.ReadAllLines(path))
                {
                    int split = line.IndexOf('\t');
                    if (split <= 0) continue;

                    string key = line.Substring(0, split);
                    string value = line.Substring(split + 1);

                    if (value.StartsWith("b:")) session.Set(key, value == "b:1");
                    else if (value.StartsWith("i:")) session.Set(key, long.Parse(value.Substring(2)));
                    else session.Set(key, Unescape(value.Substring(2)));
                }
            }
            catch { }

            return session;
        }

        public static void SaveSession(string sessionId, PhpArray session)
        {
            try
            {
                if (session == null) return;
                if (!Directory.Exists(SessionDirectory)) Directory.CreateDirectory(SessionDirectory);

                List<string> lines = new List<string>();
                foreach (object key in session.Keys)
                {
                    object value = session.Get(key);
                    string encoded;

                    if (value is bool) encoded = (bool)value ? "b:1" : "b:0";
                    else if (value is long) encoded = "i:" + (long)value;
                    else encoded = "s:" + Escape(PhpOps.ToStr(value));

                    lines.Add(PhpOps.ToStr(key) + "\t" + encoded);
                }

                File.WriteAllLines(SessionPath(sessionId), lines, new UTF8Encoding(false));
            }
            catch { }
        }

        public static void DestroySession(string sessionId)
        {
            try
            {
                string path = SessionPath(sessionId);
                if (File.Exists(path)) File.Delete(path);
            }
            catch { }
        }

        private static string SessionPath(string sessionId)
        {
            string safe = sessionId;
            foreach (char invalid in Path.GetInvalidFileNameChars()) safe = safe.Replace(invalid, '_');

            return Path.Combine(SessionDirectory, "sess_" + safe + ".txt");
        }

        private static string Escape(string text)
        {
            return text.Replace("\\", "\\\\").Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }

        private static string Unescape(string text)
        {
            return text.Replace("\\t", "\t").Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\\\", "\\");
        }
    }
}

namespace LisunOS.Php
{
    /// <summary>
    /// Библиотека встроенных функций PHP.
    /// Реализован рабочий набор: строки, массивы, числа, файлы,
    /// дата и время, регулярные выражения, JSON, хеши, сессии и заголовки.
    /// </summary>
    public static partial class PhpLibrary
    {
        private static readonly Dictionary<string, Builtin> Table =
            new Dictionary<string, Builtin>(StringComparer.OrdinalIgnoreCase);

        private static readonly HashSet<string> ByReference =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "preg_match", "preg_match_all", "sort", "rsort", "asort", "arsort",
            "ksort", "krsort", "usort", "uasort", "uksort", "array_push", "array_pop",
            "array_shift", "array_unshift", "shuffle", "settype", "array_multisort"
        };

        public static bool Has(string name) { return Table.ContainsKey(name); }
        public static bool NeedsScope(string name) { return ByReference.Contains(name); }

        public static object Call(Interp interp, string name, object[] args, int line)
        {
            Builtin function;
            if (!Table.TryGetValue(name, out function))
                throw new PhpErrorException("неизвестная функция " + name + "()", line);

            try { return function(interp, args); }
            catch (PhpExitException) { throw; }
            catch (PhpErrorException) { throw; }
            catch (Exception ex)
            {
                throw new PhpErrorException(name + "(): " + ex.Message, line);
            }
        }

        // ---------- доступ к аргументам ----------

        private static object Arg(object[] args, int index)
        {
            return index < args.Length ? args[index] : null;
        }

        private static string Str(object[] args, int index)
        {
            return PhpOps.ToStr(Arg(args, index));
        }

        private static long Int(object[] args, int index, long fallback)
        {
            return index < args.Length && args[index] != null ? PhpOps.ToInt(args[index]) : fallback;
        }

        private static double Num(object[] args, int index)
        {
            return PhpOps.ToNum(Arg(args, index));
        }

        private static bool Bool(object[] args, int index, bool fallback)
        {
            return index < args.Length && args[index] != null ? PhpOps.ToBool(args[index]) : fallback;
        }

        private static PhpArray Arr(object[] args, int index)
        {
            return Arg(args, index) as PhpArray;
        }

        private static PhpArray FromList(IEnumerable<object> values)
        {
            PhpArray array = new PhpArray();
            foreach (object value in values) array.Append(value);
            return array;
        }

        // =====================================================================
        //  Функции, которым нужны сами переменные
        // =====================================================================

        public static object CallWithScope(Interp interp, Scope scope, string name, List<Expr> args, int line)
        {
            string lower = name.ToLowerInvariant();

            if (lower == "preg_match" || lower == "preg_match_all")
            {
                string pattern = PhpOps.ToStr(args[0].Eval(interp, scope));
                string subject = args.Count > 1 ? PhpOps.ToStr(args[1].Eval(interp, scope)) : "";

                PhpArray matches;
                object result = lower == "preg_match"
                    ? PhpRegex.Match(pattern, subject, out matches)
                    : PhpRegex.MatchAll(pattern, subject, out matches);

                if (args.Count > 2) args[2].Assign(interp, scope, matches);
                return result;
            }

            // Остальные работают с массивом по ссылке.
            object target = args.Count > 0 ? args[0].Eval(interp, scope) : null;
            PhpArray array = target as PhpArray;

            if (array == null && lower != "settype")
            {
                array = new PhpArray();
                if (args.Count > 0) args[0].Assign(interp, scope, array);
            }

            object[] rest = new object[Math.Max(0, args.Count - 1)];
            for (int i = 1; i < args.Count; i++) rest[i - 1] = args[i].Eval(interp, scope);

            object outcome;

            switch (lower)
            {
                case "sort": outcome = SortArray(array, false, false, interp, null, line); break;
                case "rsort": outcome = SortArray(array, true, false, interp, null, line); break;
                case "asort": outcome = SortArray(array, false, true, interp, null, line); break;
                case "arsort": outcome = SortArray(array, true, true, interp, null, line); break;
                case "ksort": outcome = SortKeys(array, false); break;
                case "krsort": outcome = SortKeys(array, true); break;

                case "usort":
                    outcome = SortArray(array, false, false, interp, PhpOps.ToStr(Arg(rest, 0)), line);
                    break;
                case "uasort":
                    outcome = SortArray(array, false, true, interp, PhpOps.ToStr(Arg(rest, 0)), line);
                    break;

                case "uksort":
                    {
                        string comparer = PhpOps.ToStr(Arg(rest, 0));
                        array.SortKeys((a, b) => (int)PhpOps.ToInt(interp.CallByName(comparer, new[] { a, b }, line)));
                        outcome = true;
                        break;
                    }

                case "array_push":
                    foreach (object value in rest) array.Append(value);
                    outcome = (long)array.Count;
                    break;

                case "array_pop":
                    {
                        if (array.Count == 0) { outcome = null; break; }

                        object key = array.Keys[array.Count - 1];
                        outcome = array.Get(key);
                        array.Remove(key);
                        break;
                    }

                case "array_shift":
                    {
                        if (array.Count == 0) { outcome = null; break; }

                        object key = array.Keys[0];
                        outcome = array.Get(key);
                        array.Remove(key);
                        array.Reindex();
                        break;
                    }

                case "array_unshift":
                    {
                        List<object> values = new List<object>(rest);
                        values.AddRange(array.ValuesList());

                        PhpArray replacement = FromList(values);
                        args[0].Assign(interp, scope, replacement);
                        outcome = (long)replacement.Count;
                        break;
                    }

                case "shuffle":
                    {
                        List<object> values = array.ValuesList();
                        Random random = new Random();

                        for (int i = values.Count - 1; i > 0; i--)
                        {
                            int j = random.Next(i + 1);
                            object swap = values[i];
                            values[i] = values[j];
                            values[j] = swap;
                        }

                        args[0].Assign(interp, scope, FromList(values));
                        outcome = true;
                        break;
                    }

                case "settype":
                    {
                        string type = PhpOps.ToStr(Arg(rest, 0)).ToLowerInvariant();
                        object converted = target;

                        if (type == "int" || type == "integer") converted = PhpOps.ToInt(target);
                        else if (type == "float" || type == "double") converted = PhpOps.ToNum(target);
                        else if (type == "string") converted = PhpOps.ToStr(target);
                        else if (type == "bool" || type == "boolean") converted = PhpOps.ToBool(target);

                        args[0].Assign(interp, scope, converted);
                        outcome = true;
                        break;
                    }

                default:
                    throw new PhpErrorException("функция " + name + "() не поддерживается", line);
            }

            return outcome;
        }

        private static object SortArray(PhpArray array, bool descending, bool keepKeys,
            Interp interp, string comparer, int line)
        {
            List<object> keys = new List<object>(array.Keys);

            Comparison<object> comparison;
            if (!string.IsNullOrEmpty(comparer))
            {
                comparison = (a, b) => (int)PhpOps.ToInt(
                    interp.CallByName(comparer, new[] { array.Get(a), array.Get(b) }, line));
            }
            else
            {
                comparison = (a, b) =>
                {
                    int order = PhpOps.Compare(array.Get(a), array.Get(b));
                    return descending ? -order : order;
                };
            }

            keys.Sort(comparison);

            PhpArray sorted = new PhpArray();
            foreach (object key in keys)
            {
                if (keepKeys) sorted.Set(key, array.Get(key));
                else sorted.Append(array.Get(key));
            }

            // Переносим результат в исходный массив, сохраняя ссылку.
            List<object> original = new List<object>(array.Keys);
            foreach (object key in original) array.Remove(key);
            foreach (object key in sorted.Keys) array.Set(key, sorted.Get(key));

            return true;
        }

        private static object SortKeys(PhpArray array, bool descending)
        {
            array.SortKeys((a, b) =>
            {
                int order = PhpOps.Compare(a, b);
                return descending ? -order : order;
            });
            return true;
        }

        // =====================================================================
        //  Регистрация функций
        // =====================================================================

        static PhpLibrary()
        {
            RegisterStrings();
            RegisterArrays();
            RegisterMath();
            RegisterTypes();
            RegisterFiles();
            RegisterTime();
            RegisterRegex();
            RegisterJson();
            RegisterHash();
            RegisterRuntime();
            RegisterExtra();
        }

        private static void Add(string name, Builtin function)
        {
            Table[name] = function;
        }

        // ---------- строки ----------

        private static void RegisterStrings()
        {
            Add("strlen", (i, a) => (long)Str(a, 0).Length);
            Add("mb_strlen", (i, a) => (long)Str(a, 0).Length);
            Add("strtolower", (i, a) => Str(a, 0).ToLowerInvariant());
            Add("strtoupper", (i, a) => Str(a, 0).ToUpperInvariant());
            Add("mb_strtolower", (i, a) => Str(a, 0).ToLowerInvariant());
            Add("mb_strtoupper", (i, a) => Str(a, 0).ToUpperInvariant());

            Add("ucfirst", (i, a) =>
            {
                string text = Str(a, 0);
                return text.Length == 0 ? text : char.ToUpperInvariant(text[0]) + text.Substring(1);
            });

            Add("lcfirst", (i, a) =>
            {
                string text = Str(a, 0);
                return text.Length == 0 ? text : char.ToLowerInvariant(text[0]) + text.Substring(1);
            });

            Add("ucwords", (i, a) =>
            {
                string text = Str(a, 0);
                StringBuilder sb = new StringBuilder(text);
                bool upper = true;

                for (int k = 0; k < sb.Length; k++)
                {
                    if (upper && char.IsLetter(sb[k])) { sb[k] = char.ToUpperInvariant(sb[k]); upper = false; }
                    if (sb[k] == ' ' || sb[k] == '\t' || sb[k] == '\n' || sb[k] == '-') upper = true;
                }
                return sb.ToString();
            });

            Add("trim", (i, a) => a.Length > 1 ? Str(a, 0).Trim(Str(a, 1).ToCharArray()) : Str(a, 0).Trim());
            Add("ltrim", (i, a) => a.Length > 1 ? Str(a, 0).TrimStart(Str(a, 1).ToCharArray()) : Str(a, 0).TrimStart());
            Add("rtrim", (i, a) => a.Length > 1 ? Str(a, 0).TrimEnd(Str(a, 1).ToCharArray()) : Str(a, 0).TrimEnd());
            Add("chop", (i, a) => Str(a, 0).TrimEnd());

            Add("substr", (i, a) => Substring(Str(a, 0), Int(a, 1, 0), a.Length > 2 && a[2] != null ? (long?)Int(a, 2, 0) : null));
            Add("mb_substr", (i, a) => Substring(Str(a, 0), Int(a, 1, 0), a.Length > 2 && a[2] != null ? (long?)Int(a, 2, 0) : null));

            Add("strpos", (i, a) =>
            {
                string haystack = Str(a, 0), needle = Str(a, 1);
                int offset = (int)Int(a, 2, 0);
                if (offset < 0) offset = Math.Max(0, haystack.Length + offset);
                if (needle.Length == 0 || offset > haystack.Length) return false;

                int index = haystack.IndexOf(needle, offset, StringComparison.Ordinal);
                return index < 0 ? (object)false : (long)index;
            });

            Add("mb_strpos", (i, a) => Table["strpos"](i, a));

            Add("stripos", (i, a) =>
            {
                string haystack = Str(a, 0), needle = Str(a, 1);
                int offset = (int)Int(a, 2, 0);
                if (needle.Length == 0 || offset > haystack.Length) return false;

                int index = haystack.IndexOf(needle, offset, StringComparison.OrdinalIgnoreCase);
                return index < 0 ? (object)false : (long)index;
            });

            Add("strrpos", (i, a) =>
            {
                int index = Str(a, 0).LastIndexOf(Str(a, 1), StringComparison.Ordinal);
                return index < 0 ? (object)false : (long)index;
            });

            Add("str_contains", (i, a) => Str(a, 1).Length == 0 || Str(a, 0).Contains(Str(a, 1)));
            Add("str_starts_with", (i, a) => Str(a, 0).StartsWith(Str(a, 1), StringComparison.Ordinal));
            Add("str_ends_with", (i, a) => Str(a, 0).EndsWith(Str(a, 1), StringComparison.Ordinal));

            Add("str_replace", (i, a) => Replace(Arg(a, 0), Arg(a, 1), Arg(a, 2), false));
            Add("str_ireplace", (i, a) => Replace(Arg(a, 0), Arg(a, 1), Arg(a, 2), true));

            Add("str_repeat", (i, a) =>
            {
                long count = Int(a, 1, 0);
                return count <= 0 ? "" : string.Concat(System.Linq.Enumerable.Repeat(Str(a, 0), (int)count));
            });

            Add("str_pad", (i, a) =>
            {
                string text = Str(a, 0);
                int length = (int)Int(a, 1, 0);
                string pad = a.Length > 2 ? Str(a, 2) : " ";
                long type = Int(a, 3, 1);

                if (pad.Length == 0 || length <= text.Length) return text;

                int total = length - text.Length;

                if (type == 0)
                {
                    StringBuilder left = new StringBuilder();
                    while (left.Length < total) left.Append(pad);
                    return left.ToString().Substring(0, total) + text;
                }

                if (type == 2)
                {
                    int leftSize = total / 2, rightSize = total - leftSize;
                    StringBuilder both = new StringBuilder();
                    while (both.Length < Math.Max(leftSize, rightSize)) both.Append(pad);

                    return both.ToString().Substring(0, leftSize) + text + both.ToString().Substring(0, rightSize);
                }

                StringBuilder right = new StringBuilder();
                while (right.Length < total) right.Append(pad);
                return text + right.ToString().Substring(0, total);
            });

            Add("str_split", (i, a) =>
            {
                string text = Str(a, 0);
                int size = (int)Int(a, 1, 1);
                if (size < 1) size = 1;

                PhpArray result = new PhpArray();
                for (int k = 0; k < text.Length; k += size)
                    result.Append(text.Substring(k, Math.Min(size, text.Length - k)));

                if (text.Length == 0) result.Append("");
                return result;
            });

            Add("strrev", (i, a) =>
            {
                char[] chars = Str(a, 0).ToCharArray();
                Array.Reverse(chars);
                return new string(chars);
            });

            Add("strcmp", (i, a) => (long)Math.Sign(string.Compare(Str(a, 0), Str(a, 1), StringComparison.Ordinal)));
            Add("strcasecmp", (i, a) => (long)Math.Sign(string.Compare(Str(a, 0), Str(a, 1), StringComparison.OrdinalIgnoreCase)));

            Add("substr_count", (i, a) =>
            {
                string haystack = Str(a, 0), needle = Str(a, 1);
                if (needle.Length == 0) return 0L;

                long count = 0;
                int index = 0;

                while ((index = haystack.IndexOf(needle, index, StringComparison.Ordinal)) >= 0)
                {
                    count++;
                    index += needle.Length;
                }
                return count;
            });

            Add("implode", (i, a) => Implode(Arg(a, 0), Arg(a, 1)));
            Add("join", (i, a) => Implode(Arg(a, 0), Arg(a, 1)));

            Add("explode", (i, a) =>
            {
                string separator = Str(a, 0), subject = Str(a, 1);
                long limit = Int(a, 2, long.MaxValue);

                PhpArray result = new PhpArray();
                if (separator.Length == 0) { result.Append(subject); return result; }

                string[] parts = subject.Split(new[] { separator }, StringSplitOptions.None);

                if (limit > 0 && limit < parts.Length)
                {
                    for (int k = 0; k < limit - 1; k++) result.Append(parts[k]);
                    result.Append(string.Join(separator, parts, (int)limit - 1, parts.Length - (int)limit + 1));
                    return result;
                }

                foreach (string part in parts) result.Append(part);
                return result;
            });

            Add("nl2br", (i, a) => Str(a, 0).Replace("\r\n", "<br />\r\n").Replace("\n", "<br />\n"));

            Add("htmlspecialchars", (i, a) =>
            {
                string text = Str(a, 0).Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;");
                long flags = Int(a, 1, 3);

                if ((flags & 2) != 0) text = text.Replace("\"", "&quot;");
                if ((flags & 1) != 0 && (flags & 2) != 0) text = text.Replace("'", "&#039;");
                return text;
            });

            Add("htmlspecialchars_decode", (i, a) => Str(a, 0).Replace("&amp;", "&")
                .Replace("&lt;", "<").Replace("&gt;", ">").Replace("&quot;", "\"").Replace("&#039;", "'"));

            Add("html_entity_decode", (i, a) => Table["htmlspecialchars_decode"](i, a));
            Add("htmlentities", (i, a) => Table["htmlspecialchars"](i, a));

            Add("strip_tags", (i, a) =>
                System.Text.RegularExpressions.Regex.Replace(Str(a, 0), "<[^>]*>", ""));

            Add("addslashes", (i, a) => Str(a, 0).Replace("\\", "\\\\").Replace("'", "\\'").Replace("\"", "\\\""));
            Add("stripslashes", (i, a) => Str(a, 0).Replace("\\'", "'").Replace("\\\"", "\"").Replace("\\\\", "\\"));

            Add("sprintf", (i, a) => Sprintf(a));
            Add("vsprintf", (i, a) =>
            {
                PhpArray values = Arr(a, 1);
                List<object> list = new List<object> { Arg(a, 0) };
                if (values != null) list.AddRange(values.ValuesList());
                return Sprintf(list.ToArray());
            });

            Add("printf", (i, a) =>
            {
                string text = Sprintf(a);
                i.Output(text);
                return (long)text.Length;
            });

            Add("number_format", (i, a) =>
            {
                double value = Num(a, 0);
                int decimals = (int)Int(a, 1, 0);
                string point = a.Length > 2 ? Str(a, 2) : ".";
                string thousands = a.Length > 3 ? Str(a, 3) : ",";

                NumberFormatInfo format = new NumberFormatInfo();
                format.NumberDecimalSeparator = point;
                format.NumberGroupSeparator = thousands;
                format.NumberGroupSizes = new[] { 3 };

                return value.ToString("N" + decimals, format);
            });

            Add("wordwrap", (i, a) =>
            {
                string text = Str(a, 0);
                int width = (int)Int(a, 1, 75);
                string brk = a.Length > 2 ? Str(a, 2) : "\n";

                StringBuilder sb = new StringBuilder();
                int lineLength = 0;

                foreach (string word in text.Split(' '))
                {
                    if (lineLength + word.Length > width && lineLength > 0) { sb.Append(brk); lineLength = 0; }
                    else if (lineLength > 0) { sb.Append(' '); lineLength++; }

                    sb.Append(word);
                    lineLength += word.Length;
                }
                return sb.ToString();
            });

            Add("urlencode", (i, a) => Uri.EscapeDataString(Str(a, 0)).Replace("%20", "+"));
            Add("rawurlencode", (i, a) => Uri.EscapeDataString(Str(a, 0)));
            Add("urldecode", (i, a) => Uri.UnescapeDataString(Str(a, 0).Replace("+", " ")));
            Add("rawurldecode", (i, a) => Uri.UnescapeDataString(Str(a, 0)));

            Add("http_build_query", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null) return "";

                StringBuilder sb = new StringBuilder();
                foreach (object key in source.Keys)
                {
                    if (sb.Length > 0) sb.Append('&');

                    sb.Append(Uri.EscapeDataString(PhpOps.ToStr(key)));
                    sb.Append('=');
                    sb.Append(Uri.EscapeDataString(PhpOps.ToStr(source.Get(key))));
                }
                return sb.ToString();
            });

            Add("ord", (i, a) => { string t = Str(a, 0); return t.Length == 0 ? 0L : (long)t[0]; });
            Add("chr", (i, a) => ((char)(Int(a, 0, 0) & 0xFF)).ToString());
            Add("str_word_count", (i, a) => (long)Str(a, 0).Split(new[] { ' ', '\t', '\n' },
                StringSplitOptions.RemoveEmptyEntries).Length);
        }

        private static string Substring(string text, long start, long? length)
        {
            if (start < 0) start = Math.Max(0, text.Length + start);
            if (start >= text.Length) return "";

            long available = text.Length - start;
            long take = length.HasValue ? length.Value : available;

            if (take < 0) take = Math.Max(0, available + take);
            if (take > available) take = available;

            return text.Substring((int)start, (int)take);
        }

        private static object Replace(object search, object replace, object subject, bool ignoreCase)
        {
            PhpArray subjectArray = subject as PhpArray;
            if (subjectArray != null)
            {
                PhpArray result = new PhpArray();
                foreach (object key in subjectArray.Keys)
                    result.Set(key, Replace(search, replace, subjectArray.Get(key), ignoreCase));

                return result;
            }

            string text = PhpOps.ToStr(subject);
            PhpArray searchArray = search as PhpArray;

            if (searchArray != null)
            {
                PhpArray replaceArray = replace as PhpArray;
                List<object> searches = searchArray.ValuesList();
                List<object> replacements = replaceArray != null ? replaceArray.ValuesList() : null;

                for (int k = 0; k < searches.Count; k++)
                {
                    string from = PhpOps.ToStr(searches[k]);
                    string to = replacements != null
                        ? (k < replacements.Count ? PhpOps.ToStr(replacements[k]) : "")
                        : PhpOps.ToStr(replace);

                    text = ReplaceOne(text, from, to, ignoreCase);
                }
                return text;
            }

            return ReplaceOne(text, PhpOps.ToStr(search), PhpOps.ToStr(replace), ignoreCase);
        }

        private static string ReplaceOne(string text, string from, string to, bool ignoreCase)
        {
            if (from.Length == 0) return text;

            if (!ignoreCase) return text.Replace(from, to);

            StringBuilder sb = new StringBuilder();
            int index = 0;

            while (true)
            {
                int found = text.IndexOf(from, index, StringComparison.OrdinalIgnoreCase);
                if (found < 0) { sb.Append(text, index, text.Length - index); break; }

                sb.Append(text, index, found - index).Append(to);
                index = found + from.Length;
            }
            return sb.ToString();
        }

        private static string Implode(object first, object second)
        {
            PhpArray array = first as PhpArray;
            string separator;

            if (array != null) separator = PhpOps.ToStr(second);
            else { array = second as PhpArray; separator = PhpOps.ToStr(first); }

            if (array == null) return "";

            StringBuilder sb = new StringBuilder();
            foreach (object value in array.ValuesList())
            {
                if (sb.Length > 0) sb.Append(separator);
                sb.Append(PhpOps.ToStr(value));
            }
            return sb.ToString();
        }

        private static string Sprintf(object[] args)
        {
            string format = PhpOps.ToStr(Arg(args, 0));
            StringBuilder sb = new StringBuilder();
            int argIndex = 1;

            for (int k = 0; k < format.Length; k++)
            {
                if (format[k] != '%') { sb.Append(format[k]); continue; }
                if (k + 1 >= format.Length) break;

                k++;
                if (format[k] == '%') { sb.Append('%'); continue; }

                // Флаги, ширина и точность
                StringBuilder spec = new StringBuilder();
                bool leftAlign = false;
                char padChar = ' ';

                while (k < format.Length && (format[k] == '-' || format[k] == '+' || format[k] == '0' ||
                                             format[k] == ' ' || format[k] == '\''))
                {
                    if (format[k] == '-') leftAlign = true;
                    else if (format[k] == '0') padChar = '0';
                    else if (format[k] == '\'' && k + 1 < format.Length) { k++; padChar = format[k]; }

                    k++;
                }

                while (k < format.Length && char.IsDigit(format[k])) { spec.Append(format[k]); k++; }

                int width = spec.Length > 0 ? int.Parse(spec.ToString()) : 0;
                int precision = -1;

                if (k < format.Length && format[k] == '.')
                {
                    k++;
                    StringBuilder precisionText = new StringBuilder();
                    while (k < format.Length && char.IsDigit(format[k])) { precisionText.Append(format[k]); k++; }

                    precision = precisionText.Length > 0 ? int.Parse(precisionText.ToString()) : 0;
                }

                if (k >= format.Length) break;

                object value = Arg(args, argIndex++);
                string text;

                switch (format[k])
                {
                    case 'd':
                    case 'i': text = PhpOps.ToInt(value).ToString(CultureInfo.InvariantCulture); break;
                    case 'u': text = ((ulong)PhpOps.ToInt(value)).ToString(CultureInfo.InvariantCulture); break;
                    case 'f':
                    case 'F': text = PhpOps.ToNum(value).ToString("F" + (precision < 0 ? 6 : precision),
                                  CultureInfo.InvariantCulture); break;
                    case 's':
                        text = PhpOps.ToStr(value);
                        if (precision >= 0 && text.Length > precision) text = text.Substring(0, precision);
                        break;
                    case 'x': text = PhpOps.ToInt(value).ToString("x"); break;
                    case 'X': text = PhpOps.ToInt(value).ToString("X"); break;
                    case 'o': text = Convert.ToString(PhpOps.ToInt(value), 8); break;
                    case 'b': text = Convert.ToString(PhpOps.ToInt(value), 2); break;
                    case 'e': text = PhpOps.ToNum(value).ToString("e" + (precision < 0 ? 6 : precision),
                                  CultureInfo.InvariantCulture); break;
                    case 'c': text = ((char)PhpOps.ToInt(value)).ToString(); break;
                    default: text = PhpOps.ToStr(value); break;
                }

                if (width > text.Length)
                    text = leftAlign ? text.PadRight(width, padChar) : text.PadLeft(width, padChar);

                sb.Append(text);
            }

            return sb.ToString();
        }

        // ---------- массивы ----------

        private static void RegisterArrays()
        {
            Add("count", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                if (array != null) return (long)array.Count;
                return Arg(a, 0) == null ? 0L : 1L;
            });
            Add("sizeof", (i, a) => Table["count"](i, a));

            Add("array_keys", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                if (a.Length > 1)
                {
                    foreach (object key in array.Keys)
                        if (PhpOps.LooseEquals(array.Get(key), a[1])) result.Append(key);

                    return result;
                }

                foreach (object key in array.Keys) result.Append(key);
                return result;
            });

            Add("array_values", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                return array == null ? new PhpArray() : FromList(array.ValuesList());
            });

            Add("in_array", (i, a) =>
            {
                PhpArray array = Arr(a, 1);
                if (array == null) return false;

                bool strict = Bool(a, 2, false);
                foreach (object value in array.ValuesList())
                {
                    if (strict ? PhpOps.StrictEquals(value, a[0]) : PhpOps.LooseEquals(value, a[0])) return true;
                }
                return false;
            });

            Add("array_search", (i, a) =>
            {
                PhpArray array = Arr(a, 1);
                if (array == null) return false;

                bool strict = Bool(a, 2, false);
                foreach (object key in array.Keys)
                {
                    object value = array.Get(key);
                    if (strict ? PhpOps.StrictEquals(value, a[0]) : PhpOps.LooseEquals(value, a[0])) return key;
                }
                return false;
            });

            Add("array_key_exists", (i, a) =>
            {
                PhpArray array = Arr(a, 1);
                return array != null && array.Has(Arg(a, 0));
            });
            Add("key_exists", (i, a) => Table["array_key_exists"](i, a));

            Add("array_merge", (i, a) =>
            {
                PhpArray result = new PhpArray();

                foreach (object argument in a)
                {
                    PhpArray array = argument as PhpArray;
                    if (array == null) continue;

                    foreach (object key in array.Keys)
                    {
                        if (key is long) result.Append(array.Get(key));
                        else result.Set(key, array.Get(key));
                    }
                }
                return result;
            });

            Add("array_combine", (i, a) =>
            {
                PhpArray keys = Arr(a, 0), values = Arr(a, 1);
                PhpArray result = new PhpArray();
                if (keys == null || values == null) return result;

                List<object> keyList = keys.ValuesList(), valueList = values.ValuesList();
                for (int k = 0; k < Math.Min(keyList.Count, valueList.Count); k++)
                    result.Set(keyList[k], valueList[k]);

                return result;
            });

            Add("array_slice", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                if (array == null) return new PhpArray();

                List<object> keys = new List<object>(array.Keys);
                long offset = Int(a, 1, 0);
                if (offset < 0) offset = Math.Max(0, keys.Count + offset);

                long length = a.Length > 2 && a[2] != null ? Int(a, 2, 0) : keys.Count - offset;
                if (length < 0) length = Math.Max(0, keys.Count - offset + length);

                bool preserve = Bool(a, 3, false);
                PhpArray result = new PhpArray();

                for (long k = offset; k < Math.Min(keys.Count, offset + length); k++)
                {
                    object key = keys[(int)k];
                    if (preserve || key is string) result.Set(key, array.Get(key));
                    else result.Append(array.Get(key));
                }
                return result;
            });

            Add("array_reverse", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                if (array == null) return new PhpArray();

                bool preserve = Bool(a, 1, false);
                List<object> keys = new List<object>(array.Keys);
                keys.Reverse();

                PhpArray result = new PhpArray();
                foreach (object key in keys)
                {
                    if (preserve || key is string) result.Set(key, array.Get(key));
                    else result.Append(array.Get(key));
                }
                return result;
            });

            Add("array_flip", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                foreach (object key in array.Keys) result.Set(array.Get(key), key);
                return result;
            });

            Add("array_unique", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                List<object> seen = new List<object>();
                foreach (object key in array.Keys)
                {
                    object value = array.Get(key);
                    bool duplicate = false;

                    foreach (object previous in seen)
                    {
                        if (PhpOps.LooseEquals(previous, value)) { duplicate = true; break; }
                    }

                    if (duplicate) continue;

                    seen.Add(value);
                    result.Set(key, value);
                }
                return result;
            });

            Add("array_sum", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                if (array == null) return 0L;

                double sum = 0;
                bool integers = true;

                foreach (object value in array.ValuesList())
                {
                    sum += PhpOps.ToNum(value);
                    if (value is double) integers = false;
                }
                return integers && sum == Math.Floor(sum) ? (object)(long)sum : sum;
            });

            Add("array_product", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                if (array == null || array.Count == 0) return 1L;

                double product = 1;
                foreach (object value in array.ValuesList()) product *= PhpOps.ToNum(value);

                return product == Math.Floor(product) ? (object)(long)product : product;
            });

            Add("array_fill", (i, a) =>
            {
                PhpArray result = new PhpArray();
                long start = Int(a, 0, 0), count = Int(a, 1, 0);

                for (long k = 0; k < count; k++) result.Set(start + k, Arg(a, 2));
                return result;
            });

            Add("array_fill_keys", (i, a) =>
            {
                PhpArray keys = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (keys == null) return result;

                foreach (object key in keys.ValuesList()) result.Set(key, Arg(a, 1));
                return result;
            });

            Add("array_map", (i, a) =>
            {
                string callback = PhpOps.ToStr(Arg(a, 0));
                PhpArray array = Arr(a, 1);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                foreach (object key in array.Keys)
                {
                    object value = array.Get(key);
                    object mapped = callback.Length == 0 ? value : i.CallByName(callback, new[] { value }, 0);

                    if (key is string) result.Set(key, mapped);
                    else result.Append(mapped);
                }
                return result;
            });

            Add("array_filter", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                string callback = a.Length > 1 ? PhpOps.ToStr(a[1]) : "";

                foreach (object key in array.Keys)
                {
                    object value = array.Get(key);
                    bool keep = callback.Length == 0
                        ? PhpOps.ToBool(value)
                        : PhpOps.ToBool(i.CallByName(callback, new[] { value }, 0));

                    if (keep) result.Set(key, value);
                }
                return result;
            });

            Add("array_reduce", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                string callback = PhpOps.ToStr(Arg(a, 1));
                object carry = Arg(a, 2);
                if (array == null) return carry;

                foreach (object value in array.ValuesList())
                    carry = i.CallByName(callback, new[] { carry, value }, 0);

                return carry;
            });

            Add("array_key_first", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                return array == null || array.Count == 0 ? null : array.Keys[0];
            });

            Add("array_key_last", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                return array == null || array.Count == 0 ? null : array.Keys[array.Count - 1];
            });

            Add("range", (i, a) =>
            {
                PhpArray result = new PhpArray();
                object from = Arg(a, 0), to = Arg(a, 1);

                if (from is string && to is string && ((string)from).Length == 1 && ((string)to).Length == 1 &&
                    !char.IsDigit(((string)from)[0]))
                {
                    char start = ((string)from)[0], end = ((string)to)[0];
                    int direction = start <= end ? 1 : -1;

                    for (char c = start; ; c = (char)(c + direction))
                    {
                        result.Append(c.ToString());
                        if (c == end) break;
                    }
                    return result;
                }

                double begin = PhpOps.ToNum(from), finish = PhpOps.ToNum(to);
                double step = a.Length > 2 ? Math.Abs(Num(a, 2)) : 1;
                if (step == 0) step = 1;

                if (begin <= finish) for (double v = begin; v <= finish + 1e-9; v += step) result.Append(Whole(v));
                else for (double v = begin; v >= finish - 1e-9; v -= step) result.Append(Whole(v));

                return result;
            });

            Add("array_column", (i, a) =>
            {
                PhpArray array = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (array == null) return result;

                object column = Arg(a, 1);
                foreach (object value in array.ValuesList())
                {
                    PhpArray row = value as PhpArray;
                    if (row == null) continue;

                    if (column == null) result.Append(row);
                    else if (row.Has(column)) result.Append(row.Get(column));
                }
                return result;
            });

            Add("array_diff", (i, a) =>
            {
                PhpArray first = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (first == null) return result;

                foreach (object key in first.Keys)
                {
                    object value = first.Get(key);
                    bool found = false;

                    for (int k = 1; k < a.Length && !found; k++)
                    {
                        PhpArray other = a[k] as PhpArray;
                        if (other == null) continue;

                        foreach (object candidate in other.ValuesList())
                            if (PhpOps.ToStr(candidate) == PhpOps.ToStr(value)) { found = true; break; }
                    }

                    if (!found) result.Set(key, value);
                }
                return result;
            });

            Add("array_intersect", (i, a) =>
            {
                PhpArray first = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (first == null) return result;

                foreach (object key in first.Keys)
                {
                    object value = first.Get(key);
                    bool inAll = true;

                    for (int k = 1; k < a.Length && inAll; k++)
                    {
                        PhpArray other = a[k] as PhpArray;
                        bool found = false;

                        if (other != null)
                        {
                            foreach (object candidate in other.ValuesList())
                                if (PhpOps.ToStr(candidate) == PhpOps.ToStr(value)) { found = true; break; }
                        }
                        inAll = found;
                    }

                    if (inAll) result.Set(key, value);
                }
                return result;
            });
        }

        private static object Whole(double value)
        {
            return value == Math.Floor(value) ? (object)(long)value : value;
        }

        // ---------- числа ----------

        private static void RegisterMath()
        {
            Add("abs", (i, a) => Whole(Math.Abs(Num(a, 0))));
            Add("ceil", (i, a) => Math.Ceiling(Num(a, 0)));
            Add("floor", (i, a) => Math.Floor(Num(a, 0)));

            Add("round", (i, a) =>
            {
                int digits = (int)Int(a, 1, 0);
                return Math.Round(Num(a, 0), Math.Max(0, Math.Min(15, digits)), MidpointRounding.AwayFromZero);
            });

            Add("sqrt", (i, a) => Math.Sqrt(Num(a, 0)));
            Add("pow", (i, a) => Whole(Math.Pow(Num(a, 0), Num(a, 1))));
            Add("intdiv", (i, a) => Int(a, 0, 0) / Math.Max(1, Int(a, 1, 1)));
            Add("fmod", (i, a) => Num(a, 0) % Num(a, 1));
            Add("exp", (i, a) => Math.Exp(Num(a, 0)));
            Add("log", (i, a) => a.Length > 1 ? Math.Log(Num(a, 0), Num(a, 1)) : Math.Log(Num(a, 0)));
            Add("log10", (i, a) => Math.Log10(Num(a, 0)));
            Add("sin", (i, a) => Math.Sin(Num(a, 0)));
            Add("cos", (i, a) => Math.Cos(Num(a, 0)));
            Add("tan", (i, a) => Math.Tan(Num(a, 0)));
            Add("pi", (i, a) => Math.PI);
            Add("hypot", (i, a) => Math.Sqrt(Num(a, 0) * Num(a, 0) + Num(a, 1) * Num(a, 1)));

            Add("max", (i, a) => MinMax(a, true));
            Add("min", (i, a) => MinMax(a, false));

            Add("rand", (i, a) => RandomValue(a));
            Add("mt_rand", (i, a) => RandomValue(a));
            Add("random_int", (i, a) => RandomValue(a));
            Add("mt_getrandmax", (i, a) => 2147483647L);
            Add("getrandmax", (i, a) => 2147483647L);
            Add("lcg_value", (i, a) => Shared.NextDouble());

            Add("is_nan", (i, a) => double.IsNaN(Num(a, 0)));
            Add("is_infinite", (i, a) => double.IsInfinity(Num(a, 0)));
            Add("is_finite", (i, a) => !double.IsInfinity(Num(a, 0)) && !double.IsNaN(Num(a, 0)));

            Add("base_convert", (i, a) =>
                Convert.ToString(Convert.ToInt64(Str(a, 0), (int)Int(a, 1, 10)), (int)Int(a, 2, 10)));

            Add("dechex", (i, a) => Int(a, 0, 0).ToString("x"));
            Add("hexdec", (i, a) => Convert.ToInt64(Str(a, 0), 16));
            Add("decbin", (i, a) => Convert.ToString(Int(a, 0, 0), 2));
            Add("bindec", (i, a) => Convert.ToInt64(Str(a, 0), 2));
            Add("decoct", (i, a) => Convert.ToString(Int(a, 0, 0), 8));
            Add("octdec", (i, a) => Convert.ToInt64(Str(a, 0), 8));
        }

        private static readonly Random Shared = new Random();

        private static object RandomValue(object[] args)
        {
            if (args.Length < 2) return (long)Shared.Next();

            long from = PhpOps.ToInt(args[0]), to = PhpOps.ToInt(args[1]);
            if (to < from) { long swap = from; from = to; to = swap; }

            return from + (long)(Shared.NextDouble() * (to - from + 1));
        }

        private static object MinMax(object[] args, bool maximum)
        {
            List<object> values = new List<object>();

            if (args.Length == 1 && args[0] is PhpArray) values.AddRange(((PhpArray)args[0]).ValuesList());
            else values.AddRange(args);

            if (values.Count == 0) return false;

            object best = values[0];
            foreach (object value in values)
            {
                int order = PhpOps.Compare(value, best);
                if (maximum ? order > 0 : order < 0) best = value;
            }
            return best;
        }

        // ---------- типы ----------

        private static void RegisterTypes()
        {
            Add("is_array", (i, a) => Arg(a, 0) is PhpArray);
            Add("is_string", (i, a) => Arg(a, 0) is string);
            Add("is_int", (i, a) => Arg(a, 0) is long);
            Add("is_integer", (i, a) => Arg(a, 0) is long);
            Add("is_long", (i, a) => Arg(a, 0) is long);
            Add("is_float", (i, a) => Arg(a, 0) is double);
            Add("is_double", (i, a) => Arg(a, 0) is double);
            Add("is_bool", (i, a) => Arg(a, 0) is bool);
            Add("is_null", (i, a) => Arg(a, 0) == null);
            Add("is_object", (i, a) => false);
            Add("is_scalar", (i, a) =>
            {
                object value = Arg(a, 0);
                return value is string || value is long || value is double || value is bool;
            });

            Add("is_numeric", (i, a) =>
            {
                object value = Arg(a, 0);
                if (value is long || value is double) return true;
                return value is string && PhpOps.IsNumericString((string)value);
            });

            Add("is_callable", (i, a) => i.HasFunction(Str(a, 0)));
            Add("function_exists", (i, a) => i.HasFunction(Str(a, 0)));
            Add("method_exists", (i, a) => false);
            Add("class_exists", (i, a) => false);

            Add("intval", (i, a) =>
            {
                long bas = Int(a, 1, 10);
                if (bas != 10 && Arg(a, 0) is string)
                {
                    try { return Convert.ToInt64(Str(a, 0).Trim(), (int)bas); }
                    catch { return 0L; }
                }
                return PhpOps.ToInt(Arg(a, 0));
            });

            Add("floatval", (i, a) => PhpOps.ToNum(Arg(a, 0)));
            Add("doubleval", (i, a) => PhpOps.ToNum(Arg(a, 0)));
            Add("strval", (i, a) => PhpOps.ToStr(Arg(a, 0)));
            Add("boolval", (i, a) => PhpOps.ToBool(Arg(a, 0)));

            Add("gettype", (i, a) =>
            {
                object value = Arg(a, 0);
                if (value == null) return "NULL";
                if (value is bool) return "boolean";
                if (value is long) return "integer";
                if (value is double) return "double";
                if (value is string) return "string";
                if (value is PhpArray) return "array";
                return "unknown type";
            });

            Add("print_r", (i, a) =>
            {
                string text = Dump(Arg(a, 0), 0, false);
                if (Bool(a, 1, false)) return text;

                i.Output(text);
                return true;
            });

            Add("var_dump", (i, a) =>
            {
                foreach (object value in a) i.Output(Dump(value, 0, true));
                return null;
            });

            Add("var_export", (i, a) =>
            {
                string text = Dump(Arg(a, 0), 0, false);
                if (Bool(a, 1, false)) return text;

                i.Output(text);
                return null;
            });

            Add("print", (i, a) => { i.Output(Str(a, 0)); return 1L; });
        }

        private static string Dump(object value, int depth, bool typed)
        {
            string indent = new string(' ', depth * 4);

            if (value is PhpArray)
            {
                PhpArray array = (PhpArray)value;
                StringBuilder sb = new StringBuilder();

                sb.Append("Array\n").Append(indent).Append("(\n");
                foreach (object key in array.Keys)
                {
                    sb.Append(indent).Append("    [").Append(PhpOps.ToStr(key)).Append("] => ");
                    sb.Append(Dump(array.Get(key), depth + 2, typed)).Append('\n');
                }
                sb.Append(indent).Append(")\n");
                return sb.ToString();
            }

            if (!typed) return PhpOps.ToStr(value);

            if (value == null) return "NULL\n";
            if (value is bool) return "bool(" + ((bool)value ? "true" : "false") + ")\n";
            if (value is long) return "int(" + (long)value + ")\n";
            if (value is double) return "float(" + PhpOps.ToStr(value) + ")\n";

            string text = PhpOps.ToStr(value);
            return "string(" + text.Length + ") \"" + text + "\"\n";
        }

        // ---------- файлы ----------

        private static string SafePath(Interp interp, object[] args, int index)
        {
            if (interp.Context == null) return null;
            return interp.Context.SafePath(Str(args, index));
        }

        private static void RegisterFiles()
        {
            Add("file_exists", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                return path != null && (File.Exists(path) || Directory.Exists(path));
            });

            Add("is_file", (i, a) => { string p = SafePath(i, a, 0); return p != null && File.Exists(p); });
            Add("is_dir", (i, a) => { string p = SafePath(i, a, 0); return p != null && Directory.Exists(p); });
            Add("is_readable", (i, a) => Table["file_exists"](i, a));
            Add("is_writable", (i, a) => Table["file_exists"](i, a));
            Add("is_writeable", (i, a) => Table["file_exists"](i, a));

            Add("file_get_contents", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !File.Exists(path)) return false;

                return LisunCrypto.ReadAllText(path);
            });

            Add("file_put_contents", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null) return false;

                string content = PhpOps.ToStr(Arg(a, 1));
                long flags = Int(a, 2, 0);

                try
                {
                    string directory = Path.GetDirectoryName(path);
                    if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                        Directory.CreateDirectory(directory);

                    if ((flags & 8) != 0) File.AppendAllText(path, content, new UTF8Encoding(false));
                    else File.WriteAllText(path, content, new UTF8Encoding(false));

                    return (long)content.Length;
                }
                catch { return false; }
            });

            Add("file", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !File.Exists(path)) return false;

                long flags = Int(a, 1, 0);
                string[] lines = LisunCrypto.ReadAllLines(path);

                PhpArray result = new PhpArray();
                foreach (string line in lines)
                {
                    if ((flags & 4) != 0 && line.Trim().Length == 0) continue;
                    result.Append((flags & 2) != 0 ? line : line + "\n");
                }
                return result;
            });

            Add("unlink", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !File.Exists(path)) return false;

                try { File.Delete(path); return true; }
                catch { return false; }
            });

            Add("mkdir", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null) return false;

                try { Directory.CreateDirectory(path); return true; }
                catch { return false; }
            });

            Add("rmdir", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !Directory.Exists(path)) return false;

                try { Directory.Delete(path, false); return true; }
                catch { return false; }
            });

            Add("scandir", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !Directory.Exists(path)) return false;

                List<string> names = new List<string> { ".", ".." };

                foreach (string directory in Directory.GetDirectories(path)) names.Add(Path.GetFileName(directory));
                foreach (string file in Directory.GetFiles(path)) names.Add(Path.GetFileName(file));

                names.Sort(StringComparer.OrdinalIgnoreCase);
                if (Int(a, 1, 0) == 1) names.Reverse();

                PhpArray result = new PhpArray();
                foreach (string name in names) result.Append(name);
                return result;
            });

            Add("glob", (i, a) =>
            {
                PhpArray result = new PhpArray();
                if (i.Context == null) return result;

                string pattern = Str(a, 0);
                string directory = Path.GetDirectoryName(pattern);
                string mask = Path.GetFileName(pattern);

                string root = i.Context.SafePath(string.IsNullOrEmpty(directory) ? "." : directory);
                if (root == null || !Directory.Exists(root)) return result;

                try
                {
                    List<string> found = new List<string>();
                    found.AddRange(Directory.GetDirectories(root, mask));
                    found.AddRange(Directory.GetFiles(root, mask));
                    found.Sort(StringComparer.OrdinalIgnoreCase);

                    foreach (string item in found)
                    {
                        string relative = item.Substring(
                            Path.GetFullPath(i.Context.DocumentRoot).TrimEnd(Path.DirectorySeparatorChar).Length);

                        result.Append(relative.TrimStart(Path.DirectorySeparatorChar).Replace('\\', '/'));
                    }
                }
                catch { }

                return result;
            });

            Add("filesize", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null || !File.Exists(path)) return false;

                try { return new FileInfo(path).Length; }
                catch { return false; }
            });

            Add("filemtime", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null) return false;

                try
                {
                    DateTime time = File.Exists(path) ? File.GetLastWriteTime(path) : Directory.GetLastWriteTime(path);
                    return (long)new DateTimeOffset(time).ToUnixTimeSeconds();
                }
                catch { return false; }
            });

            Add("touch", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null) return false;

                try
                {
                    if (!File.Exists(path)) File.WriteAllText(path, "", new UTF8Encoding(false));
                    else File.SetLastWriteTime(path, DateTime.Now);
                    return true;
                }
                catch { return false; }
            });

            Add("copy", (i, a) =>
            {
                string from = SafePath(i, a, 0), to = SafePath(i, a, 1);
                if (from == null || to == null || !File.Exists(from)) return false;

                try { File.Copy(from, to, true); return true; }
                catch { return false; }
            });

            Add("rename", (i, a) =>
            {
                string from = SafePath(i, a, 0), to = SafePath(i, a, 1);
                if (from == null || to == null) return false;

                try
                {
                    if (Directory.Exists(from)) Directory.Move(from, to);
                    else
                    {
                        if (File.Exists(to)) File.Delete(to);
                        File.Move(from, to);
                    }
                    return true;
                }
                catch { return false; }
            });

            Add("realpath", (i, a) =>
            {
                string path = SafePath(i, a, 0);
                if (path == null) return false;
                if (!File.Exists(path) && !Directory.Exists(path)) return false;

                return Path.GetFullPath(path);
            });

            Add("dirname", (i, a) =>
            {
                string path = Str(a, 0).Replace('/', Path.DirectorySeparatorChar);
                string directory = Path.GetDirectoryName(path);
                return string.IsNullOrEmpty(directory) ? "." : directory;
            });

            Add("basename", (i, a) =>
            {
                string name = Path.GetFileName(Str(a, 0).Replace('/', Path.DirectorySeparatorChar)
                    .TrimEnd(Path.DirectorySeparatorChar));

                if (a.Length > 1)
                {
                    string suffix = Str(a, 1);
                    if (suffix.Length > 0 && name.EndsWith(suffix, StringComparison.Ordinal))
                        name = name.Substring(0, name.Length - suffix.Length);
                }
                return name;
            });

            Add("pathinfo", (i, a) =>
            {
                string path = Str(a, 0);
                PhpArray result = new PhpArray();

                result.Set("dirname", Path.GetDirectoryName(path) ?? ".");
                result.Set("basename", Path.GetFileName(path));
                result.Set("extension", Path.GetExtension(path).TrimStart('.'));
                result.Set("filename", Path.GetFileNameWithoutExtension(path));
                return result;
            });

            Add("mime_content_type", (i, a) => "application/octet-stream");
            Add("disk_free_space", (i, a) => 0L);
            Add("tempnam", (i, a) => Path.Combine(LisunEngine.TempPath, Guid.NewGuid().ToString("N") + ".tmp"));
            Add("sys_get_temp_dir", (i, a) => LisunEngine.TempPath);
        }

        // ---------- дата и время ----------

        private static void RegisterTime()
        {
            Add("time", (i, a) => DateTimeOffset.Now.ToUnixTimeSeconds());

            Add("microtime", (i, a) =>
            {
                double seconds = DateTimeOffset.Now.ToUnixTimeMilliseconds() / 1000.0;
                if (Bool(a, 0, false)) return seconds;

                long whole = (long)seconds;
                return (seconds - whole).ToString("0.00000000", CultureInfo.InvariantCulture) + " " + whole;
            });

            Add("hrtime", (i, a) => (long)(DateTime.Now.Ticks * 100));

            Add("date", (i, a) =>
            {
                DateTime moment = a.Length > 1 && a[1] != null
                    ? DateTimeOffset.FromUnixTimeSeconds(PhpOps.ToInt(a[1])).LocalDateTime
                    : DateTime.Now;

                return FormatDate(Str(a, 0), moment);
            });

            Add("gmdate", (i, a) => Table["date"](i, a));

            Add("mktime", (i, a) =>
            {
                DateTime now = DateTime.Now;
                int hour = (int)Int(a, 0, now.Hour);
                int minute = (int)Int(a, 1, now.Minute);
                int second = (int)Int(a, 2, now.Second);
                int month = (int)Int(a, 3, now.Month);
                int day = (int)Int(a, 4, now.Day);
                int year = (int)Int(a, 5, now.Year);

                try
                {
                    DateTime moment = new DateTime(year, 1, 1).AddMonths(month - 1).AddDays(day - 1)
                        .AddHours(hour).AddMinutes(minute).AddSeconds(second);

                    return (long)new DateTimeOffset(moment).ToUnixTimeSeconds();
                }
                catch { return false; }
            });

            Add("strtotime", (i, a) =>
            {
                string text = Str(a, 0).Trim();

                if (string.Equals(text, "now", StringComparison.OrdinalIgnoreCase))
                    return DateTimeOffset.Now.ToUnixTimeSeconds();

                DateTime parsed;
                if (DateTime.TryParse(text, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed))
                    return (long)new DateTimeOffset(parsed).ToUnixTimeSeconds();

                System.Text.RegularExpressions.Match relative =
                    System.Text.RegularExpressions.Regex.Match(text,
                        @"^([+-]?\d+)\s*(second|minute|hour|day|week|month|year)s?$",
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                if (relative.Success)
                {
                    int amount = int.Parse(relative.Groups[1].Value);
                    string unit = relative.Groups[2].Value.ToLowerInvariant();
                    DateTime moment = DateTime.Now;

                    if (unit == "second") moment = moment.AddSeconds(amount);
                    else if (unit == "minute") moment = moment.AddMinutes(amount);
                    else if (unit == "hour") moment = moment.AddHours(amount);
                    else if (unit == "day") moment = moment.AddDays(amount);
                    else if (unit == "week") moment = moment.AddDays(amount * 7);
                    else if (unit == "month") moment = moment.AddMonths(amount);
                    else moment = moment.AddYears(amount);

                    return (long)new DateTimeOffset(moment).ToUnixTimeSeconds();
                }

                return false;
            });

            Add("checkdate", (i, a) =>
            {
                int month = (int)Int(a, 0, 0), day = (int)Int(a, 1, 0), year = (int)Int(a, 2, 0);
                if (month < 1 || month > 12 || year < 1) return false;

                return day >= 1 && day <= DateTime.DaysInMonth(year, month);
            });

            Add("date_default_timezone_set", (i, a) => true);
            Add("date_default_timezone_get", (i, a) => "Europe/Moscow");
            Add("sleep", (i, a) =>
            {
                long seconds = Math.Min(5, Math.Max(0, Int(a, 0, 0)));
                System.Threading.Thread.Sleep((int)(seconds * 1000));
                return 0L;
            });
            Add("usleep", (i, a) =>
            {
                long micro = Math.Min(3000000, Math.Max(0, Int(a, 0, 0)));
                System.Threading.Thread.Sleep((int)(micro / 1000));
                return null;
            });
        }

        private static string FormatDate(string format, DateTime moment)
        {
            StringBuilder sb = new StringBuilder();
            string[] months =
            {
                "January", "February", "March", "April", "May", "June",
                "July", "August", "September", "October", "November", "December"
            };

            foreach (char c in format)
            {
                switch (c)
                {
                    case 'd': sb.Append(moment.Day.ToString("00")); break;
                    case 'j': sb.Append(moment.Day); break;
                    case 'm': sb.Append(moment.Month.ToString("00")); break;
                    case 'n': sb.Append(moment.Month); break;
                    case 'Y': sb.Append(moment.Year.ToString("0000")); break;
                    case 'y': sb.Append((moment.Year % 100).ToString("00")); break;
                    case 'H': sb.Append(moment.Hour.ToString("00")); break;
                    case 'G': sb.Append(moment.Hour); break;
                    case 'h': sb.Append((moment.Hour % 12 == 0 ? 12 : moment.Hour % 12).ToString("00")); break;
                    case 'g': sb.Append(moment.Hour % 12 == 0 ? 12 : moment.Hour % 12); break;
                    case 'i': sb.Append(moment.Minute.ToString("00")); break;
                    case 's': sb.Append(moment.Second.ToString("00")); break;
                    case 'D': sb.Append(moment.DayOfWeek.ToString().Substring(0, 3)); break;
                    case 'l': sb.Append(moment.DayOfWeek.ToString()); break;
                    case 'N': sb.Append(moment.DayOfWeek == DayOfWeek.Sunday ? 7 : (int)moment.DayOfWeek); break;
                    case 'w': sb.Append((int)moment.DayOfWeek); break;
                    case 'M': sb.Append(months[moment.Month - 1].Substring(0, 3)); break;
                    case 'F': sb.Append(months[moment.Month - 1]); break;
                    case 'a': sb.Append(moment.Hour < 12 ? "am" : "pm"); break;
                    case 'A': sb.Append(moment.Hour < 12 ? "AM" : "PM"); break;
                    case 't': sb.Append(DateTime.DaysInMonth(moment.Year, moment.Month)); break;
                    case 'L': sb.Append(DateTime.IsLeapYear(moment.Year) ? 1 : 0); break;
                    case 'z': sb.Append(moment.DayOfYear - 1); break;
                    case 'U': sb.Append(new DateTimeOffset(moment).ToUnixTimeSeconds()); break;
                    case '\\': break;
                    default: sb.Append(c); break;
                }
            }
            return sb.ToString();
        }

        // ---------- регулярные выражения ----------

        private static void RegisterRegex()
        {
            Add("preg_replace", (i, a) => PhpRegex.Replace(Arg(a, 0), Arg(a, 1), Arg(a, 2)));
            Add("preg_quote", (i, a) => System.Text.RegularExpressions.Regex.Escape(Str(a, 0)));

            Add("preg_split", (i, a) =>
            {
                PhpArray result = new PhpArray();
                long flags = Int(a, 3, 0);

                foreach (string part in PhpRegex.Split(Str(a, 0), Str(a, 1)))
                {
                    if ((flags & 1) != 0 && part.Length == 0) continue;
                    result.Append(part);
                }
                return result;
            });

            Add("preg_replace_callback", (i, a) =>
            {
                string callback = PhpOps.ToStr(Arg(a, 1));

                return PhpRegex.ReplaceCallback(Str(a, 0), Str(a, 2), groups =>
                    PhpOps.ToStr(i.CallByName(callback, new object[] { groups }, 0)));
            });

            Add("preg_grep", (i, a) =>
            {
                PhpArray source = Arr(a, 1);
                PhpArray result = new PhpArray();
                if (source == null) return result;

                foreach (object key in source.Keys)
                {
                    PhpArray unused;
                    if (PhpOps.ToBool(PhpRegex.Match(Str(a, 0), PhpOps.ToStr(source.Get(key)), out unused)))
                        result.Set(key, source.Get(key));
                }
                return result;
            });
        }

        // ---------- JSON ----------

        private static void RegisterJson()
        {
            Add("json_encode", (i, a) =>
            {
                long flags = Int(a, 1, 0);
                StringBuilder sb = new StringBuilder();

                JsonWrite(sb, Arg(a, 0), flags, 0);
                return sb.ToString();
            });

            Add("json_decode", (i, a) =>
            {
                int position = 0;
                string text = Str(a, 0);

                try { return JsonRead(text, ref position); }
                catch { return null; }
            });

            Add("json_last_error", (i, a) => 0L);
            Add("json_last_error_msg", (i, a) => "No error");
        }

        private static void JsonWrite(StringBuilder sb, object value, long flags, int depth)
        {
            bool pretty = (flags & 128) != 0;
            string indent = pretty ? new string(' ', (depth + 1) * 4) : "";
            string closeIndent = pretty ? new string(' ', depth * 4) : "";

            if (value == null) { sb.Append("null"); return; }
            if (value is bool) { sb.Append((bool)value ? "true" : "false"); return; }
            if (value is long) { sb.Append((long)value); return; }

            if (value is double)
            {
                double number = (double)value;
                sb.Append(number == Math.Floor(number)
                    ? ((long)number).ToString(CultureInfo.InvariantCulture)
                    : number.ToString("R", CultureInfo.InvariantCulture));
                return;
            }

            if (value is PhpArray)
            {
                PhpArray array = (PhpArray)value;

                bool isList = true;
                long expected = 0;

                foreach (object key in array.Keys)
                {
                    if (!(key is long) || (long)key != expected) { isList = false; break; }
                    expected++;
                }

                if (isList)
                {
                    sb.Append('[');
                    bool first = true;

                    foreach (object item in array.ValuesList())
                    {
                        if (!first) sb.Append(',');
                        if (pretty) sb.Append('\n').Append(indent);

                        JsonWrite(sb, item, flags, depth + 1);
                        first = false;
                    }

                    if (pretty && !first) sb.Append('\n').Append(closeIndent);
                    sb.Append(']');
                    return;
                }

                sb.Append('{');
                bool firstPair = true;

                foreach (object key in array.Keys)
                {
                    if (!firstPair) sb.Append(',');
                    if (pretty) sb.Append('\n').Append(indent);

                    JsonString(sb, PhpOps.ToStr(key), flags);
                    sb.Append(':');
                    if (pretty) sb.Append(' ');

                    JsonWrite(sb, array.Get(key), flags, depth + 1);
                    firstPair = false;
                }

                if (pretty && !firstPair) sb.Append('\n').Append(closeIndent);
                sb.Append('}');
                return;
            }

            JsonString(sb, PhpOps.ToStr(value), flags);
        }

        private static void JsonString(StringBuilder sb, string text, long flags)
        {
            bool unescapedSlashes = (flags & 64) != 0;
            bool unescapedUnicode = (flags & 256) != 0;

            sb.Append('"');

            foreach (char c in text)
            {
                switch (c)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    case '\b': sb.Append("\\b"); break;
                    case '\f': sb.Append("\\f"); break;
                    case '/': sb.Append(unescapedSlashes ? "/" : "\\/"); break;
                    default:
                        if (c < 32) sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else if (c > 127 && !unescapedUnicode) sb.Append("\\u").Append(((int)c).ToString("x4"));
                        else sb.Append(c);
                        break;
                }
            }

            sb.Append('"');
        }

        private static object JsonRead(string text, ref int pos)
        {
            while (pos < text.Length && char.IsWhiteSpace(text[pos])) pos++;
            if (pos >= text.Length) return null;

            char c = text[pos];

            if (c == '{')
            {
                pos++;
                PhpArray result = new PhpArray();

                while (pos < text.Length)
                {
                    while (pos < text.Length && (char.IsWhiteSpace(text[pos]) || text[pos] == ',')) pos++;
                    if (pos < text.Length && text[pos] == '}') { pos++; break; }

                    object key = JsonRead(text, ref pos);
                    while (pos < text.Length && (char.IsWhiteSpace(text[pos]) || text[pos] == ':')) pos++;

                    result.Set(PhpOps.ToStr(key), JsonRead(text, ref pos));
                }
                return result;
            }

            if (c == '[')
            {
                pos++;
                PhpArray result = new PhpArray();

                while (pos < text.Length)
                {
                    while (pos < text.Length && (char.IsWhiteSpace(text[pos]) || text[pos] == ',')) pos++;
                    if (pos < text.Length && text[pos] == ']') { pos++; break; }

                    result.Append(JsonRead(text, ref pos));
                }
                return result;
            }

            if (c == '"')
            {
                pos++;
                StringBuilder sb = new StringBuilder();

                while (pos < text.Length && text[pos] != '"')
                {
                    if (text[pos] == '\\' && pos + 1 < text.Length)
                    {
                        char next = text[pos + 1];
                        pos += 2;

                        if (next == 'n') sb.Append('\n');
                        else if (next == 'r') sb.Append('\r');
                        else if (next == 't') sb.Append('\t');
                        else if (next == 'u' && pos + 4 <= text.Length)
                        {
                            int code;
                            if (int.TryParse(text.Substring(pos, 4), NumberStyles.HexNumber,
                                CultureInfo.InvariantCulture, out code)) sb.Append((char)code);
                            pos += 4;
                        }
                        else sb.Append(next);
                        continue;
                    }

                    sb.Append(text[pos]);
                    pos++;
                }
                pos++;
                return sb.ToString();
            }

            if (string.CompareOrdinal(text, pos, "true", 0, 4) == 0) { pos += 4; return true; }
            if (string.CompareOrdinal(text, pos, "false", 0, 5) == 0) { pos += 5; return false; }
            if (string.CompareOrdinal(text, pos, "null", 0, 4) == 0) { pos += 4; return null; }

            int start = pos;
            while (pos < text.Length && (char.IsDigit(text[pos]) || text[pos] == '-' || text[pos] == '+' ||
                                         text[pos] == '.' || text[pos] == 'e' || text[pos] == 'E')) pos++;

            string number = text.Substring(start, pos - start);
            long integer;

            if (long.TryParse(number, out integer)) return integer;

            double real;
            if (double.TryParse(number, NumberStyles.Float, CultureInfo.InvariantCulture, out real)) return real;

            return null;
        }

        // ---------- хеши ----------

        private static void RegisterHash()
        {
            Add("md5", (i, a) => HashHex(System.Security.Cryptography.MD5.Create(), Str(a, 0)));
            Add("sha1", (i, a) => HashHex(System.Security.Cryptography.SHA1.Create(), Str(a, 0)));
            Add("crc32", (i, a) =>
            {
                string text = Str(a, 0);
                long hash = 0;
                foreach (char c in text) hash = (hash * 31 + c) & 0xFFFFFFFF;
                return hash;
            });

            Add("hash", (i, a) =>
            {
                string algorithm = Str(a, 0).ToLowerInvariant();
                string data = Str(a, 1);

                if (algorithm == "md5") return HashHex(System.Security.Cryptography.MD5.Create(), data);
                if (algorithm == "sha1") return HashHex(System.Security.Cryptography.SHA1.Create(), data);
                if (algorithm == "sha384") return HashHex(System.Security.Cryptography.SHA384.Create(), data);
                if (algorithm == "sha512") return HashHex(System.Security.Cryptography.SHA512.Create(), data);

                return HashHex(System.Security.Cryptography.SHA256.Create(), data);
            });

            Add("hash_algos", (i, a) =>
            {
                PhpArray result = new PhpArray();
                foreach (string name in new[] { "md5", "sha1", "sha256", "sha384", "sha512" }) result.Append(name);
                return result;
            });

            Add("hash_equals", (i, a) =>
            {
                string left = Str(a, 0), right = Str(a, 1);
                if (left.Length != right.Length) return false;

                int difference = 0;
                for (int k = 0; k < left.Length; k++) difference |= left[k] ^ right[k];
                return difference == 0;
            });

            Add("password_hash", (i, a) =>
                "lisun$" + HashHex(System.Security.Cryptography.SHA256.Create(), Str(a, 0)));

            Add("password_verify", (i, a) =>
                ("lisun$" + HashHex(System.Security.Cryptography.SHA256.Create(), Str(a, 0))) == Str(a, 1));

            Add("base64_encode", (i, a) => Convert.ToBase64String(Encoding.UTF8.GetBytes(Str(a, 0))));
            Add("base64_decode", (i, a) =>
            {
                try { return Encoding.UTF8.GetString(Convert.FromBase64String(Str(a, 0))); }
                catch { return false; }
            });

            Add("bin2hex", (i, a) =>
            {
                StringBuilder sb = new StringBuilder();
                foreach (byte b in Encoding.UTF8.GetBytes(Str(a, 0))) sb.Append(b.ToString("x2"));
                return sb.ToString();
            });

            Add("hex2bin", (i, a) =>
            {
                string hex = Str(a, 0);
                byte[] bytes = new byte[hex.Length / 2];

                for (int k = 0; k < bytes.Length; k++)
                    bytes[k] = Convert.ToByte(hex.Substring(k * 2, 2), 16);

                return Encoding.UTF8.GetString(bytes);
            });

            Add("random_bytes", (i, a) => RandomString((int)Int(a, 0, 16)));
            Add("openssl_random_pseudo_bytes", (i, a) => RandomString((int)Int(a, 0, 16)));
            Add("uniqid", (i, a) => DateTime.Now.Ticks.ToString("x13"));
        }

        private static string HashHex(System.Security.Cryptography.HashAlgorithm algorithm, string text)
        {
            using (algorithm)
            {
                byte[] hash = algorithm.ComputeHash(Encoding.UTF8.GetBytes(text));

                StringBuilder sb = new StringBuilder(hash.Length * 2);
                foreach (byte b in hash) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private static string RandomString(int length)
        {
            if (length < 1) length = 1;
            if (length > 1024) length = 1024;

            byte[] buffer = new byte[length];
            using (System.Security.Cryptography.RNGCryptoServiceProvider random =
                new System.Security.Cryptography.RNGCryptoServiceProvider()) random.GetBytes(buffer);

            // Байты представляем символами 0..255, как это делает PHP.
            StringBuilder sb = new StringBuilder(length);
            foreach (byte b in buffer) sb.Append((char)b);
            return sb.ToString();
        }

        // ---------- окружение ----------

        private static void RegisterRuntime()
        {
            Add("define", (i, a) => { i.DefineConstant(Str(a, 0), Arg(a, 1)); return true; });
            Add("defined", (i, a) => i.HasConstant(Str(a, 0)));
            Add("constant", (i, a) => i.GetConstant(Str(a, 0), 0));

            Add("header", (i, a) =>
            {
                if (i.Context == null) return null;

                string header = Str(a, 0);
                i.Context.Headers.Add(header);

                System.Text.RegularExpressions.Match status =
                    System.Text.RegularExpressions.Regex.Match(header, @"^HTTP/\d\.\d\s+(\d{3})");

                if (status.Success) i.Context.StatusCode = int.Parse(status.Groups[1].Value);
                else if (header.StartsWith("Location:", StringComparison.OrdinalIgnoreCase))
                    i.Context.StatusCode = 302;

                return null;
            });

            Add("headers_sent", (i, a) => false);
            Add("http_response_code", (i, a) =>
            {
                if (i.Context == null) return 200L;
                if (a.Length > 0) i.Context.StatusCode = (int)Int(a, 0, 200);

                return (long)i.Context.StatusCode;
            });

            Add("setcookie", (i, a) =>
            {
                if (i.Context == null) return false;

                string name = Str(a, 0), value = Str(a, 1);
                StringBuilder cookie = new StringBuilder();

                cookie.Append("Set-Cookie: ").Append(Uri.EscapeDataString(name)).Append('=')
                      .Append(Uri.EscapeDataString(value)).Append("; Path=/");

                long expires = Int(a, 2, 0);
                if (expires > 0)
                    cookie.Append("; Expires=").Append(DateTimeOffset.FromUnixTimeSeconds(expires)
                        .ToString("R", CultureInfo.InvariantCulture));

                i.Context.Headers.Add(cookie.ToString());
                return true;
            });

            Add("session_start", (i, a) =>
            {
                if (i.Context == null) return false;

                i.Globals.Set("_SESSION", PhpExecuter.LoadSession(i.Context.SessionId));
                i.Context.SessionStarted = true;

                i.Context.Headers.Add("Set-Cookie: PHPSESSID=" + i.Context.SessionId + "; Path=/; HttpOnly");
                return true;
            });

            Add("session_id", (i, a) => i.Context == null ? "" : i.Context.SessionId);
            Add("session_name", (i, a) => "PHPSESSID");

            Add("session_destroy", (i, a) =>
            {
                if (i.Context == null) return false;

                PhpExecuter.DestroySession(i.Context.SessionId);
                i.Globals.Set("_SESSION", new PhpArray());
                i.Context.SessionStarted = false;
                return true;
            });

            Add("session_unset", (i, a) => { i.Globals.Set("_SESSION", new PhpArray()); return true; });
            Add("session_regenerate_id", (i, a) =>
            {
                if (i.Context == null) return false;
                i.Context.SessionId = Guid.NewGuid().ToString("N");
                return true;
            });

            Add("error_reporting", (i, a) => 32767L);
            Add("ini_set", (i, a) => false);
            Add("ini_get", (i, a) => false);
            Add("set_time_limit", (i, a) => true);
            Add("error_log", (i, a) => { LisunEngine.Log("[PHP] " + Str(a, 0)); return true; });
            Add("trigger_error", (i, a) => { LisunEngine.Log("[PHP] " + Str(a, 0)); return true; });

            Add("phpversion", (i, a) => "8.2.0-LisunOS");
            Add("php_sapi_name", (i, a) => "lisun");
            Add("php_uname", (i, a) => "Windows LisunOS " + LisunEngine.Version);
            Add("memory_get_usage", (i, a) => GC.GetTotalMemory(false));
            Add("memory_get_peak_usage", (i, a) => GC.GetTotalMemory(false));
            Add("getenv", (i, a) =>
            {
                if (a.Length == 0) return new PhpArray();

                string value = Environment.GetEnvironmentVariable(Str(a, 0));
                return value == null ? (object)false : value;
            });

            Add("call_user_func", (i, a) =>
            {
                string name = Str(a, 0);
                object[] rest = new object[Math.Max(0, a.Length - 1)];
                Array.Copy(a, 1, rest, 0, rest.Length);

                return i.CallByName(name, rest, 0);
            });

            Add("call_user_func_array", (i, a) =>
            {
                string name = Str(a, 0);
                PhpArray array = Arr(a, 1);
                List<object> values = array == null ? new List<object>() : array.ValuesList();

                return i.CallByName(name, values.ToArray(), 0);
            });

            Add("filter_var", (i, a) =>
            {
                string value = Str(a, 0);
                long filter = Int(a, 1, 516);

                if (filter == 274)
                    return System.Text.RegularExpressions.Regex.IsMatch(value,
                        @"^[^@\s]+@[^@\s]+\.[^@\s]+$") ? (object)value : false;

                if (filter == 257)
                {
                    long parsed;
                    return long.TryParse(value.Trim(), out parsed) ? (object)parsed : false;
                }

                if (filter == 273)
                    return System.Text.RegularExpressions.Regex.IsMatch(value, @"^https?://\S+$")
                        ? (object)value : false;

                return value;
            });

            Add("ob_start", (i, a) => true);
            Add("ob_get_clean", (i, a) => "");
            Add("ob_end_clean", (i, a) => true);
            Add("flush", (i, a) => null);
            Add("gc_collect_cycles", (i, a) => 0L);
            Add("spl_autoload_register", (i, a) => true);
            Add("iterator_to_array", (i, a) => Arg(a, 0) is PhpArray ? a[0] : new PhpArray());
        }
    }
}

namespace LisunOS.Php
{
    /// <summary>
    /// Регулярные выражения PHP: шаблон вида /образец/флаги переводится
    /// в выражение .NET с соответствующими настройками.
    /// </summary>
    public static class PhpRegex
    {
        private static readonly Dictionary<string, System.Text.RegularExpressions.Regex> Cache =
            new Dictionary<string, System.Text.RegularExpressions.Regex>(StringComparer.Ordinal);

        public static System.Text.RegularExpressions.Regex Build(string pattern)
        {
            System.Text.RegularExpressions.Regex cached;
            if (Cache.TryGetValue(pattern, out cached)) return cached;

            if (string.IsNullOrEmpty(pattern)) throw new ArgumentException("пустой шаблон");

            char delimiter = pattern[0];
            char closing = delimiter;

            if (delimiter == '(') closing = ')';
            else if (delimiter == '[') closing = ']';
            else if (delimiter == '{') closing = '}';
            else if (delimiter == '<') closing = '>';

            int end = pattern.LastIndexOf(closing);
            if (end <= 0) throw new ArgumentException("шаблон без закрывающего разделителя");

            string body = pattern.Substring(1, end - 1);
            string flags = pattern.Substring(end + 1);

            System.Text.RegularExpressions.RegexOptions options =
                System.Text.RegularExpressions.RegexOptions.None;

            foreach (char flag in flags)
            {
                if (flag == 'i') options |= System.Text.RegularExpressions.RegexOptions.IgnoreCase;
                else if (flag == 'm') options |= System.Text.RegularExpressions.RegexOptions.Multiline;
                else if (flag == 's') options |= System.Text.RegularExpressions.RegexOptions.Singleline;
                else if (flag == 'x') options |= System.Text.RegularExpressions.RegexOptions.IgnorePatternWhitespace;
            }

            System.Text.RegularExpressions.Regex regex =
                new System.Text.RegularExpressions.Regex(body, options);

            if (Cache.Count < 256) Cache[pattern] = regex;
            return regex;
        }

        public static object Match(string pattern, string subject, out PhpArray matches)
        {
            matches = new PhpArray();

            System.Text.RegularExpressions.Regex regex = Build(pattern);
            System.Text.RegularExpressions.Match match = regex.Match(subject ?? "");
            if (!match.Success) return 0L;

            for (int i = 0; i < match.Groups.Count; i++)
            {
                System.Text.RegularExpressions.Group group = match.Groups[i];
                matches.Set((long)i, group.Success ? group.Value : "");
            }

            // Именованные группы доступны и по имени.
            foreach (string name in regex.GetGroupNames())
            {
                int number;
                if (int.TryParse(name, out number)) continue;

                System.Text.RegularExpressions.Group group = match.Groups[name];
                matches.Set(name, group.Success ? group.Value : "");
            }

            return 1L;
        }

        public static object MatchAll(string pattern, string subject, out PhpArray matches)
        {
            matches = new PhpArray();

            System.Text.RegularExpressions.MatchCollection found = Build(pattern).Matches(subject ?? "");

            int groupCount = 1;
            foreach (System.Text.RegularExpressions.Match match in found)
            {
                if (match.Groups.Count > groupCount) groupCount = match.Groups.Count;
            }

            for (int group = 0; group < groupCount; group++)
            {
                PhpArray list = new PhpArray();

                foreach (System.Text.RegularExpressions.Match match in found)
                {
                    System.Text.RegularExpressions.Group item = match.Groups[group];
                    list.Append(item.Success ? item.Value : "");
                }

                matches.Set((long)group, list);
            }

            return (long)found.Count;
        }

        public static object Replace(object pattern, object replacement, object subject)
        {
            PhpArray subjectArray = subject as PhpArray;
            if (subjectArray != null)
            {
                PhpArray result = new PhpArray();
                foreach (object key in subjectArray.Keys)
                    result.Set(key, Replace(pattern, replacement, subjectArray.Get(key)));

                return result;
            }

            string text = PhpOps.ToStr(subject);
            PhpArray patternArray = pattern as PhpArray;

            if (patternArray != null)
            {
                PhpArray replacementArray = replacement as PhpArray;
                List<object> patterns = patternArray.ValuesList();
                List<object> replacements = replacementArray != null ? replacementArray.ValuesList() : null;

                for (int i = 0; i < patterns.Count; i++)
                {
                    string with = replacements != null
                        ? (i < replacements.Count ? PhpOps.ToStr(replacements[i]) : "")
                        : PhpOps.ToStr(replacement);

                    text = ReplaceOne(PhpOps.ToStr(patterns[i]), with, text);
                }
                return text;
            }

            return ReplaceOne(PhpOps.ToStr(pattern), PhpOps.ToStr(replacement), text);
        }

        private static string ReplaceOne(string pattern, string replacement, string subject)
        {
            // \1 в PHP — то же, что $1 в .NET.
            string dotNet = System.Text.RegularExpressions.Regex.Replace(replacement, @"\\(\d+)", "$$$1");
            return Build(pattern).Replace(subject, dotNet);
        }

        public static string ReplaceCallback(string pattern, string subject, Func<PhpArray, string> callback)
        {
            return Build(pattern).Replace(subject ?? "", match =>
            {
                PhpArray groups = new PhpArray();
                for (int i = 0; i < match.Groups.Count; i++)
                {
                    System.Text.RegularExpressions.Group group = match.Groups[i];
                    groups.Set((long)i, group.Success ? group.Value : "");
                }

                return callback(groups);
            });
        }

        public static string[] Split(string pattern, string subject)
        {
            return Build(pattern).Split(subject ?? "");
        }
    }
}
