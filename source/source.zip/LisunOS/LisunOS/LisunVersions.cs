﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Версии LisunOS и их имена.
    ///
    /// Раньше кодовое имя было одно на всю систему — «Aurora» стояло и в
    /// первом выпуске, и в восьмом, так что по имени нельзя было понять
    /// ничего. Теперь у каждой версии своё слово, и берётся оно отсюда:
    /// номер версии — единственный источник, а имя выводится из таблицы.
    ///
    /// Слова идут по алфавиту в порядке выпусков: Aurora, Borealis, Cirrus…
    /// Так по имени сразу видно, какая версия старше.
    /// </summary>
    public static class LisunVersions
    {
        /// <summary>Одна строка таблицы: версия, её слово и дата выпуска.</summary>
        public sealed class Entry
        {
            public string Version = string.Empty;
            public string Codename = string.Empty;
            public string Date = string.Empty;

            /// <summary>Короткая строка о выпуске — для «ver list».</summary>
            public string Note = string.Empty;

            public override string ToString()
            {
                return Version + " «" + Codename + "»";
            }
        }

        /// <summary>Имя для версии, которой нет в таблице.</summary>
        public const string Unknown = "Nova";

        private static readonly Entry[] Table =
        {
            Make("1.1.0", "Aurora",     "2026-10-23", "Свой движок PHP, Wi-Fi, системный порт 8989"),
            Make("1.2.0", "Borealis",   "2026-10-24", "Три приложения, каталог пакетов, пять языков интерфейса"),
            Make("1.3.0", "Cirrus",     "2026-10-24", "Фоновые службы, конфиги как в nginx, подсказки субкоманд"),
            Make("1.4.0", "Drift",      "2026-10-24", "Право superuser только через приложение, ShhHost"),
            Make("1.5.0", "Ember",      "2026-10-24", "По ssh доступны все команды, пакеты и типы"),
            Make("1.5.1", "Fjord",      "2026-10-24", "Починено поле ввода в терминале"),
            Make("1.6.0", "Glacier",    "2026-10-24", "Настоящий SSH-2: вход с телефона и другого ПК"),
            Make("1.7.0", "Horizon",    "2026-10-24", "Подтверждение паролем, токены ограничений, запись www"),
            Make("1.8.0", "Icefall",    "2026-10-24", "Загрузки, компоненты lib, обновление, приложение Wi-Fi"),
            Make("1.8.1", "Jasper",     "2026-10-24", "Починена подпись обмена ключами ssh"),
            Make("1.8.2", "Kelvin",     "2026-10-24", "Мастер первого запуска, store install apps.all, пароли на пакеты"),

            // Слова вперёд: следующая версия получает имя сама, без правок кода.
            Make("1.8.3", "Lumen",      "", ""),
            Make("1.8.4", "Mirage",     "", ""),
            Make("1.8.5", "Nimbus",     "", ""),
            Make("1.9.0", "Onyx",       "", ""),
            Make("1.9.1", "Permafrost", "", ""),
            Make("1.9.2", "Quartz",     "", ""),
            Make("2.0.0", "Rime",       "", ""),
            Make("2.0.1", "Solstice",   "", ""),
            Make("2.1.0", "Tundra",     "", ""),
            Make("2.2.0", "Umbra",      "", ""),
            Make("2.3.0", "Vega",       "", ""),
            Make("3.0.0", "Zenith",     "", "")
        };

        private static Entry Make(string version, string codename, string date, string note)
        {
            Entry entry = new Entry();
            entry.Version = version;
            entry.Codename = codename;
            entry.Date = date;
            entry.Note = note;
            return entry;
        }

        /// <summary>Имя текущей версии системы.</summary>
        public static string Current
        {
            get { return CodenameOf(LisunEngine.Version); }
        }

        /// <summary>Имя для любой версии: «1.8.2» → «Jasper».</summary>
        public static string CodenameOf(string version)
        {
            Entry entry = Find(version);
            return entry == null ? Unknown : entry.Codename;
        }

        public static Entry Find(string version)
        {
            if (string.IsNullOrEmpty(version)) return null;

            string wanted = version.Trim().TrimStart('v', 'V');

            foreach (Entry entry in Table)
                if (string.Equals(entry.Version, wanted, StringComparison.OrdinalIgnoreCase))
                    return entry;

            return null;
        }

        /// <summary>Все выпуски, у которых есть дата, — то есть уже вышедшие.</summary>
        public static List<Entry> Released()
        {
            List<Entry> list = new List<Entry>();

            foreach (Entry entry in Table)
                if (entry.Date.Length > 0) list.Add(entry);

            return list;
        }

        /// <summary>Слова, занятые под будущие версии.</summary>
        public static List<Entry> Planned()
        {
            List<Entry> list = new List<Entry>();

            foreach (Entry entry in Table)
                if (entry.Date.Length == 0) list.Add(entry);

            return list;
        }

        /// <summary>Сравнивает версии по числам: 1.8.10 новее 1.8.9.</summary>
        public static int Compare(string left, string right)
        {
            string[] a = (left ?? string.Empty).TrimStart('v', 'V').Split('.');
            string[] b = (right ?? string.Empty).TrimStart('v', 'V').Split('.');

            int count = Math.Max(a.Length, b.Length);

            for (int index = 0; index < count; index++)
            {
                int first = index < a.Length ? Number(a[index]) : 0;
                int second = index < b.Length ? Number(b[index]) : 0;

                if (first != second) return first > second ? 1 : -1;
            }

            return 0;
        }

        private static int Number(string value)
        {
            StringBuilder digits = new StringBuilder();

            foreach (char symbol in value ?? string.Empty)
            {
                if (symbol >= '0' && symbol <= '9') digits.Append(symbol);
                else break;
            }

            int result;
            if (int.TryParse(digits.ToString(), NumberStyles.Integer,
                             CultureInfo.InvariantCulture, out result))
                return result;

            return 0;
        }

        /// <summary>
        /// Следующий номер после текущего: меняется последняя часть.
        /// 1.8.1 → 1.8.2, а не 1.9.0 — младший номер растёт, пока есть слова.
        /// </summary>
        public static string NextVersion(string version)
        {
            string[] parts = (version ?? LisunEngine.Version).TrimStart('v', 'V').Split('.');
            if (parts.Length < 3) return version;

            return parts[0] + "." + parts[1] + "." +
                   (Number(parts[2]) + 1).ToString(CultureInfo.InvariantCulture);
        }

        // =====================================================================
        //  Текст
        // =====================================================================

        /// <summary>Строка о текущей версии: номер, слово и дата.</summary>
        public static string Describe()
        {
            Entry entry = Find(LisunEngine.Version);

            StringBuilder sb = new StringBuilder();
            sb.Append("LisunOS ").Append(LisunEngine.Version).Append(" «").Append(Current).Append("»");

            if (entry != null && entry.Date.Length > 0) sb.Append("  ").Append(entry.Date);

            return sb.ToString();
        }

        /// <summary>Таблица версий для «ver list».</summary>
        public static string ListText()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(LisunLocale.T("ver.header"));
            sb.AppendLine();

            foreach (Entry entry in Released())
            {
                bool current = string.Equals(entry.Version, LisunEngine.Version,
                                             StringComparison.OrdinalIgnoreCase);

                sb.AppendLine("   " + (current ? "→ " : "  ") +
                              Pad(entry.Version, 9) + Pad("«" + entry.Codename + "»", 14) +
                              Pad(entry.Date, 12) + entry.Note);
            }

            List<Entry> planned = Planned();

            if (planned.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("   " + LisunLocale.T("ver.planned"));

                StringBuilder words = new StringBuilder();

                foreach (Entry entry in planned)
                {
                    if (words.Length > 0) words.Append(", ");
                    words.Append(entry.Version).Append(" «").Append(entry.Codename).Append("»");
                }

                sb.AppendLine("      " + words);
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ver.rule"));

            return sb.ToString();
        }

        private static string Pad(string value, int width)
        {
            if (value == null) value = string.Empty;

            return value.Length >= width ? value + " " : value.PadRight(width);
        }
    }
}
