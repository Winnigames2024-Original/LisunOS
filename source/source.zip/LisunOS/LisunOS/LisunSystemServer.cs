﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>
    /// Системный сервер LisunOS на порту 8989.
    ///
    /// Слушает только localhost и отдаёт одну страницу — php-frm.html —
    /// где в прямом эфире видно, как система находит сеть и качает PHP.
    /// Порт системный: он открывается лишь тогда, когда у приложения зала
    /// есть право hall. Без этого права сервер не поднимается.
    /// </summary>
    public static partial class LisunSystemServer
    {
        public const int Port = 8989;
        public const string PackageName = "lisun-system";
        public const string PageName = "php-frm.html";

        private static readonly object gate = new object();
        private static TcpListener listener;
        private static Thread worker;
        private static bool running;
        private static DateTime startedAt;
        private static long requests;

        /// <summary>Адрес страницы настройки php-frm.</summary>
        public static string SetupUrl
        {
            get { return "http://localhost:" + Port + "/" + PageName + "?action=setup"; }
        }

        public static bool Running
        {
            get { lock (gate) return running; }
        }

        public static long RequestCount
        {
            get { lock (gate) return requests; }
        }

        /// <summary>Приложение зала — из CONFIG, ключ hallapp.</summary>
        public static string HallApplication
        {
            get
            {
                string value;
                if (LisunEngine.RegistryConfig.TryGetValue("hallapp", out value) && value.Length > 0)
                    return value;

                return "LisunOS.lshall";
            }
        }

        /// <summary>Выдано ли приложению зала право hall.</summary>
        public static bool HallGranted
        {
            get { return LisunPermissions.IsGranted(HallApplication, LisunPermissions.Hall); }
        }

        // =====================================================================
        //  Запуск и остановка
        // =====================================================================

        /// <summary>
        /// Поднимает системный порт. Если права hall нет, оно запрашивается
        /// у пользователя; при отказе порт остаётся закрытым.
        /// </summary>
        public static bool Start(out string message)
        {
            lock (gate)
            {
                if (running)
                {
                    message = LisunLocale.T("sys.already", Port);
                    return true;
                }
            }

            if (!LisunPermissions.Demand(HallApplication, LisunPermissions.Hall))
            {
                message = LisunLocale.T("sys.needHall", HallApplication);
                return false;
            }

            try
            {
                // Только петля: системный порт не виден из сети.
                TcpListener created = new TcpListener(IPAddress.Loopback, Port);
                created.Start();

                lock (gate)
                {
                    listener = created;
                    running = true;
                    startedAt = DateTime.Now;
                    requests = 0;
                }

                worker = new Thread(Loop);
                worker.IsBackground = true;
                worker.Name = "LisunSystemServer";
                worker.Start();

                LisunEngine.Log("[system] " + LisunLocale.T("sys.started", Port));

                message = LisunLocale.T("sys.startedFull", Port, SetupUrl);
                return true;
            }
            catch (SocketException ex)
            {
                lock (gate) { running = false; listener = null; }

                message = LisunLocale.T("sys.portBusy", Port, ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                lock (gate) { running = false; listener = null; }

                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        public static void Stop()
        {
            TcpListener current;

            lock (gate)
            {
                if (!running) return;

                running = false;
                current = listener;
                listener = null;
            }

            try { if (current != null) current.Stop(); }
            catch { }

            LisunEngine.Log("[system] " + LisunLocale.T("sys.stopped", Port));
        }

        private static void Loop()
        {
            while (true)
            {
                TcpListener current;
                lock (gate)
                {
                    if (!running) return;
                    current = listener;
                }

                if (current == null) return;

                try
                {
                    TcpClient client = current.AcceptTcpClient();

                    ThreadPool.QueueUserWorkItem(ignored =>
                    {
                        try { Handle(client); }
                        catch { }
                        finally { try { client.Close(); } catch { } }
                    });
                }
                catch (SocketException)
                {
                    return;   // слушатель остановлен
                }
                catch (ObjectDisposedException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    LisunEngine.RunOnUi(() => LisunEngine.Log("[system] [ОШИБКА] " + ex.Message));
                }
            }
        }

        // =====================================================================
        //  Обработка запроса
        // =====================================================================

        private static void Handle(TcpClient client)
        {
            client.ReceiveTimeout = 10000;
            client.SendTimeout = 30000;

            using (NetworkStream stream = client.GetStream())
            {
                string requestLine = ReadLine(stream);
                if (string.IsNullOrEmpty(requestLine)) return;

                // Заголовки дочитываем, иначе браузер подвиснет на следующем запросе.
                while (true)
                {
                    string header = ReadLine(stream);
                    if (header == null || header.Length == 0) break;
                }

                lock (gate) requests++;

                // Право могли отозвать после запуска — тогда порт закрывается.
                if (!HallGranted)
                {
                    Send(stream, 403, "text/plain; charset=utf-8",
                        Encoding.UTF8.GetBytes(LisunLocale.T("sys.needHall", HallApplication)));

                    ThreadPool.QueueUserWorkItem(ignored => Stop());
                    return;
                }

                string[] parts = requestLine.Split(' ');
                if (parts.Length < 2)
                {
                    Send(stream, 400, "text/plain; charset=utf-8", Encoding.UTF8.GetBytes("Bad Request"));
                    return;
                }

                string target = parts[1];
                string path = target;
                string query = string.Empty;

                int mark = target.IndexOf('?');
                if (mark >= 0)
                {
                    path = target.Substring(0, mark);
                    query = target.Substring(mark + 1);
                }

                Dictionary<string, string> parameters = ParseQuery(query);

                string action;
                if (!parameters.TryGetValue("action", out action)) action = string.Empty;
                action = action.ToLowerInvariant();

                // Любое обращение к данным — это JSON, всё остальное — страница.
                switch (action)
                {
                    case "status":
                        SendJson(stream, BuildStatusJson());
                        return;

                    case "setup":
                    case "start":
                        StartSetup();
                        SendPageOrJson(stream, path, parameters);
                        return;

                    case "retry":
                        LisunPhpModule.BeginAutoDownload();
                        SendJson(stream, BuildStatusJson());
                        return;

                    case "wifi":
                        SendJson(stream, BuildWifiJson());
                        return;

                    case "portal":
                        LisunEngine.RunOnUi(() => LisunWifi.OpenPortal(LisunWifi.PortalUrl));
                        SendJson(stream, BuildStatusJson());
                        return;
                }

                if (path.EndsWith(".json", StringComparison.OrdinalIgnoreCase))
                {
                    SendJson(stream, BuildStatusJson());
                    return;
                }

                SendPage(stream);
            }
        }

        private static void SendPageOrJson(NetworkStream stream, string path,
            Dictionary<string, string> parameters)
        {
            string format;
            if (parameters.TryGetValue("format", out format) &&
                format.Equals("json", StringComparison.OrdinalIgnoreCase))
            {
                SendJson(stream, BuildStatusJson());
                return;
            }

            SendPage(stream);
        }

        /// <summary>
        /// Настройка: если PHP ещё не скачан, а интернет есть — загрузка
        /// стартует сразу; если сети нет, ждём её появления.
        /// </summary>
        private static void StartSetup()
        {
            if (LisunPhpModule.OwnPhpInstalled || LisunPhpModule.Downloading) return;

            if (LisunWifi.Online) LisunPhpModule.BeginAutoDownload();
            else LisunWifi.StartWatcher();
        }

        // =====================================================================
        //  JSON
        // =====================================================================

        private static string BuildStatusJson()
        {
            long received, total;
            LisunPhpModule.DownloadBytes(out received, out total);

            string[] log = LisunPhpModule.DownloadLog;

            StringBuilder sb = new StringBuilder();
            sb.Append('{');
            sb.Append("\"online\":").Append(LisunWifi.Online ? "true" : "false").Append(',');
            sb.Append("\"ssid\":").Append(Quote(LisunWifi.CurrentSsid())).Append(',');
            sb.Append("\"portal\":").Append(Quote(LisunWifi.PortalUrl)).Append(',');
            sb.Append("\"downloading\":").Append(LisunPhpModule.Downloading ? "true" : "false").Append(',');
            sb.Append("\"percent\":").Append(LisunPhpModule.DownloadPercent).Append(',');
            sb.Append("\"received\":").Append(received).Append(',');
            sb.Append("\"total\":").Append(total).Append(',');
            sb.Append("\"receivedText\":").Append(Quote(CustomFormUtils.FormatSize(received))).Append(',');
            sb.Append("\"totalText\":").Append(Quote(total > 0 ? CustomFormUtils.FormatSize(total) : "—")).Append(',');
            sb.Append("\"stage\":").Append(Quote(LisunPhpModule.DownloadStage)).Append(',');
            sb.Append("\"installed\":").Append(LisunPhpModule.OwnPhpInstalled ? "true" : "false").Append(',');
            sb.Append("\"enabled\":").Append(LisunPhpModule.IsInstalled ? "true" : "false").Append(',');
            sb.Append("\"executable\":").Append(Quote(LisunPhpModule.FindPhp() ?? string.Empty)).Append(',');
            sb.Append("\"engine\":").Append(Quote(LisunLocale.T("php.engineName"))).Append(',');
            sb.Append("\"uptime\":").Append(Quote(Uptime())).Append(',');
            sb.Append("\"requests\":").Append(RequestCount).Append(',');
            sb.Append("\"time\":").Append(Quote(DateTime.Now.ToString("HH:mm:ss"))).Append(',');

            sb.Append("\"log\":[");
            for (int index = 0; index < log.Length; index++)
            {
                if (index > 0) sb.Append(',');
                sb.Append(Quote(log[index]));
            }
            sb.Append(']');

            sb.Append('}');
            return sb.ToString();
        }

        private static string BuildWifiJson()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("{\"networks\":[");

            List<WifiNetwork> networks = LisunWifi.Scan();
            for (int index = 0; index < networks.Count; index++)
            {
                WifiNetwork network = networks[index];

                if (index > 0) sb.Append(',');
                sb.Append('{');
                sb.Append("\"ssid\":").Append(Quote(network.Ssid)).Append(',');
                sb.Append("\"signal\":").Append(network.Signal).Append(',');
                sb.Append("\"open\":").Append(network.Open ? "true" : "false").Append(',');
                sb.Append("\"security\":").Append(Quote(network.Authentication)).Append(',');
                sb.Append("\"connected\":").Append(network.Connected ? "true" : "false");
                sb.Append('}');
            }

            sb.Append("],\"current\":").Append(Quote(LisunWifi.CurrentSsid()));
            sb.Append(",\"online\":").Append(LisunWifi.Online ? "true" : "false");
            sb.Append('}');
            return sb.ToString();
        }

        private static string Uptime()
        {
            DateTime from;
            lock (gate) from = startedAt;

            TimeSpan span = DateTime.Now - from;
            return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}:{2:00}",
                (int)span.TotalHours, span.Minutes, span.Seconds);
        }

        private static string Quote(string value)
        {
            if (value == null) return "\"\"";

            StringBuilder sb = new StringBuilder("\"");
            foreach (char symbol in value)
            {
                switch (symbol)
                {
                    case '"': sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default:
                        if (symbol < ' ') sb.Append("\\u").Append(((int)symbol).ToString("x4"));
                        else sb.Append(symbol);
                        break;
                }
            }
            return sb.Append('"').ToString();
        }

        // =====================================================================
        //  Ответы
        // =====================================================================

        private static string ReadLine(NetworkStream stream)
        {
            StringBuilder sb = new StringBuilder();

            while (true)
            {
                int symbol = stream.ReadByte();

                if (symbol < 0) return sb.Length == 0 ? null : sb.ToString();
                if (symbol == '\n') return sb.ToString().TrimEnd('\r');
                if (sb.Length > 8192) return sb.ToString();

                sb.Append((char)symbol);
            }
        }

        private static Dictionary<string, string> ParseQuery(string query)
        {
            Dictionary<string, string> result =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

            if (string.IsNullOrEmpty(query)) return result;

            foreach (string pair in query.Split('&'))
            {
                if (pair.Length == 0) continue;

                int mark = pair.IndexOf('=');
                string key = mark < 0 ? pair : pair.Substring(0, mark);
                string value = mark < 0 ? string.Empty : pair.Substring(mark + 1);

                try { result[Uri.UnescapeDataString(key)] = Uri.UnescapeDataString(value.Replace('+', ' ')); }
                catch { result[key] = value; }
            }

            return result;
        }

        private static void SendJson(NetworkStream stream, string json)
        {
            Send(stream, 200, "application/json; charset=utf-8", Encoding.UTF8.GetBytes(json));
        }

        private static void SendPage(NetworkStream stream)
        {
            Send(stream, 200, "text/html; charset=utf-8", Encoding.UTF8.GetBytes(BuildPage()));
        }

        private static void Send(NetworkStream stream, int code, string contentType, byte[] body)
        {
            string status = code == 200 ? "OK"
                          : code == 400 ? "Bad Request"
                          : code == 403 ? "Forbidden"
                          : "Error";

            StringBuilder head = new StringBuilder();
            head.Append("HTTP/1.1 ").Append(code).Append(' ').Append(status).Append("\r\n");
            head.Append("Server: LisunOS-System/").Append(LisunEngine.Version).Append("\r\n");
            head.Append("Content-Type: ").Append(contentType).Append("\r\n");
            head.Append("Content-Length: ").Append(body.Length).Append("\r\n");
            head.Append("Cache-Control: no-store\r\n");
            head.Append("X-LisunOS-Port: system\r\n");
            head.Append("Connection: close\r\n\r\n");

            byte[] headBytes = Encoding.UTF8.GetBytes(head.ToString());

            stream.Write(headBytes, 0, headBytes.Length);
            stream.Write(body, 0, body.Length);
            stream.Flush();
        }
    }
}
