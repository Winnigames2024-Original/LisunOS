﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>Логика монитора системы: процессы, службы, память.</summary>
    public class SysMonLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label summary;
        private readonly ListBox processes;
        private readonly Label hint;
        private readonly Button refresh;
        private readonly Button kill;

        private readonly Timer timer = new Timer();
        private readonly List<string> processKeys = new List<string>();

        public SysMonLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblMonTitle");
            summary = context.Get<Label>("lblMonSummary");
            processes = context.Get<ListBox>("lstMonProcesses");
            hint = context.Get<Label>("lblMonHint");
            refresh = context.Get<Button>("btnMonRefresh");
            kill = context.Get<Button>("btnMonKill");
        }

        public void Initialize()
        {
            if (form != null)
            {
                form.Text = LisunLocale.T("mon.title");
                form.Disposed += (s, e) => { try { timer.Stop(); timer.Dispose(); } catch { } };
            }

            if (summary != null) summary.Font = Theme.Mono(9.5f);
            if (hint != null) hint.Font = Theme.Mono(9f);

            if (processes != null)
            {
                processes.Font = Theme.Mono(10f);
                processes.ItemHeight = 20;
                processes.SelectedIndexChanged += (s, e) => UpdateHint();
            }

            if (refresh != null) Theme.StyleButton(refresh, Theme.SurfaceAlt, Theme.Text);
            if (kill != null) Theme.StyleButton(kill, Theme.SurfaceAlt, Theme.Danger);

            timer.Interval = 2000;
            timer.Tick += (s, e) => Refresh();
            timer.Start();

            Refresh();
        }

        private void Refresh()
        {
            if (form == null || form.IsDisposed) return;

            if (summary != null)
            {
                TimeSpan up = LisunEngine.UptimeValue;
                StringBuilder sb = new StringBuilder();
                sb.Append(LisunLocale.T("mon.uptime")).Append(": ")
                  .Append((int)up.TotalHours).Append("h ").Append(up.Minutes).Append("m ")
                  .Append(up.Seconds).Append("s      ");
                sb.Append(LisunLocale.T("mon.memory")).Append(": ")
                  .Append(CustomFormUtils.FormatSize(GC.GetTotalMemory(false))).Append("      ");
                sb.Append(LisunLocale.T("mon.apps")).Append(": ").Append(FormEngine.ActiveApps.Count);
                sb.AppendLine();
                sb.Append(LisunLocale.T("mon.services")).Append(": ")
                  .Append(LisunServiceManager.All().Count).Append("      ");
                sb.Append("ufw: ").Append(LisunFirewall.Enabled
                    ? LisunLocale.T("ufw.on") : LisunLocale.T("ufw.off")).Append("      ");
                sb.Append(LisunLocale.T("mon.commands")).Append(": ")
                  .Append(LisunEngine.RegisteredCommands.Count);

                summary.Text = sb.ToString();
            }

            if (processes == null) return;

            int selected = processes.SelectedIndex;

            processes.BeginUpdate();
            try
            {
                processes.Items.Clear();
                processKeys.Clear();

                foreach (KeyValuePair<string, DynamicApp> kvp in FormEngine.ActiveApps)
                {
                    DynamicApp app = kvp.Value;
                    string state = app.Form == null
                        ? LisunLocale.T("ps.noForm")
                        : (app.Form.Visible ? LisunLocale.T("ps.running") : LisunLocale.T("ps.idle"));

                    processes.Items.Add("  " + kvp.Key.PadRight(18) +
                                        (app.PackageName ?? "—").PadRight(16) + state);
                    processKeys.Add(kvp.Key);
                }

                foreach (LisunServiceManager.ServiceInfo info in LisunServiceManager.All())
                {
                    if (info.Running) continue;

                    processes.Items.Add("  " + ("[" + info.Name + "]").PadRight(18) +
                                        "—".PadRight(16) + LisunLocale.T("systemctl.inactive"));
                    processKeys.Add(null);
                }

                if (processes.Items.Count == 0) processes.Items.Add("  " + LisunLocale.T("ps.empty").Trim());
            }
            finally
            {
                processes.EndUpdate();
            }

            if (selected >= 0 && selected < processes.Items.Count) processes.SelectedIndex = selected;
            UpdateHint();
        }

        private void UpdateHint()
        {
            if (hint == null) return;

            string key = SelectedKey();
            hint.Text = key == null ? LisunLocale.T("mon.pick") : LisunLocale.T("mon.selected", key);
            if (kill != null) kill.Enabled = key != null;
        }

        private string SelectedKey()
        {
            if (processes == null) return null;

            int index = processes.SelectedIndex;
            if (index < 0 || index >= processKeys.Count) return null;
            return processKeys[index];
        }

        private void btnMonRefresh_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void btnMonKill_Click(object sender, EventArgs e)
        {
            string key = SelectedKey();
            if (key == null) return;

            if (!LisunPermissions.Demand(packageName, LisunPermissions.RunServices)) return;

            FormEngine.CloseApplication(key);
            LisunEngine.Log("[SysMon] Процесс " + key + " завершён.");
            Refresh();
        }
    }
}
