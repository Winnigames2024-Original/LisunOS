﻿using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Пакет под паролем.
    ///
    /// Обычный .lnsh — это ZIP, и всё внутри открыто: кто скачал файл, тот и
    /// прочитал приложение. Для своих пакетов этого мало, поэтому у .lnsh
    /// появился второй вид — с замком:
    ///
    ///     пакет.lnsh
    ///     ├── lock.json      чем закрыто: соль, вектор, число проходов
    ///     └── payload.enc    тот же пакет целиком, но зашифрованный
    ///
    /// Ключ выводится из пароля (PBKDF2-SHA256, 120 000 проходов), данные
    /// шифруются AES-256-CBC, а поверх считается HMAC-SHA256 — подменить
    /// содержимое, не зная пароля, нельзя: проверка отпечатка не сойдётся.
    /// Пароль нигде не хранится: ни в пакете, ни в системе.
    /// </summary>
    public static class LisunPackageLock
    {
        public const string LockEntry = "lock.json";
        public const string PayloadEntry = "payload.enc";

        public const int Iterations = 120000;
        private const int SaltSize = 16;
        private const int KeySize = 32;
        private const int MacSize = 32;

        /// <summary>Что известно о замке, пока пароль не введён.</summary>
        public sealed class LockInfo
        {
            public bool Locked;
            public string Name = string.Empty;
            public string Hint = string.Empty;
            public string Algorithm = string.Empty;
            public int Iterations;
            public long PayloadSize;
        }

        // =====================================================================
        //  Чтение замка
        // =====================================================================

        /// <summary>Закрыт ли пакет паролем, и чем именно.</summary>
        public static LockInfo Inspect(string packagePath)
        {
            LockInfo info = new LockInfo();

            try
            {
                using (ZipArchive zip = ZipFile.OpenRead(packagePath))
                {
                    ZipArchiveEntry lockEntry = zip.GetEntry(LockEntry);
                    ZipArchiveEntry payload = zip.GetEntry(PayloadEntry);

                    if (lockEntry == null || payload == null) return info;

                    string body;
                    using (StreamReader reader = new StreamReader(lockEntry.Open(), Encoding.UTF8))
                        body = reader.ReadToEnd();

                    LisunJson.Node root = LisunJson.Parse(body);
                    if (root == null || !root.IsObject) return info;

                    info.Locked = true;
                    info.Name = Text(root, "name");
                    info.Hint = Text(root, "hint");
                    info.Algorithm = Text(root, "algo");
                    info.PayloadSize = payload.Length;

                    LisunJson.Node rounds = root.Child("iterations");
                    info.Iterations = rounds == null ? Iterations : (int)rounds.Number;
                }
            }
            catch { }

            return info;
        }

        public static bool IsLocked(string packagePath)
        {
            return Inspect(packagePath).Locked;
        }

        // =====================================================================
        //  Создание
        // =====================================================================

        /// <summary>
        /// Собирает пакет из папки. Без пароля получается обычный .lnsh,
        /// с паролем — тот же пакет, запертый внутри payload.enc.
        /// </summary>
        public static bool Create(string sourceFolder, string targetPath,
                                  string password, string hint, out string message)
        {
            if (!Directory.Exists(sourceFolder))
            {
                message = LisunLocale.T("pack.noFolder", sourceFolder);
                return false;
            }

            if (!File.Exists(Path.Combine(sourceFolder, "meta.json")))
            {
                message = LisunLocale.T("pack.noMeta", sourceFolder);
                return false;
            }

            string plain = Path.Combine(LisunEngine.TempPath,
                "pack_" + Guid.NewGuid().ToString("N") + ".zip");

            try
            {
                string directory = Path.GetDirectoryName(targetPath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                if (!Directory.Exists(LisunEngine.TempPath))
                    Directory.CreateDirectory(LisunEngine.TempPath);

                if (File.Exists(plain)) File.Delete(plain);
                ZipFile.CreateFromDirectory(sourceFolder, plain, CompressionLevel.Optimal, false);

                int files = 0;
                using (ZipArchive check = ZipFile.OpenRead(plain)) files = check.Entries.Count;

                if (string.IsNullOrEmpty(password))
                {
                    if (File.Exists(targetPath)) File.Delete(targetPath);
                    File.Move(plain, targetPath);

                    message = LisunLocale.T("pack.done", CustomFormUtils.ToVirtualPath(targetPath),
                        files, CustomFormUtils.FormatSize(new FileInfo(targetPath).Length));
                    return true;
                }

                byte[] data = File.ReadAllBytes(plain);

                byte[] salt = new byte[SaltSize];
                byte[] iv = new byte[16];

                using (RandomNumberGenerator random = RandomNumberGenerator.Create())
                {
                    random.GetBytes(salt);
                    random.GetBytes(iv);
                }

                byte[] cipherKey, macKey;
                DeriveKeys(password, salt, Iterations, out cipherKey, out macKey);

                byte[] encrypted = Transform(data, cipherKey, iv, true);
                byte[] mac;

                using (HMACSHA256 hmac = new HMACSHA256(macKey)) mac = hmac.ComputeHash(encrypted);

                string lockBody = BuildLockJson(Path.GetFileNameWithoutExtension(targetPath),
                    hint, salt, iv, mac);

                if (File.Exists(targetPath)) File.Delete(targetPath);

                using (FileStream output = new FileStream(targetPath, FileMode.Create, FileAccess.Write))
                using (ZipArchive zip = new ZipArchive(output, ZipArchiveMode.Create))
                {
                    ZipArchiveEntry lockEntry = zip.CreateEntry(LockEntry, CompressionLevel.Optimal);
                    using (StreamWriter writer = new StreamWriter(lockEntry.Open(), new UTF8Encoding(false)))
                        writer.Write(lockBody);

                    ZipArchiveEntry payload = zip.CreateEntry(PayloadEntry, CompressionLevel.NoCompression);
                    using (Stream stream = payload.Open()) stream.Write(encrypted, 0, encrypted.Length);
                }

                message = LisunLocale.T("pack.doneLocked", CustomFormUtils.ToVirtualPath(targetPath),
                    files, CustomFormUtils.FormatSize(new FileInfo(targetPath).Length));

                LisunEngine.Log("[pack] " + message.Trim());
                return true;
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("pack.failed", ex.Message);
                return false;
            }
            finally
            {
                try { if (File.Exists(plain)) File.Delete(plain); }
                catch { }
            }
        }

        // =====================================================================
        //  Открытие
        // =====================================================================

        /// <summary>
        /// Расшифровывает пакет во временный файл. Возвращает путь к обычному
        /// .lnsh, который дальше ставится как всегда.
        /// </summary>
        public static bool Unlock(string packagePath, string password,
                                  out string unlockedPath, out string message)
        {
            unlockedPath = null;

            try
            {
                byte[] salt, iv, mac, encrypted;
                int rounds;

                using (ZipArchive zip = ZipFile.OpenRead(packagePath))
                {
                    ZipArchiveEntry lockEntry = zip.GetEntry(LockEntry);
                    ZipArchiveEntry payload = zip.GetEntry(PayloadEntry);

                    if (lockEntry == null || payload == null)
                    {
                        message = LisunLocale.T("lock.notLocked");
                        return false;
                    }

                    string body;
                    using (StreamReader reader = new StreamReader(lockEntry.Open(), Encoding.UTF8))
                        body = reader.ReadToEnd();

                    LisunJson.Node root = LisunJson.Parse(body);
                    if (root == null || !root.IsObject)
                    {
                        message = LisunLocale.T("lock.badLock");
                        return false;
                    }

                    salt = FromBase64(Text(root, "salt"));
                    iv = FromBase64(Text(root, "iv"));
                    mac = FromBase64(Text(root, "mac"));

                    LisunJson.Node node = root.Child("iterations");
                    rounds = node == null ? Iterations : (int)node.Number;

                    if (salt.Length == 0 || iv.Length != 16 || mac.Length != MacSize || rounds < 1000)
                    {
                        message = LisunLocale.T("lock.badLock");
                        return false;
                    }

                    using (Stream stream = payload.Open())
                    using (MemoryStream buffer = new MemoryStream())
                    {
                        stream.CopyTo(buffer);
                        encrypted = buffer.ToArray();
                    }
                }

                byte[] cipherKey, macKey;
                DeriveKeys(password, salt, rounds, out cipherKey, out macKey);

                byte[] actual;
                using (HMACSHA256 hmac = new HMACSHA256(macKey)) actual = hmac.ComputeHash(encrypted);

                // Сверяем отпечаток до расшифровки: неверный пароль виден здесь,
                // и расшифровывать мусор уже не нужно.
                if (!SameBytes(actual, mac))
                {
                    message = LisunLocale.T("lock.wrongPassword");
                    return false;
                }

                byte[] plain = Transform(encrypted, cipherKey, iv, false);

                string target = Path.Combine(LisunEngine.TempPath,
                    "unlocked_" + Path.GetFileNameWithoutExtension(packagePath) + ".lnsh");

                if (!Directory.Exists(LisunEngine.TempPath))
                    Directory.CreateDirectory(LisunEngine.TempPath);

                File.WriteAllBytes(target, plain);

                if (!LisunDownloads.LooksLikeZip(target))
                {
                    try { File.Delete(target); }
                    catch { }

                    message = LisunLocale.T("lock.badPayload");
                    return false;
                }

                unlockedPath = target;
                message = LisunLocale.T("lock.opened", Path.GetFileName(packagePath));

                LisunEngine.Log("[lock] " + message.Trim());
                return true;
            }
            catch (Exception ex)
            {
                message = LisunLocale.T("lock.failed", ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Спрашивает пароль в окне и открывает пакет. По сети окна не
        /// показать, поэтому в сеансе ssh установка закрытого пакета
        /// отклоняется — пароль туда передавать неоткуда.
        /// </summary>
        public static bool AskAndUnlock(string packagePath, out string unlockedPath, out string message)
        {
            unlockedPath = null;
            message = LisunLocale.T("lock.wrongPassword");

            LockInfo info = Inspect(packagePath);

            if (!info.Locked)
            {
                message = LisunLocale.T("lock.notLocked");
                return false;
            }

            if (CommandExecutorEngine.IsRemote || LisunElevation.SilentMode)
            {
                message = LisunLocale.T("lock.remote");
                return false;
            }

            for (int attempt = 1; attempt <= 3; attempt++)
            {
                string password = LisunElevation.AskPassword(
                    LisunLocale.T("lock.title"),
                    LisunLocale.T("lock.body", Path.GetFileName(packagePath),
                        info.Hint.Length > 0 ? info.Hint : LisunLocale.T("lock.noHint")),
                    false);

                if (password == null)
                {
                    message = LisunLocale.T("lock.cancelled");
                    return false;
                }

                string note;
                if (Unlock(packagePath, password, out unlockedPath, out note))
                {
                    message = note;
                    return true;
                }

                message = note;

                if (attempt == 3) return false;
            }

            return false;
        }

        // =====================================================================
        //  Криптография
        // =====================================================================

        private static void DeriveKeys(string password, byte[] salt, int rounds,
                                       out byte[] cipherKey, out byte[] macKey)
        {
            using (Rfc2898DeriveBytes kdf = new Rfc2898DeriveBytes(
                       password ?? string.Empty, salt, rounds, HashAlgorithmName.SHA256))
            {
                byte[] material = kdf.GetBytes(KeySize + KeySize);

                cipherKey = new byte[KeySize];
                macKey = new byte[KeySize];

                Buffer.BlockCopy(material, 0, cipherKey, 0, KeySize);
                Buffer.BlockCopy(material, KeySize, macKey, 0, KeySize);
            }
        }

        private static byte[] Transform(byte[] data, byte[] key, byte[] iv, bool encrypt)
        {
            using (AesManaged aes = new AesManaged())
            {
                aes.KeySize = 256;
                aes.Key = key;
                aes.IV = iv;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                using (ICryptoTransform transform = encrypt ? aes.CreateEncryptor() : aes.CreateDecryptor())
                    return transform.TransformFinalBlock(data, 0, data.Length);
            }
        }

        private static bool SameBytes(byte[] left, byte[] right)
        {
            if (left == null || right == null || left.Length != right.Length) return false;

            int difference = 0;
            for (int index = 0; index < left.Length; index++) difference |= left[index] ^ right[index];

            return difference == 0;
        }

        // =====================================================================
        //  Мелочи
        // =====================================================================

        private static string BuildLockJson(string name, string hint, byte[] salt, byte[] iv, byte[] mac)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("{");
            sb.AppendLine("  \"lisun_lock\": 1,");
            sb.AppendLine("  \"name\": \"" + Escape(name) + "\",");
            sb.AppendLine("  \"algo\": \"aes-256-cbc\",");
            sb.AppendLine("  \"kdf\": \"pbkdf2-sha256\",");
            sb.AppendLine("  \"iterations\": " + Iterations.ToString(CultureInfo.InvariantCulture) + ",");
            sb.AppendLine("  \"salt\": \"" + Convert.ToBase64String(salt) + "\",");
            sb.AppendLine("  \"iv\": \"" + Convert.ToBase64String(iv) + "\",");
            sb.AppendLine("  \"mac\": \"" + Convert.ToBase64String(mac) + "\",");
            sb.AppendLine("  \"hint\": \"" + Escape(hint ?? string.Empty) + "\",");
            sb.AppendLine("  \"created\": \"" +
                DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "\"");
            sb.Append("}");

            return sb.ToString();
        }

        private static string Escape(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;

            return value.Replace("\\", "\\\\").Replace("\"", "\\\"")
                        .Replace("\r", " ").Replace("\n", " ");
        }

        private static string Text(LisunJson.Node node, string key)
        {
            LisunJson.Node child = node.Child(key);
            return child == null ? string.Empty : child.AsText().Trim();
        }

        private static byte[] FromBase64(string value)
        {
            try { return string.IsNullOrEmpty(value) ? new byte[0] : Convert.FromBase64String(value); }
            catch { return new byte[0]; }
        }
    }
}
