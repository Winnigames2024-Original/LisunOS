﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Разрешения приложений LisunOS.
    /// Приложение объявляет их в meta.json ("permissions": [...]), пользователь выдаёт их
    /// при установке или по запросу во время работы, а ядро проверяет каждое
    /// чувствительное действие через Demand(). Выданные права хранятся
    /// в /os/root/regedit/PERMISSIONS.
    /// </summary>
    public static class LisunPermissions
    {
        public const string Superuser = "superuser";
        public const string ReadFiles = "read_files";
        public const string WriteFiles = "write_files";
        public const string EditFiles = "edit_files";
        public const string ManageFiles = "manage_files";
        public const string EditSettings = "edit_settings";
        public const string Network = "network";
        public const string RunServices = "run_services";
        public const string ShowDialogs = "show_dialogs";
        public const string Autostart = "autostart";

        /// <summary>Доступ зала: системные порты и службы уровня оболочки.</summary>
        public const string Hall = "hall";

        /// <summary>Фоновая работа по таймеру без окна.</summary>
        public const string Background = "background";

        /// <summary>Приём входящих подключений: сервер, ssh, системный порт.</summary>
        public const string Listen = "listen";

        /// <summary>Управление другими пакетами: установка и удаление.</summary>
        public const string ManagePackages = "manage_packages";

        /// <summary>Чтение и запись учётных записей пользователей.</summary>
        public const string ManageUsers = "manage_users";

        /// <summary>Смена языка, раскладки и оформления системы.</summary>
        public const string Appearance = "appearance";

        /// <summary>Доступ к буферу обмена Windows.</summary>
        public const string Clipboard = "clipboard";

        /// <summary>Запуск внешних программ Windows.</summary>
        public const string RunExternal = "run_external";

        /// <summary>Чтение журнала ядра целиком.</summary>
        public const string ReadLog = "read_log";

        public static readonly string[] Known =
        {
            Superuser, ReadFiles, WriteFiles, EditFiles, ManageFiles,
            EditSettings, Network, RunServices, ShowDialogs, Autostart, Hall,
            Background, Listen, ManagePackages, ManageUsers, Appearance,
            Clipboard, RunExternal, ReadLog
        };

        private static readonly Dictionary<string, string[]> Descriptions =
            new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase)
        {
            { Superuser,    new[] { "Полный доступ ко всем возможностям системы", "Full access to every system capability" } },
            { ReadFiles,    new[] { "Чтение файлов виртуальной системы",          "Read files in the virtual file system" } },
            { WriteFiles,   new[] { "Создание новых файлов и папок",              "Create new files and folders" } },
            { EditFiles,    new[] { "Изменение и переименование файлов",          "Modify and rename files" } },
            { ManageFiles,  new[] { "Удаление файлов и папок",                    "Delete files and folders" } },
            { EditSettings, new[] { "Изменение реестра и настроек системы",       "Change the registry and system settings" } },
            { Network,      new[] { "Загрузка данных из сети",                    "Download data from the network" } },
            { RunServices,  new[] { "Запуск других служб и приложений",           "Start other services and applications" } },
            { ShowDialogs,  new[] { "Показ системных окон и уведомлений",         "Show system dialogs and notifications" } },
            { Autostart,    new[] { "Автозапуск при загрузке системы",            "Start automatically when the system boots" } },
            { Hall,         new[] { "Доступ зала: системные порты и службы оболочки", "Hall access: system ports and shell services" } },
            { Background,   new[] { "Работа по таймеру без окна",           "Timed work with no window" } },
            { Listen,       new[] { "Приём входящих подключений",            "Accept incoming connections" } },
            { ManagePackages, new[] { "Установка и удаление пакетов",        "Install and remove packages" } },
            { ManageUsers,  new[] { "Учётные записи пользователей",          "User accounts" } },
            { Appearance,   new[] { "Язык, раскладка и оформление",          "Language, layout and appearance" } },
            { Clipboard,    new[] { "Буфер обмена Windows",                  "The Windows clipboard" } },
            { RunExternal,  new[] { "Запуск внешних программ Windows",       "Starting external Windows programs" } },
            { ReadLog,      new[] { "Чтение журнала ядра",                   "Reading the kernel log" } }
        };

        private static readonly Dictionary<string, HashSet<string>> Grants =
            new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        /// Время последнего отказа по паре «приложение + право».
        /// Отказ больше не запоминается навсегда: право запрашивается снова при
        /// следующем действии, а короткая пауза лишь не даёт окнам сыпаться подряд,
        /// когда одно и то же действие вызывается в цикле или по таймеру.
        /// </summary>
        private static readonly Dictionary<string, DateTime> LastDenied =
            new Dictionary<string, DateTime>(StringComparer.OrdinalIgnoreCase);

        private static readonly TimeSpan AskCooldown = TimeSpan.FromSeconds(2);

        private static bool loaded;

        /// <summary>Пока true, запросы прав не показываются (например, во время загрузки системы).</summary>
        public static bool SilentMode { get; set; }

        public static event Action<string, string, bool> OnPermissionDecision;

        public static string StorePath
        {
            get { return Path.Combine(LisunEngine.RegeditPath, "PERMISSIONS"); }
        }

        // =====================================================================
        //  Хранилище
        // =====================================================================

        public static void Load()
        {
            Grants.Clear();
            loaded = true;

            try
            {
                if (!File.Exists(StorePath)) return;

                foreach (string raw in File.ReadAllLines(StorePath))
                {
                    string line = raw.Trim();
                    if (line.Length == 0 || line.StartsWith("#")) continue;

                    string[] parts = line.Split(new[] { '=' }, 2);
                    if (parts.Length != 2) continue;

                    HashSet<string> set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                    foreach (string item in parts[1].Split(','))
                    {
                        string permission = item.Trim();
                        if (permission.Length > 0) set.Add(permission);
                    }

                    Grants[parts[0].Trim()] = set;
                }

                LisunEngine.Log("[Perm] Загружены права приложений: " + Grants.Count + ".");
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Perm] [ОШИБКА] Чтение PERMISSIONS: " + ex.Message);
            }
        }

        public static void Save()
        {
            try
            {
                List<string> lines = new List<string>();
                foreach (KeyValuePair<string, HashSet<string>> kvp in Grants)
                {
                    string[] values = new string[kvp.Value.Count];
                    kvp.Value.CopyTo(values);
                    Array.Sort(values, StringComparer.OrdinalIgnoreCase);
                    lines.Add(kvp.Key + "=" + string.Join(",", values));
                }
                File.WriteAllLines(StorePath, lines, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Perm] [ОШИБКА] Запись PERMISSIONS: " + ex.Message);
            }
        }

        private static void EnsureLoaded()
        {
            if (!loaded) Load();
        }

        // =====================================================================
        //  Справочник
        // =====================================================================

        public static bool IsKnown(string permission)
        {
            return permission != null && Descriptions.ContainsKey(permission.Trim());
        }

        public static string Describe(string permission)
        {
            string[] variants;
            if (permission != null && Descriptions.TryGetValue(permission.Trim(), out variants))
            {
                int index = LisunLocale.Language == LisunLanguage.English ? 1 : 0;
                return index < variants.Length ? variants[index] : variants[0];
            }
            return LisunLocale.T("perm.unknown");
        }

        public static string DescribeAll()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("perm.allTitle") + Environment.NewLine);
            foreach (string permission in Known) sb.AppendLine("   " + permission.PadRight(14) + " — " + Describe(permission));
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Проверки
        // =====================================================================

        public static string[] GrantedFor(string application)
        {
            EnsureLoaded();

            HashSet<string> set;
            if (string.IsNullOrEmpty(application) || !Grants.TryGetValue(application, out set)) return new string[0];

            string[] values = new string[set.Count];
            set.CopyTo(values);
            Array.Sort(values, StringComparer.OrdinalIgnoreCase);
            return values;
        }

        public static bool IsGranted(string application, string permission)
        {
            EnsureLoaded();

            // Системные компоненты без пакета работают с полными правами.
            if (string.IsNullOrEmpty(application)) return true;

            HashSet<string> set;
            if (!Grants.TryGetValue(application, out set)) return false;

            return set.Contains(Superuser) || set.Contains(permission);
        }

        public static void Grant(string application, string permission)
        {
            EnsureLoaded();
            if (string.IsNullOrEmpty(application) || string.IsNullOrEmpty(permission)) return;

            HashSet<string> set;
            if (!Grants.TryGetValue(application, out set))
            {
                set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                Grants[application] = set;
            }

            set.Add(permission.Trim());
            Save();

            Action<string, string, bool> handler = OnPermissionDecision;
            if (handler != null) handler(application, permission, true);
        }

        public static void Revoke(string application, string permission)
        {
            EnsureLoaded();

            HashSet<string> set;
            if (!Grants.TryGetValue(application, out set)) return;

            set.Remove(permission.Trim());
            Save();

            Action<string, string, bool> handler = OnPermissionDecision;
            if (handler != null) handler(application, permission, false);
        }

        public static bool Reset(string application)
        {
            EnsureLoaded();
            ForgetDenials(application);

            if (!Grants.Remove(application)) return false;
            Save();
            return true;
        }

        public static List<string> ApplicationsWithGrants()
        {
            EnsureLoaded();
            List<string> names = new List<string>(Grants.Keys);
            names.Sort(StringComparer.OrdinalIgnoreCase);
            return names;
        }

        public static string ListAllGrants()
        {
            List<string> apps = ApplicationsWithGrants();
            if (apps.Count == 0) return LisunLocale.T("perm.listEmpty");

            StringBuilder sb = new StringBuilder(LisunLocale.T("perm.listTitle") + Environment.NewLine);
            foreach (string app in apps)
            {
                sb.AppendLine("   • " + app);
                foreach (string permission in GrantedFor(app))
                    sb.AppendLine("       " + permission.PadRight(14) + " — " + Describe(permission));
            }
            return sb.ToString().TrimEnd();
        }

        public static string ListFor(string application)
        {
            string[] granted = GrantedFor(application);
            if (granted.Length == 0) return LisunLocale.T("perm.appNone", application);

            StringBuilder sb = new StringBuilder(LisunLocale.T("perm.appTitle", application) + Environment.NewLine);
            foreach (string permission in granted)
                sb.AppendLine("   " + permission.PadRight(14) + " — " + Describe(permission));
            return sb.ToString().TrimEnd();
        }

        /// <summary>
        /// Проверка перед действием. Если право не выдано — приложение запрашивает его
        /// у пользователя. Повторный отказ в пределах сессии больше не беспокоит вопросами.
        /// </summary>
        public static bool Demand(string application, string permission)
        {
            if (IsGranted(application, permission)) return true;
            if (string.IsNullOrEmpty(application)) return true;
            if (SilentMode) return false;

            string key = application + "|" + permission;

            DateTime lastDenial;
            if (LastDenied.TryGetValue(key, out lastDenial) && DateTime.Now - lastDenial < AskCooldown)
            {
                // Пауза после отказа — чтобы повторный вызов того же действия
                // не открыл окно второй раз мгновенно.
                return false;
            }

            if (Request(application, permission))
            {
                LastDenied.Remove(key);
                return true;
            }

            LastDenied[key] = DateTime.Now;
            LisunEngine.Log(LisunLocale.T("perm.denied", application, permission).Trim());
            return false;
        }

        /// <summary>Забыть отказы приложения — следующее действие спросит право заново.</summary>
        public static void ForgetDenials(string application)
        {
            if (string.IsNullOrEmpty(application))
            {
                LastDenied.Clear();
                return;
            }

            List<string> stale = new List<string>();
            foreach (KeyValuePair<string, DateTime> item in LastDenied)
            {
                if (item.Key.StartsWith(application + "|", StringComparison.OrdinalIgnoreCase)) stale.Add(item.Key);
            }

            foreach (string key in stale) LastDenied.Remove(key);
        }

        /// <summary>Проверка без запроса — для фоновых операций.</summary>
        public static bool Check(string application, string permission)
        {
            return IsGranted(application, permission);
        }

        // =====================================================================
        //  Запрос у пользователя
        // =====================================================================

        /// <summary>
        /// Токен ALLOW_PERMISSION_*_REQUEST текущего пользователя закрывает
        /// приложению саму возможность попросить право: окно не появится,
        /// и согласие уже ничего не изменит.
        /// </summary>
        public static bool MayAsk(string permission)
        {
            string token = RequestTokenFor(permission);
            if (token.Length == 0) return true;

            return LisunUsers.IsAllowed(CommandExecutorEngine.ActiveUser, token);
        }

        private static string RequestTokenFor(string permission)
        {
            switch ((permission ?? string.Empty).ToLowerInvariant())
            {
                case ReadFiles:   return "ALLOW_PERMISSION_READ_FILES_REQUEST";
                case WriteFiles:  return "ALLOW_PERMISSION_CREATE_FILES_REQUEST";
                case EditFiles:   return "ALLOW_PERMISSION_EDIT_FILES_REQUEST";
                case ManageFiles: return "ALLOW_PERMISSION_DELETE_FILES_REQUEST";
                case ManagePackages: return "ALLOW_PERMISSION_PACKAGES_REQUEST";
                case Network:
                case Listen:      return "ALLOW_PERMISSION_NETWORK_REQUEST";
                case ManageUsers: return "ALLOW_PERMISSION_USERS_REQUEST";
                case RunServices: return "ALLOW_PERMISSION_APPS_REQUEST";
                case EditSettings:
                case Autostart:
                case Appearance:  return "ALLOW_PERMISSION_SYSTEM_REQUEST";
                case Superuser:
                case Hall:        return "ALLOW_PERMISSION_SUPERUSER_REQUEST";

                default: return string.Empty;
            }
        }

        public static bool Request(string application, string permission)
        {
            if (!MayAsk(permission))
            {
                LisunEngine.Log("[Perm] " + LisunLocale.T("perm.askBlocked", application, permission).Trim());
                return false;
            }

            List<string> single = new List<string>();
            single.Add(permission);

            List<string> approved = Ask(LisunLocale.T("perm.askSingle", application), single);
            if (approved == null || approved.Count == 0) return false;

            foreach (string item in approved) Grant(application, item);
            return IsGranted(application, permission);
        }

        /// <summary>Запрос всего списка прав — вызывается при установке пакета.</summary>
        public static bool RequestMany(string application, string description, List<string> permissions)
        {
            if (permissions == null || permissions.Count == 0) return true;

            List<string> valid = new List<string>();
            foreach (string permission in permissions)
            {
                if (!IsKnown(permission))
                {
                    LisunEngine.Log("[Perm] Пропущено неизвестное право в манифесте: " + permission);
                    continue;
                }

                if (!MayAsk(permission))
                {
                    LisunEngine.Log("[Perm] " + LisunLocale.T("perm.askBlocked", application, permission).Trim());
                    continue;
                }

                valid.Add(permission);
            }
            if (valid.Count == 0) return true;

            string header = LisunLocale.T("perm.askInstall", application);
            if (!string.IsNullOrEmpty(description)) header += Environment.NewLine + description;

            List<string> approved = Ask(header, valid);
            if (approved == null) return false;

            foreach (string item in approved) Grant(application, item);

            LisunEngine.Log("[Perm] " + application + ": выдано прав — " + approved.Count + " из " + valid.Count + ".");
            return true;
        }

        /// <summary>Диалог согласия в стиле оболочки. Возвращает null, если пользователь отказал.</summary>
        private static List<string> Ask(string header, List<string> permissions)
        {
            List<string> result = null;

            LisunEngine.RunOnUi(() =>
            {
                using (Form dialog = new Form())
                {
                    dialog.Text = LisunLocale.T("perm.dialogTitle");
                    dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
                    dialog.StartPosition = FormStartPosition.CenterScreen;
                    dialog.MinimizeBox = false;
                    dialog.MaximizeBox = false;
                    dialog.ShowInTaskbar = false;
                    dialog.TopMost = true;
                    dialog.BackColor = Theme.Background;
                    dialog.ForeColor = Theme.Text;
                    dialog.Font = Theme.Ui(9.5f);
                    dialog.ClientSize = new Size(580, 196 + permissions.Count * 52);

                    // Цветная полоса сверху: окно сразу читается как системное,
                    // а не как часть самого приложения.
                    Panel stripe = new Panel();
                    stripe.BackColor = Theme.Accent;
                    stripe.SetBounds(0, 0, 580, 4);
                    dialog.Controls.Add(stripe);

                    Label caption = new Label();
                    caption.Text = header;
                    caption.ForeColor = Theme.Text;
                    caption.Font = Theme.Ui(12f, FontStyle.Bold);
                    caption.AutoSize = false;
                    caption.SetBounds(22, 20, 536, 48);
                    dialog.Controls.Add(caption);

                    Label who = new Label();
                    who.Text = LisunLocale.T("perm.askWho", CommandExecutorEngine.ActiveUser);
                    who.ForeColor = Theme.TextDim;
                    who.Font = Theme.Ui(9f);
                    who.AutoSize = false;
                    who.SetBounds(22, 68, 536, 20);
                    dialog.Controls.Add(who);

                    List<CheckBox> boxes = new List<CheckBox>();
                    int top = 96;

                    foreach (string permission in permissions)
                    {
                        bool isSuperuser = permission.Equals(Superuser, StringComparison.OrdinalIgnoreCase) ||
                                           permission.Equals(Hall, StringComparison.OrdinalIgnoreCase);

                        // Каждое право — карточка: сверху само право,
                        // снизу обычными словами, что оно открывает.
                        Panel card = new Panel();
                        card.BackColor = isSuperuser ? Color.FromArgb(58, 36, 22) : Theme.Surface;
                        card.SetBounds(22, top, 536, 44);
                        dialog.Controls.Add(card);

                        CheckBox box = new CheckBox();
                        box.Text = permission;
                        box.Tag = permission;
                        box.ForeColor = isSuperuser ? Theme.Warning : Theme.Text;
                        box.Font = Theme.Mono(9.75f, FontStyle.Bold);
                        box.FlatStyle = FlatStyle.Flat;
                        box.AutoSize = false;
                        box.TextAlign = ContentAlignment.MiddleLeft;
                        box.CheckAlign = ContentAlignment.MiddleLeft;
                        box.Padding = new Padding(8, 0, 0, 0);
                        box.SetBounds(10, 3, 516, 22);

                        // Полный доступ по умолчанию снят — его включают осознанно.
                        box.Checked = !isSuperuser;
                        card.Controls.Add(box);

                        Label what = new Label();
                        what.Text = Describe(permission);
                        what.ForeColor = Theme.TextDim;
                        what.Font = Theme.Ui(8.75f);
                        what.AutoSize = false;
                        what.SetBounds(38, 24, 488, 18);
                        card.Controls.Add(what);

                        boxes.Add(box);
                        top += 52;
                    }

                    top += 4;

                    Label note = new Label();
                    note.Text = LisunLocale.T("perm.note");
                    note.ForeColor = Theme.TextDim;
                    note.AutoSize = false;
                    note.SetBounds(22, top + 6, 330, 36);
                    dialog.Controls.Add(note);

                    Button allow = new Button();
                    allow.Text = LisunLocale.T("perm.allow");
                    allow.DialogResult = DialogResult.OK;
                    allow.SetBounds(332, top + 10, 110, 32);
                    Theme.StyleButton(allow, Theme.AccentDeep, Theme.Text);

                    Button deny = new Button();
                    deny.Text = LisunLocale.T("perm.deny");
                    deny.DialogResult = DialogResult.Cancel;
                    deny.SetBounds(450, top + 10, 110, 32);
                    Theme.StyleButton(deny, Theme.SurfaceAlt, Theme.Text);

                    dialog.Controls.Add(allow);
                    dialog.Controls.Add(deny);
                    dialog.AcceptButton = allow;
                    dialog.CancelButton = deny;

                    if (dialog.ShowDialog() != DialogResult.OK) return;

                    List<string> approved = new List<string>();
                    foreach (CheckBox box in boxes)
                    {
                        if (box.Checked) approved.Add(box.Tag.ToString());
                    }
                    result = approved;
                }
            });

            return result;
        }
    }
}
