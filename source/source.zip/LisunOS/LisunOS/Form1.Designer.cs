﻿namespace LisunOS
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlTitleBar;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Button btnMaximize;
        private System.Windows.Forms.Button btnClose;

        private System.Windows.Forms.FlowLayoutPanel pnlTabs;

        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlTerminal;
        private System.Windows.Forms.Panel pnlConsolePad;
        private System.Windows.Forms.RichTextBox rtbConsole;
        private System.Windows.Forms.Panel pnlInputOuter;
        private System.Windows.Forms.Panel pnlInputInner;
        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.ListBox lstSuggest;

        private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.Label lblStatusLeft;
        private System.Windows.Forms.Label lblStatusRight;
        private System.Windows.Forms.Button btnLanguage;
        private System.Windows.Forms.Button btnLayout;

        private System.Windows.Forms.Timer clockTimer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pnlTitleBar = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.btnMaximize = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.pnlTabs = new System.Windows.Forms.FlowLayoutPanel();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlTerminal = new System.Windows.Forms.Panel();
            this.pnlConsolePad = new System.Windows.Forms.Panel();
            this.rtbConsole = new System.Windows.Forms.RichTextBox();
            this.pnlInputOuter = new System.Windows.Forms.Panel();
            this.pnlInputInner = new System.Windows.Forms.Panel();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.lstSuggest = new System.Windows.Forms.ListBox();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.lblStatusLeft = new System.Windows.Forms.Label();
            this.lblStatusRight = new System.Windows.Forms.Label();
            this.btnLanguage = new System.Windows.Forms.Button();
            this.btnLayout = new System.Windows.Forms.Button();
            this.clockTimer = new System.Windows.Forms.Timer(this.components);

            this.pnlTitleBar.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlTerminal.SuspendLayout();
            this.pnlConsolePad.SuspendLayout();
            this.pnlInputOuter.SuspendLayout();
            this.pnlInputInner.SuspendLayout();
            this.pnlStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 10F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(214)))), ((int)(((byte)(224)))));
            this.lblTitle.Padding = new System.Windows.Forms.Padding(8, 0, 0, 0);
            this.lblTitle.Text = "LisunOS  ·  Core Terminal";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnMenu
            // 
            this.btnMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMenu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.btnMenu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(150)))), ((int)(((byte)(162)))));
            this.btnMenu.Size = new System.Drawing.Size(46, 38);
            this.btnMenu.TabStop = false;
            this.btnMenu.Text = "☰";
            this.btnMenu.UseVisualStyleBackColor = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnMinimize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(150)))), ((int)(((byte)(162)))));
            this.btnMinimize.Size = new System.Drawing.Size(48, 38);
            this.btnMinimize.TabStop = false;
            this.btnMinimize.Text = "—";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMaximize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMaximize.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnMaximize.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(150)))), ((int)(((byte)(162)))));
            this.btnMaximize.Size = new System.Drawing.Size(48, 38);
            this.btnMaximize.TabStop = false;
            this.btnMaximize.Text = "☐";
            this.btnMaximize.UseVisualStyleBackColor = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // btnClose
            // 
            this.btnClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnClose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(150)))), ((int)(((byte)(162)))));
            this.btnClose.Size = new System.Drawing.Size(48, 38);
            this.btnClose.TabStop = false;
            this.btnClose.Text = "✕";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlTitleBar
            // 
            this.pnlTitleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.pnlTitleBar.Controls.Add(this.lblTitle);
            this.pnlTitleBar.Controls.Add(this.btnMenu);
            this.pnlTitleBar.Controls.Add(this.btnMinimize);
            this.pnlTitleBar.Controls.Add(this.btnMaximize);
            this.pnlTitleBar.Controls.Add(this.btnClose);
            this.pnlTitleBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTitleBar.Size = new System.Drawing.Size(1100, 38);
            // 
            // pnlTabs
            // 
            this.pnlTabs.AutoScroll = false;
            this.pnlTabs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlTabs.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTabs.FlowDirection = System.Windows.Forms.FlowDirection.LeftToRight;
            this.pnlTabs.Padding = new System.Windows.Forms.Padding(12, 6, 12, 0);
            this.pnlTabs.Size = new System.Drawing.Size(1100, 38);
            this.pnlTabs.WrapContents = false;
            // 
            // rtbConsole
            // 
            this.rtbConsole.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.rtbConsole.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbConsole.DetectUrls = false;
            this.rtbConsole.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbConsole.Font = new System.Drawing.Font("Consolas", 10.5F);
            this.rtbConsole.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(214)))), ((int)(((byte)(224)))));
            this.rtbConsole.ReadOnly = true;
            this.rtbConsole.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbConsole.TabIndex = 99;
            this.rtbConsole.TabStop = false;
            this.rtbConsole.Text = "";
            // 
            // pnlConsolePad
            // 
            this.pnlConsolePad.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlConsolePad.Controls.Add(this.rtbConsole);
            this.pnlConsolePad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlConsolePad.Padding = new System.Windows.Forms.Padding(16, 12, 8, 4);
            // 
            // lblPrompt
            // 
            this.lblPrompt.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblPrompt.Font = new System.Drawing.Font("Consolas", 10.5F, System.Drawing.FontStyle.Bold);
            this.lblPrompt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(88)))), ((int)(((byte)(166)))), ((int)(((byte)(255)))));
            this.lblPrompt.Size = new System.Drawing.Size(96, 24);
            this.lblPrompt.Text = "LisunOS:\\>";
            this.lblPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtInput
            // 
            this.txtInput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.txtInput.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInput.Font = new System.Drawing.Font("Consolas", 10.5F);
            this.txtInput.ForeColor = System.Drawing.Color.White;
            this.txtInput.Multiline = true;
            this.txtInput.TabIndex = 0;
            this.txtInput.WordWrap = false;
            this.txtInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtInput_KeyDown);
            // 
            // pnlInputInner
            // 
            this.pnlInputInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.pnlInputInner.Controls.Add(this.txtInput);
            this.pnlInputInner.Controls.Add(this.lblPrompt);
            this.pnlInputInner.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlInputInner.Padding = new System.Windows.Forms.Padding(16, 8, 16, 8);
            this.pnlInputInner.Resize += new System.EventHandler(this.pnlInputInner_Resize);
            this.pnlInputInner.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlInputInner_Paint);
            // 
            // pnlInputOuter
            // 
            this.pnlInputOuter.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlInputOuter.Controls.Add(this.pnlInputInner);
            this.pnlInputOuter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlInputOuter.Padding = new System.Windows.Forms.Padding(16, 6, 16, 14);
            this.pnlInputOuter.Size = new System.Drawing.Size(1100, 60);
            // 
            // lstSuggest
            // 
            this.lstSuggest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(36)))), ((int)(((byte)(46)))));
            this.lstSuggest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstSuggest.Font = new System.Drawing.Font("Consolas", 10F);
            this.lstSuggest.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(214)))), ((int)(((byte)(224)))));
            this.lstSuggest.IntegralHeight = false;
            this.lstSuggest.ItemHeight = 20;
            this.lstSuggest.Name = "lstSuggest";
            this.lstSuggest.TabStop = false;
            this.lstSuggest.Visible = false;
            this.lstSuggest.Click += new System.EventHandler(this.lstSuggest_Click);
            // 
            // pnlTerminal
            // 
            this.pnlTerminal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlTerminal.Controls.Add(this.pnlConsolePad);
            this.pnlTerminal.Controls.Add(this.pnlInputOuter);
            this.pnlTerminal.Controls.Add(this.lstSuggest);
            this.pnlTerminal.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.pnlMain.Controls.Add(this.pnlTerminal);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // lblStatusLeft
            // 
            this.lblStatusLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblStatusLeft.Font = new System.Drawing.Font("Consolas", 9F);
            this.lblStatusLeft.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.lblStatusLeft.Padding = new System.Windows.Forms.Padding(16, 0, 0, 0);
            this.lblStatusLeft.Text = "LisunOS:\\";
            this.lblStatusLeft.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblStatusRight
            // 
            this.lblStatusRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblStatusRight.Font = new System.Drawing.Font("Consolas", 9F);
            this.lblStatusRight.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.lblStatusRight.Padding = new System.Windows.Forms.Padding(0, 0, 16, 0);
            this.lblStatusRight.Size = new System.Drawing.Size(360, 28);
            this.lblStatusRight.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLanguage
            // 
            this.btnLanguage.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLanguage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLanguage.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.btnLanguage.Size = new System.Drawing.Size(96, 28);
            this.btnLanguage.TabStop = false;
            this.btnLanguage.Text = "Русский";
            this.btnLanguage.UseVisualStyleBackColor = false;
            this.btnLanguage.Click += new System.EventHandler(this.btnLanguage_Click);
            // 
            // btnLayout
            // 
            this.btnLayout.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnLayout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLayout.Font = new System.Drawing.Font("Segoe UI Semibold", 8.5F, System.Drawing.FontStyle.Bold);
            this.btnLayout.Size = new System.Drawing.Size(54, 28);
            this.btnLayout.TabStop = false;
            this.btnLayout.Text = "RU";
            this.btnLayout.UseVisualStyleBackColor = false;
            this.btnLayout.Click += new System.EventHandler(this.btnLayout_Click);
            // 
            // pnlStatus
            // 
            this.pnlStatus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(27)))), ((int)(((byte)(34)))));
            this.pnlStatus.Controls.Add(this.lblStatusLeft);
            this.pnlStatus.Controls.Add(this.lblStatusRight);
            this.pnlStatus.Controls.Add(this.btnLanguage);
            this.pnlStatus.Controls.Add(this.btnLayout);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlStatus.Size = new System.Drawing.Size(1100, 28);
            // 
            // clockTimer
            // 
            this.clockTimer.Interval = 1000;
            this.clockTimer.Tick += new System.EventHandler(this.clockTimer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(13)))), ((int)(((byte)(17)))), ((int)(((byte)(23)))));
            this.ClientSize = new System.Drawing.Size(1100, 680);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.pnlStatus);
            this.Controls.Add(this.pnlTabs);
            this.Controls.Add(this.pnlTitleBar);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(214)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.MinimumSize = new System.Drawing.Size(900, 560);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LisunOS Core Terminal";

            this.pnlTitleBar.ResumeLayout(false);
            this.pnlMain.ResumeLayout(false);
            this.pnlTerminal.ResumeLayout(false);
            this.pnlConsolePad.ResumeLayout(false);
            this.pnlInputOuter.ResumeLayout(false);
            this.pnlInputInner.ResumeLayout(false);
            this.pnlInputInner.PerformLayout();
            this.pnlStatus.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}
