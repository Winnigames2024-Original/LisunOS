﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика приложения SuperUser (пакет apps/superuserapp).
    ///
    /// Единственное место, где пакет получает право superuser: команды su и
    /// sudo в терминале больше его не включают, а только сообщают, что нужно
    /// открыть это окно. Пользователь выбирает пакет в списке, подтверждает
    /// флажком, что понимает последствия, и нажимает «Выдать superuser».
    /// </summary>
    public partial class SuperUserLogicBridge
    {
        private readonly Form form;
        private readonly string packageName;

        private readonly Label title;
        private readonly Label warning;
        private readonly ListView targets;
        private readonly Label pick;
        private readonly Label explain;
        private readonly CheckBox understand;
        private readonly Button grant;
        private readonly Button revoke;
        private readonly Button elevate;
        private readonly Button drop;
        private readonly Label mode;
        private readonly Label status;

        /// <summary>Пакеты в том же порядке, в каком они лежат в списке.</summary>
        private readonly List<string> rows = new List<string>();

        public SuperUserLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            title = context.Get<Label>("lblTitle");
            warning = context.Get<Label>("lblWarning");
            targets = context.Get<ListView>("lstTargets");
            pick = context.Get<Label>("lblPick");
            explain = context.Get<Label>("lblExplain");
            understand = context.Get<CheckBox>("chkUnderstand");
            grant = context.Get<Button>("btnGrantSuper");
            revoke = context.Get<Button>("btnRevokeSuper");
            elevate = context.Get<Button>("btnElevate");
            drop = context.Get<Button>("btnDrop");
            mode = context.Get<Label>("lblMode");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("suapp.windowTitle");

            if (title != null)
            {
                title.Text = LisunLocale.T("suapp.windowTitle");
                title.Font = Theme.Ui(14f, FontStyle.Bold);
                title.ForeColor = Theme.Text;
            }

            if (warning != null)
            {
                warning.Text = LisunLocale.T("suapp.warning");
                warning.Font = Theme.Ui(9f);
                warning.ForeColor = Theme.Warning;
            }

            if (pick != null)
            {
                pick.Font = Theme.Ui(11f, FontStyle.Bold);
                pick.ForeColor = Theme.Text;
            }

            if (explain != null) explain.Font = Theme.Ui(8.75f);
            if (status != null) status.Font = Theme.Mono(8.75f);
            if (mode != null) mode.Font = Theme.Mono(9f);

            if (understand != null)
            {
                understand.Text = LisunLocale.T("suapp.understand");
                understand.Font = Theme.Ui(8.75f);
                understand.ForeColor = Theme.TextDim;
            }

            if (targets != null)
            {
                targets.Font = Theme.Mono(9.5f);
                targets.Columns.Add(LisunLocale.T("suapp.columnPackage"), 170);
                targets.Columns.Add(LisunLocale.T("suapp.columnType"), 90);
                targets.Columns.Add(LisunLocale.T("suapp.columnSuper"), 90);
                targets.Columns.Add(LisunLocale.T("suapp.columnRights"), 80);
            }

            if (grant != null)
            {
                grant.Text = LisunLocale.T("suapp.grant");
                Theme.StyleButton(grant, Theme.AccentDeep, Theme.Text);
            }
            if (revoke != null)
            {
                revoke.Text = LisunLocale.T("suapp.revoke");
                Theme.StyleButton(revoke, Theme.SurfaceAlt, Theme.TextDim);
            }
            if (elevate != null)
            {
                elevate.Text = LisunLocale.T("suapp.enableMode");
                Theme.StyleButton(elevate, Theme.SurfaceAlt, Theme.Text);
            }
            if (drop != null)
            {
                drop.Text = LisunLocale.T("suapp.disableMode");
                Theme.StyleButton(drop, Theme.SurfaceAlt, Theme.TextDim);
            }

            FillList();
            ShowSelected();
            ShowMode();
            SetStatus(LisunLocale.T("suapp.ready"));
        }

        // =====================================================================
        //  Список пакетов
        // =====================================================================

        /// <summary>
        /// Собирает список кандидатов: установленные пакеты плюс те приложения,
        /// у которых уже есть хоть одно выданное право (встроенные службы).
        /// </summary>
        private List<string> Candidates()
        {
            List<string> names = new List<string>();

            try
            {
                foreach (LisunServiceManager.ServiceInfo info in LisunServiceManager.All())
                {
                    if (string.IsNullOrEmpty(info.Name)) continue;
                    if (!names.Contains(info.Name)) names.Add(info.Name);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[superuser] [ОШИБКА] " + ex.Message);
            }

            try
            {
                foreach (string application in LisunPermissions.ApplicationsWithGrants())
                {
                    if (string.IsNullOrEmpty(application)) continue;

                    bool known = false;
                    foreach (string existing in names)
                    {
                        if (existing.Equals(application, StringComparison.OrdinalIgnoreCase)) { known = true; break; }
                    }
                    if (!known) names.Add(application);
                }
            }
            catch { }

            names.Sort(StringComparer.OrdinalIgnoreCase);
            return names;
        }

        private void FillList()
        {
            if (targets == null) return;

            string selected = SelectedPackage();

            targets.BeginUpdate();
            targets.Items.Clear();
            rows.Clear();

            foreach (string name in Candidates())
            {
                bool super = LisunPermissions.IsGranted(name, LisunPermissions.Superuser);
                string type = TypeOf(name);
                int count = 0;
                try { count = LisunPermissions.GrantedFor(name).Length; }
                catch { count = 0; }

                ListViewItem row = new ListViewItem(name);
                row.SubItems.Add(type);
                row.SubItems.Add(super ? LisunLocale.T("suapp.yes") : LisunLocale.T("suapp.no"));
                row.SubItems.Add(count.ToString());
                row.ForeColor = super ? Theme.Warning : Theme.Text;

                targets.Items.Add(row);
                rows.Add(name);
            }

            targets.EndUpdate();

            if (selected != null) Select(selected);
            else if (targets.Items.Count > 0) targets.Items[0].Selected = true;
        }

        private string TypeOf(string name)
        {
            try
            {
                LisunServiceManager.ServiceInfo info = LisunServiceManager.Find(name);
                if (info != null)
                {
                    LisunManifest manifest = LisunOSInstallerShell.ReadManifest(info.Folder);
                    if (manifest != null && !string.IsNullOrEmpty(manifest.Type)) return manifest.Type;
                }
            }
            catch { }

            return LisunLocale.T("suapp.typeSystem");
        }

        private void Select(string name)
        {
            if (targets == null || name == null) return;

            for (int index = 0; index < rows.Count && index < targets.Items.Count; index++)
            {
                if (rows[index].Equals(name, StringComparison.OrdinalIgnoreCase))
                {
                    targets.Items[index].Selected = true;
                    targets.Items[index].EnsureVisible();
                    return;
                }
            }
        }

        private string SelectedPackage()
        {
            if (targets == null) return null;
            if (targets.SelectedIndices.Count == 0) return null;

            int index = targets.SelectedIndices[0];
            if (index < 0 || index >= rows.Count) return null;
            return rows[index];
        }

        // =====================================================================
        //  Карточка выбранного пакета
        // =====================================================================

        private void ShowSelected()
        {
            string name = SelectedPackage();

            if (name == null)
            {
                if (pick != null) pick.Text = LisunLocale.T("suapp.nothing");
                if (explain != null) explain.Text = LisunLocale.T("suapp.explainEmpty");
                if (understand != null) { understand.Checked = false; understand.Enabled = false; }
                if (grant != null) grant.Enabled = false;
                if (revoke != null) revoke.Enabled = false;
                return;
            }

            bool super = LisunPermissions.IsGranted(name, LisunPermissions.Superuser);

            if (pick != null) pick.Text = name;
            if (explain != null)
            {
                string rights;
                try { rights = string.Join(", ", LisunPermissions.GrantedFor(name)); }
                catch { rights = string.Empty; }
                if (string.IsNullOrEmpty(rights)) rights = LisunLocale.T("suapp.noRights");

                explain.Text = (super ? LisunLocale.T("suapp.hasSuper") : LisunLocale.T("suapp.noSuper")) +
                               "\r\n\r\n" + LisunLocale.T("suapp.rightsLabel") + "\r\n" + rights +
                               "\r\n\r\n" + LisunLocale.T("suapp.explain");
            }

            if (understand != null)
            {
                understand.Enabled = !super;
                if (super) understand.Checked = false;
            }

            if (grant != null) grant.Enabled = !super && understand != null && understand.Checked;
            if (revoke != null) revoke.Enabled = super;
        }

        private void ShowMode()
        {
            if (mode == null) return;

            mode.Text = CommandExecutorEngine.IsSuperUser
                ? LisunLocale.T("suapp.modeOn")
                : LisunLocale.T("suapp.modeOff");
            mode.ForeColor = CommandExecutorEngine.IsSuperUser ? Theme.Warning : Theme.TextDim;

            if (elevate != null)
            {
                string name = SelectedPackage();
                elevate.Enabled = !CommandExecutorEngine.IsSuperUser && name != null &&
                                  LisunPermissions.IsGranted(name, LisunPermissions.Superuser);
            }
            if (drop != null) drop.Enabled = CommandExecutorEngine.IsSuperUser;
        }

        private void SetStatus(string text)
        {
            if (status != null) status.Text = text;
            LisunEngine.Log("[superuser] " + (text ?? string.Empty));
        }

        // =====================================================================
        //  Обработчики формы
        // =====================================================================

        public void lstTargets_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowSelected();
            ShowMode();
        }

        public void chkUnderstand_CheckedChanged(object sender, EventArgs e)
        {
            if (grant == null) return;

            string name = SelectedPackage();
            bool super = name != null && LisunPermissions.IsGranted(name, LisunPermissions.Superuser);
            grant.Enabled = name != null && !super && understand != null && understand.Checked;
        }

        public void btnGrantSuper_Click(object sender, EventArgs e)
        {
            string name = SelectedPackage();
            if (name == null)
            {
                SetStatus(LisunLocale.T("suapp.pickFirst"));
                return;
            }

            if (understand == null || !understand.Checked)
            {
                SetStatus(LisunLocale.T("suapp.confirmFirst"));
                return;
            }

            if (LisunPermissions.IsGranted(name, LisunPermissions.Superuser))
            {
                SetStatus(LisunLocale.T("suapp.alreadySuper", name));
                return;
            }

            DialogResult answer = MessageBox.Show(
                LisunLocale.T("suapp.askBody", name),
                LisunLocale.T("suapp.askTitle"),
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning,
                MessageBoxDefaultButton.Button2);

            if (answer != DialogResult.Yes)
            {
                SetStatus(LisunLocale.T("suapp.cancelled"));
                return;
            }

            LisunPermissions.Grant(name, LisunPermissions.Superuser);
            understand.Checked = false;

            FillList();
            Select(name);
            ShowSelected();
            ShowMode();
            SetStatus(LisunLocale.T("suapp.granted", name));
        }

        public void btnRevokeSuper_Click(object sender, EventArgs e)
        {
            string name = SelectedPackage();
            if (name == null)
            {
                SetStatus(LisunLocale.T("suapp.pickFirst"));
                return;
            }

            if (!LisunPermissions.IsGranted(name, LisunPermissions.Superuser))
            {
                SetStatus(LisunLocale.T("suapp.notSuper", name));
                return;
            }

            LisunPermissions.Revoke(name, LisunPermissions.Superuser);

            // Если режим был включён этим пакетом, он больше не обоснован.
            if (CommandExecutorEngine.IsSuperUser) CommandExecutorEngine.DropElevation();

            FillList();
            Select(name);
            ShowSelected();
            ShowMode();
            SetStatus(LisunLocale.T("suapp.revoked", name));
        }

        public void btnElevate_Click(object sender, EventArgs e)
        {
            string name = SelectedPackage();
            if (name == null)
            {
                SetStatus(LisunLocale.T("suapp.pickFirst"));
                return;
            }

            if (CommandExecutorEngine.ElevateFromSuperUserApp(name))
            {
                ShowMode();
                SetStatus(LisunLocale.T("suapp.modeEnabled", name));
            }
            else
            {
                SetStatus(LisunLocale.T("suapp.modeRefused", name));
            }
        }

        public void btnDrop_Click(object sender, EventArgs e)
        {
            CommandExecutorEngine.DropElevation();
            ShowMode();
            SetStatus(LisunLocale.T("suapp.modeDisabled"));
        }
    }
}
