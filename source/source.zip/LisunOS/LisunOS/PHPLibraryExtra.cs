﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS.Php
{
    /// <summary>
    /// Вторая часть библиотеки PHP: функции, которых не хватало движку.
    /// Строки, массивы, тригонометрия, дата, работа с дескрипторами файлов,
    /// ctype, hmac, сериализация и разбор адресов.
    /// </summary>
    public static partial class PhpLibrary
    {
        // =====================================================================
        //  Дескрипторы файлов для fopen/fread/fwrite
        // =====================================================================

        private class PhpStream
        {
            public FileStream Stream;
            public string Mode = string.Empty;
            public string Path = string.Empty;
        }

        // Запросы к серверу идут в своих потоках, поэтому таблица дескрипторов
        // у каждого потока своя: иначе один запрос закрыл бы файлы другого.
        [ThreadStatic] private static Dictionary<long, PhpStream> streams;
        [ThreadStatic] private static long streamCounter;

        private static Dictionary<long, PhpStream> Streams
        {
            get { return streams ?? (streams = new Dictionary<long, PhpStream>()); }
        }

        private static PhpStream Handle(object[] args, int index)
        {
            object value = Arg(args, index);
            if (value == null) return null;

            long id = PhpOps.ToInt(value);

            PhpStream stream;
            return Streams.TryGetValue(id, out stream) ? stream : null;
        }

        /// <summary>Закрывает все открытые дескрипторы: вызывается после запроса.</summary>
        public static void CloseStreams()
        {
            foreach (KeyValuePair<long, PhpStream> pair in Streams)
            {
                try { pair.Value.Stream.Dispose(); }
                catch { }
            }

            Streams.Clear();
        }

        private static void RegisterExtra()
        {
            RegisterExtraStrings();
            RegisterExtraArrays();
            RegisterExtraMath();
            RegisterExtraTime();
            RegisterExtraFiles();
            RegisterCtype();
            RegisterExtraHash();
            RegisterExtraUrl();
        }

        // =====================================================================
        //  Строки
        // =====================================================================

        private static void RegisterExtraStrings()
        {
            Add("strstr", (i, a) =>
            {
                string haystack = Str(a, 0);
                string needle = Str(a, 1);
                int at = haystack.IndexOf(needle, StringComparison.Ordinal);

                if (at < 0) return false;
                return Bool(a, 2, false) ? haystack.Substring(0, at) : haystack.Substring(at);
            });

            Add("stristr", (i, a) =>
            {
                string haystack = Str(a, 0);
                string needle = Str(a, 1);
                int at = haystack.IndexOf(needle, StringComparison.OrdinalIgnoreCase);

                if (at < 0) return false;
                return Bool(a, 2, false) ? haystack.Substring(0, at) : haystack.Substring(at);
            });

            Add("strrchr", (i, a) =>
            {
                string haystack = Str(a, 0);
                string needle = Str(a, 1);
                if (needle.Length == 0) return false;

                int at = haystack.LastIndexOf(needle[0]);
                return at < 0 ? (object)false : haystack.Substring(at);
            });

            Add("strpbrk", (i, a) =>
            {
                string text = Str(a, 0);
                string symbols = Str(a, 1);
                int at = text.IndexOfAny(symbols.ToCharArray());

                return at < 0 ? (object)false : text.Substring(at);
            });

            Add("strspn", (i, a) =>
            {
                string text = Str(a, 0);
                string mask = Str(a, 1);
                int length = 0;

                while (length < text.Length && mask.IndexOf(text[length]) >= 0) length++;
                return (long)length;
            });

            Add("strcspn", (i, a) =>
            {
                string text = Str(a, 0);
                string mask = Str(a, 1);
                int length = 0;

                while (length < text.Length && mask.IndexOf(text[length]) < 0) length++;
                return (long)length;
            });

            Add("strncmp", (i, a) =>
            {
                int length = (int)Int(a, 2, 0);
                return (long)Math.Sign(string.CompareOrdinal(Cut(Str(a, 0), length), Cut(Str(a, 1), length)));
            });

            Add("strncasecmp", (i, a) =>
            {
                int length = (int)Int(a, 2, 0);
                return (long)Math.Sign(string.Compare(Cut(Str(a, 0), length), Cut(Str(a, 1), length),
                    StringComparison.OrdinalIgnoreCase));
            });

            Add("strnatcmp", (i, a) => (long)NaturalCompare(Str(a, 0), Str(a, 1), false));
            Add("strnatcasecmp", (i, a) => (long)NaturalCompare(Str(a, 0), Str(a, 1), true));

            Add("substr_replace", (i, a) =>
            {
                string text = Str(a, 0);
                string replacement = Str(a, 1);
                int start = (int)Int(a, 2, 0);

                if (start < 0) start = Math.Max(0, text.Length + start);
                if (start > text.Length) start = text.Length;

                int length = a.Length > 3 && a[3] != null ? (int)Int(a, 3, 0) : text.Length - start;
                if (length < 0) length = Math.Max(0, text.Length + length - start);
                if (start + length > text.Length) length = text.Length - start;

                return text.Substring(0, start) + replacement + text.Substring(start + length);
            });

            Add("substr_compare", (i, a) =>
            {
                string text = Str(a, 0);
                string other = Str(a, 1);
                int offset = (int)Int(a, 2, 0);

                if (offset < 0) offset = Math.Max(0, text.Length + offset);
                if (offset > text.Length) return false;

                string part = text.Substring(offset);

                if (a.Length > 3 && a[3] != null)
                {
                    int length = (int)Int(a, 3, 0);
                    part = Cut(part, length);
                    other = Cut(other, length);
                }

                return (long)Math.Sign(Bool(a, 4, false)
                    ? string.Compare(part, other, StringComparison.OrdinalIgnoreCase)
                    : string.CompareOrdinal(part, other));
            });

            Add("strtr", (i, a) =>
            {
                string text = Str(a, 0);

                // strtr($text, ['из' => 'в', ...])
                PhpArray map = Arr(a, 1);
                if (map != null)
                {
                    List<string> keys = new List<string>();
                    foreach (object key in map.Keys) keys.Add(PhpOps.ToStr(key));

                    // Длинные пары заменяются первыми — так требует PHP.
                    keys.Sort((left, right) => right.Length.CompareTo(left.Length));

                    StringBuilder sb = new StringBuilder();
                    int position = 0;

                    while (position < text.Length)
                    {
                        bool replaced = false;

                        foreach (string key in keys)
                        {
                            if (key.Length == 0) continue;
                            if (position + key.Length > text.Length) continue;

                            if (string.CompareOrdinal(text, position, key, 0, key.Length) == 0)
                            {
                                sb.Append(PhpOps.ToStr(map.Get(key)));
                                position += key.Length;
                                replaced = true;
                                break;
                            }
                        }

                        if (!replaced) sb.Append(text[position++]);
                    }

                    return sb.ToString();
                }

                // strtr($text, 'абв', 'xyz')
                string from = Str(a, 1);
                string to = Str(a, 2);
                int pairs = Math.Min(from.Length, to.Length);

                StringBuilder result = new StringBuilder(text.Length);
                foreach (char symbol in text)
                {
                    int at = from.IndexOf(symbol);
                    result.Append(at >= 0 && at < pairs ? to[at] : symbol);
                }

                return result.ToString();
            });

            Add("chunk_split", (i, a) =>
            {
                string text = Str(a, 0);
                int size = (int)Int(a, 1, 76);
                string ending = a.Length > 2 ? Str(a, 2) : "\r\n";

                if (size < 1) size = 76;

                StringBuilder sb = new StringBuilder();
                for (int at = 0; at < text.Length; at += size)
                    sb.Append(text, at, Math.Min(size, text.Length - at)).Append(ending);

                return sb.ToString();
            });

            Add("str_shuffle", (i, a) =>
            {
                char[] symbols = Str(a, 0).ToCharArray();

                for (int at = symbols.Length - 1; at > 0; at--)
                {
                    int other = Shared.Next(at + 1);
                    char keep = symbols[at];
                    symbols[at] = symbols[other];
                    symbols[other] = keep;
                }

                return new string(symbols);
            });

            Add("count_chars", (i, a) =>
            {
                string text = Str(a, 0);
                long mode = Int(a, 1, 0);

                Dictionary<char, long> counts = new Dictionary<char, long>();
                foreach (char symbol in text)
                {
                    long value;
                    counts[symbol] = counts.TryGetValue(symbol, out value) ? value + 1 : 1;
                }

                PhpArray result = new PhpArray();

                if (mode == 1)
                {
                    List<char> ordered = new List<char>(counts.Keys);
                    ordered.Sort();

                    foreach (char symbol in ordered) result.Set((long)symbol, counts[symbol]);
                    return result;
                }

                for (int code = 0; code < 256; code++)
                {
                    long value;
                    counts.TryGetValue((char)code, out value);
                    result.Set((long)code, value);
                }

                return result;
            });

            Add("quotemeta", (i, a) =>
            {
                StringBuilder sb = new StringBuilder();
                foreach (char symbol in Str(a, 0))
                {
                    if (".\\+*?[^]$()".IndexOf(symbol) >= 0) sb.Append('\\');
                    sb.Append(symbol);
                }
                return sb.ToString();
            });

            Add("levenshtein", (i, a) =>
            {
                string left = Str(a, 0);
                string right = Str(a, 1);

                int[,] distance = new int[left.Length + 1, right.Length + 1];

                for (int row = 0; row <= left.Length; row++) distance[row, 0] = row;
                for (int column = 0; column <= right.Length; column++) distance[0, column] = column;

                for (int row = 1; row <= left.Length; row++)
                {
                    for (int column = 1; column <= right.Length; column++)
                    {
                        int cost = left[row - 1] == right[column - 1] ? 0 : 1;

                        distance[row, column] = Math.Min(
                            Math.Min(distance[row - 1, column] + 1, distance[row, column - 1] + 1),
                            distance[row - 1, column - 1] + cost);
                    }
                }

                return (long)distance[left.Length, right.Length];
            });

            Add("similar_text", (i, a) => (long)Similar(Str(a, 0), Str(a, 1)));

            Add("soundex", (i, a) =>
            {
                string text = Str(a, 0).ToUpperInvariant();
                StringBuilder letters = new StringBuilder();

                foreach (char symbol in text)
                    if (symbol >= 'A' && symbol <= 'Z') letters.Append(symbol);

                if (letters.Length == 0) return string.Empty;

                const string codes = "01230120022455012623010202";

                StringBuilder sb = new StringBuilder();
                sb.Append(letters[0]);

                char previous = codes[letters[0] - 'A'];

                for (int at = 1; at < letters.Length && sb.Length < 4; at++)
                {
                    char code = codes[letters[at] - 'A'];

                    if (code != '0' && code != previous) sb.Append(code);
                    if (letters[at] != 'H' && letters[at] != 'W') previous = code;
                }

                while (sb.Length < 4) sb.Append('0');
                return sb.ToString();
            });

            Add("str_word_count_list", (i, a) =>
                FromList(Str(a, 0).Split(new[] { ' ', '\t', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)));

            Add("vprintf", (i, a) =>
            {
                PhpArray values = Arr(a, 1);

                List<object> list = new List<object> { Arg(a, 0) };
                if (values != null) list.AddRange(values.ValuesList());

                string text = Sprintf(list.ToArray());
                i.Output(text);
                return (long)text.Length;
            });

            Add("str_getcsv", (i, a) =>
            {
                string line = Str(a, 0);
                char separator = a.Length > 1 && Str(a, 1).Length > 0 ? Str(a, 1)[0] : ',';
                char quote = a.Length > 2 && Str(a, 2).Length > 0 ? Str(a, 2)[0] : '"';

                PhpArray result = new PhpArray();
                StringBuilder field = new StringBuilder();
                bool quoted = false;

                for (int at = 0; at < line.Length; at++)
                {
                    char symbol = line[at];

                    if (quoted)
                    {
                        if (symbol == quote)
                        {
                            if (at + 1 < line.Length && line[at + 1] == quote) { field.Append(quote); at++; }
                            else quoted = false;
                        }
                        else field.Append(symbol);
                    }
                    else if (symbol == quote) quoted = true;
                    else if (symbol == separator)
                    {
                        result.Append(field.ToString());
                        field.Length = 0;
                    }
                    else field.Append(symbol);
                }

                result.Append(field.ToString());
                return result;
            });

            Add("version_compare", (i, a) =>
            {
                int sign = CompareVersions(Str(a, 0), Str(a, 1));

                if (a.Length < 3 || a[2] == null) return (long)sign;

                switch (Str(a, 2))
                {
                    case "<":
                    case "lt": return sign < 0;
                    case "<=":
                    case "le": return sign <= 0;
                    case ">":
                    case "gt": return sign > 0;
                    case ">=":
                    case "ge": return sign >= 0;
                    case "==":
                    case "eq": return sign == 0;
                    case "!=":
                    case "ne":
                    case "<>": return sign != 0;
                    default: return (long)sign;
                }
            });
        }

        private static string Cut(string text, int length)
        {
            if (length <= 0 || length >= text.Length) return text;
            return text.Substring(0, length);
        }

        private static int Similar(string left, string right)
        {
            if (left.Length == 0 || right.Length == 0) return 0;

            int bestLeft = 0, bestRight = 0, best = 0;

            for (int row = 0; row < left.Length; row++)
            {
                for (int column = 0; column < right.Length; column++)
                {
                    int length = 0;
                    while (row + length < left.Length && column + length < right.Length &&
                           left[row + length] == right[column + length]) length++;

                    if (length > best) { best = length; bestLeft = row; bestRight = column; }
                }
            }

            if (best == 0) return 0;

            return best
                 + Similar(left.Substring(0, bestLeft), right.Substring(0, bestRight))
                 + Similar(left.Substring(bestLeft + best), right.Substring(bestRight + best));
        }

        private static int NaturalCompare(string left, string right, bool ignoreCase)
        {
            int leftAt = 0, rightAt = 0;

            while (leftAt < left.Length && rightAt < right.Length)
            {
                char leftSymbol = left[leftAt];
                char rightSymbol = right[rightAt];

                if (char.IsDigit(leftSymbol) && char.IsDigit(rightSymbol))
                {
                    int leftStart = leftAt, rightStart = rightAt;

                    while (leftAt < left.Length && char.IsDigit(left[leftAt])) leftAt++;
                    while (rightAt < right.Length && char.IsDigit(right[rightAt])) rightAt++;

                    string leftNumber = left.Substring(leftStart, leftAt - leftStart).TrimStart('0');
                    string rightNumber = right.Substring(rightStart, rightAt - rightStart).TrimStart('0');

                    if (leftNumber.Length != rightNumber.Length)
                        return leftNumber.Length < rightNumber.Length ? -1 : 1;

                    int byDigits = string.CompareOrdinal(leftNumber, rightNumber);
                    if (byDigits != 0) return Math.Sign(byDigits);

                    continue;
                }

                if (ignoreCase)
                {
                    leftSymbol = char.ToLowerInvariant(leftSymbol);
                    rightSymbol = char.ToLowerInvariant(rightSymbol);
                }

                if (leftSymbol != rightSymbol) return leftSymbol < rightSymbol ? -1 : 1;

                leftAt++;
                rightAt++;
            }

            int rest = (left.Length - leftAt) - (right.Length - rightAt);
            return rest == 0 ? 0 : rest < 0 ? -1 : 1;
        }

        private static int CompareVersions(string left, string right)
        {
            string[] leftParts = left.Split('.', '-', '+', '_');
            string[] rightParts = right.Split('.', '-', '+', '_');

            int count = Math.Max(leftParts.Length, rightParts.Length);

            for (int at = 0; at < count; at++)
            {
                long leftValue = at < leftParts.Length ? ParseLong(leftParts[at]) : 0;
                long rightValue = at < rightParts.Length ? ParseLong(rightParts[at]) : 0;

                if (leftValue != rightValue) return leftValue < rightValue ? -1 : 1;
            }

            return 0;
        }

        private static long ParseLong(string text)
        {
            long value;
            return long.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out value) ? value : 0;
        }

        // =====================================================================
        //  Массивы
        // =====================================================================

        private static void RegisterExtraArrays()
        {
            Add("array_chunk", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                int size = (int)Int(a, 1, 1);
                bool keepKeys = Bool(a, 2, false);

                PhpArray result = new PhpArray();
                if (source == null || size < 1) return result;

                PhpArray chunk = new PhpArray();

                foreach (object key in new List<object>(source.Keys))
                {
                    if (keepKeys) chunk.Set(key, source.Get(key));
                    else chunk.Append(source.Get(key));

                    if (chunk.Count >= size)
                    {
                        result.Append(chunk);
                        chunk = new PhpArray();
                    }
                }

                if (chunk.Count > 0) result.Append(chunk);
                return result;
            });

            Add("array_pad", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                int size = (int)Int(a, 1, 0);
                object filler = Arg(a, 2);

                List<object> values = source == null ? new List<object>() : source.ValuesList();
                int missing = Math.Abs(size) - values.Count;

                if (missing <= 0) return FromList(values);

                List<object> padding = new List<object>();
                for (int at = 0; at < missing; at++) padding.Add(filler);

                if (size > 0) padding.InsertRange(0, values);
                else padding.AddRange(values);

                return FromList(padding);
            });

            Add("array_rand", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return null;

                long count = Int(a, 1, 1);
                List<object> keys = new List<object>(source.Keys);

                if (count <= 1) return keys[Shared.Next(keys.Count)];

                if (count > keys.Count) count = keys.Count;

                PhpArray result = new PhpArray();
                for (int at = 0; at < count; at++)
                {
                    int pick = Shared.Next(keys.Count);
                    result.Append(keys[pick]);
                    keys.RemoveAt(pick);
                }

                return result;
            });

            Add("array_count_values", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                PhpArray result = new PhpArray();
                if (source == null) return result;

                foreach (object value in source.ValuesList())
                {
                    object key = value is long || value is int ? value : (object)PhpOps.ToStr(value);

                    object current = result.Get(key);
                    result.Set(key, current == null ? 1L : PhpOps.ToInt(current) + 1);
                }

                return result;
            });

            Add("array_diff_key", (i, a) => ByKeys(a, false, false));
            Add("array_intersect_key", (i, a) => ByKeys(a, true, false));
            Add("array_diff_assoc", (i, a) => ByKeys(a, false, true));
            Add("array_intersect_assoc", (i, a) => ByKeys(a, true, true));

            Add("array_replace", (i, a) =>
            {
                PhpArray result = new PhpArray();

                foreach (object argument in a)
                {
                    PhpArray part = argument as PhpArray;
                    if (part == null) continue;

                    foreach (object key in new List<object>(part.Keys)) result.Set(key, part.Get(key));
                }

                return result;
            });

            Add("array_merge_recursive", (i, a) =>
            {
                PhpArray result = new PhpArray();

                foreach (object argument in a)
                {
                    PhpArray part = argument as PhpArray;
                    if (part != null) MergeInto(result, part);
                }

                return result;
            });

            Add("array_is_list", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null) return false;

                long expected = 0;
                foreach (object key in source.Keys)
                {
                    if (!(key is long) || (long)key != expected) return false;
                    expected++;
                }

                return true;
            });

            Add("array_splice_copy", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null) return new PhpArray();

                List<object> values = source.ValuesList();
                int offset = (int)Int(a, 1, 0);

                if (offset < 0) offset = Math.Max(0, values.Count + offset);
                if (offset > values.Count) offset = values.Count;

                int length = a.Length > 2 && a[2] != null ? (int)Int(a, 2, 0) : values.Count - offset;
                if (length < 0) length = Math.Max(0, values.Count + length - offset);
                if (offset + length > values.Count) length = values.Count - offset;

                values.RemoveRange(offset, length);

                PhpArray replacement = Arr(a, 3);
                if (replacement != null) values.InsertRange(offset, replacement.ValuesList());

                return FromList(values);
            });

            Add("end", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return false;

                List<object> values = source.ValuesList();
                return values[values.Count - 1];
            });

            Add("reset", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return false;

                return source.ValuesList()[0];
            });

            Add("current", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return false;

                return source.ValuesList()[0];
            });

            Add("array_first", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                return source == null || source.Count == 0 ? null : source.ValuesList()[0];
            });

            Add("array_last", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return null;

                List<object> values = source.ValuesList();
                return values[values.Count - 1];
            });
        }

        /// <summary>Общая основа для array_diff_key и родственных функций.</summary>
        private static PhpArray ByKeys(object[] args, bool keep, bool compareValues)
        {
            PhpArray source = args.Length > 0 ? args[0] as PhpArray : null;

            PhpArray result = new PhpArray();
            if (source == null) return result;

            foreach (object key in new List<object>(source.Keys))
            {
                object value = source.Get(key);
                bool found = false;

                for (int at = 1; at < args.Length; at++)
                {
                    PhpArray other = args[at] as PhpArray;
                    if (other == null || !other.Has(key)) continue;

                    if (!compareValues || PhpOps.ToStr(other.Get(key)) == PhpOps.ToStr(value))
                    {
                        found = true;
                        break;
                    }
                }

                if (found == keep) result.Set(key, value);
            }

            return result;
        }

        private static void MergeInto(PhpArray target, PhpArray source)
        {
            foreach (object key in new List<object>(source.Keys))
            {
                object value = source.Get(key);

                if (key is long)
                {
                    target.Append(value);
                    continue;
                }

                PhpArray nested = value as PhpArray;
                PhpArray existing = target.Get(key) as PhpArray;

                if (nested != null && existing != null)
                {
                    MergeInto(existing, nested);
                    continue;
                }

                target.Set(key, value);
            }
        }

        // =====================================================================
        //  Математика
        // =====================================================================

        private static void RegisterExtraMath()
        {
            Add("asin", (i, a) => Math.Asin(Num(a, 0)));
            Add("acos", (i, a) => Math.Acos(Num(a, 0)));
            Add("atan", (i, a) => Math.Atan(Num(a, 0)));
            Add("atan2", (i, a) => Math.Atan2(Num(a, 0), Num(a, 1)));
            Add("sinh", (i, a) => Math.Sinh(Num(a, 0)));
            Add("cosh", (i, a) => Math.Cosh(Num(a, 0)));
            Add("tanh", (i, a) => Math.Tanh(Num(a, 0)));
            Add("asinh", (i, a) => { double x = Num(a, 0); return Math.Log(x + Math.Sqrt(x * x + 1)); });
            Add("acosh", (i, a) => { double x = Num(a, 0); return Math.Log(x + Math.Sqrt(x * x - 1)); });
            Add("atanh", (i, a) => { double x = Num(a, 0); return 0.5 * Math.Log((1 + x) / (1 - x)); });
            Add("deg2rad", (i, a) => Num(a, 0) * Math.PI / 180.0);
            Add("rad2deg", (i, a) => Num(a, 0) * 180.0 / Math.PI);
            Add("expm1", (i, a) => Math.Exp(Num(a, 0)) - 1.0);
            Add("log1p", (i, a) => Math.Log(1.0 + Num(a, 0)));

            Add("fdiv", (i, a) =>
            {
                double divisor = Num(a, 1);
                double value = Num(a, 0);

                if (divisor != 0) return value / divisor;

                return value == 0 ? double.NaN : value > 0 ? double.PositiveInfinity : double.NegativeInfinity;
            });

            Add("array_median", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return false;

                List<double> numbers = new List<double>();
                foreach (object value in source.ValuesList()) numbers.Add(PhpOps.ToNum(value));

                numbers.Sort();

                int middle = numbers.Count / 2;
                return numbers.Count % 2 == 1 ? numbers[middle] : (numbers[middle - 1] + numbers[middle]) / 2.0;
            });

            Add("array_average", (i, a) =>
            {
                PhpArray source = Arr(a, 0);
                if (source == null || source.Count == 0) return false;

                double sum = 0;
                foreach (object value in source.ValuesList()) sum += PhpOps.ToNum(value);

                return sum / source.Count;
            });
        }

        // =====================================================================
        //  Дата и время
        // =====================================================================

        private static void RegisterExtraTime()
        {
            Add("getdate", (i, a) =>
            {
                DateTime when = a.Length > 0 && a[0] != null
                    ? Epoch.AddSeconds(PhpOps.ToInt(a[0])).ToLocalTime()
                    : DateTime.Now;

                PhpArray result = new PhpArray();
                result.Set("seconds", (long)when.Second);
                result.Set("minutes", (long)when.Minute);
                result.Set("hours", (long)when.Hour);
                result.Set("mday", (long)when.Day);
                result.Set("wday", (long)(int)when.DayOfWeek);
                result.Set("mon", (long)when.Month);
                result.Set("year", (long)when.Year);
                result.Set("yday", (long)(when.DayOfYear - 1));
                result.Set("weekday", when.DayOfWeek.ToString());
                result.Set("month", CultureInfo.InvariantCulture.DateTimeFormat.GetMonthName(when.Month));
                result.Set(0L, (long)(when.ToUniversalTime() - Epoch).TotalSeconds);

                return result;
            });

            Add("idate", (i, a) =>
            {
                string format = Str(a, 0);
                DateTime when = a.Length > 1 && a[1] != null
                    ? Epoch.AddSeconds(PhpOps.ToInt(a[1])).ToLocalTime()
                    : DateTime.Now;

                if (format.Length == 0) return false;

                switch (format[0])
                {
                    case 'Y': return (long)when.Year;
                    case 'y': return (long)(when.Year % 100);
                    case 'm': return (long)when.Month;
                    case 'd': return (long)when.Day;
                    case 'H': return (long)when.Hour;
                    case 'i': return (long)when.Minute;
                    case 's': return (long)when.Second;
                    case 'w': return (long)(int)when.DayOfWeek;
                    case 'z': return (long)(when.DayOfYear - 1);
                    case 'L': return DateTime.IsLeapYear(when.Year) ? 1L : 0L;
                    case 't': return (long)DateTime.DaysInMonth(when.Year, when.Month);
                    case 'U': return (long)(when.ToUniversalTime() - Epoch).TotalSeconds;
                    default: return false;
                }
            });

            Add("cal_days_in_month", (i, a) =>
            {
                int month = (int)Int(a, 1, 1);
                int year = (int)Int(a, 2, DateTime.Now.Year);

                if (month < 1 || month > 12) return false;

                return (long)DateTime.DaysInMonth(year, month);
            });

            Add("gmmktime", (i, a) =>
            {
                DateTime now = DateTime.UtcNow;

                int hour = (int)Int(a, 0, now.Hour);
                int minute = (int)Int(a, 1, now.Minute);
                int second = (int)Int(a, 2, now.Second);
                int month = (int)Int(a, 3, now.Month);
                int day = (int)Int(a, 4, now.Day);
                int year = (int)Int(a, 5, now.Year);

                DateTime when = new DateTime(year, 1, 1, 0, 0, 0, DateTimeKind.Utc);
                when = when.AddMonths(month - 1).AddDays(day - 1)
                           .AddHours(hour).AddMinutes(minute).AddSeconds(second);

                return (long)(when - Epoch).TotalSeconds;
            });

            Add("date_diff_days", (i, a) =>
            {
                long left = Int(a, 0, 0);
                long right = Int(a, 1, 0);

                return (long)Math.Abs((right - left) / 86400);
            });

            Add("gettimeofday", (i, a) =>
            {
                DateTime now = DateTime.UtcNow;
                double seconds = (now - Epoch).TotalSeconds;

                if (Bool(a, 0, false)) return seconds;

                PhpArray result = new PhpArray();
                result.Set("sec", (long)seconds);
                result.Set("usec", (long)((seconds - Math.Floor(seconds)) * 1000000));
                return result;
            });
        }

        private static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

        // =====================================================================
        //  Файлы и дескрипторы
        // =====================================================================

        private static void RegisterExtraFiles()
        {
            Add("fopen", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null) return false;

                string mode = Str(a, 1).ToLowerInvariant();

                FileMode fileMode;
                FileAccess access;

                if (mode.StartsWith("r")) { fileMode = FileMode.Open; access = mode.Contains("+") ? FileAccess.ReadWrite : FileAccess.Read; }
                else if (mode.StartsWith("w")) { fileMode = FileMode.Create; access = mode.Contains("+") ? FileAccess.ReadWrite : FileAccess.Write; }
                else if (mode.StartsWith("a")) { fileMode = FileMode.Append; access = FileAccess.Write; }
                else if (mode.StartsWith("x")) { fileMode = FileMode.CreateNew; access = FileAccess.Write; }
                else { fileMode = FileMode.OpenOrCreate; access = FileAccess.ReadWrite; }

                try
                {
                    FileStream stream = new FileStream(path, fileMode, access);

                    long id = ++streamCounter;
                    Streams[id] = new PhpStream { Stream = stream, Mode = mode, Path = path };
                    return id;
                }
                catch { return false; }
            });

            Add("fclose", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                try { stream.Stream.Dispose(); }
                catch { }

                Streams.Remove(PhpOps.ToInt(Arg(a, 0)));
                return true;
            });

            Add("fwrite", (i, a) => WriteToStream(a));
            Add("fputs", (i, a) => WriteToStream(a));

            Add("fread", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                int length = (int)Int(a, 1, 8192);
                if (length < 1) return string.Empty;

                byte[] buffer = new byte[length];
                int read = stream.Stream.Read(buffer, 0, length);

                return Encoding.UTF8.GetString(buffer, 0, read);
            });

            Add("fgets", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                StringBuilder sb = new StringBuilder();

                while (true)
                {
                    int symbol = stream.Stream.ReadByte();
                    if (symbol < 0) break;

                    sb.Append((char)symbol);
                    if (symbol == '\n') break;
                }

                return sb.Length == 0 ? (object)false : sb.ToString();
            });

            Add("fgetc", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                int symbol = stream.Stream.ReadByte();
                return symbol < 0 ? (object)false : ((char)symbol).ToString();
            });

            Add("feof", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return true;

                return stream.Stream.Position >= stream.Stream.Length;
            });

            Add("ftell", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                return stream == null ? (object)false : stream.Stream.Position;
            });

            Add("fseek", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return -1L;

                long offset = Int(a, 1, 0);
                long whence = Int(a, 2, 0);

                SeekOrigin origin = whence == 1 ? SeekOrigin.Current
                                  : whence == 2 ? SeekOrigin.End
                                  : SeekOrigin.Begin;

                stream.Stream.Seek(offset, origin);
                return 0L;
            });

            Add("rewind", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                stream.Stream.Seek(0, SeekOrigin.Begin);
                return true;
            });

            Add("fflush", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                stream.Stream.Flush();
                return true;
            });

            Add("ftruncate", (i, a) =>
            {
                PhpStream stream = Handle(a, 0);
                if (stream == null) return false;

                stream.Stream.SetLength(Int(a, 1, 0));
                return true;
            });

            Add("readfile", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null || !File.Exists(path)) return false;

                string text = File.ReadAllText(path);
                i.Output(text);
                return (long)text.Length;
            });

            Add("filetype", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null) return false;

                if (Directory.Exists(path)) return "dir";
                if (File.Exists(path)) return "file";
                return false;
            });

            Add("fileatime", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null || !File.Exists(path)) return false;

                return (long)(File.GetLastAccessTimeUtc(path) - Epoch).TotalSeconds;
            });

            Add("filectime", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null || !File.Exists(path)) return false;

                return (long)(File.GetCreationTimeUtc(path) - Epoch).TotalSeconds;
            });

            Add("clearstatcache", (i, a) => null);

            Add("file_append", (i, a) =>
            {
                string path = i.Context.SafePath(Str(a, 0));
                if (path == null) return false;

                File.AppendAllText(path, Str(a, 1));
                return true;
            });

            Add("getcwd", (i, a) => i.Context.DocumentRoot);
        }

        private static object WriteToStream(object[] args)
        {
            PhpStream stream = Handle(args, 0);
            if (stream == null) return false;

            string text = Str(args, 1);

            if (args.Length > 2 && args[2] != null)
            {
                int limit = (int)Int(args, 2, text.Length);
                if (limit >= 0 && limit < text.Length) text = text.Substring(0, limit);
            }

            byte[] bytes = Encoding.UTF8.GetBytes(text);
            stream.Stream.Write(bytes, 0, bytes.Length);
            stream.Stream.Flush();

            return (long)bytes.Length;
        }

        // =====================================================================
        //  ctype
        // =====================================================================

        private static void RegisterCtype()
        {
            Add("ctype_alpha", (i, a) => AllSymbols(Str(a, 0), char.IsLetter));
            Add("ctype_digit", (i, a) => AllSymbols(Str(a, 0), char.IsDigit));
            Add("ctype_alnum", (i, a) => AllSymbols(Str(a, 0), char.IsLetterOrDigit));
            Add("ctype_space", (i, a) => AllSymbols(Str(a, 0), char.IsWhiteSpace));
            Add("ctype_upper", (i, a) => AllSymbols(Str(a, 0), char.IsUpper));
            Add("ctype_lower", (i, a) => AllSymbols(Str(a, 0), char.IsLower));
            Add("ctype_punct", (i, a) => AllSymbols(Str(a, 0),
                symbol => !char.IsLetterOrDigit(symbol) && !char.IsWhiteSpace(symbol) && !char.IsControl(symbol)));
            Add("ctype_xdigit", (i, a) => AllSymbols(Str(a, 0),
                symbol => "0123456789abcdefABCDEF".IndexOf(symbol) >= 0));
        }

        private static bool AllSymbols(string text, Func<char, bool> test)
        {
            if (text.Length == 0) return false;

            foreach (char symbol in text)
                if (!test(symbol)) return false;

            return true;
        }

        // =====================================================================
        //  Хеши и сериализация
        // =====================================================================

        private static void RegisterExtraHash()
        {
            Add("hash_hmac", (i, a) =>
            {
                string algorithm = Str(a, 0).ToLowerInvariant();
                byte[] data = Encoding.UTF8.GetBytes(Str(a, 1));
                byte[] key = Encoding.UTF8.GetBytes(Str(a, 2));

                using (HMAC hmac = CreateHmac(algorithm, key))
                {
                    if (hmac == null) return false;

                    byte[] result = hmac.ComputeHash(data);

                    // raw_output = true: байты как есть, по одному символу на байт.
                    if (Bool(a, 3, false))
                    {
                        StringBuilder raw = new StringBuilder(result.Length);
                        foreach (byte value in result) raw.Append((char)value);
                        return raw.ToString();
                    }


                    StringBuilder sb = new StringBuilder(result.Length * 2);
                    foreach (byte value in result) sb.Append(value.ToString("x2"));
                    return sb.ToString();
                }
            });

            Add("md5_file", (i, a) => FileDigest(i, Str(a, 0), "md5"));
            Add("sha1_file", (i, a) => FileDigest(i, Str(a, 0), "sha1"));
            Add("hash_file", (i, a) => FileDigest(i, Str(a, 1), Str(a, 0).ToLowerInvariant()));

            Add("serialize", (i, a) => Serialize(Arg(a, 0)));

            Add("unserialize", (i, a) =>
            {
                int position = 0;
                try { return Unserialize(Str(a, 0), ref position); }
                catch { return false; }
            });
        }

        private static HMAC CreateHmac(string algorithm, byte[] key)
        {
            switch (algorithm)
            {
                case "md5": return new HMACMD5(key);
                case "sha1": return new HMACSHA1(key);
                case "sha256": return new HMACSHA256(key);
                case "sha384": return new HMACSHA384(key);
                case "sha512": return new HMACSHA512(key);
                default: return null;
            }
        }

        private static object FileDigest(Interp interp, string virtualPath, string algorithm)
        {
            string path = interp.Context.SafePath(virtualPath);
            if (path == null || !File.Exists(path)) return false;

            using (HashAlgorithm hash = CreateHash(algorithm))
            {
                if (hash == null) return false;

                using (FileStream stream = File.OpenRead(path))
                {
                    byte[] result = hash.ComputeHash(stream);

                    StringBuilder sb = new StringBuilder(result.Length * 2);
                    foreach (byte value in result) sb.Append(value.ToString("x2"));
                    return sb.ToString();
                }
            }
        }

        private static HashAlgorithm CreateHash(string algorithm)
        {
            switch (algorithm)
            {
                case "md5": return MD5.Create();
                case "sha1": return SHA1.Create();
                case "sha256": return SHA256.Create();
                case "sha384": return SHA384.Create();
                case "sha512": return SHA512.Create();
                default: return null;
            }
        }

        /// <summary>serialize() в формате PHP: поддержаны null, bool, числа, строки и массивы.</summary>
        private static string Serialize(object value)
        {
            if (value == null) return "N;";

            if (value is bool) return "b:" + ((bool)value ? "1" : "0") + ";";

            if (value is long || value is int) return "i:" + PhpOps.ToInt(value) + ";";

            if (value is double)
            {
                return "d:" + ((double)value).ToString("R", CultureInfo.InvariantCulture) + ";";
            }

            PhpArray array = value as PhpArray;
            if (array != null)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("a:").Append(array.Count).Append(":{");

                foreach (object key in new List<object>(array.Keys))
                {
                    sb.Append(Serialize(key));
                    sb.Append(Serialize(array.Get(key)));
                }

                return sb.Append('}').ToString();
            }

            string text = PhpOps.ToStr(value);
            return "s:" + Encoding.UTF8.GetByteCount(text) + ":\"" + text + "\";";
        }

        private static object Unserialize(string text, ref int position)
        {
            if (position >= text.Length) throw new FormatException("serialize");

            char kind = text[position];

            switch (kind)
            {
                case 'N':
                    position += 2;
                    return null;

                case 'b':
                {
                    position += 2;
                    bool value = text[position] == '1';
                    position += 2;
                    return value;
                }

                case 'i':
                {
                    position += 2;
                    int end = text.IndexOf(';', position);
                    long value = ParseLong(text.Substring(position, end - position));
                    position = end + 1;
                    return value;
                }

                case 'd':
                {
                    position += 2;
                    int end = text.IndexOf(';', position);

                    double value;
                    double.TryParse(text.Substring(position, end - position),
                        NumberStyles.Float, CultureInfo.InvariantCulture, out value);

                    position = end + 1;
                    return value;
                }

                case 's':
                {
                    position += 2;
                    int colon = text.IndexOf(':', position);
                    int length = (int)ParseLong(text.Substring(position, colon - position));

                    int start = colon + 2;
                    string value = Take(text, start, length);

                    position = start + value.Length + 2;
                    return value;
                }

                case 'a':
                {
                    position += 2;
                    int colon = text.IndexOf(':', position);
                    int count = (int)ParseLong(text.Substring(position, colon - position));

                    position = colon + 2;

                    PhpArray array = new PhpArray();
                    for (int at = 0; at < count; at++)
                    {
                        object key = Unserialize(text, ref position);
                        object value = Unserialize(text, ref position);
                        array.Set(key, value);
                    }

                    position++;
                    return array;
                }

                default:
                    throw new FormatException("serialize");
            }
        }

        /// <summary>Длина в serialize() считается в байтах, а строка — в символах.</summary>
        private static string Take(string text, int start, int byteLength)
        {
            int count = 0;
            int at = start;

            while (at < text.Length && count < byteLength)
            {
                count += Encoding.UTF8.GetByteCount(text[at].ToString());
                at++;
            }

            return text.Substring(start, at - start);
        }

        // =====================================================================
        //  Адреса
        // =====================================================================

        private static void RegisterExtraUrl()
        {
            Add("parse_url", (i, a) =>
            {
                string text = Str(a, 0);

                PhpArray result = new PhpArray();

                int schemeAt = text.IndexOf("://", StringComparison.Ordinal);
                string rest = text;

                if (schemeAt > 0)
                {
                    result.Set("scheme", text.Substring(0, schemeAt));
                    rest = text.Substring(schemeAt + 3);
                }

                int fragmentAt = rest.IndexOf('#');
                if (fragmentAt >= 0)
                {
                    result.Set("fragment", rest.Substring(fragmentAt + 1));
                    rest = rest.Substring(0, fragmentAt);
                }

                int queryAt = rest.IndexOf('?');
                if (queryAt >= 0)
                {
                    result.Set("query", rest.Substring(queryAt + 1));
                    rest = rest.Substring(0, queryAt);
                }

                if (schemeAt > 0)
                {
                    int pathAt = rest.IndexOf('/');
                    string authority = pathAt < 0 ? rest : rest.Substring(0, pathAt);

                    if (pathAt >= 0) result.Set("path", rest.Substring(pathAt));

                    int credentialsAt = authority.IndexOf('@');
                    if (credentialsAt >= 0)
                    {
                        string credentials = authority.Substring(0, credentialsAt);
                        authority = authority.Substring(credentialsAt + 1);

                        int passwordAt = credentials.IndexOf(':');
                        if (passwordAt >= 0)
                        {
                            result.Set("user", credentials.Substring(0, passwordAt));
                            result.Set("pass", credentials.Substring(passwordAt + 1));
                        }
                        else result.Set("user", credentials);
                    }

                    int portAt = authority.LastIndexOf(':');
                    if (portAt > 0)
                    {
                        result.Set("host", authority.Substring(0, portAt));
                        result.Set("port", ParseLong(authority.Substring(portAt + 1)));
                    }
                    else result.Set("host", authority);
                }
                else if (rest.Length > 0) result.Set("path", rest);

                if (a.Length > 1 && a[1] != null)
                {
                    switch (Int(a, 1, -1))
                    {
                        case 0: return result.Get("scheme");
                        case 1: return result.Get("host");
                        case 2: return result.Get("port");
                        case 3: return result.Get("user");
                        case 4: return result.Get("pass");
                        case 5: return result.Get("path");
                        case 6: return result.Get("query");
                        case 7: return result.Get("fragment");
                    }
                }

                return result;
            });

            Add("parse_query", (i, a) =>
            {
                PhpArray result = new PhpArray();

                foreach (string pair in Str(a, 0).Split('&'))
                {
                    if (pair.Length == 0) continue;

                    int mark = pair.IndexOf('=');
                    string key = mark < 0 ? pair : pair.Substring(0, mark);
                    string value = mark < 0 ? string.Empty : pair.Substring(mark + 1);

                    try { result.Set(Uri.UnescapeDataString(key), Uri.UnescapeDataString(value.Replace('+', ' '))); }
                    catch { result.Set(key, value); }
                }

                return result;
            });

            Add("gethostname", (i, a) =>
            {
                try { return Environment.MachineName; }
                catch { return false; }
            });
        }

    }
}
