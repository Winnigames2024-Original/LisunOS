﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Логика Калькулятора LisunOS (пакет apps/calcapp).
    /// Вычисления идут через тот же разбор выражений, что и команда calc,
    /// поэтому поведение в окне и в терминале совпадает.
    /// </summary>
    public partial class CalcLogicBridge
    {
        private const string HistoryKey = "calc_history";
        private const string MemoryKey = "calc_memory";

        private readonly Form form;
        private readonly string packageName;

        private readonly TextBox expression;
        private readonly Label result;
        private readonly Label memory;
        private readonly ListBox history;
        private readonly Label status;

        private double memoryValue;

        public CalcLogicBridge(DynamicFormContext context)
        {
            form = context.Form;
            packageName = context.PackageName;

            expression = context.Get<TextBox>("txtExpression");
            result = context.Get<Label>("lblResult");
            memory = context.Get<Label>("lblMemory");
            history = context.Get<ListBox>("lstHistory");
            status = context.Get<Label>("lblStatus");
        }

        public void Initialize()
        {
            if (form != null) form.Text = LisunLocale.T("calcapp.title");

            if (expression != null) expression.Font = Theme.Mono(13f);
            if (result != null) result.Font = Theme.Mono(20f, System.Drawing.FontStyle.Bold);
            if (memory != null) memory.Font = Theme.Mono(9f);
            if (history != null) history.Font = Theme.Mono(9.5f);
            if (status != null) status.Font = Theme.Mono(8.75f);

            StyleKeys();
            LoadHistory();
            LoadMemory();

            SetStatus(LisunLocale.T("calcapp.ready"));
        }

        /// <summary>Цвет клавиш: цифры светлые, действия синие, сброс красный.</summary>
        private void StyleKeys()
        {
            if (form == null) return;

            foreach (Control panel in form.Controls)
            {
                foreach (Control child in panel.Controls)
                {
                    Button key = child as Button;
                    if (key == null) continue;

                    key.Font = Theme.Mono(12f);

                    string text = key.Text;

                    if (text == "=") Theme.StyleButton(key, Theme.AccentDeep, Theme.Text);
                    else if (text == "C") Theme.StyleButton(key, System.Drawing.Color.FromArgb(70, 32, 34), Theme.Text);
                    else if (text.StartsWith("M")) Theme.StyleButton(key, Theme.Surface, Theme.Cyan);
                    else if ("+-*/^%()←".IndexOf(text) >= 0) Theme.StyleButton(key, Theme.Surface, Theme.Accent);
                    else Theme.StyleButton(key, Theme.SurfaceAlt, Theme.Text);
                }
            }
        }

        // =====================================================================
        //  Обработчики из designer-файла
        // =====================================================================

        private void btnKey_Click(object sender, EventArgs e)
        {
            Button key = sender as Button;
            if (key == null || expression == null) return;

            switch (key.Text)
            {
                case "C":
                    expression.Clear();
                    SetResult("0");
                    return;

                case "←":
                    if (expression.Text.Length > 0)
                        expression.Text = expression.Text.Substring(0, expression.Text.Length - 1);

                    expression.SelectionStart = expression.Text.Length;
                    return;

                case "MC":
                    memoryValue = 0;
                    SaveMemory();
                    SetStatus(LisunLocale.T("calcapp.memoryCleared"));
                    return;

                case "MR":
                    expression.Text += Format(memoryValue);
                    expression.SelectionStart = expression.Text.Length;
                    return;

                case "M+":
                {
                    double value;
                    if (!TryCompute(expression.Text, out value))
                    {
                        SetStatus(LisunLocale.T("calcapp.badExpression"));
                        return;
                    }

                    memoryValue += value;
                    SaveMemory();
                    SetStatus(LisunLocale.T("calcapp.memoryAdded", Format(memoryValue)));
                    return;
                }
            }

            expression.Text += key.Text;
            expression.SelectionStart = expression.Text.Length;
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            if (expression == null) return;

            string source = expression.Text.Trim();
            if (source.Length == 0) return;

            double value;
            if (!TryCompute(source, out value))
            {
                SetResult(LisunLocale.T("calcapp.error"));
                SetStatus(LisunLocale.T("calcapp.badExpression"));
                return;
            }

            string line = source + " = " + Format(value);

            SetResult(Format(value));
            SetStatus(line);

            if (history != null)
            {
                history.Items.Insert(0, line);
                while (history.Items.Count > 100) history.Items.RemoveAt(history.Items.Count - 1);
            }

            SaveHistory();
        }

        /// <summary>Пока выражение набирается, результат считается молча.</summary>
        private void txtExpression_TextChanged(object sender, EventArgs e)
        {
            if (expression == null) return;

            string source = expression.Text.Trim();
            if (source.Length == 0)
            {
                SetResult("0");
                return;
            }

            double value;
            SetResult(TryCompute(source, out value) ? Format(value) : "…");
        }

        private void lstHistory_DoubleClick(object sender, EventArgs e)
        {
            if (history == null || expression == null) return;
            if (history.SelectedIndex < 0) return;

            string line = history.SelectedItem.ToString();
            int mark = line.LastIndexOf(" = ", StringComparison.Ordinal);

            expression.Text = mark > 0 ? line.Substring(0, mark) : line;
            expression.SelectionStart = expression.Text.Length;
            expression.Focus();
        }

        // =====================================================================
        //  Вычисление и хранение
        // =====================================================================

        private static bool TryCompute(string source, out double value)
        {
            return CommandExecutorEngine.TryEvaluate(source, out value);
        }

        private static string Format(double value)
        {
            return value.ToString("0.##########", CultureInfo.InvariantCulture);
        }

        private void SetResult(string text)
        {
            if (result != null && !result.IsDisposed) result.Text = text;
        }

        private void SetStatus(string text)
        {
            if (status != null && !status.IsDisposed) status.Text = text;
        }

        private void LoadHistory()
        {
            if (history == null) return;

            string stored;
            if (!LisunEngine.RegistryData.TryGetValue(HistoryKey, out stored) || stored.Length == 0) return;

            foreach (string line in stored.Split('|'))
                if (line.Trim().Length > 0) history.Items.Add(line.Replace("¦", "|"));
        }

        private void SaveHistory()
        {
            if (history == null) return;
            if (!LisunPermissions.Check(packageName, LisunPermissions.EditSettings)) return;

            List<string> lines = new List<string>();
            foreach (object item in history.Items)
            {
                lines.Add(item.ToString().Replace("|", "¦"));
                if (lines.Count >= 50) break;
            }

            LisunEngine.RegistryData[HistoryKey] = string.Join("|", lines.ToArray());
            LisunEngine.SaveRegistry();
        }

        private void LoadMemory()
        {
            string stored;
            if (LisunEngine.RegistryData.TryGetValue(MemoryKey, out stored))
                double.TryParse(stored, NumberStyles.Any, CultureInfo.InvariantCulture, out memoryValue);

            ShowMemory();
        }

        private void SaveMemory()
        {
            if (LisunPermissions.Check(packageName, LisunPermissions.EditSettings))
            {
                LisunEngine.RegistryData[MemoryKey] = Format(memoryValue);
                LisunEngine.SaveRegistry();
            }

            ShowMemory();
        }

        private void ShowMemory()
        {
            if (memory == null) return;

            memory.Text = memoryValue == 0 ? string.Empty : "M = " + Format(memoryValue);
        }
    }
}
