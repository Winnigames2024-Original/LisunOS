﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace LisunOS
{
    /// <summary>Сеть Wi-Fi, найденная при сканировании.</summary>
    public class WifiNetwork
    {
        public string Ssid = string.Empty;
        public string Authentication = string.Empty;
        public string Encryption = string.Empty;
        public int Signal;
        public bool Connected;

        /// <summary>Сеть без пароля — подключаемся сразу.</summary>
        public bool Open
        {
            get
            {
                string auth = Authentication.ToUpperInvariant();
                return !(auth.Contains("WPA") || auth.Contains("WEP") || auth.Contains("802.1X"));
            }
        }

        /// <summary>Сеть предприятия: пароля недостаточно, нужен вход через браузер.</summary>
        public bool Enterprise
        {
            get
            {
                string auth = Authentication.ToUpperInvariant();
                return auth.Contains("ENTERPRISE") || auth.Contains("802.1X");
            }
        }

        /// <summary>Строка профиля netsh: WPA3SAE, WPA2PSK, WPAPSK, open.</summary>
        public string ProfileAuth
        {
            get
            {
                string auth = Authentication.ToUpperInvariant();

                if (auth.Contains("WPA3")) return "WPA3SAE";
                if (auth.Contains("WPA2")) return "WPA2PSK";
                if (auth.Contains("WPA")) return "WPAPSK";
                if (auth.Contains("WEP")) return "open";

                return "open";
            }
        }

        /// <summary>Строка шифрования профиля netsh: AES, TKIP, WEP, none.</summary>
        public string ProfileCipher
        {
            get
            {
                string cipher = Encryption.ToUpperInvariant();

                if (cipher.Contains("CCMP") || cipher.Contains("AES") || cipher.Contains("GCMP")) return "AES";
                if (cipher.Contains("TKIP")) return "TKIP";
                if (cipher.Contains("WEP")) return "WEP";

                return Open ? "none" : "AES";
            }
        }

        /// <summary>Полоска уровня сигнала для списка и терминала.</summary>
        public string SignalBar
        {
            get
            {
                int filled = Signal <= 0 ? 0 : (Signal + 19) / 20;
                if (filled > 5) filled = 5;

                return new string('█', filled) + new string('░', 5 - filled);
            }
        }

        public override string ToString()
        {
            return Ssid + "  " + SignalBar + " " + Signal + "%  " +
                   (Open ? LisunLocale.T("wifi.openShort") : Authentication);
        }
    }

    /// <summary>
    /// Wi-Fi в LisunOS: поиск сетей, подключение с паролем и без,
    /// распознавание страницы авторизации и проверка выхода в интернет.
    /// Работает через netsh — права администратора не нужны.
    /// </summary>
    public static class LisunWifi
    {
        public const string PackageName = "wifi";

        /// <summary>Адреса для проверки интернета: 204 без тела значит «сеть есть».</summary>
        private static readonly string[] Probes =
        {
            "http://connectivitycheck.gstatic.com/generate_204",
            "http://www.msftconnecttest.com/connecttest.txt",
            "http://detectportal.firefox.com/success.txt"
        };

        private static readonly object gate = new object();
        private static bool online;
        private static bool watching;
        private static string portalUrl = string.Empty;

        /// <summary>Последнее известное состояние интернета.</summary>
        public static bool Online
        {
            get { lock (gate) return online; }
        }

        /// <summary>Адрес страницы авторизации, если сеть требует входа.</summary>
        public static string PortalUrl
        {
            get { lock (gate) return portalUrl; }
        }

        // =====================================================================
        //  Запуск netsh
        // =====================================================================

        /// <summary>
        /// Выполняет netsh и возвращает вывод. chcp 65001 нужен, чтобы
        /// названия сетей на русском не превращались в кракозябры.
        /// </summary>
        private static string RunNetsh(string arguments)
        {
            try
            {
                ProcessStartInfo info = new ProcessStartInfo("cmd.exe",
                    "/c chcp 65001>nul & netsh " + arguments);

                info.UseShellExecute = false;
                info.CreateNoWindow = true;
                info.RedirectStandardOutput = true;
                info.RedirectStandardError = true;
                info.StandardOutputEncoding = Encoding.UTF8;
                info.StandardErrorEncoding = Encoding.UTF8;

                using (Process process = Process.Start(info))
                {
                    if (process == null) return string.Empty;

                    string output = process.StandardOutput.ReadToEnd();
                    string errors = process.StandardError.ReadToEnd();

                    process.WaitForExit(20000);

                    return output + Environment.NewLine + errors;
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[wifi] [ОШИБКА] netsh " + arguments + ": " + ex.Message);
                return string.Empty;
            }
        }

        /// <summary>Есть ли на машине адаптер Wi-Fi.</summary>
        public static bool AdapterPresent
        {
            get
            {
                string output = RunNetsh("wlan show interfaces");

                return output.IndexOf("SSID", StringComparison.OrdinalIgnoreCase) >= 0 ||
                       output.IndexOf("GUID", StringComparison.OrdinalIgnoreCase) >= 0;
            }
        }

        // =====================================================================
        //  Сканирование
        // =====================================================================

        /// <summary>
        /// Список сетей вокруг. Разбор идёт по значениям, а не по названиям
        /// полей: netsh переводит подписи, но WPA2-Personal, CCMP и проценты
        /// остаются такими же на любом языке Windows.
        /// </summary>
        public static List<WifiNetwork> Scan()
        {
            List<WifiNetwork> result = new List<WifiNetwork>();

            string output = RunNetsh("wlan show networks mode=bssid");
            if (output.Length == 0) return result;

            string current = CurrentSsid();

            // Блок каждой сети начинается строкой «SSID <номер> : <имя>».
            string[] blocks = Regex.Split(output, @"(?im)^\s*SSID\s+\d+\s*:");
            for (int index = 1; index < blocks.Length; index++)
            {
                string block = blocks[index];

                int lineEnd = block.IndexOf('\n');
                string ssid = (lineEnd < 0 ? block : block.Substring(0, lineEnd)).Trim();
                if (ssid.Length == 0) continue;

                WifiNetwork network = new WifiNetwork();
                network.Ssid = ssid;
                network.Authentication = ExtractAuthentication(block);
                network.Encryption = ExtractEncryption(block);
                network.Signal = ExtractSignal(block);
                network.Connected = string.Equals(ssid, current, StringComparison.Ordinal);

                result.Add(network);
            }

            result.Sort((left, right) => right.Signal.CompareTo(left.Signal));
            return result;
        }

        private static string ExtractAuthentication(string block)
        {
            Match match = Regex.Match(block,
                @"(WPA3[\w\- ]*|WPA2[\w\- ]*|WPA[\w\- ]*|WEP|802\.1X)",
                RegexOptions.IgnoreCase);

            if (match.Success) return match.Groups[1].Value.Trim();

            return LisunLocale.T("wifi.openShort");
        }

        private static string ExtractEncryption(string block)
        {
            Match match = Regex.Match(block, @"(CCMP|GCMP|TKIP|WEP|AES)", RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value.ToUpperInvariant() : "—";
        }

        private static int ExtractSignal(string block)
        {
            Match match = Regex.Match(block, @"(\d{1,3})\s*%");
            if (!match.Success) return 0;

            int value;
            return int.TryParse(match.Groups[1].Value, out value) ? Math.Min(100, value) : 0;
        }

        /// <summary>Имя сети, к которой машина подключена сейчас, либо пустая строка.</summary>
        public static string CurrentSsid()
        {
            string output = RunNetsh("wlan show interfaces");

            foreach (Match match in Regex.Matches(output, @"(?im)^\s*SSID\s*:\s*(.+)$"))
            {
                string value = match.Groups[1].Value.Trim();
                if (value.Length > 0) return value;
            }

            return string.Empty;
        }

        /// <summary>Сохранённые профили Wi-Fi: к ним можно подключиться без пароля.</summary>
        public static List<string> SavedProfiles()
        {
            List<string> result = new List<string>();

            string output = RunNetsh("wlan show profiles");
            foreach (Match match in Regex.Matches(output, @"(?im)^\s*\S.*?:\s*(.+)$"))
            {
                string value = match.Groups[1].Value.Trim();

                if (value.Length == 0) continue;
                if (value.IndexOf("Group", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                if (!result.Contains(value)) result.Add(value);
            }

            return result;
        }

        // =====================================================================
        //  Подключение
        // =====================================================================

        /// <summary>
        /// Подключение к сети. Пустой пароль годится для открытой сети и для
        /// сети с уже сохранённым профилем. Для сети предприятия пароля мало —
        /// после подключения откроется страница входа.
        /// </summary>
        public static bool Connect(string ssid, string password, out string message)
        {
            if (string.IsNullOrEmpty(ssid))
            {
                message = LisunLocale.T("wifi.noSsid");
                return false;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("wifi.needNetwork");
                return false;
            }

            WifiNetwork network = Find(ssid);
            bool open = network == null ? string.IsNullOrEmpty(password) : network.Open;

            if (!open && string.IsNullOrEmpty(password) && !SavedProfiles().Contains(ssid))
            {
                message = LisunLocale.T("wifi.needPassword", ssid);
                return false;
            }

            // Профиль нужен только когда пароль задали или сеть открытая:
            // для сохранённой сети netsh подключится сам.
            if (!string.IsNullOrEmpty(password) || open)
            {
                string profileError;
                if (!AddProfile(ssid, password, network, out profileError))
                {
                    message = profileError;
                    return false;
                }
            }

            LisunEngine.Log("[wifi] " + LisunLocale.T("wifi.connecting", ssid));

            string output = RunNetsh("wlan connect name=\"" + ssid + "\" ssid=\"" + ssid + "\"");

            // netsh отвечает мгновенно, а подключение занимает несколько секунд.
            for (int attempt = 0; attempt < 15; attempt++)
            {
                Thread.Sleep(1000);
                if (string.Equals(CurrentSsid(), ssid, StringComparison.Ordinal)) break;
            }

            if (!string.Equals(CurrentSsid(), ssid, StringComparison.Ordinal))
            {
                message = LisunLocale.T("wifi.connectFailed", ssid,
                    FirstMeaningfulLine(output));
                return false;
            }

            LisunEngine.Log("[wifi] " + LisunLocale.T("wifi.connected", ssid));

            // Проверяем, пускают ли нас дальше точки доступа.
            string portal;
            ConnectivityState state = CheckConnectivity(out portal);

            switch (state)
            {
                case ConnectivityState.Online:
                    message = LisunLocale.T("wifi.onlineNow", ssid);
                    break;

                case ConnectivityState.Portal:
                    lock (gate) portalUrl = portal;

                    message = LisunLocale.T("wifi.portalFound", ssid, portal);
                    OpenPortal(portal);
                    break;

                default:
                    message = LisunLocale.T("wifi.noInternet", ssid);
                    break;
            }

            lock (gate) online = state == ConnectivityState.Online;

            NotifyStateChanged(state == ConnectivityState.Online);
            StartWatcher();
            return true;
        }

        /// <summary>Отключение от текущей сети.</summary>
        public static bool Disconnect(out string message)
        {
            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("wifi.needNetwork");
                return false;
            }

            RunNetsh("wlan disconnect");
            lock (gate) { online = false; portalUrl = string.Empty; }

            message = LisunLocale.T("wifi.disconnected");
            LisunEngine.Log("[wifi] " + message);
            return true;
        }

        /// <summary>Удаляет сохранённый профиль сети.</summary>
        public static bool Forget(string ssid, out string message)
        {
            if (string.IsNullOrEmpty(ssid))
            {
                message = LisunLocale.T("wifi.noSsid");
                return false;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Network))
            {
                message = LisunLocale.T("wifi.needNetwork");
                return false;
            }

            RunNetsh("wlan delete profile name=\"" + ssid + "\"");

            message = LisunLocale.T("wifi.forgotten", ssid);
            return true;
        }

        public static WifiNetwork Find(string ssid)
        {
            foreach (WifiNetwork network in Scan())
                if (string.Equals(network.Ssid, ssid, StringComparison.OrdinalIgnoreCase)) return network;

            return null;
        }

        /// <summary>Создаёт профиль Wi-Fi и отдаёт его netsh.</summary>
        private static bool AddProfile(string ssid, string password, WifiNetwork network, out string message)
        {
            string auth = network == null
                ? (string.IsNullOrEmpty(password) ? "open" : "WPA2PSK")
                : network.ProfileAuth;

            string cipher = network == null
                ? (string.IsNullOrEmpty(password) ? "none" : "AES")
                : network.ProfileCipher;

            StringBuilder xml = new StringBuilder();
            xml.AppendLine("<?xml version=\"1.0\"?>");
            xml.AppendLine("<WLANProfile xmlns=\"http://www.microsoft.com/networking/WLAN/profile/v1\">");
            xml.AppendLine("    <name>" + Escape(ssid) + "</name>");
            xml.AppendLine("    <SSIDConfig>");
            xml.AppendLine("        <SSID>");
            xml.AppendLine("            <name>" + Escape(ssid) + "</name>");
            xml.AppendLine("        </SSID>");
            xml.AppendLine("    </SSIDConfig>");
            xml.AppendLine("    <connectionType>ESS</connectionType>");
            xml.AppendLine("    <connectionMode>auto</connectionMode>");
            xml.AppendLine("    <MSM>");
            xml.AppendLine("        <security>");
            xml.AppendLine("            <authEncryption>");
            xml.AppendLine("                <authentication>" + auth + "</authentication>");
            xml.AppendLine("                <encryption>" + cipher + "</encryption>");
            xml.AppendLine("                <useOneX>false</useOneX>");
            xml.AppendLine("            </authEncryption>");

            if (!string.IsNullOrEmpty(password))
            {
                xml.AppendLine("            <sharedKey>");
                xml.AppendLine("                <keyType>passPhrase</keyType>");
                xml.AppendLine("                <protected>false</protected>");
                xml.AppendLine("                <keyMaterial>" + Escape(password) + "</keyMaterial>");
                xml.AppendLine("            </sharedKey>");
            }

            xml.AppendLine("        </security>");
            xml.AppendLine("    </MSM>");
            xml.AppendLine("</WLANProfile>");

            string path = Path.Combine(LisunEngine.TempPath, "wifi-profile.xml");

            try
            {
                if (!Directory.Exists(LisunEngine.TempPath)) Directory.CreateDirectory(LisunEngine.TempPath);

                File.WriteAllText(path, xml.ToString(), new UTF8Encoding(false));

                string output = RunNetsh("wlan add profile filename=\"" + path + "\" user=current");

                // Пароль не должен остаться на диске.
                try { File.Delete(path); }
                catch { }

                if (output.IndexOf("SSID", StringComparison.OrdinalIgnoreCase) < 0 &&
                    output.IndexOf(ssid, StringComparison.OrdinalIgnoreCase) < 0)
                {
                    message = LisunLocale.T("wifi.profileFailed", FirstMeaningfulLine(output));
                    return false;
                }

                message = string.Empty;
                return true;
            }
            catch (Exception ex)
            {
                try { if (File.Exists(path)) File.Delete(path); }
                catch { }

                message = LisunLocale.T("wifi.profileFailed", ex.Message);
                return false;
            }
        }

        private static string Escape(string value)
        {
            if (value == null) return string.Empty;

            return value.Replace("&", "&amp;").Replace("<", "&lt;")
                        .Replace(">", "&gt;").Replace("\"", "&quot;");
        }

        private static string FirstMeaningfulLine(string output)
        {
            if (string.IsNullOrEmpty(output)) return "—";

            foreach (string line in output.Split('\n'))
            {
                string trimmed = line.Trim();
                if (trimmed.Length > 3 && trimmed.IndexOf("Active code page", StringComparison.OrdinalIgnoreCase) < 0)
                    return trimmed;
            }

            return "—";
        }

        // =====================================================================
        //  Интернет и страница авторизации
        // =====================================================================

        public enum ConnectivityState
        {
            Offline,
            Portal,
            Online
        }

        /// <summary>
        /// Проверяет выход в интернет. Ответ 204 без тела — интернет есть.
        /// Подмена ответа или перенаправление — перед нами страница входа.
        /// </summary>
        public static ConnectivityState CheckConnectivity(out string portal)
        {
            portal = string.Empty;

            foreach (string probe in Probes)
            {
                try
                {
                    ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(probe);
                    request.UserAgent = "LisunOS/" + LisunEngine.Version;
                    request.Timeout = 6000;
                    request.ReadWriteTimeout = 6000;
                    request.AllowAutoRedirect = false;
                    request.CachePolicy = new System.Net.Cache.RequestCachePolicy(
                        System.Net.Cache.RequestCacheLevel.NoCacheNoStore);

                    using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                    {
                        int code = (int)response.StatusCode;

                        if (code == 204) return ConnectivityState.Online;

                        if (code >= 300 && code < 400)
                        {
                            portal = response.Headers["Location"] ?? probe;
                            return ConnectivityState.Portal;
                        }

                        using (Stream stream = response.GetResponseStream())
                        using (StreamReader reader = new StreamReader(stream))
                        {
                            string body = reader.ReadToEnd();

                            // msftconnecttest отдаёт ровно «Microsoft Connect Test».
                            if (body.IndexOf("Microsoft Connect Test", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                body.Trim().Equals("success", StringComparison.OrdinalIgnoreCase))
                                return ConnectivityState.Online;

                            // Тело там, где его быть не должно — это портал.
                            portal = response.ResponseUri != null ? response.ResponseUri.ToString() : probe;
                            return ConnectivityState.Portal;
                        }
                    }
                }
                catch (WebException ex)
                {
                    HttpWebResponse response = ex.Response as HttpWebResponse;
                    if (response != null)
                    {
                        int code = (int)response.StatusCode;
                        if (code >= 300 && code < 400)
                        {
                            portal = response.Headers["Location"] ?? probe;
                            return ConnectivityState.Portal;
                        }
                    }
                }
                catch { }
            }

            return ConnectivityState.Offline;
        }

        /// <summary>Открывает страницу авторизации во встроенном браузере LisunOS.</summary>
        public static bool OpenPortal(string url)
        {
            if (string.IsNullOrEmpty(url)) url = Probes[0];

            LisunEngine.Log("[wifi] " + LisunLocale.T("wifi.openingPortal", url));

            if (LisunEngine.OpenInShellBrowser(url)) return true;

            try
            {
                Process.Start(url);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[wifi] [ОШИБКА] " + ex.Message);
                return false;
            }
        }

        // =====================================================================
        //  Наблюдение за появлением интернета
        // =====================================================================

        /// <summary>Вызывается при смене состояния интернета: true — сеть появилась.</summary>
        public static event Action<bool> ConnectivityChanged;

        /// <summary>
        /// Запускает слежение за сетью. Как только интернет появляется,
        /// событие поднимает автозагрузку php-frm.
        /// </summary>
        public static void StartWatcher()
        {
            lock (gate)
            {
                if (watching) return;
                watching = true;
            }

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                while (true)
                {
                    try
                    {
                        string portal;
                        ConnectivityState state = CheckConnectivity(out portal);

                        bool nowOnline = state == ConnectivityState.Online;

                        bool changed;
                        lock (gate)
                        {
                            changed = nowOnline != online;
                            online = nowOnline;

                            if (state == ConnectivityState.Portal) portalUrl = portal;
                            else if (nowOnline) portalUrl = string.Empty;
                        }

                        if (changed) NotifyStateChanged(nowOnline);
                    }
                    catch { }

                    Thread.Sleep(nowOnlineDelay());
                }
            });
        }

        /// <summary>Пока сети нет — проверяем часто, когда появилась — редко.</summary>
        private static int nowOnlineDelay()
        {
            return Online ? 30000 : 5000;
        }

        private static void NotifyStateChanged(bool nowOnline)
        {
            LisunEngine.Log("[wifi] " + LisunLocale.T(nowOnline ? "wifi.wentOnline" : "wifi.wentOffline"));

            Action<bool> handler = ConnectivityChanged;
            if (handler != null)
            {
                try { handler(nowOnline); }
                catch (Exception ex) { LisunEngine.Log("[wifi] [ОШИБКА] " + ex.Message); }
            }
        }

        // =====================================================================
        //  Текстовый вывод для терминала
        // =====================================================================

        /// <summary>Таблица сетей для команды «wifi list».</summary>
        public static string ListText()
        {
            if (!AdapterPresent) return LisunLocale.T("wifi.noAdapter");

            List<WifiNetwork> networks = Scan();
            if (networks.Count == 0) return LisunLocale.T("wifi.nothingFound");

            StringBuilder sb = new StringBuilder(LisunLocale.T("wifi.listTitle", networks.Count));
            sb.AppendLine();

            List<string> saved = SavedProfiles();

            foreach (WifiNetwork network in networks)
            {
                sb.AppendLine("   " + (network.Connected ? "●" : " ") + " " +
                              network.SignalBar + " " + network.Signal.ToString().PadLeft(3) + "%   " +
                              network.Ssid.PadRight(28).Substring(0, Math.Max(28, network.Ssid.Length)) + "  " +
                              (network.Open ? LisunLocale.T("wifi.openShort") : network.Authentication) +
                              (saved.Contains(network.Ssid) ? "  " + LisunLocale.T("wifi.savedMark") : ""));
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>Состояние сети для команды «wifi status».</summary>
        public static string StatusText()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("wifi.statusTitle") + Environment.NewLine);

            string ssid = CurrentSsid();

            sb.AppendLine("   " + LisunLocale.T("wifi.fieldAdapter") + ": " +
                          (AdapterPresent ? LisunLocale.T("wifi.present") : LisunLocale.T("wifi.absent")));
            sb.AppendLine("   " + LisunLocale.T("wifi.fieldNetwork") + ": " +
                          (ssid.Length == 0 ? "—" : ssid));

            string portal;
            ConnectivityState state = CheckConnectivity(out portal);

            sb.AppendLine("   " + LisunLocale.T("wifi.fieldInternet") + ": " +
                          LisunLocale.T(state == ConnectivityState.Online ? "wifi.stateOnline"
                                      : state == ConnectivityState.Portal ? "wifi.statePortal"
                                      : "wifi.stateOffline"));

            if (state == ConnectivityState.Portal)
                sb.AppendLine("   " + LisunLocale.T("wifi.fieldPortal") + ": " + portal);

            return sb.ToString().TrimEnd();
        }
    }
}
