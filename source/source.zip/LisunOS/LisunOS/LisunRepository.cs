﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Встроенный каталог системных библиотек LisunOS.
    /// Пакеты не скачиваются, а собираются ядром и устанавливаются обычным путём:
    /// apt install &lt;имя&gt; — с запросом разрешений, сценарием .lsi и шифрованием.
    /// </summary>
    public static class LisunRepository
    {
        public sealed class RepoPackage
        {
            public string Name;
            public string Version;
            public string TitleRu;
            public string TitleEn;
            public string DescriptionRu;
            public string DescriptionEn;
            public string Command;
            public List<string> Permissions = new List<string>();

            /// <summary>Файлы пакета: путь внутри архива → содержимое.</summary>
            public readonly Dictionary<string, string> Files = new Dictionary<string, string>();
        }

        private static List<RepoPackage> catalog;

        public static List<RepoPackage> Catalog()
        {
            if (catalog == null)
            {
                catalog = new List<RepoPackage>();
                catalog.Add(BuildWebServer());
                catalog.Add(BuildNotepad());
                catalog.Add(BuildSysMon());
                catalog.Add(BuildSuperUser());
            }
            return catalog;
        }

        public static RepoPackage Find(string name)
        {
            if (string.IsNullOrEmpty(name)) return null;
            name = name.Trim();

            foreach (RepoPackage package in Catalog())
            {
                if (package.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) return package;
            }

            // superuser = SuperUserApp: имя ищется и без суффикса, и по команде.
            foreach (RepoPackage package in Catalog())
            {
                if (LisunStore.SameName(package.Name, name)) return package;
                if (LisunStore.SameName(package.Command, name)) return package;
            }

            return null;
        }

        public static string Describe()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("repo.title") + Environment.NewLine);

            // Системный модуль PHP живёт отдельно от обычных пакетов.
            sb.AppendLine("   • " + LisunPhpModule.PackageName.PadRight(14) + " —        " +
                          (LisunPhpModule.IsInstalled ? LisunLocale.T("repo.installed") : LisunLocale.T("repo.available")));
            sb.AppendLine("       " + LisunLocale.T("php.catalogLine"));


            foreach (RepoPackage package in Catalog())
            {
                bool installed = LisunOSInstallerShell.FindInstalledPackage(package.Name) != null;

                sb.AppendLine("   • " + package.Name.PadRight(14) + " v" + package.Version.PadRight(8) +
                              (installed ? LisunLocale.T("repo.installed") : LisunLocale.T("repo.available")));
                sb.AppendLine("       " + (LisunLocale.Language == LisunLanguage.English
                                  ? package.DescriptionEn
                                  : package.DescriptionRu));
            }

            sb.AppendLine();
            sb.AppendLine(LisunLocale.T("repo.hint"));
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Установка
        // =====================================================================

        /// <summary>Собирает пакет каталога в .lnsh и ставит его обычным установщиком.</summary>
        public static bool Install(string name, bool elevated, out string message)
        {
            RepoPackage package = Find(name);
            if (package == null)
            {
                message = LisunLocale.T("repo.notFound", name);
                return false;
            }

            string staging = Path.Combine(LisunEngine.TempPath, "repo_" + package.Name);
            string archive = Path.Combine(LisunEngine.TempPath, package.Name + ".lnsh");

            try
            {
                if (Directory.Exists(staging)) Directory.Delete(staging, true);
                Directory.CreateDirectory(staging);

                foreach (KeyValuePair<string, string> file in package.Files)
                {
                    string target = Path.Combine(staging, file.Key.Replace('/', Path.DirectorySeparatorChar));
                    string directory = Path.GetDirectoryName(target);
                    if (!string.IsNullOrEmpty(directory)) Directory.CreateDirectory(directory);

                    File.WriteAllText(target, file.Value, new UTF8Encoding(false));
                }

                if (File.Exists(archive)) File.Delete(archive);
                ZipFile.CreateFromDirectory(staging, archive);

                LisunEngine.Log("[Repo] Пакет " + package.Name + " собран из встроенного каталога.");

                // Встроенный пакет — часть системы: права выдаются сразу.
                bool previous = LisunPermissions.TrustedSource;
                LisunPermissions.TrustedSource = true;

                bool installed;
                try { installed = LisunOSInstallerShell.InstallPackage(archive, elevated); }
                finally { LisunPermissions.TrustedSource = previous; }

                if (!installed)
                {
                    message = LisunLocale.T("repo.installFailed", package.Name);
                    return false;
                }

                message = LisunLocale.T("repo.installOk", package.Name, package.Command ?? package.Name);
                return true;
            }
            catch (Exception ex)
            {
                message = "[ERROR] " + ex.Message;
                return false;
            }
            finally
            {
                try { if (Directory.Exists(staging)) Directory.Delete(staging, true); }
                catch { }
            }
        }

        // =====================================================================
        //  Общие части манифеста
        // =====================================================================

        /// <summary>
        /// Манифест в новом формате — массив локализаций ruRU / enUS.
        /// В шаблонах вместо кавычек используются апострофы и заменяются здесь,
        /// чтобы код генератора оставался читаемым.
        /// </summary>
        private static string BuildMeta(RepoPackage package)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("[");
            sb.AppendLine(MetaEntry(package, "ruRU", package.TitleRu, package.DescriptionRu) + ",");
            sb.AppendLine(MetaEntry(package, "enUS", package.TitleEn, package.DescriptionEn));
            sb.AppendLine("]");
            return sb.ToString();
        }

        private static string MetaEntry(RepoPackage package, string lang, string title, string description)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("  {");
            sb.AppendLine("    'name': '" + package.Name + "',");
            sb.AppendLine("    'lang': '" + lang + "',");
            sb.AppendLine("    'type': 'service',");
            sb.AppendLine("    'version': '" + package.Version + "',");
            sb.AppendLine("    'author': 'LisunOS Core',");
            sb.AppendLine("    'title': '" + title + "',");
            sb.AppendLine("    'description': '" + description + "',");
            sb.AppendLine("    'permissions': [");

            for (int i = 0; i < package.Permissions.Count; i++)
            {
                sb.AppendLine("      '" + package.Permissions[i] + "'" +
                              (i < package.Permissions.Count - 1 ? "," : ""));
            }

            sb.AppendLine("    ]");
            sb.Append("  }");
            return sb.ToString().Replace('\'', '"');
        }

        private static string BuildLsi(RepoPackage package, string extra)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# Установка встроенной библиотеки " + package.Name);
            sb.AppendLine("require_core 1.1.0");
            sb.AppendLine("log Развёртывание " + package.Name + " из системного каталога");
            if (!string.IsNullOrEmpty(extra)) sb.AppendLine(extra);
            sb.AppendLine("register_service " + package.Name + ".service");
            sb.AppendLine("protect");
            return sb.ToString();
        }

        private static string BuildService(RepoPackage package, string formProperties)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("# Служба " + package.Name);
            sb.AppendLine("import winforms");
            sb.AppendLine();
            sb.AppendLine("winforms.Application " + package.Name + "App = new winforms.Application()");
            sb.AppendLine("winforms.Form MainForm = new winforms.Form(" +
                          "'%appfiles%\\Form1.cs', '%appfiles%\\Form1.designer.cs')".Replace('\'', '"'));
            sb.AppendLine();
            sb.Append(formProperties);
            sb.AppendLine();
            sb.AppendLine(package.Name + "App.program.addForm(MainForm)");
            sb.AppendLine(package.Name + "App.title = " + Quote(package.TitleRu));
            sb.AppendLine(package.Name + "App.description = " + Quote(package.DescriptionRu));
            sb.AppendLine(package.Name + "App.namespace = " + Quote(package.Name.ToLowerInvariant()));
            if (!string.IsNullOrEmpty(package.Command))
                sb.AppendLine(package.Name + "App.command = " + Quote(package.Command));
            sb.AppendLine();
            sb.AppendLine("log Служба " + package.Name + " готова");
            return sb.ToString();
        }

        private static string Quote(string value)
        {
            return "\"" + value + "\"";
        }

        // =====================================================================
        //  Пакет: webserver — панель запуска сервера
        // =====================================================================

        private static RepoPackage BuildWebServer()
        {
            RepoPackage package = new RepoPackage();
            package.Name = "WebServerV2";
            package.Version = "2.1.0";
            package.TitleRu = "Сервер LisunOS v2";
            package.TitleEn = "LisunOS Server v2";
            package.DescriptionRu = "Панель запуска HTTP-сервера на этом устройстве";
            package.DescriptionEn = "Control panel for running an HTTP server on this device";
            package.Command = "server";
            package.Permissions.Add(LisunPermissions.Network);
            package.Permissions.Add(LisunPermissions.ReadFiles);
            package.Permissions.Add(LisunPermissions.WriteFiles);
            package.Permissions.Add(LisunPermissions.EditSettings);
            package.Permissions.Add(LisunPermissions.ShowDialogs);

            string formProperties =
                "MainForm.size = 1000, 752" + Environment.NewLine +
                "MainForm.minsize = 880, 650" + Environment.NewLine +
                "MainForm.background = #0D1117" + Environment.NewLine +
                "MainForm.foreground = #CED6E0" + Environment.NewLine +
                "MainForm.center = true" + Environment.NewLine;

            package.Files["meta.json"] = BuildMeta(package);
            package.Files["main.lsi"] = BuildLsi(package, "mkdir root/www" + Environment.NewLine +
                                                          "set_data server_port=8080" + Environment.NewLine +
                                                          "register_command httpd -> WebServerV2App");
            package.Files[package.Name + ".service"] = BuildService(package, formProperties);
            package.Files["assets/Form1.cs"] = BuildLogicStub("ServerLogicBridge", package.DescriptionRu);
            package.Files["assets/Form1.designer.cs"] = WebServerDesigner();

            return package;
        }

        private static string WebServerDesigner()
        {
            string designer = @"namespace LisunOS
{
    partial class ServerForm
    {
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Panel pnlStatus;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblServerState;
        private System.Windows.Forms.Label lblStats;

        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Label lblSettingsCaption;
        private System.Windows.Forms.Label lblPortCaption;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label lblRootCaption;
        private System.Windows.Forms.TextBox txtRoot;
        private System.Windows.Forms.CheckBox chkRemote;
        private System.Windows.Forms.CheckBox chkListing;
        private System.Windows.Forms.CheckBox chkUfw;
        private System.Windows.Forms.CheckBox chkAutostart;
        private System.Windows.Forms.Button btnStartServer;
        private System.Windows.Forms.Button btnStopServer;
        private System.Windows.Forms.Button btnOpenBrowser;
        private System.Windows.Forms.Button btnOpenFolder;
        private System.Windows.Forms.Button btnManageFiles;
        private System.Windows.Forms.Button btnApiKey;
        private System.Windows.Forms.Button btnPanel;

        private System.Windows.Forms.Panel pnlSide;
        private System.Windows.Forms.Label lblAddrCaption;
        private System.Windows.Forms.Label lblAddresses;
        private System.Windows.Forms.Label lblHintCaption;
        private System.Windows.Forms.Label lblHints;

        private System.Windows.Forms.Label lblHostsCaption;
        private System.Windows.Forms.ListView lstHosts;
        private System.Windows.Forms.Button btnReloadConfig;
        private System.Windows.Forms.Button btnEditConfig;
        private System.Windows.Forms.Panel pnlLog;
        private System.Windows.Forms.Panel pnlLogHead;
        private System.Windows.Forms.TextBox txtLogFilter;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.Label lblLogCaption;
        private System.Windows.Forms.ListBox lstServerLog;

        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.pnlStatus = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblServerState = new System.Windows.Forms.Label();
            this.lblStats = new System.Windows.Forms.Label();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.lblSettingsCaption = new System.Windows.Forms.Label();
            this.lblPortCaption = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.lblRootCaption = new System.Windows.Forms.Label();
            this.txtRoot = new System.Windows.Forms.TextBox();
            this.chkRemote = new System.Windows.Forms.CheckBox();
            this.chkListing = new System.Windows.Forms.CheckBox();
            this.chkUfw = new System.Windows.Forms.CheckBox();
            this.chkAutostart = new System.Windows.Forms.CheckBox();
            this.btnStartServer = new System.Windows.Forms.Button();
            this.btnStopServer = new System.Windows.Forms.Button();
            this.btnOpenBrowser = new System.Windows.Forms.Button();
            this.btnOpenFolder = new System.Windows.Forms.Button();
            this.btnManageFiles = new System.Windows.Forms.Button();
            this.btnApiKey = new System.Windows.Forms.Button();
            this.btnPanel = new System.Windows.Forms.Button();
            this.pnlSide = new System.Windows.Forms.Panel();
            this.lblAddrCaption = new System.Windows.Forms.Label();
            this.lblAddresses = new System.Windows.Forms.Label();
            this.lblHintCaption = new System.Windows.Forms.Label();
            this.lblHints = new System.Windows.Forms.Label();
            this.lblHostsCaption = new System.Windows.Forms.Label();
            this.lstHosts = new System.Windows.Forms.ListView();
            this.btnReloadConfig = new System.Windows.Forms.Button();
            this.btnEditConfig = new System.Windows.Forms.Button();
            this.pnlLog = new System.Windows.Forms.Panel();
            this.pnlLogHead = new System.Windows.Forms.Panel();
            this.txtLogFilter = new System.Windows.Forms.TextBox();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.lblLogCaption = new System.Windows.Forms.Label();
            this.lstServerLog = new System.Windows.Forms.ListBox();

            // 
            // Заголовок
            // 
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Size = new System.Drawing.Size(1000, 100);

            this.pnlStatus.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlStatus.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlStatus.Size = new System.Drawing.Size(6, 100);

            this.lblTitle.Text = 'Сервер LisunOS';
            this.lblTitle.Font = new System.Drawing.Font('Segoe UI Semibold', 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(88, 166, 255);
            this.lblTitle.Location = new System.Drawing.Point(30, 18);
            this.lblTitle.Size = new System.Drawing.Size(470, 32);

            this.lblServerState.Text = 'Сервер остановлен';
            this.lblServerState.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblServerState.Location = new System.Drawing.Point(32, 56);
            this.lblServerState.Size = new System.Drawing.Size(470, 26);

            this.lblStats.Text = '';
            this.lblStats.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblStats.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblStats.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.lblStats.Location = new System.Drawing.Point(510, 56);
            this.lblStats.Size = new System.Drawing.Size(462, 26);

            this.pnlHeader.Controls.Add(this.lblStats);
            this.pnlHeader.Controls.Add(this.lblServerState);
            this.pnlHeader.Controls.Add(this.lblTitle);
            this.pnlHeader.Controls.Add(this.pnlStatus);

            // 
            // Параметры
            // 
            this.pnlSettings.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlSettings.Location = new System.Drawing.Point(24, 124);
            this.pnlSettings.Size = new System.Drawing.Size(568, 320);

            this.lblSettingsCaption.Text = 'ПАРАМЕТРЫ';
            this.lblSettingsCaption.Font = new System.Drawing.Font('Segoe UI Semibold', 9F, System.Drawing.FontStyle.Bold);
            this.lblSettingsCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblSettingsCaption.Location = new System.Drawing.Point(22, 14);
            this.lblSettingsCaption.Size = new System.Drawing.Size(220, 20);

            this.lblPortCaption.Text = 'Порт';
            this.lblPortCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblPortCaption.Location = new System.Drawing.Point(22, 44);
            this.lblPortCaption.Size = new System.Drawing.Size(110, 20);

            this.txtPort.Text = '8080';
            this.txtPort.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.txtPort.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.txtPort.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPort.Location = new System.Drawing.Point(22, 66);
            this.txtPort.Size = new System.Drawing.Size(112, 28);

            this.lblRootCaption.Text = 'Корневая папка сайта';
            this.lblRootCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblRootCaption.Location = new System.Drawing.Point(152, 44);
            this.lblRootCaption.Size = new System.Drawing.Size(390, 20);

            this.txtRoot.Text = 'LisunOS:\root\www';
            this.txtRoot.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.txtRoot.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.txtRoot.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRoot.Location = new System.Drawing.Point(152, 66);
            this.txtRoot.Size = new System.Drawing.Size(394, 28);

            this.chkRemote.Text = 'Разрешить подключения из локальной сети';
            this.chkRemote.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.chkRemote.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkRemote.Location = new System.Drawing.Point(22, 112);
            this.chkRemote.Size = new System.Drawing.Size(510, 24);
            this.chkRemote.CheckedChanged += new System.EventHandler(this.chkRemote_CheckedChanged);

            this.chkListing.Text = 'Показывать список файлов, если нет index.html';
            this.chkListing.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.chkListing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkListing.Checked = true;
            this.chkListing.Location = new System.Drawing.Point(22, 140);
            this.chkListing.Size = new System.Drawing.Size(510, 24);
            this.chkListing.CheckedChanged += new System.EventHandler(this.chkListing_CheckedChanged);

            this.chkUfw.Text = 'Брандмауэр ufw включён — порт откроется сам';
            this.chkUfw.ForeColor = System.Drawing.Color.FromArgb(226, 176, 65);
            this.chkUfw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkUfw.Location = new System.Drawing.Point(22, 168);
            this.chkUfw.Size = new System.Drawing.Size(510, 24);
            this.chkUfw.CheckedChanged += new System.EventHandler(this.chkUfw_CheckedChanged);

            this.chkAutostart.Text = 'Запускать сервер автоматически при загрузке LisunOS';
            this.chkAutostart.ForeColor = System.Drawing.Color.FromArgb(86, 211, 100);
            this.chkAutostart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkAutostart.Location = new System.Drawing.Point(22, 196);
            this.chkAutostart.Size = new System.Drawing.Size(510, 24);
            this.chkAutostart.CheckedChanged += new System.EventHandler(this.chkAutostart_CheckedChanged);

            this.btnStartServer.Text = 'Запустить';
            this.btnStartServer.Font = new System.Drawing.Font('Segoe UI Semibold', 9.5F, System.Drawing.FontStyle.Bold);
            this.btnStartServer.Location = new System.Drawing.Point(22, 228);
            this.btnStartServer.Size = new System.Drawing.Size(152, 34);
            this.btnStartServer.Click += new System.EventHandler(this.btnStartServer_Click);

            this.btnStopServer.Text = 'Остановить';
            this.btnStopServer.Location = new System.Drawing.Point(182, 228);
            this.btnStopServer.Size = new System.Drawing.Size(152, 34);
            this.btnStopServer.Click += new System.EventHandler(this.btnStopServer_Click);

            this.btnOpenBrowser.Text = 'Открыть сайт';
            this.btnOpenBrowser.Location = new System.Drawing.Point(342, 228);
            this.btnOpenBrowser.Size = new System.Drawing.Size(116, 34);
            this.btnOpenBrowser.Click += new System.EventHandler(this.btnOpenBrowser_Click);

            this.btnOpenFolder.Text = 'Папка';
            this.btnOpenFolder.Location = new System.Drawing.Point(466, 228);
            this.btnOpenFolder.Size = new System.Drawing.Size(80, 34);
            this.btnOpenFolder.Click += new System.EventHandler(this.btnOpenFolder_Click);

            this.btnManageFiles.Text = 'Управлять файлами';
            this.btnManageFiles.Font = new System.Drawing.Font('Segoe UI Semibold', 9.5F, System.Drawing.FontStyle.Bold);
            this.btnManageFiles.Location = new System.Drawing.Point(22, 270);
            this.btnManageFiles.Size = new System.Drawing.Size(236, 34);
            this.btnManageFiles.Click += new System.EventHandler(this.btnManageFiles_Click);

            this.btnApiKey.Text = 'Ключ API';
            this.btnApiKey.Location = new System.Drawing.Point(266, 270);
            this.btnApiKey.Size = new System.Drawing.Size(130, 34);
            this.btnApiKey.Click += new System.EventHandler(this.btnApiKey_Click);

            this.btnPanel.Text = 'Веб-панель';
            this.btnPanel.Font = new System.Drawing.Font('Segoe UI Semibold', 9.5F, System.Drawing.FontStyle.Bold);
            this.btnPanel.Location = new System.Drawing.Point(406, 270);
            this.btnPanel.Size = new System.Drawing.Size(140, 34);
            this.btnPanel.Click += new System.EventHandler(this.btnPanel_Click);

            this.pnlSettings.Controls.Add(this.lblSettingsCaption);
            this.pnlSettings.Controls.Add(this.lblPortCaption);
            this.pnlSettings.Controls.Add(this.txtPort);
            this.pnlSettings.Controls.Add(this.lblRootCaption);
            this.pnlSettings.Controls.Add(this.txtRoot);
            this.pnlSettings.Controls.Add(this.chkRemote);
            this.pnlSettings.Controls.Add(this.chkListing);
            this.pnlSettings.Controls.Add(this.chkUfw);
            this.pnlSettings.Controls.Add(this.chkAutostart);
            this.pnlSettings.Controls.Add(this.btnStartServer);
            this.pnlSettings.Controls.Add(this.btnStopServer);
            this.pnlSettings.Controls.Add(this.btnOpenBrowser);
            this.pnlSettings.Controls.Add(this.btnOpenFolder);
            this.pnlSettings.Controls.Add(this.btnManageFiles);
            this.pnlSettings.Controls.Add(this.btnApiKey);
            this.pnlSettings.Controls.Add(this.btnPanel);

            // 
            // Боковая панель
            // 
            this.pnlSide.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlSide.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
            this.pnlSide.Location = new System.Drawing.Point(616, 124);
            this.pnlSide.Size = new System.Drawing.Size(360, 452);

            this.lblAddrCaption.Text = 'АДРЕСА';
            this.lblAddrCaption.Font = new System.Drawing.Font('Segoe UI Semibold', 9F, System.Drawing.FontStyle.Bold);
            this.lblAddrCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblAddrCaption.Location = new System.Drawing.Point(22, 14);
            this.lblAddrCaption.Size = new System.Drawing.Size(220, 20);

            this.lblAddresses.Text = 'сервер остановлен';
            this.lblAddresses.ForeColor = System.Drawing.Color.FromArgb(87, 208, 214);
            this.lblAddresses.Location = new System.Drawing.Point(22, 40);
            this.lblAddresses.Size = new System.Drawing.Size(316, 74);

            this.lblHintCaption.Text = 'ПОДСКАЗКИ';
            this.lblHintCaption.Font = new System.Drawing.Font('Segoe UI Semibold', 9F, System.Drawing.FontStyle.Bold);
            this.lblHintCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblHintCaption.Location = new System.Drawing.Point(22, 122);
            this.lblHintCaption.Size = new System.Drawing.Size(220, 20);

            this.lblHints.Text = 'Файлы сайта — в LisunOS:\root\www.  PHP и Node.js настраиваются в .htaccess, PHP подключается командой apt install php-frm.  Веб-панель — panel.php с паролем.  Закрыть порт: ufw port 8080 disable';
            this.lblHints.ForeColor = System.Drawing.Color.FromArgb(110, 118, 129);
            this.lblHints.Location = new System.Drawing.Point(22, 146);
            this.lblHints.Size = new System.Drawing.Size(316, 96);

            // 
            // Узлы из конфигурации (server { ... } в .htaccess и conf.d)
            // 
            this.lblHostsCaption.Text = 'УЗЛЫ КОНФИГУРАЦИИ';
            this.lblHostsCaption.Font = new System.Drawing.Font('Segoe UI Semibold', 9F, System.Drawing.FontStyle.Bold);
            this.lblHostsCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblHostsCaption.Location = new System.Drawing.Point(22, 250);
            this.lblHostsCaption.Size = new System.Drawing.Size(316, 20);

            this.lstHosts.View = System.Windows.Forms.View.Details;
            this.lstHosts.FullRowSelect = true;
            this.lstHosts.MultiSelect = false;
            this.lstHosts.HideSelection = false;
            this.lstHosts.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.lstHosts.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.lstHosts.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstHosts.Location = new System.Drawing.Point(22, 274);
            this.lstHosts.Size = new System.Drawing.Size(316, 122);

            this.btnReloadConfig.Text = 'Перечитать конфиг';
            this.btnReloadConfig.Location = new System.Drawing.Point(22, 406);
            this.btnReloadConfig.Size = new System.Drawing.Size(154, 30);
            this.btnReloadConfig.Click += new System.EventHandler(this.btnReloadConfig_Click);

            this.btnEditConfig.Text = 'Открыть конфиг';
            this.btnEditConfig.Location = new System.Drawing.Point(184, 406);
            this.btnEditConfig.Size = new System.Drawing.Size(154, 30);
            this.btnEditConfig.Click += new System.EventHandler(this.btnEditConfig_Click);

            this.pnlSide.Controls.Add(this.lblAddrCaption);
            this.pnlSide.Controls.Add(this.lblAddresses);
            this.pnlSide.Controls.Add(this.lblHintCaption);
            this.pnlSide.Controls.Add(this.lblHints);
            this.pnlSide.Controls.Add(this.lblHostsCaption);
            this.pnlSide.Controls.Add(this.lstHosts);
            this.pnlSide.Controls.Add(this.btnReloadConfig);
            this.pnlSide.Controls.Add(this.btnEditConfig);

            // 
            // Журнал
            // 
            this.pnlLog.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlLog.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.pnlLog.Location = new System.Drawing.Point(24, 592);
            this.pnlLog.Size = new System.Drawing.Size(952, 248);
            this.pnlLog.Padding = new System.Windows.Forms.Padding(1, 1, 1, 1);

            this.lblLogCaption.Text = 'ЖУРНАЛ ЗАПРОСОВ';
            this.lblLogCaption.Font = new System.Drawing.Font('Segoe UI Semibold', 9F, System.Drawing.FontStyle.Bold);
            this.lblLogCaption.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblLogCaption.Padding = new System.Windows.Forms.Padding(21, 0, 0, 0);
            this.lblLogCaption.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblLogCaption.Location = new System.Drawing.Point(0, 0);
            this.lblLogCaption.Size = new System.Drawing.Size(420, 36);

            this.pnlLogHead.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlLogHead.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlLogHead.Size = new System.Drawing.Size(952, 36);

            this.txtLogFilter.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.txtLogFilter.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.txtLogFilter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLogFilter.Location = new System.Drawing.Point(600, 5);
            this.txtLogFilter.Size = new System.Drawing.Size(210, 24);
            this.txtLogFilter.TextChanged += new System.EventHandler(this.txtLogFilter_TextChanged);

            this.btnClearLog.Text = 'Очистить';
            this.btnClearLog.Location = new System.Drawing.Point(820, 4);
            this.btnClearLog.Size = new System.Drawing.Size(110, 26);
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);

            this.pnlLogHead.Controls.Add(this.lblLogCaption);
            this.pnlLogHead.Controls.Add(this.txtLogFilter);
            this.pnlLogHead.Controls.Add(this.btnClearLog);

            this.lstServerLog.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.lstServerLog.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lstServerLog.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstServerLog.Dock = System.Windows.Forms.DockStyle.Fill;

            this.pnlLog.Controls.Add(this.lstServerLog);
            this.pnlLog.Controls.Add(this.pnlLogHead);

            // 
            // Форма
            // 
            this.Text = 'Сервер LisunOS';
            this.ClientSize = new System.Drawing.Size(1000, 868);
            this.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Controls.Add(this.pnlLog);
            this.Controls.Add(this.pnlSide);
            this.Controls.Add(this.pnlSettings);
            this.Controls.Add(this.pnlHeader);
        }
    }
}
";
            return designer.Replace('\'', '"');
        }

        // =====================================================================
        //  Пакет: notepad — текстовый редактор
        // =====================================================================

        private static RepoPackage BuildNotepad()
        {
            RepoPackage package = new RepoPackage();
            package.Name = "notepad";
            package.Version = "1.0.0";
            package.TitleRu = "Блокнот LisunOS";
            package.TitleEn = "LisunOS Notepad";
            package.DescriptionRu = "Текстовый редактор для файлов виртуальной системы";
            package.DescriptionEn = "Text editor for the virtual file system";
            package.Command = "edit";
            package.Permissions.Add(LisunPermissions.ReadFiles);
            package.Permissions.Add(LisunPermissions.WriteFiles);
            package.Permissions.Add(LisunPermissions.EditFiles);

            string formProperties =
                "MainForm.size = 860, 600" + Environment.NewLine +
                "MainForm.minsize = 620, 420" + Environment.NewLine +
                "MainForm.background = #0D1117" + Environment.NewLine +
                "MainForm.center = true" + Environment.NewLine;

            package.Files["meta.json"] = BuildMeta(package);
            package.Files["main.lsi"] = BuildLsi(package, "mkdir root/documents");
            package.Files[package.Name + ".service"] = BuildService(package, formProperties);
            package.Files["assets/Form1.cs"] = BuildLogicStub("NotepadLogicBridge", package.DescriptionRu);
            package.Files["assets/Form1.designer.cs"] = NotepadDesigner();

            return package;
        }

        // =====================================================================
        //  Пакет: superuser — выдача права superuser
        //
        //  Этот пакет лежит внутри системы, а не только на сайте: без него
        //  право superuser выдать нечем, а значит и чинить систему, когда
        //  сети нет, было бы нечем тоже.
        // =====================================================================

        private static RepoPackage BuildSuperUser()
        {
            RepoPackage package = new RepoPackage();
            package.Name = "superuser";
            package.Version = "1.1.0";
            package.TitleRu = "SuperUser";
            package.TitleEn = "SuperUser";
            package.DescriptionRu = "Выдача права superuser пакетам и включение команды su";
            package.DescriptionEn = "Grants the superuser right to packages and enables the su command";
            package.Command = "su-app";
            package.Permissions.Add(LisunPermissions.EditSettings);
            package.Permissions.Add(LisunPermissions.ShowDialogs);
            package.Permissions.Add(LisunPermissions.ReadLog);
            package.Permissions.Add(LisunPermissions.EnableSuperuser);
            package.Permissions.Add(LisunPermissions.EnableSu);

            string formProperties =
                "MainForm.size = 780, 560" + Environment.NewLine +
                "MainForm.minsize = 680, 480" + Environment.NewLine +
                "MainForm.background = #0D1117" + Environment.NewLine +
                "MainForm.foreground = #CED6E0" + Environment.NewLine +
                "MainForm.center = true" + Environment.NewLine;

            package.Files["meta.json"] = BuildMeta(package);
            package.Files["main.lsi"] = BuildLsi(package,
                "register_command su-app -> superuserApp");
            package.Files[package.Name + ".service"] = BuildService(package, formProperties);
            package.Files["assets/Form1.cs"] = BuildLogicStub("SuperUserLogicBridge", package.DescriptionRu);
            package.Files["assets/Form1.designer.cs"] = SuperUserDesigner();

            return package;
        }

        private static string SuperUserDesigner()
        {
            string designer = @"namespace LisunOS
{
    partial class SuperUserForm
    {
        // ====================================================================
        //  Разметка приложения SuperUser.
        //  Слева список пакетов, справа — что даёт право и кнопки выдачи.
        // ====================================================================

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblWarning;

        private System.Windows.Forms.ListView lstTargets;

        private System.Windows.Forms.Panel pnlSide;
        private System.Windows.Forms.Label lblPick;
        private System.Windows.Forms.Label lblExplain;
        private System.Windows.Forms.CheckBox chkUnderstand;
        private System.Windows.Forms.Button btnGrantSuper;
        private System.Windows.Forms.Button btnRevokeSuper;
        private System.Windows.Forms.Button btnElevate;
        private System.Windows.Forms.Button btnDrop;

        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label lblStatus;

        private void InitializeComponent()
        {
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblWarning = new System.Windows.Forms.Label();
            this.lstTargets = new System.Windows.Forms.ListView();
            this.pnlSide = new System.Windows.Forms.Panel();
            this.lblPick = new System.Windows.Forms.Label();
            this.lblExplain = new System.Windows.Forms.Label();
            this.chkUnderstand = new System.Windows.Forms.CheckBox();
            this.btnGrantSuper = new System.Windows.Forms.Button();
            this.btnRevokeSuper = new System.Windows.Forms.Button();
            this.btnElevate = new System.Windows.Forms.Button();
            this.btnDrop = new System.Windows.Forms.Button();
            this.lblMode = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();

            // ---------- шапка ----------
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Size = new System.Drawing.Size(780, 78);
            this.pnlHeader.BackColor = System.Drawing.Color.FromArgb(70, 32, 34);

            this.lblTitle.Location = new System.Drawing.Point(22, 14);
            this.lblTitle.Size = new System.Drawing.Size(500, 26);
            this.lblTitle.Text = ""SuperUser"";
            this.pnlHeader.Controls.Add(this.lblTitle);

            this.lblWarning.Location = new System.Drawing.Point(24, 42);
            this.lblWarning.Size = new System.Drawing.Size(730, 30);
            this.lblWarning.Text = """";
            this.lblWarning.ForeColor = System.Drawing.Color.FromArgb(226, 176, 65);
            this.pnlHeader.Controls.Add(this.lblWarning);

            this.Controls.Add(this.pnlHeader);

            // ---------- список пакетов ----------
            this.lstTargets.Location = new System.Drawing.Point(16, 94);
            this.lstTargets.Size = new System.Drawing.Size(450, 390);
            this.lstTargets.View = System.Windows.Forms.View.Details;
            this.lstTargets.FullRowSelect = true;
            this.lstTargets.MultiSelect = false;
            this.lstTargets.HideSelection = false;
            this.lstTargets.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.lstTargets.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.lstTargets.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstTargets.SelectedIndexChanged += new System.EventHandler(this.lstTargets_SelectedIndexChanged);
            this.Controls.Add(this.lstTargets);

            // ---------- правая колонка ----------
            this.pnlSide.Location = new System.Drawing.Point(482, 94);
            this.pnlSide.Size = new System.Drawing.Size(282, 390);
            this.pnlSide.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);

            this.lblPick.Location = new System.Drawing.Point(16, 16);
            this.lblPick.Size = new System.Drawing.Size(250, 26);
            this.lblPick.Text = """";
            this.pnlSide.Controls.Add(this.lblPick);

            this.lblExplain.Location = new System.Drawing.Point(16, 48);
            this.lblExplain.Size = new System.Drawing.Size(250, 170);
            this.lblExplain.Text = """";
            this.lblExplain.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.pnlSide.Controls.Add(this.lblExplain);

            this.chkUnderstand.Location = new System.Drawing.Point(16, 226);
            this.chkUnderstand.Size = new System.Drawing.Size(250, 40);
            this.chkUnderstand.Text = """";
            this.chkUnderstand.CheckedChanged += new System.EventHandler(this.chkUnderstand_CheckedChanged);
            this.pnlSide.Controls.Add(this.chkUnderstand);

            this.btnGrantSuper.Location = new System.Drawing.Point(16, 272);
            this.btnGrantSuper.Size = new System.Drawing.Size(250, 34);
            this.btnGrantSuper.Text = ""Выдать superuser"";
            this.btnGrantSuper.Click += new System.EventHandler(this.btnGrantSuper_Click);
            this.pnlSide.Controls.Add(this.btnGrantSuper);

            this.btnRevokeSuper.Location = new System.Drawing.Point(16, 312);
            this.btnRevokeSuper.Size = new System.Drawing.Size(250, 34);
            this.btnRevokeSuper.Text = ""Отозвать"";
            this.btnRevokeSuper.Click += new System.EventHandler(this.btnRevokeSuper_Click);
            this.pnlSide.Controls.Add(this.btnRevokeSuper);

            this.Controls.Add(this.pnlSide);

            // ---------- режим системы ----------
            this.lblMode.Location = new System.Drawing.Point(16, 496);
            this.lblMode.Size = new System.Drawing.Size(440, 22);
            this.lblMode.Text = """";
            this.Controls.Add(this.lblMode);

            this.btnElevate.Location = new System.Drawing.Point(482, 494);
            this.btnElevate.Size = new System.Drawing.Size(140, 30);
            this.btnElevate.Text = ""Включить режим"";
            this.btnElevate.Click += new System.EventHandler(this.btnElevate_Click);
            this.Controls.Add(this.btnElevate);

            this.btnDrop.Location = new System.Drawing.Point(628, 494);
            this.btnDrop.Size = new System.Drawing.Size(136, 30);
            this.btnDrop.Text = ""Выключить"";
            this.btnDrop.Click += new System.EventHandler(this.btnDrop_Click);
            this.Controls.Add(this.btnDrop);

            this.lblStatus.Location = new System.Drawing.Point(16, 528);
            this.lblStatus.Size = new System.Drawing.Size(748, 20);
            this.lblStatus.Text = """";
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.Controls.Add(this.lblStatus);
        }
    }
}
";

            return designer;
        }

        private static string NotepadDesigner()
        {
            string designer = @"namespace LisunOS
{
    partial class NotepadForm
    {
        private System.Windows.Forms.Panel pnlToolbar;
        private System.Windows.Forms.Button btnNewFile;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Label lblFilePath;
        private System.Windows.Forms.TextBox txtEditor;
        private System.Windows.Forms.Label lblEditorStatus;

        private void InitializeComponent()
        {
            this.pnlToolbar = new System.Windows.Forms.Panel();
            this.btnNewFile = new System.Windows.Forms.Button();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.lblFilePath = new System.Windows.Forms.Label();
            this.txtEditor = new System.Windows.Forms.TextBox();
            this.lblEditorStatus = new System.Windows.Forms.Label();

            this.pnlToolbar.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlToolbar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlToolbar.Size = new System.Drawing.Size(860, 56);
            this.pnlToolbar.Padding = new System.Windows.Forms.Padding(14, 11, 14, 11);

            this.btnNewFile.Text = 'Новый';
            this.btnNewFile.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnNewFile.Size = new System.Drawing.Size(96, 34);
            this.btnNewFile.Click += new System.EventHandler(this.btnNewFile_Click);

            this.btnOpenFile.Text = 'Открыть';
            this.btnOpenFile.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnOpenFile.Size = new System.Drawing.Size(96, 34);
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);

            this.btnSaveFile.Text = 'Сохранить';
            this.btnSaveFile.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnSaveFile.Size = new System.Drawing.Size(110, 34);
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);

            this.lblFilePath.Text = 'новый файл';
            this.lblFilePath.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblFilePath.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblFilePath.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblFilePath.Padding = new System.Windows.Forms.Padding(16, 0, 6, 0);

            this.pnlToolbar.Controls.Add(this.lblFilePath);
            this.pnlToolbar.Controls.Add(this.btnSaveFile);
            this.pnlToolbar.Controls.Add(this.btnOpenFile);
            this.pnlToolbar.Controls.Add(this.btnNewFile);

            this.txtEditor.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.txtEditor.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.txtEditor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEditor.Multiline = true;
            this.txtEditor.AcceptsTab = true;
            this.txtEditor.WordWrap = false;
            this.txtEditor.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtEditor.TextChanged += new System.EventHandler(this.txtEditor_TextChanged);

            this.lblEditorStatus.Text = 'строк: 1   символов: 0';
            this.lblEditorStatus.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.lblEditorStatus.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblEditorStatus.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lblEditorStatus.Padding = new System.Windows.Forms.Padding(18, 0, 0, 0);
            this.lblEditorStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblEditorStatus.Size = new System.Drawing.Size(860, 30);

            this.Text = 'Блокнот LisunOS';
            this.ClientSize = new System.Drawing.Size(860, 600);
            this.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.Padding = new System.Windows.Forms.Padding(16);
            this.Controls.Add(this.txtEditor);
            this.Controls.Add(this.lblEditorStatus);
            this.Controls.Add(this.pnlToolbar);
        }
    }
}
";
            return designer.Replace('\'', '"');
        }

        // =====================================================================
        //  Пакет: sysmon — системный монитор
        // =====================================================================

        private static RepoPackage BuildSysMon()
        {
            RepoPackage package = new RepoPackage();
            package.Name = "sysmon";
            package.Version = "1.0.0";
            package.TitleRu = "Монитор системы";
            package.TitleEn = "System Monitor";
            package.DescriptionRu = "Процессы, память и состояние служб LisunOS";
            package.DescriptionEn = "Processes, memory and LisunOS service state";
            package.Command = "monitor";
            package.Permissions.Add(LisunPermissions.ReadFiles);
            package.Permissions.Add(LisunPermissions.RunServices);

            string formProperties =
                "MainForm.size = 820, 560" + Environment.NewLine +
                "MainForm.background = #0D1117" + Environment.NewLine +
                "MainForm.center = true" + Environment.NewLine;

            package.Files["meta.json"] = BuildMeta(package);
            package.Files["main.lsi"] = BuildLsi(package, null);
            package.Files[package.Name + ".service"] = BuildService(package, formProperties);
            package.Files["assets/Form1.cs"] = BuildLogicStub("SysMonLogicBridge", package.DescriptionRu);
            package.Files["assets/Form1.designer.cs"] = SysMonDesigner();

            return package;
        }

        private static string SysMonDesigner()
        {
            string designer = @"namespace LisunOS
{
    partial class SysMonForm
    {
        private System.Windows.Forms.Panel pnlMonHeader;
        private System.Windows.Forms.Label lblMonTitle;
        private System.Windows.Forms.Label lblMonSummary;
        private System.Windows.Forms.ListBox lstMonProcesses;
        private System.Windows.Forms.Panel pnlMonFooter;
        private System.Windows.Forms.Button btnMonRefresh;
        private System.Windows.Forms.Button btnMonKill;
        private System.Windows.Forms.Label lblMonHint;

        private void InitializeComponent()
        {
            this.pnlMonHeader = new System.Windows.Forms.Panel();
            this.lblMonTitle = new System.Windows.Forms.Label();
            this.lblMonSummary = new System.Windows.Forms.Label();
            this.lstMonProcesses = new System.Windows.Forms.ListBox();
            this.pnlMonFooter = new System.Windows.Forms.Panel();
            this.btnMonRefresh = new System.Windows.Forms.Button();
            this.btnMonKill = new System.Windows.Forms.Button();
            this.lblMonHint = new System.Windows.Forms.Label();

            this.pnlMonHeader.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlMonHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlMonHeader.Size = new System.Drawing.Size(820, 104);

            this.lblMonTitle.Text = 'Монитор системы';
            this.lblMonTitle.Font = new System.Drawing.Font('Segoe UI Semibold', 15F, System.Drawing.FontStyle.Bold);
            this.lblMonTitle.ForeColor = System.Drawing.Color.FromArgb(188, 140, 255);
            this.lblMonTitle.Location = new System.Drawing.Point(24, 16);
            this.lblMonTitle.Size = new System.Drawing.Size(420, 30);

            this.lblMonSummary.Text = '';
            this.lblMonSummary.ForeColor = System.Drawing.Color.FromArgb(128, 137, 149);
            this.lblMonSummary.Location = new System.Drawing.Point(26, 50);
            this.lblMonSummary.Size = new System.Drawing.Size(760, 46);

            this.pnlMonHeader.Controls.Add(this.lblMonSummary);
            this.pnlMonHeader.Controls.Add(this.lblMonTitle);

            this.lstMonProcesses.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.lstMonProcesses.ForeColor = System.Drawing.Color.FromArgb(206, 214, 224);
            this.lstMonProcesses.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstMonProcesses.Dock = System.Windows.Forms.DockStyle.Fill;

            this.pnlMonFooter.BackColor = System.Drawing.Color.FromArgb(22, 27, 34);
            this.pnlMonFooter.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlMonFooter.Size = new System.Drawing.Size(820, 58);
            this.pnlMonFooter.Padding = new System.Windows.Forms.Padding(16, 12, 16, 12);

            this.btnMonRefresh.Text = 'Обновить';
            this.btnMonRefresh.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMonRefresh.Size = new System.Drawing.Size(120, 34);
            this.btnMonRefresh.Click += new System.EventHandler(this.btnMonRefresh_Click);

            this.btnMonKill.Text = 'Завершить';
            this.btnMonKill.Dock = System.Windows.Forms.DockStyle.Left;
            this.btnMonKill.Size = new System.Drawing.Size(120, 34);
            this.btnMonKill.Click += new System.EventHandler(this.btnMonKill_Click);

            this.lblMonHint.Text = 'выберите процесс в списке';
            this.lblMonHint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblMonHint.ForeColor = System.Drawing.Color.FromArgb(110, 118, 129);
            this.lblMonHint.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lblMonHint.Padding = new System.Windows.Forms.Padding(14, 0, 6, 0);

            this.pnlMonFooter.Controls.Add(this.lblMonHint);
            this.pnlMonFooter.Controls.Add(this.btnMonKill);
            this.pnlMonFooter.Controls.Add(this.btnMonRefresh);

            this.Text = 'Монитор системы';
            this.ClientSize = new System.Drawing.Size(820, 560);
            this.BackColor = System.Drawing.Color.FromArgb(13, 17, 23);
            this.Padding = new System.Windows.Forms.Padding(14);
            this.Controls.Add(this.lstMonProcesses);
            this.Controls.Add(this.pnlMonFooter);
            this.Controls.Add(this.pnlMonHeader);
        }
    }
}
";
            return designer.Replace('\'', '"');
        }

        /// <summary>Заглушка логики: настоящая логика встроена в ядро как LogicBridge.</summary>
        private static string BuildLogicStub(string bridgeName, string description)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("// " + description);
            sb.AppendLine("// Логика этой формы реализована в ядре LisunOS: " + bridgeName + ".");
            sb.AppendLine("// Файл нужен сервису как ссылка на обработчики событий.");
            sb.AppendLine("namespace LisunOS { partial class " + bridgeName + " { } }");
            return sb.ToString();
        }
    }
}
