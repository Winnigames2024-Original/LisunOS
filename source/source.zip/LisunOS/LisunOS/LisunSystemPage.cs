﻿using System;

namespace LisunOS
{
    /// <summary>
    /// Страница php-frm.html для системного порта 8989.
    /// Вся разметка и скрипт лежат здесь, чтобы сервер отдавал страницу
    /// без обращения к диску: порт поднимается раньше, чем появляется www.
    /// </summary>
    public static partial class LisunSystemServer
    {
        /// <summary>Собирает страницу прямого эфира установки PHP.</summary>
        private static string BuildPage()
        {
            return Page;
        }

        private const string Page = @"<!DOCTYPE html>
<html lang=""ru"">
<head>
<meta charset=""utf-8"">
<meta name=""viewport"" content=""width=device-width, initial-scale=1"">
<title>php-frm — настройка LisunOS</title>
<style>
  :root {
    --bg: #0d1117;
    --surface: #161b22;
    --surface-2: #1c2330;
    --line: #262d3a;
    --text: #e6eaf2;
    --dim: #8b95a7;
    --accent: #4c8dff;
    --ok: #3fb950;
    --warn: #d29922;
    --err: #f85149;
    --mono: ""Cascadia Mono"", ""JetBrains Mono"", Consolas, monospace;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    padding: 32px 16px 56px;
    background: var(--bg);
    color: var(--text);
    font: 15px/1.55 -apple-system, ""Segoe UI"", Roboto, sans-serif;
  }
  .wrap { max-width: 860px; margin: 0 auto; }
  header { margin-bottom: 26px; }
  h1 { margin: 0 0 6px; font-size: 25px; font-weight: 650; letter-spacing: -.02em; }
  .sub { color: var(--dim); font-size: 14px; }
  .sub code { font-family: var(--mono); color: var(--accent); }

  .grid { display: grid; gap: 14px; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); margin-bottom: 20px; }
  .tile {
    background: var(--surface); border: 1px solid var(--line);
    border-radius: 12px; padding: 14px 16px;
  }
  .tile .k { color: var(--dim); font-size: 12px; text-transform: uppercase; letter-spacing: .07em; }
  .tile .v { margin-top: 6px; font-size: 17px; font-weight: 600; font-family: var(--mono); overflow-wrap: anywhere; line-height: 1.35; }
  .dot { display: inline-block; width: 9px; height: 9px; border-radius: 50%; margin-right: 7px; vertical-align: 1px; }
  .dot.on { background: var(--ok); box-shadow: 0 0 0 3px rgba(63,185,80,.18); }
  .dot.off { background: var(--err); box-shadow: 0 0 0 3px rgba(248,81,73,.16); }
  .dot.wait { background: var(--warn); box-shadow: 0 0 0 3px rgba(210,153,34,.16); }

  .card {
    background: var(--surface); border: 1px solid var(--line);
    border-radius: 14px; padding: 20px; margin-bottom: 18px;
  }
  .card h2 { margin: 0 0 14px; font-size: 16px; font-weight: 600; }

  .bar { height: 10px; border-radius: 99px; background: var(--surface-2); overflow: hidden; }
  .bar i {
    display: block; height: 100%; width: 0;
    background: linear-gradient(90deg, var(--accent), #7cb0ff);
    transition: width .35s ease;
  }
  .barline { display: flex; justify-content: space-between; margin-top: 9px; font-family: var(--mono); font-size: 13px; color: var(--dim); }
  .barline b { color: var(--text); font-weight: 600; }

  .feed {
    margin: 0; padding: 14px; height: 300px; overflow-y: auto;
    background: #0a0e14; border: 1px solid var(--line); border-radius: 10px;
    font-family: var(--mono); font-size: 12.5px; line-height: 1.75;
    white-space: pre-wrap; word-break: break-word; color: #c9d3e3;
  }
  .feed .t { color: var(--dim); }
  .feed .e { color: var(--err); }
  .feed .g { color: var(--ok); }

  .row { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 16px; }
  button {
    font: inherit; font-size: 14px; font-weight: 550;
    padding: 10px 18px; border-radius: 9px; cursor: pointer;
    border: 1px solid var(--line); background: var(--surface-2); color: var(--text);
    transition: background .15s, border-color .15s;
  }
  button:hover:not(:disabled) { background: #232b3a; border-color: #36405a; }
  button.primary { background: var(--accent); border-color: var(--accent); color: #fff; }
  button.primary:hover:not(:disabled) { background: #3d7ced; }
  button:disabled { opacity: .45; cursor: default; }

  table { width: 100%; border-collapse: collapse; font-size: 14px; }
  th, td { text-align: left; padding: 9px 10px; border-bottom: 1px solid var(--line); }
  th { color: var(--dim); font-size: 12px; text-transform: uppercase; letter-spacing: .06em; font-weight: 600; }
  td.sig { font-family: var(--mono); color: var(--dim); }
  .tag { font-size: 11.5px; padding: 2px 8px; border-radius: 99px; border: 1px solid var(--line); color: var(--dim); }
  .meter { display: inline-flex; gap: 3px; vertical-align: -1px; margin-right: 8px; }
  .meter i { width: 5px; height: 12px; border-radius: 1px; background: var(--surface-2); }
  .meter i.on { background: var(--accent); }
  .meter i.on.weak { background: var(--warn); }
  .tag.ok { color: var(--ok); border-color: rgba(63,185,80,.35); }

  footer { margin-top: 26px; color: var(--dim); font-size: 12.5px; font-family: var(--mono); }
</style>
</head>
<body>
<div class=""wrap"">

  <header>
    <h1>php-frm</h1>
    <div class=""sub"">Системный порт <code>8989</code> · прямой эфир установки PHP · право <code>hall</code></div>
  </header>

  <div class=""grid"">
    <div class=""tile"">
      <div class=""k"">Интернет</div>
      <div class=""v""><span id=""netdot"" class=""dot wait""></span><span id=""net"">проверка…</span></div>
    </div>
    <div class=""tile"">
      <div class=""k"">Сеть Wi-Fi</div>
      <div class=""v"" id=""ssid"">—</div>
    </div>
    <div class=""tile"">
      <div class=""k"">PHP</div>
      <div class=""v""><span id=""phpdot"" class=""dot wait""></span><span id=""php"">—</span></div>
    </div>
    <div class=""tile"">
      <div class=""k"">Порт работает</div>
      <div class=""v"" id=""uptime"">00:00:00</div>
    </div>
  </div>

  <div class=""card"">
    <h2>Загрузка сборки PHP</h2>
    <div class=""bar""><i id=""fill""></i></div>
    <div class=""barline"">
      <span id=""stage"">ожидание сети</span>
      <span><b id=""pct"">0%</b> · <span id=""size"">—</span></span>
    </div>
    <div class=""row"">
      <button class=""primary"" id=""go"">Скачать PHP сейчас</button>
      <button id=""again"">Повторить</button>
      <button id=""portal"" disabled>Открыть страницу входа</button>
      <button id=""scan"">Обновить сети</button>
    </div>
  </div>

  <div class=""card"">
    <h2>Прямой эфир</h2>
    <pre class=""feed"" id=""feed"">подключение к системе…</pre>
  </div>

  <div class=""card"">
    <h2>Сети вокруг</h2>
    <table>
      <thead><tr><th>Сеть</th><th>Сигнал</th><th>Защита</th></tr></thead>
      <tbody id=""nets""><tr><td colspan=""3"" style=""color:var(--dim)"">нажмите «Обновить сети»</td></tr></tbody>
    </table>
  </div>

  <footer>LisunOS · страница обновляется сама, перезагружать не нужно</footer>
</div>

<script>
""use strict"";

var feed = document.getElementById(""feed"");
var shown = 0;
var failed = 0;

function text(id, value) {
  var node = document.getElementById(id);
  if (node && node.textContent !== value) node.textContent = value;
}

function dot(id, state) {
  var node = document.getElementById(id);
  if (node) node.className = ""dot "" + state;
}

function paintLog(lines) {
  if (!lines) return;

  if (lines.length < shown) { feed.textContent = """"; shown = 0; }
  if (lines.length === shown) return;

  // Первая настоящая запись вытесняет заглушку «подключение к системе…».
  if (shown === 0) feed.textContent = """";

  for (var index = shown; index < lines.length; index++) {
    var line = lines[index];
    var span = document.createElement(""span"");

    var lowered = line.toLowerCase();
    if (lowered.indexOf(""error"") >= 0 || lowered.indexOf(""ошиб"") >= 0 ||
        lowered.indexOf(""не удал"") >= 0 || lowered.indexOf(""failed"") >= 0) span.className = ""e"";
    else if (lowered.indexOf(""готов"") >= 0 || lowered.indexOf(""подключ"") >= 0 ||
             lowered.indexOf(""ready"") >= 0 || lowered.indexOf(""connect"") >= 0) span.className = ""g"";

    span.textContent = line + ""\n"";
    feed.appendChild(span);
  }

  shown = lines.length;
  feed.scrollTop = feed.scrollHeight;
}

function paint(data) {
  failed = 0;

  text(""net"", data.online ? ""есть"" : (data.portal ? ""нужен вход"" : ""нет""));
  dot(""netdot"", data.online ? ""on"" : (data.portal ? ""wait"" : ""off""));

  text(""ssid"", data.ssid && data.ssid.length ? data.ssid : ""—"");
  text(""uptime"", data.uptime || ""—"");

  var php = data.installed ? (data.executable || ""скачан"")
          : data.enabled ? data.engine
          : ""не настроен"";
  text(""php"", php);
  dot(""phpdot"", data.installed ? ""on"" : (data.enabled ? ""wait"" : ""off""));

  var percent = data.percent || 0;
  document.getElementById(""fill"").style.width = percent + ""%"";
  text(""pct"", percent + ""%"");
  text(""size"", data.total > 0 ? data.receivedText + "" / "" + data.totalText
                              : (data.received > 0 ? data.receivedText : ""—""));
  text(""stage"", data.stage && data.stage.length ? data.stage
                : (data.installed ? ""PHP готов"" : data.online ? ""готов к загрузке"" : ""ожидание сети""));

  document.getElementById(""go"").disabled = data.downloading || data.installed;
  document.getElementById(""again"").disabled = data.downloading;
  document.getElementById(""portal"").disabled = !(data.portal && data.portal.length);

  paintLog(data.log);
}

function ask(action) {
  var url = ""/php-frm.html?action="" + action + ""&_="" + Date.now();

  return fetch(url, { cache: ""no-store"", headers: { ""Accept"": ""application/json"" } })
    .then(function (response) { return response.json(); })
    .then(paint)
    .catch(function () {
      failed++;
      if (failed === 3) feed.textContent += ""\n[нет связи с системным портом 8989]\n"";
    });
}

function poll() { ask(""status""); }

document.getElementById(""go"").addEventListener(""click"", function () {
  feed.textContent += ""\n[запрошена загрузка PHP]\n"";
  ask(""start&format=json"");
});

document.getElementById(""again"").addEventListener(""click"", function () {
  feed.textContent = """";
  shown = 0;
  ask(""retry"");
});

document.getElementById(""portal"").addEventListener(""click"", function () {
  ask(""portal"");
});

document.getElementById(""scan"").addEventListener(""click"", function () {
  var body = document.getElementById(""nets"");
  body.innerHTML = ""<tr><td colspan='3' style='color:var(--dim)'>сканирование…</td></tr>"";

  fetch(""/php-frm.html?action=wifi&_="" + Date.now(), { cache: ""no-store"" })
    .then(function (response) { return response.json(); })
    .then(function (data) {
      body.innerHTML = """";

      if (!data.networks || !data.networks.length) {
        body.innerHTML = ""<tr><td colspan='3' style='color:var(--dim)'>сетей не найдено</td></tr>"";
        return;
      }

      data.networks.forEach(function (network) {
        var row = document.createElement(""tr"");

        var name = document.createElement(""td"");
        name.textContent = network.ssid;
        if (network.connected) {
          var tag = document.createElement(""span"");
          tag.className = ""tag ok"";
          tag.textContent = ""подключена"";
          name.appendChild(document.createTextNode("" ""));
          name.appendChild(tag);
        }

        var signal = document.createElement(""td"");
        signal.className = ""sig"";

        var meter = document.createElement(""span"");
        meter.className = ""meter"";

        var filled = Math.min(5, Math.ceil(network.signal / 20));
        for (var bar = 0; bar < 5; bar++) {
          var piece = document.createElement(""i"");
          if (bar < filled) piece.className = filled <= 2 ? ""on weak"" : ""on"";
          meter.appendChild(piece);
        }

        signal.appendChild(meter);
        signal.appendChild(document.createTextNode(network.signal + ""%""));

        var security = document.createElement(""td"");
        security.innerHTML = network.open
          ? ""<span class='tag'>без пароля</span>""
          : ""<span class='tag'>"" + network.security + ""</span>"";

        row.appendChild(name);
        row.appendChild(signal);
        row.appendChild(security);
        body.appendChild(row);
      });
    })
    .catch(function () {
      body.innerHTML = ""<tr><td colspan='3' class='e'>не удалось получить список</td></tr>"";
    });
});

poll();
setInterval(poll, 800);
</script>
</body>
</html>
";
    }
}
