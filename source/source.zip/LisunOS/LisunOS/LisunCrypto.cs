﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace LisunOS
{
    /// <summary>
    /// Прозрачное шифрование файлов установленных приложений (.service, .lsi и содержимое assets).
    /// Формат контейнера: "LSNC1" + 16 байт IV + AES-256-CBC.
    /// Любое чтение в системе идёт через этот класс, поэтому открытые и защищённые
    /// пакеты работают одинаково.
    /// </summary>
    public static class LisunCrypto
    {
        private static readonly byte[] Magic = { 0x4C, 0x53, 0x4E, 0x43, 0x31 }; // LSNC1

        private static readonly byte[] Salt =
        {
            0x4C, 0x69, 0x73, 0x75, 0x6E, 0x4F, 0x53, 0x21,
            0x07, 0x1A, 0x3C, 0x5E, 0x90, 0xB2, 0xD4, 0xF6
        };

        private const string MasterSeed = "LisunOS::PackageVault::v1::";

        /// <summary>Какие файлы пакета защищаются после установки.</summary>
        public static readonly string[] ProtectedExtensions = { ".service", ".lsi", ".cs", ".designer.cs", ".txt", ".json", ".xml", ".lsf" };

        private static byte[] BuildKey()
        {
            string hall;
            if (!LisunEngine.RegistryConfig.TryGetValue("lisunhallkey", out hall) || string.IsNullOrEmpty(hall))
                hall = "LisunOSFallbackKey";

            using (Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes(MasterSeed + hall, Salt, 20000))
            {
                return derive.GetBytes(32);
            }
        }

        // =====================================================================
        //  Определение формата
        // =====================================================================

        public static bool IsEncrypted(byte[] data)
        {
            if (data == null || data.Length < Magic.Length + 16) return false;
            for (int i = 0; i < Magic.Length; i++)
            {
                if (data[i] != Magic[i]) return false;
            }
            return true;
        }

        public static bool IsEncryptedFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;

                using (FileStream stream = File.OpenRead(path))
                {
                    byte[] head = new byte[Magic.Length];
                    if (stream.Read(head, 0, head.Length) != head.Length) return false;

                    for (int i = 0; i < Magic.Length; i++)
                    {
                        if (head[i] != Magic[i]) return false;
                    }
                    return true;
                }
            }
            catch { return false; }
        }

        // =====================================================================
        //  Прозрачное чтение
        // =====================================================================

        public static string ReadAllText(string path)
        {
            if (!File.Exists(path)) return string.Empty;

            byte[] raw;
            try { raw = File.ReadAllBytes(path); }
            catch (Exception ex)
            {
                LisunEngine.Log("[Crypto] [ОШИБКА] Чтение " + Path.GetFileName(path) + ": " + ex.Message);
                return string.Empty;
            }

            if (!IsEncrypted(raw)) return StripBom(Encoding.UTF8.GetString(raw));

            byte[] plain = Decrypt(raw);
            if (plain == null)
            {
                LisunEngine.Log("[Crypto] [ОШИБКА] Файл " + Path.GetFileName(path) +
                                " защищён ключом другой установки LisunOS.");
                return string.Empty;
            }

            return StripBom(Encoding.UTF8.GetString(plain));
        }

        public static string[] ReadAllLines(string path)
        {
            string text = ReadAllText(path);
            if (text.Length == 0) return new string[0];

            return text.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
        }

        private static string StripBom(string value)
        {
            if (value.Length > 0 && value[0] == '﻿') return value.Substring(1);
            return value;
        }

        // =====================================================================
        //  Шифрование / расшифровка
        // =====================================================================

        private static byte[] Encrypt(byte[] plain)
        {
            using (AesManaged aes = new AesManaged())
            {
                aes.KeySize = 256;
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                aes.Key = BuildKey();
                aes.GenerateIV();

                using (ICryptoTransform encryptor = aes.CreateEncryptor())
                using (MemoryStream output = new MemoryStream())
                {
                    output.Write(Magic, 0, Magic.Length);
                    output.Write(aes.IV, 0, aes.IV.Length);

                    using (CryptoStream crypto = new CryptoStream(output, encryptor, CryptoStreamMode.Write))
                    {
                        crypto.Write(plain, 0, plain.Length);
                        crypto.FlushFinalBlock();
                    }
                    return output.ToArray();
                }
            }
        }

        private static byte[] Decrypt(byte[] container)
        {
            try
            {
                using (AesManaged aes = new AesManaged())
                {
                    aes.KeySize = 256;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    aes.Key = BuildKey();

                    byte[] iv = new byte[16];
                    Array.Copy(container, Magic.Length, iv, 0, 16);
                    aes.IV = iv;

                    int offset = Magic.Length + 16;
                    using (ICryptoTransform decryptor = aes.CreateDecryptor())
                    using (MemoryStream input = new MemoryStream(container, offset, container.Length - offset))
                    using (CryptoStream crypto = new CryptoStream(input, decryptor, CryptoStreamMode.Read))
                    using (MemoryStream output = new MemoryStream())
                    {
                        byte[] buffer = new byte[4096];
                        int read;
                        while ((read = crypto.Read(buffer, 0, buffer.Length)) > 0) output.Write(buffer, 0, read);
                        return output.ToArray();
                    }
                }
            }
            catch { return null; }
        }

        public static bool EncryptFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;

                byte[] raw = File.ReadAllBytes(path);
                if (IsEncrypted(raw)) return false;

                File.WriteAllBytes(path, Encrypt(raw));
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Crypto] [ОШИБКА] Шифрование " + Path.GetFileName(path) + ": " + ex.Message);
                return false;
            }
        }

        public static bool DecryptFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return false;

                byte[] raw = File.ReadAllBytes(path);
                if (!IsEncrypted(raw)) return false;

                byte[] plain = Decrypt(raw);
                if (plain == null) return false;

                File.WriteAllBytes(path, plain);
                return true;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Crypto] [ОШИБКА] Расшифровка " + Path.GetFileName(path) + ": " + ex.Message);
                return false;
            }
        }

        // =====================================================================
        //  Пакеты целиком
        // =====================================================================

        /// <summary>Шифрует main.lsi, все *.service и всё содержимое assets установленного пакета.</summary>
        public static int ProtectPackage(string packageDirectory)
        {
            int count = 0;
            foreach (string file in CollectPackageFiles(packageDirectory))
            {
                if (EncryptFile(file)) count++;
            }
            return count;
        }

        public static int UnprotectPackage(string packageDirectory)
        {
            int count = 0;
            foreach (string file in CollectPackageFiles(packageDirectory))
            {
                if (DecryptFile(file)) count++;
            }
            return count;
        }

        public static bool IsPackageProtected(string packageDirectory)
        {
            foreach (string file in CollectPackageFiles(packageDirectory))
            {
                if (IsEncryptedFile(file)) return true;
            }
            return false;
        }

        private static List<string> CollectPackageFiles(string packageDirectory)
        {
            List<string> files = new List<string>();
            if (string.IsNullOrEmpty(packageDirectory) || !Directory.Exists(packageDirectory)) return files;

            try
            {
                foreach (string file in Directory.GetFiles(packageDirectory, "*.service", SearchOption.TopDirectoryOnly))
                    files.Add(file);

                foreach (string file in Directory.GetFiles(packageDirectory, "*.lsi", SearchOption.TopDirectoryOnly))
                    files.Add(file);

                string assets = Path.Combine(packageDirectory, "assets");
                if (Directory.Exists(assets))
                {
                    foreach (string file in Directory.GetFiles(assets, "*", SearchOption.AllDirectories))
                        files.Add(file);
                }
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[Crypto] [ОШИБКА] Обход пакета: " + ex.Message);
            }

            return files;
        }
    }
}
