﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>
    /// Удалённый вход в LisunOS с компьютера или телефона.
    ///
    /// На одном порту работают два протокола, и выбирается он по первым
    /// байтам клиента:
    ///
    ///     SSH-2        — обычный клиент ssh, в том числе с телефона:
    ///                    ssh имя@192.168.0.5 -p 2222
    ///                    Обмен ключами и шифрование настоящие, сам
    ///                    протокол собран в SshProtocol.cs.
    ///
    ///     простой текст — telnet, nc или PuTTY в режиме Raw. Остался
    ///                    для случаев, когда клиента ssh под рукой нет;
    ///                    трафик идёт открытым.
    ///
    /// Клиент ssh здоровается строкой «SSH-2.0-…» сразу после соединения,
    /// а telnet молчит и ждёт приглашения — по этому и различаем.
    /// </summary>
    public static class SshHost
    {
        public const int DefaultPort = 2222;
        public const string PackageName = "sshd";

        private static readonly object gate = new object();

        private static TcpListener listener;
        private static Thread worker;
        private static bool running;
        private static int port = DefaultPort;
        private static DateTime startedAt;
        private static long sessions;
        private static long rejected;

        private static readonly List<string> log = new List<string>();

        /// <summary>Кто сейчас в сети. Нужен для команды «ssh who» и для предела подключений.</summary>
        private static readonly List<CommandExecutorEngine.RemoteSession> live =
            new List<CommandExecutorEngine.RemoteSession>();

        /// <summary>Больше восьми одновременных клиентов — уже не рабочий сценарий, а нагрузка.</summary>
        public const int MaxSessions = 8;

        /// <summary>
        /// Поднимать ли сервер при запуске системы. Хранится в реестре,
        /// поэтому переживает перезапуск; порт запоминается там же.
        /// </summary>
        public static bool AutoStart
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData != null &&
                    LisunEngine.RegistryData.TryGetValue("ssh_autostart", out value))
                    return value == "1" || string.Equals(value, "true", StringComparison.OrdinalIgnoreCase);

                return false;
            }
            set
            {
                if (LisunEngine.RegistryData == null) return;

                LisunEngine.RegistryData["ssh_autostart"] = value ? "1" : "0";
                LisunEngine.SaveRegistry();
            }
        }

        /// <summary>Порт, который система помнит между запусками.</summary>
        public static int SavedPort
        {
            get
            {
                string value;
                int number;

                if (LisunEngine.RegistryData != null &&
                    LisunEngine.RegistryData.TryGetValue("ssh_port", out value) &&
                    int.TryParse(value, out number) && number > 0 && number < 65536)
                    return number;

                return DefaultPort;
            }
            set
            {
                if (LisunEngine.RegistryData == null) return;
                if (value < 1 || value > 65535) value = DefaultPort;

                LisunEngine.RegistryData["ssh_port"] = value.ToString(CultureInfo.InvariantCulture);
                LisunEngine.SaveRegistry();
            }
        }

        /// <summary>
        /// Поднимает сервер при загрузке, если это включено. Ошибку сюда не
        /// выносим: загрузка системы не должна падать из-за занятого порта.
        /// </summary>
        public static void StartIfAuto()
        {
            if (!AutoStart || Running) return;

            string message;
            bool started = Start(SavedPort, out message);

            LisunEngine.Log("[ssh] " + (started
                ? LisunLocale.T("ssh.autoStarted", SavedPort)
                : LisunLocale.T("ssh.autoFailed", message.Trim())).Trim());
        }

        public static bool Running
        {
            get { lock (gate) return running; }
        }

        public static int Port
        {
            get { lock (gate) return port; }
        }

        public static long Sessions
        {
            get { lock (gate) return sessions; }
        }

        public static string[] Log
        {
            get { lock (gate) return log.ToArray(); }
        }

        /// <summary>Снимок активных сеансов.</summary>
        public static List<CommandExecutorEngine.RemoteSession> Live
        {
            get { lock (gate) return new List<CommandExecutorEngine.RemoteSession>(live); }
        }

        /// <summary>Таблица подключённых для команды «ssh who».</summary>
        public static string WhoText()
        {
            List<CommandExecutorEngine.RemoteSession> rows = Live;
            if (rows.Count == 0) return LisunLocale.T("ssh.sessionNone");

            StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.sessionHeader", rows.Count));
            sb.AppendLine();

            foreach (CommandExecutorEngine.RemoteSession row in rows)
            {
                TimeSpan online = DateTime.Now - row.Started;

                sb.AppendLine(LisunLocale.T("ssh.sessionRow", row.User, row.Address, row.Commands,
                    (int)online.TotalMinutes + " мин"));
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>Адреса этой машины в сети — их и вводят на телефоне.</summary>
        public static List<string> Addresses()
        {
            // Список берётся из общего места и держится там несколько секунд:
            // окно «Доступ по сети» спрашивает адреса каждые полторы секунды,
            // а опрос всех адаптеров — не бесплатная операция.
            List<string> result = new List<string>();

            try { result.AddRange(LisunNetwork.Addresses()); }
            catch { }

            if (result.Count == 0) result.Add("127.0.0.1");
            return result;
        }

        // =====================================================================
        //  Запуск и остановка
        // =====================================================================

        public static bool Start(int wantedPort, out string message)
        {
            lock (gate)
            {
                if (running)
                {
                    message = LisunLocale.T("ssh.already", port);
                    return true;
                }
            }

            if (LisunUsers.Count == 0)
            {
                message = LisunLocale.T("ssh.noUsers");
                return false;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Listen))
            {
                message = LisunLocale.T("ssh.needListen");
                return false;
            }

            if (wantedPort < 1 || wantedPort > 65535) wantedPort = DefaultPort;

            try
            {
                TcpListener created = new TcpListener(IPAddress.Any, wantedPort);
                created.Start();

                lock (gate)
                {
                    listener = created;
                    running = true;
                    port = wantedPort;
                    startedAt = DateTime.Now;
                }

                worker = new Thread(Loop);
                worker.IsBackground = true;
                worker.Name = "LisunSshHost";
                worker.Start();

                Note(LisunLocale.T("ssh.started", wantedPort));

                StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.startedFull", wantedPort));
                sb.AppendLine();

                foreach (string address in Addresses())
                    sb.AppendLine("   nc " + address + " " + wantedPort + "        telnet " + address + " " + wantedPort);

                message = sb.ToString().TrimEnd();
                return true;
            }
            catch (SocketException ex)
            {
                lock (gate) { running = false; listener = null; }

                message = LisunLocale.T("ssh.portBusy", wantedPort, ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                lock (gate) { running = false; listener = null; }

                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        public static void Stop()
        {
            TcpListener current;

            lock (gate)
            {
                if (!running) return;

                running = false;
                current = listener;
                listener = null;
            }

            try { if (current != null) current.Stop(); }
            catch { }

            Note(LisunLocale.T("ssh.stopped"));
        }

        private static void Loop()
        {
            while (true)
            {
                TcpListener current;
                lock (gate)
                {
                    if (!running) return;
                    current = listener;
                }

                if (current == null) return;

                try
                {
                    TcpClient client = current.AcceptTcpClient();

                    ThreadPool.QueueUserWorkItem(ignored =>
                    {
                        try { Serve(client); }
                        catch { }
                        finally { try { client.Close(); } catch { } }
                    });
                }
                catch (SocketException) { return; }
                catch (ObjectDisposedException) { return; }
                catch (Exception ex)
                {
                    Note("[ERROR] " + ex.Message);
                }
            }
        }

        // =====================================================================
        //  Сессия
        // =====================================================================

        private static void Serve(TcpClient client)
        {
            client.ReceiveTimeout = 600000;
            client.SendTimeout = 30000;

            string address = "?";
            try { address = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); }
            catch { }

            using (NetworkStream stream = client.GetStream())
            {
                // Настоящий клиент ssh здоровается первым строкой «SSH-2.0-…».
                // По ней и различаем: протокол SSH-2 или простой текст, как
                // в PuTTY режима Raw. Порт при этом остаётся один.
                string greeting = PeekGreeting(stream);

                if (greeting != null && greeting.StartsWith("SSH-", StringComparison.Ordinal))
                {
                    ServeSsh2(client, stream, greeting, address);
                    return;
                }

                carried = greeting;

                Send(stream, "LisunOS " + LisunEngine.Version + " \"" + LisunEngine.Codename + "\"\r\n");
                Send(stream, LisunLocale.T("ssh.greeting") + "\r\n\r\n");

                Send(stream, LisunLocale.T("ssh.askUser") + ": ");
                string user = ReadLine(stream);

                Send(stream, LisunLocale.T("ssh.askPassword") + ": ");
                string password = ReadLine(stream);

                if (user == null || password == null) return;

                if (!LisunUsers.Check(user, password))
                {
                    lock (gate) rejected++;

                    Send(stream, "\r\n" + LisunLocale.T("ssh.denied") + "\r\n");
                    Note(LisunLocale.T("ssh.rejectedFrom", address, user ?? "?"));
                    return;
                }

                // Сеанс со своей текущей папкой: cd одного клиента не уводит
                // ни терминал, ни остальных подключённых.
                CommandExecutorEngine.RemoteSession session = new CommandExecutorEngine.RemoteSession();
                session.User = user;
                session.Address = address;
                session.Directory = LisunEngine.RootPath;

                lock (gate)
                {
                    if (live.Count >= MaxSessions)
                    {
                        Send(stream, "\r\n" + LisunLocale.T("ssh.tooMany") + "\r\n");
                        return;
                    }

                    sessions++;
                    live.Add(session);
                }

                LisunUsers.NoteLogin(user);
                Note(LisunLocale.T("ssh.connected", user, address));

                Send(stream, "\r\n" + LisunLocale.T("ssh.welcome", user) + "\r\n");
                Send(stream, LisunLocale.T("ssh.hint") + "\r\n\r\n");

                string previous = string.Empty;

                try
                {
                    while (true)
                    {
                        Send(stream, "LisunOS " + session.User + ":" +
                                     CommandExecutorEngine.RemotePrompt(session) + "> ");

                        string line = ReadLine(stream);
                        if (line == null) break;

                        line = line.Trim();
                        if (line.Length == 0) continue;

                        if (line.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("logout", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("quit", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, LisunLocale.T("ssh.bye") + "\r\n");
                            break;
                        }

                        // Экран чистит клиент: ядро про его размер ничего не знает.
                        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("cls", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, "\u001b[2J\u001b[H");
                            continue;
                        }

                        // Повтор прошлой команды — набирать длинную строку заново
                        // в телефонном клиенте особенно неудобно.
                        if (line == "!!")
                        {
                            if (previous.Length == 0)
                            {
                                Send(stream, LisunLocale.T("ssh.noHistory") + "\r\n");
                                continue;
                            }

                            line = previous;
                            Send(stream, line + "\r\n");
                        }

                        if (line.Equals("?", StringComparison.Ordinal) ||
                            line.Equals("ssh help", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, LisunLocale.T("ssh.helpTitle") + "\r\n" +
                                         LisunLocale.T("ssh.helpBody") + "\r\n");
                            continue;
                        }

                        previous = line;

                        // Команды выполняет то же ядро, что и терминал, поэтому
                        // доступны и встроенные, и добавленные приложениями.
                        string answer = RunOnUi(session, line);

                        Send(stream, (answer ?? string.Empty).Replace("\r\n", "\n").Replace("\n", "\r\n"));
                        Send(stream, "\r\n");
                    }
                }
                finally
                {
                    lock (gate) live.Remove(session);
                }

                Note(LisunLocale.T("ssh.disconnected", user, address));
            }
        }

        /// <summary>
        /// Читает первые байты, пока не станет понятно, кто пришёл.
        /// Клиент ssh шлёт строку версии сразу; у простого клиента (telnet,
        /// PuTTY Raw) в начале тишина — он ждёт приглашения от нас.
        /// </summary>
        private static string PeekGreeting(NetworkStream stream)
        {
            int saved = -1;
            try { saved = stream.ReadTimeout; }
            catch { }

            try
            {
                stream.ReadTimeout = 1200;

                StringBuilder sb = new StringBuilder();
                while (sb.Length < 255)
                {
                    int value = stream.ReadByte();
                    if (value < 0) break;

                    sb.Append((char)value);

                    if (value == 10) break;

                    // Четырёх байт достаточно: либо это «SSH-», либо нет.
                    if (sb.Length == 4 && sb.ToString() != "SSH-") return sb.ToString();
                }

                return sb.Length == 0 ? null : sb.ToString();
            }
            catch (IOException)
            {
                // Молчание означает простого клиента: он ждёт приглашения.
                return null;
            }
            finally
            {
                try { if (saved > 0) stream.ReadTimeout = saved; else stream.ReadTimeout = Timeout.Infinite; }
                catch { }
            }
        }

        /// <summary>Сеанс по настоящему SSH-2.</summary>
        private static void ServeSsh2(TcpClient client, NetworkStream stream, string greeting, string address)
        {
            CommandExecutorEngine.RemoteSession session = new CommandExecutorEngine.RemoteSession();
            session.Address = address;
            session.Directory = LisunEngine.RootPath;

            bool counted = false;

            using (SshTransport transport = new SshTransport(stream))
            {
                try
                {
                    string clientVersion = transport.ExchangeVersions(greeting);
                    Note(LisunLocale.T("ssh.clientIs", clientVersion, address));

                    transport.Handshake(clientVersion);

                    SshSession ssh = new SshSession(transport, session,
                        delegate (string user, string password)
                        {
                            if (!LisunUsers.Check(user, password))
                            {
                                lock (gate) rejected++;
                                Note(LisunLocale.T("ssh.rejectedFrom", address, user ?? "?"));
                                return false;
                            }

                            return true;
                        },
                        RunOnUi,
                        Note);

                    if (!ssh.Authenticate()) return;

                    lock (gate)
                    {
                        if (live.Count >= MaxSessions) return;

                        sessions++;
                        live.Add(session);
                        counted = true;
                    }

                    LisunUsers.NoteLogin(session.User);
                    Note(LisunLocale.T("ssh.connected", session.User, address));

                    ssh.Serve();
                }
                catch (Exception ex)
                {
                    Note(LisunLocale.T("ssh.sessionFailed", address, ex.Message));
                }
                finally
                {
                    if (counted) { lock (gate) live.Remove(session); }
                    if (session.User != null) Note(LisunLocale.T("ssh.disconnected", session.User, address));
                }
            }
        }

        /// <summary>Исполнитель работает с формами, поэтому команда идёт в UI-поток.</summary>
        private static string RunOnUi(CommandExecutorEngine.RemoteSession session, string command)
        {
            string result = string.Empty;
            ManualResetEvent done = new ManualResetEvent(false);

            LisunEngine.RunOnUi(() =>
            {
                try { result = CommandExecutorEngine.ExecuteRemote(session, command); }
                catch (Exception ex) { result = " [ERROR] " + ex.Message; }
                finally { done.Set(); }
            });

            // Если UI занят, лучше честно ответить, чем держать соединение.
            if (!done.WaitOne(30000)) return LisunLocale.T("ssh.busy");

            return result;
        }

        private static void Send(NetworkStream stream, string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text ?? string.Empty);

            stream.Write(bytes, 0, bytes.Length);
            stream.Flush();
        }

        /// <summary>
        /// То, что уже прочитано при опознании протокола. Простой клиент мог
        /// успеть отправить первые символы — потерять их нельзя.
        /// </summary>
        [ThreadStatic]
        private static string carried;

        private static string ReadLine(NetworkStream stream)
        {
            StringBuilder sb = new StringBuilder();
            List<byte> buffer = new List<byte>();

            if (!string.IsNullOrEmpty(carried))
            {
                string head = carried;
                carried = null;

                foreach (char symbol in head)
                {
                    if (symbol == '\n') return Decode(buffer);
                    if (symbol == '\r') continue;

                    buffer.Add((byte)symbol);
                }
            }

            while (true)
            {
                int symbol;
                try { symbol = stream.ReadByte(); }
                catch { return null; }

                if (symbol < 0) return buffer.Count == 0 && sb.Length == 0 ? null : Decode(buffer);

                if (symbol == '\n') return Decode(buffer);
                if (symbol == '\r') continue;

                // telnet шлёт служебные последовательности, начинающиеся с 255.
                if (symbol == 255)
                {
                    try { stream.ReadByte(); stream.ReadByte(); }
                    catch { }
                    continue;
                }

                // Backspace с телефона и из telnet.
                if (symbol == 8 || symbol == 127)
                {
                    if (buffer.Count > 0) buffer.RemoveAt(buffer.Count - 1);
                    continue;
                }

                if (buffer.Count > 4096) return Decode(buffer);

                buffer.Add((byte)symbol);
            }
        }

        private static string Decode(List<byte> buffer)
        {
            try { return Encoding.UTF8.GetString(buffer.ToArray()); }
            catch { return string.Empty; }
        }

        private static void Note(string text)
        {
            lock (gate)
            {
                log.Add(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "  " + (text ?? string.Empty).Trim());
                while (log.Count > 200) log.RemoveAt(0);
            }

            LisunEngine.RunOnUi(() => LisunEngine.Log("[ssh] " + (text ?? string.Empty).Trim()));
        }

        // =====================================================================
        //  Вывод
        // =====================================================================

        public static string StatusText()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.statusTitle") + Environment.NewLine);

            sb.AppendLine("   " + LisunLocale.T("ssh.fieldState") + ": " +
                          LisunLocale.T(Running ? "sys.open" : "sys.closed"));
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldPort") + ": " + Port);
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldUsers") + ": " + LisunUsers.Count);
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldSessions") + ": " + Sessions);

            if (Running)
            {
                sb.AppendLine("   " + LisunLocale.T("ssh.fieldUptime") + ": " +
                              ((int)(DateTime.Now - startedAt).TotalMinutes) + " " + LisunLocale.T("ssh.minutes"));
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ssh.howTo"));

            foreach (string address in Addresses())
                sb.AppendLine("       ssh " + (LisunUsers.Count > 0 ? LisunUsers.Names()[0] : "<пользователь>") +
                              "@" + address + " -p " + Port);

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ssh.alsoPlain"));

            foreach (string address in Addresses())
                sb.AppendLine("       nc " + address + " " + Port + "        telnet " + address + " " + Port);

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ssh.fingerprint") + ": " + SshHostKey.Fingerprint());

            return sb.ToString().TrimEnd();
        }
    }
}
