﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace LisunOS
{
    /// <summary>
    /// Удалённый вход в LisunOS с компьютера или телефона.
    ///
    /// ВАЖНО о протоколе: это НЕ протокол SSH-2 с обменом ключами и
    /// шифрованием. Это текстовый shell поверх TCP: сервер спрашивает
    /// имя и пароль, дальше принимает команды построчно и отвечает
    /// их выводом. Подключаться нужно клиентом, который умеет чистый
    /// TCP или telnet:
    ///
    ///     PuTTY        — тип подключения Raw или Telnet, порт 2222
    ///     Windows      — telnet 192.168.0.5 2222
    ///     Android      — Termux: nc 192.168.0.5 2222
    ///     Linux, mac   — nc 192.168.0.5 2222
    ///
    /// Обычный клиент ssh сюда не подключится: он ждёт рукопожатия SSH-2.
    /// Трафик идёт открытым текстом, поэтому порт имеет смысл открывать
    /// только в своей сети.
    /// </summary>
    public static class SshHost
    {
        public const int DefaultPort = 2222;
        public const string PackageName = "sshd";

        private static readonly object gate = new object();

        private static TcpListener listener;
        private static Thread worker;
        private static bool running;
        private static int port = DefaultPort;
        private static DateTime startedAt;
        private static long sessions;
        private static long rejected;

        private static readonly List<string> log = new List<string>();

        /// <summary>Кто сейчас в сети. Нужен для команды «ssh who» и для предела подключений.</summary>
        private static readonly List<CommandExecutorEngine.RemoteSession> live =
            new List<CommandExecutorEngine.RemoteSession>();

        /// <summary>Больше восьми одновременных клиентов — уже не рабочий сценарий, а нагрузка.</summary>
        public const int MaxSessions = 8;

        public static bool Running
        {
            get { lock (gate) return running; }
        }

        public static int Port
        {
            get { lock (gate) return port; }
        }

        public static long Sessions
        {
            get { lock (gate) return sessions; }
        }

        public static string[] Log
        {
            get { lock (gate) return log.ToArray(); }
        }

        /// <summary>Снимок активных сеансов.</summary>
        public static List<CommandExecutorEngine.RemoteSession> Live
        {
            get { lock (gate) return new List<CommandExecutorEngine.RemoteSession>(live); }
        }

        /// <summary>Таблица подключённых для команды «ssh who».</summary>
        public static string WhoText()
        {
            List<CommandExecutorEngine.RemoteSession> rows = Live;
            if (rows.Count == 0) return LisunLocale.T("ssh.sessionNone");

            StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.sessionHeader", rows.Count));
            sb.AppendLine();

            foreach (CommandExecutorEngine.RemoteSession row in rows)
            {
                TimeSpan online = DateTime.Now - row.Started;

                sb.AppendLine(LisunLocale.T("ssh.sessionRow", row.User, row.Address, row.Commands,
                    (int)online.TotalMinutes + " мин"));
            }

            return sb.ToString().TrimEnd();
        }

        /// <summary>Адреса этой машины в сети — их и вводят на телефоне.</summary>
        public static List<string> Addresses()
        {
            List<string> result = new List<string>();

            try
            {
                foreach (NetworkInterface adapter in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (adapter.OperationalStatus != OperationalStatus.Up) continue;
                    if (adapter.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                    foreach (UnicastIPAddressInformation address in adapter.GetIPProperties().UnicastAddresses)
                    {
                        if (address.Address.AddressFamily != AddressFamily.InterNetwork) continue;

                        string text = address.Address.ToString();
                        if (!result.Contains(text)) result.Add(text);
                    }
                }
            }
            catch { }

            if (result.Count == 0) result.Add("127.0.0.1");
            return result;
        }

        // =====================================================================
        //  Запуск и остановка
        // =====================================================================

        public static bool Start(int wantedPort, out string message)
        {
            lock (gate)
            {
                if (running)
                {
                    message = LisunLocale.T("ssh.already", port);
                    return true;
                }
            }

            if (LisunUsers.Count == 0)
            {
                message = LisunLocale.T("ssh.noUsers");
                return false;
            }

            if (!LisunPermissions.Demand(PackageName, LisunPermissions.Listen))
            {
                message = LisunLocale.T("ssh.needListen");
                return false;
            }

            if (wantedPort < 1 || wantedPort > 65535) wantedPort = DefaultPort;

            try
            {
                TcpListener created = new TcpListener(IPAddress.Any, wantedPort);
                created.Start();

                lock (gate)
                {
                    listener = created;
                    running = true;
                    port = wantedPort;
                    startedAt = DateTime.Now;
                }

                worker = new Thread(Loop);
                worker.IsBackground = true;
                worker.Name = "LisunSshHost";
                worker.Start();

                Note(LisunLocale.T("ssh.started", wantedPort));

                StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.startedFull", wantedPort));
                sb.AppendLine();

                foreach (string address in Addresses())
                    sb.AppendLine("   nc " + address + " " + wantedPort + "        telnet " + address + " " + wantedPort);

                message = sb.ToString().TrimEnd();
                return true;
            }
            catch (SocketException ex)
            {
                lock (gate) { running = false; listener = null; }

                message = LisunLocale.T("ssh.portBusy", wantedPort, ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                lock (gate) { running = false; listener = null; }

                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        public static void Stop()
        {
            TcpListener current;

            lock (gate)
            {
                if (!running) return;

                running = false;
                current = listener;
                listener = null;
            }

            try { if (current != null) current.Stop(); }
            catch { }

            Note(LisunLocale.T("ssh.stopped"));
        }

        private static void Loop()
        {
            while (true)
            {
                TcpListener current;
                lock (gate)
                {
                    if (!running) return;
                    current = listener;
                }

                if (current == null) return;

                try
                {
                    TcpClient client = current.AcceptTcpClient();

                    ThreadPool.QueueUserWorkItem(ignored =>
                    {
                        try { Serve(client); }
                        catch { }
                        finally { try { client.Close(); } catch { } }
                    });
                }
                catch (SocketException) { return; }
                catch (ObjectDisposedException) { return; }
                catch (Exception ex)
                {
                    Note("[ERROR] " + ex.Message);
                }
            }
        }

        // =====================================================================
        //  Сессия
        // =====================================================================

        private static void Serve(TcpClient client)
        {
            client.ReceiveTimeout = 600000;
            client.SendTimeout = 30000;

            string address = "?";
            try { address = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString(); }
            catch { }

            using (NetworkStream stream = client.GetStream())
            {
                Send(stream, "LisunOS " + LisunEngine.Version + " \"" + LisunEngine.Codename + "\"\r\n");
                Send(stream, LisunLocale.T("ssh.greeting") + "\r\n\r\n");

                Send(stream, LisunLocale.T("ssh.askUser") + ": ");
                string user = ReadLine(stream);

                Send(stream, LisunLocale.T("ssh.askPassword") + ": ");
                string password = ReadLine(stream);

                if (user == null || password == null) return;

                if (!LisunUsers.Check(user, password))
                {
                    lock (gate) rejected++;

                    Send(stream, "\r\n" + LisunLocale.T("ssh.denied") + "\r\n");
                    Note(LisunLocale.T("ssh.rejectedFrom", address, user ?? "?"));
                    return;
                }

                // Сеанс со своей текущей папкой: cd одного клиента не уводит
                // ни терминал, ни остальных подключённых.
                CommandExecutorEngine.RemoteSession session = new CommandExecutorEngine.RemoteSession();
                session.User = user;
                session.Address = address;
                session.Directory = LisunEngine.RootPath;

                lock (gate)
                {
                    if (live.Count >= MaxSessions)
                    {
                        Send(stream, "\r\n" + LisunLocale.T("ssh.tooMany") + "\r\n");
                        return;
                    }

                    sessions++;
                    live.Add(session);
                }

                LisunUsers.NoteLogin(user);
                Note(LisunLocale.T("ssh.connected", user, address));

                Send(stream, "\r\n" + LisunLocale.T("ssh.welcome", user) + "\r\n");
                Send(stream, LisunLocale.T("ssh.hint") + "\r\n\r\n");

                string previous = string.Empty;

                try
                {
                    while (true)
                    {
                        Send(stream, CommandExecutorEngine.RemotePrompt(session) + "> ");

                        string line = ReadLine(stream);
                        if (line == null) break;

                        line = line.Trim();
                        if (line.Length == 0) continue;

                        if (line.Equals("exit", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("logout", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("quit", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, LisunLocale.T("ssh.bye") + "\r\n");
                            break;
                        }

                        // Экран чистит клиент: ядро про его размер ничего не знает.
                        if (line.Equals("clear", StringComparison.OrdinalIgnoreCase) ||
                            line.Equals("cls", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, "\u001b[2J\u001b[H");
                            continue;
                        }

                        // Повтор прошлой команды — набирать длинную строку заново
                        // в телефонном клиенте особенно неудобно.
                        if (line == "!!")
                        {
                            if (previous.Length == 0)
                            {
                                Send(stream, LisunLocale.T("ssh.noHistory") + "\r\n");
                                continue;
                            }

                            line = previous;
                            Send(stream, line + "\r\n");
                        }

                        if (line.Equals("?", StringComparison.Ordinal) ||
                            line.Equals("ssh help", StringComparison.OrdinalIgnoreCase))
                        {
                            Send(stream, LisunLocale.T("ssh.helpTitle") + "\r\n" +
                                         LisunLocale.T("ssh.helpBody") + "\r\n");
                            continue;
                        }

                        previous = line;

                        // Команды выполняет то же ядро, что и терминал, поэтому
                        // доступны и встроенные, и добавленные приложениями.
                        string answer = RunOnUi(session, line);

                        Send(stream, (answer ?? string.Empty).Replace("\r\n", "\n").Replace("\n", "\r\n"));
                        Send(stream, "\r\n");
                    }
                }
                finally
                {
                    lock (gate) live.Remove(session);
                }

                Note(LisunLocale.T("ssh.disconnected", user, address));
            }
        }

        /// <summary>Исполнитель работает с формами, поэтому команда идёт в UI-поток.</summary>
        private static string RunOnUi(CommandExecutorEngine.RemoteSession session, string command)
        {
            string result = string.Empty;
            ManualResetEvent done = new ManualResetEvent(false);

            LisunEngine.RunOnUi(() =>
            {
                try { result = CommandExecutorEngine.ExecuteRemote(session, command); }
                catch (Exception ex) { result = " [ERROR] " + ex.Message; }
                finally { done.Set(); }
            });

            // Если UI занят, лучше честно ответить, чем держать соединение.
            if (!done.WaitOne(30000)) return LisunLocale.T("ssh.busy");

            return result;
        }

        private static void Send(NetworkStream stream, string text)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(text ?? string.Empty);

            stream.Write(bytes, 0, bytes.Length);
            stream.Flush();
        }

        private static string ReadLine(NetworkStream stream)
        {
            StringBuilder sb = new StringBuilder();
            List<byte> buffer = new List<byte>();

            while (true)
            {
                int symbol;
                try { symbol = stream.ReadByte(); }
                catch { return null; }

                if (symbol < 0) return buffer.Count == 0 && sb.Length == 0 ? null : Decode(buffer);

                if (symbol == '\n') return Decode(buffer);
                if (symbol == '\r') continue;

                // telnet шлёт служебные последовательности, начинающиеся с 255.
                if (symbol == 255)
                {
                    try { stream.ReadByte(); stream.ReadByte(); }
                    catch { }
                    continue;
                }

                // Backspace с телефона и из telnet.
                if (symbol == 8 || symbol == 127)
                {
                    if (buffer.Count > 0) buffer.RemoveAt(buffer.Count - 1);
                    continue;
                }

                if (buffer.Count > 4096) return Decode(buffer);

                buffer.Add((byte)symbol);
            }
        }

        private static string Decode(List<byte> buffer)
        {
            try { return Encoding.UTF8.GetString(buffer.ToArray()); }
            catch { return string.Empty; }
        }

        private static void Note(string text)
        {
            lock (gate)
            {
                log.Add(DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture) + "  " + (text ?? string.Empty).Trim());
                while (log.Count > 200) log.RemoveAt(0);
            }

            LisunEngine.RunOnUi(() => LisunEngine.Log("[ssh] " + (text ?? string.Empty).Trim()));
        }

        // =====================================================================
        //  Вывод
        // =====================================================================

        public static string StatusText()
        {
            StringBuilder sb = new StringBuilder(LisunLocale.T("ssh.statusTitle") + Environment.NewLine);

            sb.AppendLine("   " + LisunLocale.T("ssh.fieldState") + ": " +
                          LisunLocale.T(Running ? "sys.open" : "sys.closed"));
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldPort") + ": " + Port);
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldUsers") + ": " + LisunUsers.Count);
            sb.AppendLine("   " + LisunLocale.T("ssh.fieldSessions") + ": " + Sessions);

            if (Running)
            {
                sb.AppendLine("   " + LisunLocale.T("ssh.fieldUptime") + ": " +
                              ((int)(DateTime.Now - startedAt).TotalMinutes) + " " + LisunLocale.T("ssh.minutes"));
            }

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ssh.howTo"));

            foreach (string address in Addresses())
                sb.AppendLine("       nc " + address + " " + Port + "        telnet " + address + " " + Port);

            sb.AppendLine();
            sb.AppendLine("   " + LisunLocale.T("ssh.protocolNote"));

            return sb.ToString().TrimEnd();
        }
    }
}
