﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace LisunOS
{
    /// <summary>
    /// Системный модуль php-frm: подключение PHP к серверу LisunOS.
    /// Устанавливается командой «apt install php-frm» — находит интерпретатор,
    /// включает блок location ~ \.php$ в .htaccess и создаёт api.php.
    /// </summary>
    public static class LisunPhpModule
    {
        public const string PackageName = "php-frm";

        /// <summary>Свой PHP живёт внутри LisunOS: /os/sys/php/</summary>
        public static string OwnDirectory
        {
            get { return Path.Combine(LisunEngine.RootPath, "sys", "php"); }
        }

        /// <summary>Адрес сборки PHP для Windows; можно переопределить ключом php_download_url.</summary>
        public static string DownloadUrl
        {
            get
            {
                string value;
                if (LisunEngine.RegistryData.TryGetValue("php_download_url", out value) && value.Length > 10)
                    return value;

                return DefaultMirrors[0];
            }
        }

        /// <summary>
        /// Зеркала сборок PHP для Windows. Перебираются по порядку: первое
        /// рабочее и скачивается. Разные ветки и компиляторы — чтобы загрузка
        /// не ломалась, когда очередная сборка снимается с публикации.
        /// </summary>
        public static readonly string[] DefaultMirrors =
        {
            "https://windows.php.net/downloads/releases/latest/php-8.3-nts-Win32-vs16-x64-latest.zip",
            "https://windows.php.net/downloads/releases/latest/php-8.2-nts-Win32-vs16-x64-latest.zip",
            "https://windows.php.net/downloads/releases/latest/php-8.4-nts-Win32-vs17-x64-latest.zip",
            "https://windows.php.net/downloads/releases/archives/php-8.3.13-nts-Win32-vs16-x64.zip",
            "https://windows.php.net/downloads/releases/latest/php-8.3-nts-Win32-vs16-x86-latest.zip"
        };

        /// <summary>Список адресов для загрузки: сначала свой из реестра, затем зеркала.</summary>
        public static string[] Mirrors
        {
            get
            {
                List<string> list = new List<string>();

                string custom;
                if (LisunEngine.RegistryData.TryGetValue("php_download_url", out custom) && custom.Length > 10)
                {
                    foreach (string part in custom.Split(new[] { ' ', ',', ';' }, StringSplitOptions.RemoveEmptyEntries))
                        if (part.Length > 10 && !list.Contains(part)) list.Add(part);
                }

                foreach (string mirror in DefaultMirrors)
                    if (!list.Contains(mirror)) list.Add(mirror);

                return list.ToArray();
            }
        }

        /// <summary>
        /// Автозагрузка PHP включена по умолчанию: ключ php_autodownload = false
        /// её выключает, и тогда работает только встроенный движок.
        /// </summary>
        public static bool AutoDownloadEnabled
        {
            get
            {
                string value;
                if (!LisunEngine.RegistryData.TryGetValue("php_autodownload", out value)) return true;

                return !(value.Equals("false", StringComparison.OrdinalIgnoreCase) ||
                         value.Equals("0", StringComparison.Ordinal) ||
                         value.Equals("off", StringComparison.OrdinalIgnoreCase));
            }
        }

        private static readonly object downloadGate = new object();
        private static bool downloading;
        private static int downloadPercent;
        private static long downloadBytes;
        private static long downloadTotal;
        private static string downloadStage = string.Empty;
        private static readonly List<string> downloadLog = new List<string>();

        /// <summary>Идёт ли загрузка PHP прямо сейчас.</summary>
        public static bool Downloading
        {
            get { lock (downloadGate) return downloading; }
        }

        /// <summary>Процент загрузки, 0..100. При неизвестном размере остаётся 0.</summary>
        public static int DownloadPercent
        {
            get { lock (downloadGate) return downloadPercent; }
        }

        /// <summary>Сколько байт получено и сколько всего ожидается.</summary>
        public static void DownloadBytes(out long received, out long total)
        {
            lock (downloadGate) { received = downloadBytes; total = downloadTotal; }
        }

        /// <summary>Текущий этап: загрузка, распаковка, готово, ошибка.</summary>
        public static string DownloadStage
        {
            get { lock (downloadGate) return downloadStage; }
        }

        /// <summary>Журнал загрузки для прямого эфира на странице php-frm.html.</summary>
        public static string[] DownloadLog
        {
            get { lock (downloadGate) return downloadLog.ToArray(); }
        }

        /// <summary>Строка состояния загрузки для панели сервера и команды php-frm.</summary>
        public static string DownloadStatus
        {
            get
            {
                lock (downloadGate)
                {
                    if (!downloading) return downloadStage;

                    string size = downloadTotal > 0
                        ? CustomFormUtils.FormatSize(downloadBytes) + " / " + CustomFormUtils.FormatSize(downloadTotal)
                        : CustomFormUtils.FormatSize(downloadBytes);

                    return downloadTotal > 0
                        ? LisunLocale.T("php.progress", downloadPercent, size)
                        : LisunLocale.T("php.progressUnknown", size);
                }
            }
        }

        /// <summary>Строка в журнал загрузки и в терминал. Безопасно из любого потока.</summary>
        private static void Report(string message)
        {
            lock (downloadGate)
            {
                downloadLog.Add(DateTime.Now.ToString("HH:mm:ss") + "  " + message);
                while (downloadLog.Count > 200) downloadLog.RemoveAt(0);
            }

            LisunEngine.RunOnUi(() => LisunEngine.Log("[php-frm] " + message));
        }

        private static readonly string[] Executables = { "php-cgi.exe", "php.exe" };

        private static readonly string[] SearchRoots =
        {
            @"C:\php", @"C:\PHP", @"C:\xampp\php", @"C:\wamp64\bin\php",
            @"C:\wamp\bin\php", @"C:\laragon\bin\php", @"C:\tools\php",
            @"C:\Program Files\php", @"C:\Program Files (x86)\php",
            @"C:\ProgramData\chocolatey\lib\php\tools"
        };

        // =====================================================================
        //  Поиск интерпретатора
        // =====================================================================

        /// <summary>PHP внутри LisunOS — он имеет приоритет над системным.</summary>
        public static string FindOwnPhp()
        {
            return SearchInDirectory(OwnDirectory);
        }

        public static bool OwnPhpInstalled
        {
            get { return FindOwnPhp() != null; }
        }

        /// <summary>Путь к php-cgi.exe или php.exe, либо null. Сначала свой, затем системный.</summary>
        public static string FindPhp()
        {
            string own = FindOwnPhp();
            if (own != null) return own;

            string saved;
            if (LisunEngine.RegistryData.TryGetValue("php_path", out saved) &&
                !string.IsNullOrEmpty(saved) && File.Exists(saved)) return saved;

            foreach (string name in Executables)
            {
                string found = SearchInPath(name);
                if (found != null) return found;
            }

            foreach (string root in SearchRoots)
            {
                string found = SearchInDirectory(root);
                if (found != null) return found;
            }

            return null;
        }

        private static string SearchInDirectory(string root)
        {
            try
            {
                if (!Directory.Exists(root)) return null;

                foreach (string name in Executables)
                {
                    string direct = Path.Combine(root, name);
                    if (File.Exists(direct)) return direct;
                }

                // wamp и laragon держат версии во вложенных каталогах
                foreach (string sub in Directory.GetDirectories(root))
                {
                    foreach (string name in Executables)
                    {
                        string nested = Path.Combine(sub, name);
                        if (File.Exists(nested)) return nested;
                    }
                }
            }
            catch { }

            return null;
        }

        public static string SearchInPath(string fileName)
        {
            try
            {
                string pathVariable = Environment.GetEnvironmentVariable("PATH");
                if (string.IsNullOrEmpty(pathVariable)) return null;

                foreach (string directory in pathVariable.Split(Path.PathSeparator))
                {
                    if (directory.Trim().Length == 0) continue;

                    try
                    {
                        string candidate = Path.Combine(directory.Trim(), fileName);
                        if (File.Exists(candidate)) return candidate;
                    }
                    catch { }
                }
            }
            catch { }

            return null;
        }

        public static bool IsInstalled
        {
            get
            {
                string value;
                return LisunEngine.RegistryData.TryGetValue("php_enabled", out value) &&
                       value.Equals("true", StringComparison.OrdinalIgnoreCase);
            }
        }

        public static bool IsOwn(string executable)
        {
            if (string.IsNullOrEmpty(executable)) return false;

            try
            {
                return Path.GetFullPath(executable).StartsWith(
                    Path.GetFullPath(OwnDirectory), StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public static string WwwRoot()
        {
            string saved;
            if (LisunEngine.RegistryData.TryGetValue("server_root", out saved) && !string.IsNullOrEmpty(saved))
            {
                if (saved.StartsWith("LisunOS:", StringComparison.OrdinalIgnoreCase))
                {
                    string tail = saved.Substring(8).TrimStart('\\', '/');
                    return Path.Combine(LisunEngine.RootPath, tail);
                }

                string resolved;
                if (CustomFormUtils.TryResolveInsideRoot(LisunEngine.RootPath, saved, out resolved)) return resolved;
            }

            return Path.Combine(LisunEngine.RootPath, "root", "www");
        }

        // =====================================================================
        //  Установка
        // =====================================================================

        /// <summary>
        /// apt install php-frm [архив.zip | папка с PHP | путь к php-cgi.exe]
        /// Порядок: аргумент → свой PHP в /sys/php → загрузка с windows.php.net → системный.
        /// </summary>
        public static bool Install(string argument, out string message)
        {
            string executable = null;
            StringBuilder report = new StringBuilder();

            if (!string.IsNullOrEmpty(argument))
            {
                argument = argument.Trim().Trim('"');

                if (Directory.Exists(argument))
                {
                    executable = ImportFromFolder(argument, report);
                }
                else if (File.Exists(argument))
                {
                    if (argument.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                        executable = ImportFromZip(argument, report);
                    else
                        executable = argument;   // прямой путь к php-cgi.exe
                }
                else
                {
                    message = LisunLocale.T("php.badArgument", argument);
                    return false;
                }
            }

            // Порядок поиска: аргумент → свой PHP в /os/sys/php → системный.
            if (executable == null) executable = FindOwnPhp();
            if (executable == null) executable = FindPhp();

            // Нет ни своего, ни системного — сайт поднимается на встроенном
            // движке сразу, а сборка PHP докачивается в фоне и подключается сама.
            bool startDownload = executable == null && AutoDownloadEnabled;

            string root = WwwRoot();

            try
            {
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);
                LisunServerConfig.EnsureDefaultFile(root);

                if (!EnableInConfig(root, executable))
                {
                    message = LisunLocale.T("php.configFailed");
                    return false;
                }

                LisunApiEndpoint.EnsureFiles(root);
                LisunWebPanel.EnsureFiles(root);

                LisunEngine.RegistryData["php_path"] = executable ?? string.Empty;
                LisunEngine.RegistryData["php_enabled"] = "true";
                LisunEngine.SaveRegistry();

                LisunEngine.Log("[php-frm] PHP подключён: " + (executable ?? "встроенный движок LisunOS"));

                if (report.Length > 0) report.AppendLine();
                report.AppendLine(LisunLocale.T(executable == null ? "php.sourceBuiltIn"
                                                : IsOwn(executable) ? "php.sourceOwn" : "php.sourceSystem"));

                StringBuilder tail = new StringBuilder();
                tail.Append(report.ToString());
                tail.AppendLine(LisunLocale.T("php.installed",
                    executable ?? LisunLocale.T("php.engineName")));
                tail.AppendLine(LisunLocale.T("php.apiReady"));
                tail.AppendLine(LisunLocale.T("php.panelReady",
                    LisunWebPanel.PasswordSet(root) ? LisunLocale.T("php.panelHasPass")
                                                    : LisunLocale.T("php.panelNoPass")));

                if (startDownload && BeginAutoDownload())
                {
                    tail.AppendLine(LisunLocale.T("php.autoQueued"));
                    tail.AppendLine(LisunLocale.T("php.autoWatch", LisunSystemServer.SetupUrl));
                }

                message = tail.ToString().TrimEnd();
                return true;
            }
            catch (Exception ex)
            {
                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        /// <summary>Распаковывает архив PHP в /os/sys/php и возвращает путь к интерпретатору.</summary>
        public static string ImportFromZip(string archivePath, StringBuilder report)
        {
            try
            {
                string target = OwnDirectory;
                if (!Directory.Exists(target)) Directory.CreateDirectory(target);

                LisunEngine.Log("[php-frm] Распаковка " + Path.GetFileName(archivePath) + "...");

                using (ZipArchive archive = ZipFile.OpenRead(archivePath))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        if (entry.Length == 0 && entry.FullName.EndsWith("/")) continue;

                        string destination = Path.Combine(target, entry.FullName.Replace('/', Path.DirectorySeparatorChar));
                        string directory = Path.GetDirectoryName(destination);

                        if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                            Directory.CreateDirectory(directory);

                        entry.ExtractToFile(destination, true);
                    }
                }

                string executable = SearchInDirectory(target);
                if (executable == null)
                {
                    if (report != null) report.AppendLine(LisunLocale.T("php.zipNoBinary"));
                    return null;
                }

                EnsureIni(Path.GetDirectoryName(executable));
                if (report != null) report.AppendLine(LisunLocale.T("php.imported", CustomFormUtils.ToVirtualPath(target)));
                return executable;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[php-frm] [ОШИБКА] Распаковка: " + ex.Message);
                if (report != null) report.AppendLine(" [ERROR] " + ex.Message);
                return null;
            }
        }

        /// <summary>Копирует готовую папку с PHP внутрь LisunOS.</summary>
        public static string ImportFromFolder(string sourceDirectory, StringBuilder report)
        {
            try
            {
                string source = SearchInDirectory(sourceDirectory);
                if (source == null)
                {
                    if (report != null) report.AppendLine(LisunLocale.T("php.folderNoBinary", sourceDirectory));
                    return null;
                }

                string from = Path.GetDirectoryName(source);
                string target = OwnDirectory;
                if (!Directory.Exists(target)) Directory.CreateDirectory(target);

                foreach (string directory in Directory.GetDirectories(from, "*", SearchOption.AllDirectories))
                    Directory.CreateDirectory(directory.Replace(from, target));

                foreach (string file in Directory.GetFiles(from, "*.*", SearchOption.AllDirectories))
                    File.Copy(file, file.Replace(from, target), true);

                string executable = SearchInDirectory(target);
                if (executable == null) return null;

                EnsureIni(Path.GetDirectoryName(executable));
                if (report != null) report.AppendLine(LisunLocale.T("php.imported", CustomFormUtils.ToVirtualPath(target)));
                return executable;
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[php-frm] [ОШИБКА] Копирование: " + ex.Message);
                if (report != null) report.AppendLine(" [ERROR] " + ex.Message);
                return null;
            }
        }

        // =====================================================================
        //  Загрузка PHP: автоматическая, по зеркалам, с прогрессом
        // =====================================================================

        /// <summary>
        /// Запускает автозагрузку PHP в фоне и сразу возвращает управление.
        /// Сайт в это время уже работает на встроенном движке, а внешний PHP
        /// подключается сам, когда архив скачан и распакован.
        /// </summary>
        public static bool BeginAutoDownload()
        {
            lock (downloadGate)
            {
                if (downloading) return false;

                downloading = true;
                downloadPercent = 0;
                downloadBytes = 0;
                downloadTotal = 0;
                downloadStage = LisunLocale.T("php.stageStart");
            }

            Report(LisunLocale.T("php.autoStart"));

            ThreadPool.QueueUserWorkItem(ignored =>
            {
                string executable = null;

                try
                {
                    executable = DownloadAndImport(null);
                }
                catch (Exception ex)
                {
                    Report(LisunLocale.T("php.mirrorFailed", ex.Message));
                }
                finally
                {
                    lock (downloadGate)
                    {
                        downloading = false;
                        downloadPercent = executable != null ? 100 : downloadPercent;
                        downloadStage = executable != null
                            ? LisunLocale.T("php.stageDone")
                            : LisunLocale.T("php.stageFailed");
                    }
                }

                // Подключение правит реестр и .htaccess — только в UI-потоке.
                if (executable != null) LisunEngine.RunOnUi(() => Attach(executable));
                else Report(LisunLocale.T("php.autoFailed"));
            });

            return true;
        }

        /// <summary>Синхронная загрузка — для команды «php-frm download».</summary>
        public static string DownloadNow(StringBuilder report)
        {
            lock (downloadGate)
            {
                if (downloading) return null;

                downloading = true;
                downloadPercent = 0;
                downloadStage = LisunLocale.T("php.stageStart");
            }

            try { return DownloadAndImport(report); }
            finally
            {
                lock (downloadGate)
                {
                    downloading = false;
                    downloadStage = LisunLocale.T("php.stageDone");
                }
            }
        }

        /// <summary>Перебирает зеркала, скачивает первое доступное и распаковывает.</summary>
        private static string DownloadAndImport(StringBuilder report)
        {
            string archive = Path.Combine(LisunEngine.TempPath, "php-frm.zip");
            string[] mirrors = Mirrors;

            for (int index = 0; index < mirrors.Length; index++)
            {
                string url = mirrors[index];

                lock (downloadGate)
                    downloadStage = LisunLocale.T("php.stageMirror", index + 1, mirrors.Length);

                Report(LisunLocale.T("php.tryMirror", index + 1, mirrors.Length, url));

                try
                {
                    long size = DownloadFile(url, archive);

                    if (size < 1024 * 512)
                    {
                        Report(LisunLocale.T("php.tooSmall", CustomFormUtils.FormatSize(size)));
                        continue;
                    }

                    if (!LooksLikeZip(archive))
                    {
                        Report(LisunLocale.T("php.notArchive"));
                        continue;
                    }

                    string done = LisunLocale.T("php.downloaded", CustomFormUtils.FormatSize(size));
                    Report(done);
                    if (report != null) report.AppendLine(done);

                    lock (downloadGate) downloadStage = LisunLocale.T("php.stageUnpack");
                    Report(LisunLocale.T("php.stageUnpack"));

                    string executable = ImportFromZip(archive, report);
                    if (executable != null)
                    {
                        Report(LisunLocale.T("php.imported", CustomFormUtils.ToVirtualPath(
                            Path.GetDirectoryName(executable))));
                        return executable;
                    }

                    Report(LisunLocale.T("php.zipNoBinary").Trim());
                }
                catch (Exception ex)
                {
                    Report(LisunLocale.T("php.mirrorFailed", ex.Message));
                    if (report != null) report.AppendLine(LisunLocale.T("php.mirrorFailed", ex.Message));
                }
                finally
                {
                    try { if (File.Exists(archive)) File.Delete(archive); }
                    catch { }
                }
            }

            Report(LisunLocale.T("php.allMirrorsFailed"));
            if (report != null) report.AppendLine(LisunLocale.T("php.allMirrorsFailed"));
            return null;
        }

        /// <summary>
        /// Качает файл по частям, чтобы знать прогресс: WebClient его не даёт
        /// в синхронном режиме. Возвращает размер полученного файла.
        /// </summary>
        private static long DownloadFile(string url, string destination)
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;
            try { ServicePointManager.SecurityProtocol |= (SecurityProtocolType)3072; }
            catch { }

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.UserAgent = "LisunOS/" + LisunEngine.Version;
            request.Timeout = 30000;
            request.ReadWriteTimeout = 120000;
            request.AllowAutoRedirect = true;

            string directory = Path.GetDirectoryName(destination);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                Directory.CreateDirectory(directory);

            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream input = response.GetResponseStream())
            using (FileStream output = new FileStream(destination, FileMode.Create, FileAccess.Write))
            {
                long total = response.ContentLength;
                lock (downloadGate) { downloadTotal = total; downloadBytes = 0; }

                byte[] buffer = new byte[81920];
                long received = 0;
                int lastReported = -10;
                int read;

                while (input != null && (read = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    output.Write(buffer, 0, read);
                    received += read;

                    int percent = total > 0 ? (int)(received * 100 / total) : 0;

                    lock (downloadGate)
                    {
                        downloadBytes = received;
                        downloadPercent = percent;
                    }

                    // В журнал — каждые 10 %, иначе терминал зальёт строками.
                    if (total > 0 && percent >= lastReported + 10)
                    {
                        lastReported = percent - percent % 10;
                        Report(LisunLocale.T("php.progress", percent,
                            CustomFormUtils.FormatSize(received) + " / " + CustomFormUtils.FormatSize(total)));
                    }
                }

                output.Flush();
                return received;
            }
        }

        /// <summary>Подпись PK — иначе вместо архива пришла страница с ошибкой.</summary>
        private static bool LooksLikeZip(string path)
        {
            try
            {
                using (FileStream stream = File.OpenRead(path))
                {
                    if (stream.Length < 4) return false;

                    return stream.ReadByte() == 0x50 && stream.ReadByte() == 0x4B;
                }
            }
            catch { return false; }
        }

        /// <summary>Подключает найденный интерпретатор к серверу и реестру.</summary>
        public static bool Attach(string executable)
        {
            if (string.IsNullOrEmpty(executable) || !File.Exists(executable)) return false;

            try
            {
                string root = WwwRoot();
                if (!Directory.Exists(root)) Directory.CreateDirectory(root);

                LisunServerConfig.EnsureDefaultFile(root);
                if (!EnableInConfig(root, executable)) return false;

                LisunApiEndpoint.EnsureFiles(root);
                LisunWebPanel.EnsureFiles(root);

                LisunEngine.RegistryData["php_path"] = executable;
                LisunEngine.RegistryData["php_enabled"] = "true";
                LisunEngine.SaveRegistry();

                Report(LisunLocale.T("php.attached", executable));
                return true;
            }
            catch (Exception ex)
            {
                Report("[ERROR] " + ex.Message);
                return false;
            }
        }

        /// <summary>Удаляет скачанный PHP и возвращает систему на встроенный движок.</summary>
        public static bool RemoveOwnPhp(out string message)
        {
            try
            {
                if (!Directory.Exists(OwnDirectory))
                {
                    message = LisunLocale.T("php.ownMissing");
                    return false;
                }

                Directory.Delete(OwnDirectory, true);

                LisunEngine.RegistryData["php_path"] = string.Empty;
                LisunEngine.SaveRegistry();

                string root = WwwRoot();
                if (Directory.Exists(root)) EnableInConfig(root, null);

                message = LisunLocale.T("php.ownRemoved");
                Report(message);
                return true;
            }
            catch (Exception ex)
            {
                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        /// <summary>Создаёт php.ini, пригодный для работы под сервером LisunOS.</summary>
        public static void EnsureIni(string phpDirectory)
        {
            try
            {
                if (string.IsNullOrEmpty(phpDirectory) || !Directory.Exists(phpDirectory)) return;

                string ini = Path.Combine(phpDirectory, "php.ini");
                if (File.Exists(ini)) return;

                StringBuilder sb = new StringBuilder();
                sb.AppendLine("; php.ini для LisunOS (php-frm)");
                sb.AppendLine("cgi.force_redirect = 0");
                sb.AppendLine("cgi.fix_pathinfo = 1");
                sb.AppendLine("short_open_tag = On");
                sb.AppendLine("display_errors = On");
                sb.AppendLine("error_reporting = E_ALL & ~E_DEPRECATED & ~E_NOTICE");
                sb.AppendLine("default_charset = \"UTF-8\"");
                sb.AppendLine("max_execution_time = 30");
                sb.AppendLine("memory_limit = 256M");
                sb.AppendLine("post_max_size = 16M");
                sb.AppendLine("upload_max_filesize = 16M");
                sb.AppendLine("extension_dir = \"ext\"");
                sb.AppendLine("extension = mbstring");
                sb.AppendLine("extension = openssl");
                sb.AppendLine("extension = curl");
                sb.AppendLine("extension = fileinfo");
                sb.AppendLine("extension = gd");
                sb.AppendLine("extension = sqlite3");
                sb.AppendLine("extension = pdo_sqlite");
                sb.AppendLine("extension = zip");

                File.WriteAllText(ini, sb.ToString(), new UTF8Encoding(false));
                LisunEngine.Log("[php-frm] Создан php.ini в " + CustomFormUtils.ToVirtualPath(phpDirectory));
            }
            catch (Exception ex)
            {
                LisunEngine.Log("[php-frm] [ОШИБКА] php.ini: " + ex.Message);
            }
        }

        /// <summary>apt remove php-frm — выключает обработку PHP, файлы сайта не трогает.</summary>
        public static bool Uninstall(out string message)
        {
            string root = WwwRoot();

            try
            {
                DisableInConfig(root);

                LisunEngine.RegistryData["php_enabled"] = "false";
                LisunEngine.SaveRegistry();

                LisunEngine.Log("[php-frm] Обработка PHP выключена.");
                message = LisunLocale.T("php.removed");
                return true;
            }
            catch (Exception ex)
            {
                message = " [ERROR] " + ex.Message;
                return false;
            }
        }

        public static string Status()
        {
            string executable = FindPhp();
            string root = WwwRoot();

            StringBuilder sb = new StringBuilder(LisunLocale.T("php.statusTitle") + Environment.NewLine);
            sb.AppendLine("   " + LisunLocale.T("php.fieldState") + ": " +
                          (IsInstalled ? LisunLocale.T("php.on") : LisunLocale.T("php.off")));
            sb.AppendLine("   " + LisunLocale.T("php.fieldBinary") + ": " +
                          (executable ?? LisunLocale.T("php.engineName")));
            sb.AppendLine("   " + LisunLocale.T("php.fieldSource") + ": " +
                          LisunLocale.T(executable == null ? "php.sourceBuiltInShort"
                                      : IsOwn(executable) ? "php.sourceOwnShort"
                                      : "php.sourceSystemShort"));
            sb.AppendLine("   " + LisunLocale.T("php.fieldAuto") + ": " +
                          LisunLocale.T(AutoDownloadEnabled ? "php.on" : "php.off"));
            sb.AppendLine("   " + LisunLocale.T("php.fieldMirrors") + ": " + Mirrors.Length);
            sb.AppendLine("   " + LisunLocale.T("php.fieldProgress") + ": " +
                          (DownloadStatus.Length == 0 ? "—" : DownloadStatus));
            sb.AppendLine("   " + LisunLocale.T("php.fieldOwnDir") + ": " +
                          CustomFormUtils.ToVirtualPath(OwnDirectory) +
                          (OwnPhpInstalled ? "" : "  (" + LisunLocale.T("php.notInstalledHere") + ")"));
            sb.AppendLine("   " + LisunLocale.T("php.fieldConfig") + ": " +
                          CustomFormUtils.ToVirtualPath(Path.Combine(root, LisunServerConfig.FileName)));
            sb.AppendLine("   " + LisunLocale.T("php.fieldApi") + ": " +
                          (LisunApiEndpoint.ApiFilesPresent(root)
                              ? CustomFormUtils.ToVirtualPath(Path.Combine(root, LisunApiEndpoint.ApiFileName))
                              : "—"));
            return sb.ToString().TrimEnd();
        }

        // =====================================================================
        //  Правка .htaccess
        // =====================================================================

        private static readonly Regex PhpBlock = new Regex(
            @"(?<indent>[ \t]*)location\s+~\s*\\\.php\$\s*\{(?<body>[^}]*)\}",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);

        /// <summary>Включает блок PHP в .htaccess и прописывает путь к интерпретатору.</summary>
        public static bool EnableInConfig(string root, string executable)
        {
            string path = Path.Combine(root, LisunServerConfig.FileName);
            string text = File.Exists(path) ? LisunCrypto.ReadAllText(path) : LisunServerConfig.DefaultContent();

            Match existing = PhpBlock.Match(text);
            string block = BuildBlock(existing.Success ? existing.Groups["indent"].Value : "    ", executable);

            if (existing.Success)
            {
                // Совпадение начинается с отступа, поэтому блок вставляем с ним же.
                text = text.Substring(0, existing.Index) + block +
                       text.Substring(existing.Index + existing.Length);
            }
            else
            {
                // Вставляем блок перед закрывающей скобкой server { }
                int close = text.LastIndexOf('}');
                if (close < 0) text = text.TrimEnd() + Environment.NewLine + block + Environment.NewLine;
                else text = text.Substring(0, close) + block + Environment.NewLine + text.Substring(close);
            }

            return CustomFormUtils.WriteFileText(path, text);
        }

        /// <summary>Убирает блок PHP — файлы .php перестают исполняться.</summary>
        public static bool DisableInConfig(string root)
        {
            string path = Path.Combine(root, LisunServerConfig.FileName);
            if (!File.Exists(path)) return true;

            string text = LisunCrypto.ReadAllText(path);
            Match existing = PhpBlock.Match(text);
            if (!existing.Success) return true;

            text = text.Substring(0, existing.Index) + text.Substring(existing.Index + existing.Length);
            return CustomFormUtils.WriteFileText(path, text);
        }

        private static string BuildBlock(string indent, string executable)
        {
            if (indent == null) indent = "    ";
            string inner = indent + "    ";

            StringBuilder sb = new StringBuilder();
            sb.Append(indent).AppendLine("location ~ \\.php$ {");
            sb.Append(inner).AppendLine("handler        php;");

            // Путь к fastcgi_pass пишется только для внешнего php-cgi.exe.
            // Без него сервер исполняет .php нашим движком (PHPExecuter).
            if (!string.IsNullOrEmpty(executable))
                sb.Append(inner).AppendLine("fastcgi_pass   " + executable + ";");

            sb.Append(inner).AppendLine("timeout        15;");
            sb.Append(inner).AppendLine("add_header     X-Handler php-frm;");
            sb.Append(indent).Append("}");
            return sb.ToString();
        }

        // =====================================================================
        //  Отдача .php без PHP
        // =====================================================================

        private static readonly Regex PhpTags = new Regex(
            @"<\?php.*?(?:\?>|$)|<\?=.*?(?:\?>|$)|<\?.*?(?:\?>|$)",
            RegexOptions.Singleline | RegexOptions.Compiled);

        /// <summary>
        /// Вырезает PHP-код, оставляя HTML. Нужно, когда PHP не подключён:
        /// страница всё равно открывается, разметка работает, код не исполняется
        /// и не показывается посетителю.
        /// </summary>
        public static string StripPhp(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;

            string html = PhpTags.Replace(text, string.Empty);

            // Подчищаем пустые строки, оставшиеся от вырезанных блоков.
            html = Regex.Replace(html, @"(\r?\n){3,}", Environment.NewLine + Environment.NewLine);
            return html.Trim().Length == 0 ? EmptyNotice() : html;
        }

        private static string EmptyNotice()
        {
            return "<!doctype html>" + Environment.NewLine +
                   "<html lang=\"ru\"><head><meta charset=\"utf-8\">" +
                   "<title>PHP выключен</title><style>body{margin:0;min-height:100vh;display:flex;" +
                   "align-items:center;justify-content:center;background:#0d1117;color:#808995;" +
                   "font:16px/1.6 Segoe UI,system-ui,sans-serif;text-align:center}" +
                   "code{color:#58a6ff}</style></head><body><div>" +
                   "<p>В файле нет HTML — только код PHP, а PHP не подключён.</p>" +
                   "<p>Подключить: <code>apt install php-frm</code></p>" +
                   "</div></body></html>";
        }
    }
}
