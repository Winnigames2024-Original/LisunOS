﻿using System;
using System.Windows.Forms;

namespace PythonToExeConverter
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения-конвертера.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Включаем визуальные стили Windows для кнопок и полей
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Запускаем созданную графическую форму выбора файлов
            Application.Run(new Form1());
        }
    }
}
