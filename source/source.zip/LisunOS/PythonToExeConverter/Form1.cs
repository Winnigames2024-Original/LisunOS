﻿using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using CmlLib.Core;
using CmlLib.Core.Auth;
using CmlLib.Core.ProcessBuilder;

namespace AIMinecraftServerBotPlayer
{
    public partial class Form1 : Form
    {
        private string configPath = "config.txt";
        private Process aiServerProcess;

        public string ServerIP { get; set; } = "127.0.0.1";
        public string ServerPort { get; set; } = "25565";
        public string Username { get; set; } = "AI_Bot_Player";
        public string GameVersion { get; set; } = "1.20.1";

        public Form1()
        {
            InitializeComponent();
            LoadConfig();
            StartLocalAIServer(); // Запускаем бесплатный локальный ИИ-сервер
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lblStatus.Text = "Готов к запуску. Перейдите в настройки панели.";
        }

        private void btnOpenAdmin_Click(object sender, EventArgs e)
        {
            AdminForm admin = new AdminForm(this);
            admin.ShowDialog();
        }

        private void StartLocalAIServer()
        {
            try
            {
                string serverPath = Path.Combine(Application.StartupPath, "ai_server");
                if (!Directory.Exists(serverPath)) Directory.CreateDirectory(serverPath);

                aiServerProcess = new Process();

                // --- ВАРИАНТ ДЛЯ JAVASCRIPT (Node.js) ---
                aiServerProcess.StartInfo.FileName = "node.exe";
                aiServerProcess.StartInfo.Arguments = $"\"{Path.Combine(serverPath, "server.js")}\"";

                // --- ВАРИАНТ ДЛЯ PYTHON (Раскомментируйте, если используете Python) ---
                // aiServerProcess.StartInfo.FileName = "python.exe";
                // aiServerProcess.StartInfo.Arguments = $"\"{Path.Combine(serverPath, "server.py")}\"";

                aiServerProcess.StartInfo.CreateNoWindow = true;
                aiServerProcess.StartInfo.UseShellExecute = false;
                aiServerProcess.Start();

                lblStatus.Text = "Локальный бесплатный ИИ-сервер активен на порту 8282";
            }
            catch
            {
                lblStatus.Text = "Ошибка запуска ИИ-сервера. Проверьте Node.js/Python в системе.";
            }
        }

        private void StopLocalAIServer()
        {
            if (aiServerProcess != null && !aiServerProcess.HasExited)
            {
                aiServerProcess.Kill();
            }
        }

        public void SaveConfig()
        {
            try
            {
                string[] lines = { Username, ServerIP, ServerPort, GameVersion };
                File.WriteAllLines(configPath, lines);
            }
            catch (Exception ex) { MessageBox.Show($"Ошибка конфига: {ex.Message}"); }
        }

        private void LoadConfig()
        {
            if (File.Exists(configPath))
            {
                try
                {
                    string[] lines = File.ReadAllLines(configPath);
                    if (lines.Length >= 4)
                    {
                        Username = lines[0];
                        ServerIP = lines[1];
                        ServerPort = lines[2];
                        GameVersion = lines[3];
                    }
                }
                catch { SaveConfig(); }
            }
            else { SaveConfig(); }
        }

        private async void btnLaunchGame_Click(object sender, EventArgs e)
        {
            btnLaunchGame.Enabled = false;
            btnOpenAdmin.Enabled = false;
            lblStatus.Text = $"Запуск Minecraft {GameVersion}...";

            try
            {
                var gamePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "AIMinecraftBot");
                var path = new MinecraftPath(gamePath);
                var launcher = new MinecraftLauncher(path);

                launcher.FileProgressChanged += (s, eArgs) =>
                {
                    Invoke(new Action(() => { lblStatus.Text = $"[Загрузка] {eArgs.Name}"; }));
                };

                var session = MSession.CreateOfflineSession(Username);
                var launchOption = new MLaunchOption
                {
                    Session = session,
                    ServerIp = ServerIP,
                    ServerPort = int.Parse(ServerPort),
                    MaximumRamMb = 2048
                };

                var process = await launcher.InstallAndBuildProcessAsync(GameVersion, launchOption);
                lblStatus.Text = "Игра запущена! Мод связывается с сервером 8282.";
                process.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка запуска: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnLaunchGame.Enabled = true;
                btnOpenAdmin.Enabled = true;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            StopLocalAIServer(); // Закрываем ИИ-сервер вместе с лаунчером
            base.OnFormClosing(e);
        }
    }
}
